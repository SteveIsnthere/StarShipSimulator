import { C as e, F as t, R as n, _ as r, at as i, it as a, nt as o, tt as s, v as c } from "./Geometry-CYPxRocb.js";
import "./init-Dz7_hNy6.js";
import "./init--pTYeZJt.js";
//#region node_modules/pixi.js/lib/dom/CanvasObserver.mjs
var l = class {
	constructor(e) {
		this._lastTransform = "", this._observer = null, this._tickerAttached = !1, this.updateTranslation = () => {
			if (!this._canvas) return;
			let e = this._canvas.getBoundingClientRect(), t = this._canvas.width, n = this._canvas.height, r = e.width / t * this._renderer.resolution, i = e.height / n * this._renderer.resolution, a = `translate(${e.left}px, ${e.top}px) scale(${r}, ${i})`;
			a !== this._lastTransform && (this._domElement.style.transform = a, this._lastTransform = a);
		}, this._domElement = e.domElement, this._renderer = e.renderer, !(globalThis.OffscreenCanvas && this._renderer.canvas instanceof OffscreenCanvas) && (this._canvas = this._renderer.canvas, this._attachObserver());
	}
	get canvas() {
		return this._canvas;
	}
	ensureAttached() {
		!this._domElement.parentNode && this._canvas.parentNode && (this._canvas.parentNode.appendChild(this._domElement), this.updateTranslation());
	}
	_attachObserver() {
		"ResizeObserver" in globalThis ? (this._observer &&= (this._observer.disconnect(), null), this._observer = new ResizeObserver((e) => {
			for (let t of e) {
				if (t.target !== this._canvas) continue;
				let e = this.canvas.width, n = this.canvas.height, r = t.contentRect.width / e * this._renderer.resolution, i = t.contentRect.height / n * this._renderer.resolution;
				(this._lastScaleX !== r || this._lastScaleY !== i) && (this.updateTranslation(), this._lastScaleX = r, this._lastScaleY = i);
			}
		}), this._observer.observe(this._canvas)) : this._tickerAttached || r.shared.add(this.updateTranslation, this, c.HIGH);
	}
	destroy() {
		this._observer ? (this._observer.disconnect(), this._observer = null) : this._tickerAttached && r.shared.remove(this.updateTranslation), this._domElement = null, this._renderer = null, this._canvas = null, this._tickerAttached = !1, this._lastTransform = "", this._lastScaleX = null, this._lastScaleY = null;
	}
}, u = class e {
	constructor(t) {
		this.bubbles = !0, this.cancelBubble = !0, this.cancelable = !1, this.composed = !1, this.defaultPrevented = !1, this.eventPhase = e.prototype.NONE, this.propagationStopped = !1, this.propagationImmediatelyStopped = !1, this.layer = new s(), this.page = new s(), this.NONE = 0, this.CAPTURING_PHASE = 1, this.AT_TARGET = 2, this.BUBBLING_PHASE = 3, this.manager = t;
	}
	get layerX() {
		return this.layer.x;
	}
	get layerY() {
		return this.layer.y;
	}
	get pageX() {
		return this.page.x;
	}
	get pageY() {
		return this.page.y;
	}
	get data() {
		return this;
	}
	composedPath() {
		return this.manager && (!this.path || this.path[this.path.length - 1] !== this.target) && (this.path = this.target ? this.manager.propagationPath(this.target) : []), this.path;
	}
	initEvent(e, t, n) {
		throw Error("initEvent() is a legacy DOM API. It is not implemented in the Federated Events API.");
	}
	initUIEvent(e, t, n, r, i) {
		throw Error("initUIEvent() is a legacy DOM API. It is not implemented in the Federated Events API.");
	}
	preventDefault() {
		this.nativeEvent instanceof Event && this.nativeEvent.cancelable && this.nativeEvent.preventDefault(), this.defaultPrevented = !0;
	}
	stopImmediatePropagation() {
		this.propagationImmediatelyStopped = !0;
	}
	stopPropagation() {
		this.propagationStopped = !0;
	}
}, d = /iPhone/i, f = /iPod/i, p = /iPad/i, m = /\biOS-universal(?:.+)Mac\b/i, h = /\bAndroid(?:.+)Mobile\b/i, g = /Android/i, _ = /(?:SD4930UR|\bSilk(?:.+)Mobile\b)/i, v = /Silk/i, y = /Windows Phone/i, b = /\bWindows(?:.+)ARM\b/i, x = /BlackBerry/i, S = /BB10/i, C = /Opera Mini/i, w = /\b(CriOS|Chrome)(?:.+)Mobile/i, T = /Mobile(?:.+)Firefox\b/i, E = function(e) {
	return e !== void 0 && e.platform === "MacIntel" && typeof e.maxTouchPoints == "number" && e.maxTouchPoints > 1 && typeof MSStream > "u";
};
function D(e) {
	return function(t) {
		return t.test(e);
	};
}
function O(e) {
	var t = {
		userAgent: "",
		platform: "",
		maxTouchPoints: 0
	};
	!e && typeof navigator < "u" ? t = {
		userAgent: navigator.userAgent,
		platform: navigator.platform,
		maxTouchPoints: navigator.maxTouchPoints || 0
	} : typeof e == "string" ? t.userAgent = e : e && e.userAgent && (t = {
		userAgent: e.userAgent,
		platform: e.platform,
		maxTouchPoints: e.maxTouchPoints || 0
	});
	var n = t.userAgent, r = n.split("[FBAN");
	r[1] !== void 0 && (n = r[0]), r = n.split("Twitter"), r[1] !== void 0 && (n = r[0]);
	var i = D(n), a = {
		apple: {
			phone: i(d) && !i(y),
			ipod: i(f),
			tablet: !i(d) && (i(p) || E(t)) && !i(y),
			universal: i(m),
			device: (i(d) || i(f) || i(p) || i(m) || E(t)) && !i(y)
		},
		amazon: {
			phone: i(_),
			tablet: !i(_) && i(v),
			device: i(_) || i(v)
		},
		android: {
			phone: !i(y) && i(_) || !i(y) && i(h),
			tablet: !i(y) && !i(_) && !i(h) && (i(v) || i(g)),
			device: !i(y) && (i(_) || i(v) || i(h) || i(g)) || i(/\bokhttp\b/i)
		},
		windows: {
			phone: i(y),
			tablet: i(b),
			device: i(y) || i(b)
		},
		other: {
			blackberry: i(x),
			blackberry10: i(S),
			opera: i(C),
			firefox: i(T),
			chrome: i(w),
			device: i(x) || i(S) || i(C) || i(T) || i(w)
		},
		any: !1,
		phone: !1,
		tablet: !1
	};
	return a.any = a.apple.device || a.android.device || a.windows.device || a.other.device, a.phone = a.apple.phone || a.android.phone || a.windows.phone, a.tablet = a.apple.tablet || a.android.tablet || a.windows.tablet, a;
}
//#endregion
//#region node_modules/pixi.js/lib/utils/browser/isMobile.mjs
var k = (O.default ?? O)(globalThis.navigator), A = 9, j = 100, M = 0, N = 0, P = 2, F = 1, I = -1e3, L = -1e3, R = 2, z = class e {
	constructor(e, t = k) {
		this._mobileInfo = t, this.debug = !1, this._activateOnTab = !0, this._deactivateOnMouseMove = !0, this._isActive = !1, this._isMobileAccessibility = !1, this._div = null, this._pools = {}, this._renderId = 0, this._children = [], this._androidUpdateCount = 0, this._androidUpdateFrequency = 500, this._isRunningTests = !1, this._boundOnKeyDown = this._onKeyDown.bind(this), this._boundOnMouseMove = this._onMouseMove.bind(this), this._hookDiv = null, (t.tablet || t.phone) && this._createTouchHook(), this._renderer = e;
	}
	get isActive() {
		return this._isActive;
	}
	get isMobileAccessibility() {
		return this._isMobileAccessibility;
	}
	get hookDiv() {
		return this._hookDiv;
	}
	get div() {
		return this._div;
	}
	_createTouchHook() {
		let e = document.createElement("button");
		e.style.width = `${F}px`, e.style.height = `${F}px`, e.style.position = "absolute", e.style.top = `${I}px`, e.style.left = `${L}px`, e.style.zIndex = R.toString(), e.style.backgroundColor = "#FF0000", e.title = "select to enable accessibility for this content", e.addEventListener("focus", () => {
			this._isMobileAccessibility = !0, this._activate(), this._destroyTouchHook();
		}), document.body.appendChild(e), this._hookDiv = e;
	}
	_destroyTouchHook() {
		this._hookDiv &&= (document.body.removeChild(this._hookDiv), null);
	}
	_activate() {
		if (this._isActive) return;
		this._isActive = !0, this._div || (this._div = document.createElement("div"), this._div.style.position = "absolute", this._div.style.top = `${M}px`, this._div.style.left = `${N}px`, this._div.style.pointerEvents = "none", this._div.style.zIndex = P.toString(), this._canvasObserver = new l({
			domElement: this._div,
			renderer: this._renderer
		})), this._activateOnTab && globalThis.addEventListener("keydown", this._boundOnKeyDown, !1), this._deactivateOnMouseMove && globalThis.document.addEventListener("mousemove", this._boundOnMouseMove, !0);
		let e = this._renderer.view.canvas;
		if (e.parentNode) this._canvasObserver.ensureAttached(), this._initAccessibilitySetup();
		else {
			let t = new MutationObserver(() => {
				e.parentNode && (t.disconnect(), this._canvasObserver.ensureAttached(), this._initAccessibilitySetup());
			});
			t.observe(document.body, {
				childList: !0,
				subtree: !0
			});
		}
	}
	_initAccessibilitySetup() {
		this._renderer.runners.postrender.add(this), this._renderer.lastObjectRendered && this._updateAccessibleObjects(this._renderer.lastObjectRendered);
	}
	_deactivate() {
		if (!(!this._isActive || this._isMobileAccessibility)) {
			this._isActive = !1, globalThis.document.removeEventListener("mousemove", this._boundOnMouseMove, !0), this._activateOnTab && globalThis.addEventListener("keydown", this._boundOnKeyDown, !1), this._renderer.runners.postrender.remove(this);
			for (let e of this._children) e._accessibleDiv?.parentNode && (e._accessibleDiv.parentNode.removeChild(e._accessibleDiv), e._accessibleDiv = null), e._accessibleActive = !1;
			for (let e in this._pools) this._pools[e].forEach((e) => {
				e.parentNode && e.parentNode.removeChild(e);
			}), delete this._pools[e];
			this._div?.parentNode && this._div.parentNode.removeChild(this._div), this._pools = {}, this._children = [];
		}
	}
	_updateAccessibleObjects(e) {
		if (!e.visible || !e.accessibleChildren) return;
		e.accessible && (e._accessibleActive || this._addChild(e), e._renderId = this._renderId);
		let t = e.children;
		if (t) for (let e = 0; e < t.length; e++) this._updateAccessibleObjects(t[e]);
	}
	init(t) {
		let n = { accessibilityOptions: {
			...e.defaultOptions,
			...t?.accessibilityOptions || {}
		} };
		this.debug = n.accessibilityOptions.debug, this._activateOnTab = n.accessibilityOptions.activateOnTab, this._deactivateOnMouseMove = n.accessibilityOptions.deactivateOnMouseMove, n.accessibilityOptions.enabledByDefault && this._activate(), this._renderer.runners.postrender.remove(this);
	}
	postrender() {
		let e = performance.now();
		if (this._mobileInfo.android.device && e < this._androidUpdateCount || (this._androidUpdateCount = e + this._androidUpdateFrequency, (!this._renderer.renderingToScreen || !this._renderer.view.canvas) && !this._isRunningTests)) return;
		let n = /* @__PURE__ */ new Set();
		if (this._renderer.lastObjectRendered) {
			this._updateAccessibleObjects(this._renderer.lastObjectRendered);
			for (let e of this._children) e._renderId === this._renderId && n.add(this._children.indexOf(e));
		}
		for (let e = this._children.length - 1; e >= 0; e--) {
			let r = this._children[e];
			n.has(e) || (r._accessibleDiv && r._accessibleDiv.parentNode && (r._accessibleDiv.parentNode.removeChild(r._accessibleDiv), this._getPool(r.accessibleType).push(r._accessibleDiv), r._accessibleDiv = null), r._accessibleActive = !1, t(this._children, e, 1));
		}
		this._renderer.renderingToScreen && this._canvasObserver.ensureAttached();
		for (let e = 0; e < this._children.length; e++) {
			let t = this._children[e];
			if (!t._accessibleActive || !t._accessibleDiv) continue;
			let n = t._accessibleDiv, r = t.hitArea || t.getBounds().rectangle;
			if (t.hitArea) {
				let e = t.worldTransform;
				n.style.left = `${e.tx + r.x * e.a}px`, n.style.top = `${e.ty + r.y * e.d}px`, n.style.width = `${r.width * e.a}px`, n.style.height = `${r.height * e.d}px`;
			} else this._capHitArea(r), n.style.left = `${r.x}px`, n.style.top = `${r.y}px`, n.style.width = `${r.width}px`, n.style.height = `${r.height}px`;
		}
		this._renderId++;
	}
	_updateDebugHTML(e) {
		e.innerHTML = `type: ${e.type}</br> title : ${e.title}</br> tabIndex: ${e.tabIndex}`;
	}
	_capHitArea(e) {
		e.x < 0 && (e.width += e.x, e.x = 0), e.y < 0 && (e.height += e.y, e.y = 0);
		let { width: t, height: n } = this._renderer;
		e.x + e.width > t && (e.width = t - e.x), e.y + e.height > n && (e.height = n - e.y);
	}
	_addChild(e) {
		let t = this._getPool(e.accessibleType).pop();
		t ? (t.innerHTML = "", t.removeAttribute("title"), t.removeAttribute("aria-label"), t.tabIndex = 0) : (e.accessibleType === "button" ? t = document.createElement("button") : (t = document.createElement(e.accessibleType), t.style.cssText = "\n                        color: transparent;\n                        pointer-events: none;\n                        padding: 0;\n                        margin: 0;\n                        border: 0;\n                        outline: 0;\n                        background: transparent;\n                        box-sizing: border-box;\n                        user-select: none;\n                        -webkit-user-select: none;\n                        -moz-user-select: none;\n                        -ms-user-select: none;\n                    ", e.accessibleText && (t.innerText = e.accessibleText)), t.style.width = `${j}px`, t.style.height = `${j}px`, t.style.backgroundColor = this.debug ? "rgba(255,255,255,0.5)" : "transparent", t.style.position = "absolute", t.style.zIndex = P.toString(), t.style.borderStyle = "none", navigator.userAgent.toLowerCase().includes("chrome") ? t.setAttribute("aria-live", "off") : t.setAttribute("aria-live", "polite"), navigator.userAgent.match(/rv:.*Gecko\//) ? t.setAttribute("aria-relevant", "additions") : t.setAttribute("aria-relevant", "text"), t.addEventListener("click", this._onClick.bind(this)), t.addEventListener("focus", this._onFocus.bind(this)), t.addEventListener("focusout", this._onFocusOut.bind(this))), t.style.pointerEvents = e.accessiblePointerEvents, t.type = e.accessibleType, e.accessibleTitle && e.accessibleTitle !== null ? t.title = e.accessibleTitle : (!e.accessibleHint || e.accessibleHint === null) && (t.title = `container ${e.tabIndex}`), e.accessibleHint && e.accessibleHint !== null && t.setAttribute("aria-label", e.accessibleHint), e.interactive ? t.tabIndex = e.tabIndex : t.tabIndex = 0, this.debug && this._updateDebugHTML(t), e._accessibleActive = !0, e._accessibleDiv = t, t.container = e, this._children.push(e), this._div.appendChild(e._accessibleDiv);
	}
	_dispatchEvent(e, t) {
		let { container: n } = e.target, r = this._renderer.events.rootBoundary, i = Object.assign(new u(r), { target: n });
		r.rootTarget = this._renderer.lastObjectRendered, t.forEach((e) => r.dispatchEvent(i, e));
	}
	_onClick(e) {
		this._dispatchEvent(e, [
			"click",
			"pointertap",
			"tap"
		]);
	}
	_onFocus(e) {
		e.target.getAttribute("aria-live") || e.target.setAttribute("aria-live", "assertive"), this._dispatchEvent(e, ["mouseover"]);
	}
	_onFocusOut(e) {
		e.target.getAttribute("aria-live") || e.target.setAttribute("aria-live", "polite"), this._dispatchEvent(e, ["mouseout"]);
	}
	_onKeyDown(e) {
		e.keyCode !== A || !this._activateOnTab || this._activate();
	}
	_onMouseMove(e) {
		(e.movementX !== 0 || e.movementY !== 0) && this._deactivate();
	}
	destroy() {
		this._deactivate(), this._destroyTouchHook(), this._canvasObserver?.destroy(), this._canvasObserver = null, this._div = null, this._pools = null, this._children = null, this._renderer = null, this._hookDiv = null, globalThis.removeEventListener("keydown", this._boundOnKeyDown), this._boundOnKeyDown = null, globalThis.document.removeEventListener("mousemove", this._boundOnMouseMove, !0), this._boundOnMouseMove = null;
	}
	setAccessibilityEnabled(e) {
		e ? this._activate() : this._deactivate();
	}
	_getPool(e) {
		return this._pools[e] || (this._pools[e] = []), this._pools[e];
	}
};
z.extension = {
	type: [a.WebGLSystem, a.WebGPUSystem],
	name: "accessibility"
}, z.defaultOptions = {
	enabledByDefault: !1,
	debug: !1,
	activateOnTab: !0,
	deactivateOnMouseMove: !0
};
var B = z, V = {
	accessible: !1,
	accessibleTitle: null,
	accessibleHint: null,
	tabIndex: 0,
	accessibleType: "button",
	accessibleText: null,
	accessiblePointerEvents: "auto",
	accessibleChildren: !0,
	_accessibleActive: !1,
	_accessibleDiv: null,
	_renderId: -1
}, H = class {
	constructor(e) {
		this._attachedDomElements = [], this._renderer = e, this._renderer.runners.postrender.add(this), this._renderer.runners.init.add(this), this._domElement = document.createElement("div"), this._domElement.style.position = "absolute", this._domElement.style.top = "0", this._domElement.style.left = "0", this._domElement.style.pointerEvents = "none", this._domElement.style.zIndex = "1000";
	}
	init() {
		this._canvasObserver = new l({
			domElement: this._domElement,
			renderer: this._renderer
		});
	}
	addRenderable(e, t) {
		this._attachedDomElements.includes(e) || this._attachedDomElements.push(e);
	}
	updateRenderable(e) {}
	validateRenderable(e) {
		return !0;
	}
	postrender() {
		let e = this._attachedDomElements;
		if (e.length === 0) {
			this._domElement.remove();
			return;
		}
		this._canvasObserver.ensureAttached();
		for (let t = 0; t < e.length; t++) {
			let n = e[t], r = n.element;
			if (!n.parent || n.globalDisplayStatus < 7) r?.remove(), e.splice(t, 1), t--;
			else {
				this._domElement.contains(r) || (r.style.position = "absolute", r.style.pointerEvents = "auto", this._domElement.appendChild(r));
				let e = n.worldTransform, t = n._anchor, i = n.width * t.x, a = n.height * t.y;
				r.style.transformOrigin = `${i}px ${a}px`, r.style.transform = `matrix(${e.a}, ${e.b}, ${e.c}, ${e.d}, ${e.tx - i}, ${e.ty - a})`, r.style.opacity = n.groupAlpha.toString();
			}
		}
	}
	destroy() {
		this._renderer.runners.postrender.remove(this);
		for (let e = 0; e < this._attachedDomElements.length; e++) this._attachedDomElements[e].element?.remove();
		this._attachedDomElements.length = 0, this._domElement.remove(), this._canvasObserver.destroy(), this._renderer = null;
	}
};
H.extension = {
	type: [
		a.WebGLPipes,
		a.WebGPUPipes,
		a.CanvasPipes
	],
	name: "dom"
};
var U = new class {
	constructor() {
		this.interactionFrequency = 10, this._deltaTime = 0, this._didMove = !1, this._tickerAdded = !1, this._pauseUpdate = !0;
	}
	init(e) {
		this.removeTickerListener(), this.events = e, this.interactionFrequency = 10, this._deltaTime = 0, this._didMove = !1, this._tickerAdded = !1, this._pauseUpdate = !0;
	}
	get pauseUpdate() {
		return this._pauseUpdate;
	}
	set pauseUpdate(e) {
		this._pauseUpdate = e;
	}
	addTickerListener() {
		this._tickerAdded || !this.domElement || (r.system.add(this._tickerUpdate, this, c.INTERACTION), this._tickerAdded = !0);
	}
	removeTickerListener() {
		this._tickerAdded &&= (r.system.remove(this._tickerUpdate, this), !1);
	}
	pointerMoved() {
		this._didMove = !0;
	}
	_update() {
		if (!this.domElement || this._pauseUpdate) return;
		if (this._didMove) {
			this._didMove = !1;
			return;
		}
		let e = this.events._rootPointerEvent;
		this.events.supportsTouchEvents && e.pointerType === "touch" || globalThis.document.dispatchEvent(this.events.supportsPointerEvents ? new PointerEvent("pointermove", {
			clientX: e.clientX,
			clientY: e.clientY,
			pointerType: e.pointerType,
			pointerId: e.pointerId
		}) : new MouseEvent("mousemove", {
			clientX: e.clientX,
			clientY: e.clientY
		}));
	}
	_tickerUpdate(e) {
		this._deltaTime += e.deltaTime, !(this._deltaTime < this.interactionFrequency) && (this._deltaTime = 0, this._update());
	}
	destroy() {
		this.removeTickerListener(), this.events = null, this.domElement = null, this._deltaTime = 0, this._didMove = !1, this._tickerAdded = !1, this._pauseUpdate = !0;
	}
}(), W = class extends u {
	constructor() {
		super(...arguments), this.client = new s(), this.movement = new s(), this.offset = new s(), this.global = new s(), this.screen = new s();
	}
	get clientX() {
		return this.client.x;
	}
	get clientY() {
		return this.client.y;
	}
	get x() {
		return this.clientX;
	}
	get y() {
		return this.clientY;
	}
	get movementX() {
		return this.movement.x;
	}
	get movementY() {
		return this.movement.y;
	}
	get offsetX() {
		return this.offset.x;
	}
	get offsetY() {
		return this.offset.y;
	}
	get globalX() {
		return this.global.x;
	}
	get globalY() {
		return this.global.y;
	}
	get screenX() {
		return this.screen.x;
	}
	get screenY() {
		return this.screen.y;
	}
	getLocalPosition(e, t, n) {
		return e.worldTransform.applyInverse(n || this.global, t);
	}
	getModifierState(e) {
		return "getModifierState" in this.nativeEvent && this.nativeEvent.getModifierState(e);
	}
	initMouseEvent(e, t, n, r, i, a, o, s, c, l, u, d, f, p, m) {
		throw Error("Method not implemented.");
	}
}, G = class extends W {
	constructor() {
		super(...arguments), this.width = 0, this.height = 0, this.isPrimary = !1, this.persistentDeviceId = 0;
	}
	getCoalescedEvents() {
		return this.type === "pointermove" || this.type === "mousemove" || this.type === "touchmove" ? [this] : [];
	}
	getPredictedEvents() {
		throw Error("getPredictedEvents is not supported!");
	}
}, K = class extends W {
	constructor() {
		super(...arguments), this.DOM_DELTA_PIXEL = 0, this.DOM_DELTA_LINE = 1, this.DOM_DELTA_PAGE = 2;
	}
};
K.DOM_DELTA_PIXEL = 0, K.DOM_DELTA_LINE = 1, K.DOM_DELTA_PAGE = 2;
//#endregion
//#region node_modules/pixi.js/lib/events/EventBoundary.mjs
var q = 2048, J = new s(), Y = new s(), X = class {
	constructor(e) {
		this.dispatch = new o(), this.moveOnAll = !1, this.enableGlobalMoveEvents = !0, this.mappingState = { trackingData: {} }, this.eventPool = /* @__PURE__ */ new Map(), this._allInteractiveElements = [], this._hitElements = [], this._isPointerMoveEvent = !1, this.rootTarget = e, this.hitPruneFn = this.hitPruneFn.bind(this), this.hitTestFn = this.hitTestFn.bind(this), this.mapPointerDown = this.mapPointerDown.bind(this), this.mapPointerMove = this.mapPointerMove.bind(this), this.mapPointerOut = this.mapPointerOut.bind(this), this.mapPointerOver = this.mapPointerOver.bind(this), this.mapPointerUp = this.mapPointerUp.bind(this), this.mapPointerUpOutside = this.mapPointerUpOutside.bind(this), this.mapWheel = this.mapWheel.bind(this), this.mappingTable = {}, this.addEventMapping("pointerdown", this.mapPointerDown), this.addEventMapping("pointermove", this.mapPointerMove), this.addEventMapping("pointerout", this.mapPointerOut), this.addEventMapping("pointerleave", this.mapPointerOut), this.addEventMapping("pointerover", this.mapPointerOver), this.addEventMapping("pointerup", this.mapPointerUp), this.addEventMapping("pointerupoutside", this.mapPointerUpOutside), this.addEventMapping("wheel", this.mapWheel);
	}
	addEventMapping(e, t) {
		this.mappingTable[e] || (this.mappingTable[e] = []), this.mappingTable[e].push({
			fn: t,
			priority: 0
		}), this.mappingTable[e].sort((e, t) => e.priority - t.priority);
	}
	dispatchEvent(e, t) {
		e.propagationStopped = !1, e.propagationImmediatelyStopped = !1, this.propagate(e, t), this.dispatch.emit(t || e.type, e);
	}
	mapEvent(e) {
		if (!this.rootTarget) return;
		let t = this.mappingTable[e.type];
		if (t) for (let n = 0, r = t.length; n < r; n++) t[n].fn(e);
		else n(`[EventBoundary]: Event mapping not defined for ${e.type}`);
	}
	hitTest(e, t) {
		U.pauseUpdate = !0;
		let n = this._isPointerMoveEvent && this.enableGlobalMoveEvents ? "hitTestMoveRecursive" : "hitTestRecursive", r = this[n](this.rootTarget, this.rootTarget.eventMode, J.set(e, t), this.hitTestFn, this.hitPruneFn);
		return r && r[0];
	}
	propagate(e, t) {
		if (!e.target) return;
		let n = e.composedPath();
		e.eventPhase = e.CAPTURING_PHASE;
		for (let r = 0, i = n.length - 1; r < i; r++) if (e.currentTarget = n[r], this.notifyTarget(e, t), e.propagationStopped || e.propagationImmediatelyStopped) return;
		if (e.eventPhase = e.AT_TARGET, e.currentTarget = e.target, this.notifyTarget(e, t), !(e.propagationStopped || e.propagationImmediatelyStopped)) {
			e.eventPhase = e.BUBBLING_PHASE;
			for (let r = n.length - 2; r >= 0; r--) if (e.currentTarget = n[r], this.notifyTarget(e, t), e.propagationStopped || e.propagationImmediatelyStopped) return;
		}
	}
	all(e, t, n = this._allInteractiveElements) {
		if (n.length === 0) return;
		e.eventPhase = e.BUBBLING_PHASE;
		let r = Array.isArray(t) ? t : [t];
		for (let t = n.length - 1; t >= 0; t--) r.forEach((r) => {
			e.currentTarget = n[t], this.notifyTarget(e, r);
		});
	}
	propagationPath(e) {
		let t = [e];
		for (let n = 0; n < q && e !== this.rootTarget && e.parent; n++) {
			if (!e.parent) throw Error("Cannot find propagation path to disconnected target");
			t.push(e.parent), e = e.parent;
		}
		return t.reverse(), t;
	}
	hitTestMoveRecursive(e, t, n, r, i, a = !1) {
		let o = !1;
		if (this._interactivePrune(e)) return null;
		if ((e.eventMode === "dynamic" || t === "dynamic") && (U.pauseUpdate = !1), e.interactiveChildren && e.children) {
			let s = e.children;
			for (let c = s.length - 1; c >= 0; c--) {
				let l = s[c], u = this.hitTestMoveRecursive(l, this._isInteractive(t) ? t : l.eventMode, n, r, i, a || i(e, n));
				if (u) {
					if (u.length > 0 && !u[u.length - 1].parent) continue;
					let t = e.isInteractive();
					(u.length > 0 || t) && (t && this._allInteractiveElements.push(e), u.push(e)), this._hitElements.length === 0 && (this._hitElements = u), o = !0;
				}
			}
		}
		let s = this._isInteractive(t), c = e.isInteractive();
		return c && c && this._allInteractiveElements.push(e), a || this._hitElements.length > 0 ? null : o ? this._hitElements : s && !i(e, n) && r(e, n) ? c ? [e] : [] : null;
	}
	hitTestRecursive(e, t, n, r, i) {
		if (this._interactivePrune(e) || i(e, n)) return null;
		if ((e.eventMode === "dynamic" || t === "dynamic") && (U.pauseUpdate = !1), e.interactiveChildren && e.children) {
			let a = e.children, o = n;
			for (let n = a.length - 1; n >= 0; n--) {
				let s = a[n], c = this.hitTestRecursive(s, this._isInteractive(t) ? t : s.eventMode, o, r, i);
				if (c) {
					if (c.length > 0 && !c[c.length - 1].parent) continue;
					let t = e.isInteractive();
					return (c.length > 0 || t) && c.push(e), c;
				}
			}
		}
		let a = this._isInteractive(t), o = e.isInteractive();
		return a && r(e, n) ? o ? [e] : [] : null;
	}
	_isInteractive(e) {
		return e === "static" || e === "dynamic";
	}
	_interactivePrune(e) {
		return !e || !e.visible || !e.renderable || !e.measurable || e.eventMode === "none" || e.eventMode === "passive" && !e.interactiveChildren;
	}
	hitPruneFn(e, t) {
		if (e.hitArea && (e.worldTransform.applyInverse(t, Y), !e.hitArea.contains(Y.x, Y.y))) return !0;
		if (e.effects && e.effects.length) for (let n = 0; n < e.effects.length; n++) {
			let r = e.effects[n];
			if (r.containsPoint && !r.containsPoint(t, this.hitTestFn)) return !0;
		}
		return !1;
	}
	hitTestFn(e, t) {
		return e.hitArea ? !0 : e?.containsPoint ? (e.worldTransform.applyInverse(t, Y), e.containsPoint(Y)) : !1;
	}
	notifyTarget(e, t) {
		if (!e.currentTarget.isInteractive()) return;
		t ??= e.type;
		let n = `on${t}`;
		e.currentTarget[n]?.(e);
		let r = e.eventPhase === e.CAPTURING_PHASE || e.eventPhase === e.AT_TARGET ? `${t}capture` : t;
		this._notifyListeners(e, r), e.eventPhase === e.AT_TARGET && this._notifyListeners(e, t);
	}
	mapPointerDown(e) {
		if (!(e instanceof G)) {
			n("EventBoundary cannot map a non-pointer event as a pointer event");
			return;
		}
		let t = this.createPointerEvent(e);
		if (this.dispatchEvent(t, "pointerdown"), t.pointerType === "touch") this.dispatchEvent(t, "touchstart");
		else if (t.pointerType === "mouse" || t.pointerType === "pen") {
			let e = t.button === 2;
			this.dispatchEvent(t, e ? "rightdown" : "mousedown");
		}
		let r = this.trackingData(e.pointerId);
		r.pressTargetsByButton[e.button] = t.composedPath(), this.freeEvent(t);
	}
	mapPointerMove(e) {
		if (!(e instanceof G)) {
			n("EventBoundary cannot map a non-pointer event as a pointer event");
			return;
		}
		this._allInteractiveElements.length = 0, this._hitElements.length = 0, this._isPointerMoveEvent = !0;
		let t = this.createPointerEvent(e);
		this._isPointerMoveEvent = !1;
		let r = t.pointerType === "mouse" || t.pointerType === "pen", i = this.trackingData(e.pointerId), a = this.findMountedTarget(i.overTargets);
		if (i.overTargets?.length > 0 && a !== t.target) {
			let n = e.type === "mousemove" ? "mouseout" : "pointerout", i = this.createPointerEvent(e, n, a);
			if (this.dispatchEvent(i, "pointerout"), r && this.dispatchEvent(i, "mouseout"), !t.composedPath().includes(a)) {
				let n = this.createPointerEvent(e, "pointerleave", a);
				for (n.eventPhase = n.AT_TARGET; n.target && !t.composedPath().includes(n.target);) n.currentTarget = n.target, this.notifyTarget(n), r && this.notifyTarget(n, "mouseleave"), n.target = n.target.parent;
				this.freeEvent(n);
			}
			this.freeEvent(i);
		}
		if (a !== t.target) {
			let n = e.type === "mousemove" ? "mouseover" : "pointerover", i = this.clonePointerEvent(t, n);
			this.dispatchEvent(i, "pointerover"), r && this.dispatchEvent(i, "mouseover");
			let o = a?.parent;
			for (; o && o !== this.rootTarget.parent && o !== t.target;) o = o.parent;
			if (!o || o === this.rootTarget.parent) {
				let e = this.clonePointerEvent(t, "pointerenter");
				for (e.eventPhase = e.AT_TARGET; e.target && e.target !== a && e.target !== this.rootTarget.parent;) e.currentTarget = e.target, this.notifyTarget(e), r && this.notifyTarget(e, "mouseenter"), e.target = e.target.parent;
				this.freeEvent(e);
			}
			this.freeEvent(i);
		}
		let o = [], s = this.enableGlobalMoveEvents ?? !0;
		this.moveOnAll ? o.push("pointermove") : this.dispatchEvent(t, "pointermove"), s && o.push("globalpointermove"), t.pointerType === "touch" && (this.moveOnAll ? o.splice(1, 0, "touchmove") : this.dispatchEvent(t, "touchmove"), s && o.push("globaltouchmove")), r && (this.moveOnAll ? o.splice(1, 0, "mousemove") : this.dispatchEvent(t, "mousemove"), s && o.push("globalmousemove"), this.cursor = t.target?.cursor), o.length > 0 && this.all(t, o), this._allInteractiveElements.length = 0, this._hitElements.length = 0, i.overTargets = t.composedPath(), this.freeEvent(t);
	}
	mapPointerOver(e) {
		if (!(e instanceof G)) {
			n("EventBoundary cannot map a non-pointer event as a pointer event");
			return;
		}
		let t = this.trackingData(e.pointerId), r = this.createPointerEvent(e), i = r.pointerType === "mouse" || r.pointerType === "pen";
		this.dispatchEvent(r, "pointerover"), i && this.dispatchEvent(r, "mouseover"), r.pointerType === "mouse" && (this.cursor = r.target?.cursor);
		let a = this.clonePointerEvent(r, "pointerenter");
		for (a.eventPhase = a.AT_TARGET; a.target && a.target !== this.rootTarget.parent;) a.currentTarget = a.target, this.notifyTarget(a), i && this.notifyTarget(a, "mouseenter"), a.target = a.target.parent;
		t.overTargets = r.composedPath(), this.freeEvent(r), this.freeEvent(a);
	}
	mapPointerOut(e) {
		if (!(e instanceof G)) {
			n("EventBoundary cannot map a non-pointer event as a pointer event");
			return;
		}
		let t = this.trackingData(e.pointerId);
		if (t.overTargets) {
			let n = e.pointerType === "mouse" || e.pointerType === "pen", r = this.findMountedTarget(t.overTargets), i = this.createPointerEvent(e, "pointerout", r);
			this.dispatchEvent(i), n && this.dispatchEvent(i, "mouseout");
			let a = this.createPointerEvent(e, "pointerleave", r);
			for (a.eventPhase = a.AT_TARGET; a.target && a.target !== this.rootTarget.parent;) a.currentTarget = a.target, this.notifyTarget(a), n && this.notifyTarget(a, "mouseleave"), a.target = a.target.parent;
			t.overTargets = null, this.freeEvent(i), this.freeEvent(a);
		}
		this.cursor = null;
	}
	mapPointerUp(e) {
		if (!(e instanceof G)) {
			n("EventBoundary cannot map a non-pointer event as a pointer event");
			return;
		}
		let t = performance.now(), r = this.createPointerEvent(e);
		if (this.dispatchEvent(r, "pointerup"), r.pointerType === "touch") this.dispatchEvent(r, "touchend");
		else if (r.pointerType === "mouse" || r.pointerType === "pen") {
			let e = r.button === 2;
			this.dispatchEvent(r, e ? "rightup" : "mouseup");
		}
		let i = this.trackingData(e.pointerId), a = this.findMountedTarget(i.pressTargetsByButton[e.button]), o = a;
		if (a && !r.composedPath().includes(a)) {
			let t = a;
			for (; t && !r.composedPath().includes(t);) {
				if (r.currentTarget = t, this.notifyTarget(r, "pointerupoutside"), r.pointerType === "touch") this.notifyTarget(r, "touchendoutside");
				else if (r.pointerType === "mouse" || r.pointerType === "pen") {
					let e = r.button === 2;
					this.notifyTarget(r, e ? "rightupoutside" : "mouseupoutside");
				}
				t = t.parent;
			}
			delete i.pressTargetsByButton[e.button], o = t;
		}
		if (o) {
			let n = this.clonePointerEvent(r, "click");
			n.target = o, n.path = null, i.clicksByButton[e.button] || (i.clicksByButton[e.button] = {
				clickCount: 0,
				target: n.target,
				timeStamp: t
			});
			let a = i.clicksByButton[e.button];
			if (a.target === n.target && t - a.timeStamp < 200 ? ++a.clickCount : a.clickCount = 1, a.target = n.target, a.timeStamp = t, n.detail = a.clickCount, n.pointerType === "mouse") {
				let e = n.button === 2;
				this.dispatchEvent(n, e ? "rightclick" : "click");
			} else n.pointerType === "touch" && this.dispatchEvent(n, "tap");
			this.dispatchEvent(n, "pointertap"), this.freeEvent(n);
		}
		this.freeEvent(r);
	}
	mapPointerUpOutside(e) {
		if (!(e instanceof G)) {
			n("EventBoundary cannot map a non-pointer event as a pointer event");
			return;
		}
		let t = this.trackingData(e.pointerId), r = this.findMountedTarget(t.pressTargetsByButton[e.button]), i = this.createPointerEvent(e);
		if (r) {
			let n = r;
			for (; n;) i.currentTarget = n, this.notifyTarget(i, "pointerupoutside"), i.pointerType === "touch" ? this.notifyTarget(i, "touchendoutside") : (i.pointerType === "mouse" || i.pointerType === "pen") && this.notifyTarget(i, i.button === 2 ? "rightupoutside" : "mouseupoutside"), n = n.parent;
			delete t.pressTargetsByButton[e.button];
		}
		this.freeEvent(i);
	}
	mapWheel(e) {
		if (!(e instanceof K)) {
			n("EventBoundary cannot map a non-wheel event as a wheel event");
			return;
		}
		let t = this.createWheelEvent(e);
		this.dispatchEvent(t), this.freeEvent(t);
	}
	findMountedTarget(e) {
		if (!e) return null;
		let t = e[0];
		for (let n = 1; n < e.length && e[n].parent === t; n++) t = e[n];
		return t;
	}
	createPointerEvent(e, t, n) {
		let r = this.allocateEvent(G);
		return this.copyPointerData(e, r), this.copyMouseData(e, r), this.copyData(e, r), r.nativeEvent = e.nativeEvent, r.originalEvent = e, r.target = n ?? this.hitTest(r.global.x, r.global.y) ?? this._hitElements[0], typeof t == "string" && (r.type = t), r;
	}
	createWheelEvent(e) {
		let t = this.allocateEvent(K);
		return this.copyWheelData(e, t), this.copyMouseData(e, t), this.copyData(e, t), t.nativeEvent = e.nativeEvent, t.originalEvent = e, t.target = this.hitTest(t.global.x, t.global.y), t;
	}
	clonePointerEvent(e, t) {
		let n = this.allocateEvent(G);
		return n.nativeEvent = e.nativeEvent, n.originalEvent = e.originalEvent, this.copyPointerData(e, n), this.copyMouseData(e, n), this.copyData(e, n), n.target = e.target, n.path = e.composedPath().slice(), n.type = t ?? n.type, n;
	}
	copyWheelData(e, t) {
		t.deltaMode = e.deltaMode, t.deltaX = e.deltaX, t.deltaY = e.deltaY, t.deltaZ = e.deltaZ;
	}
	copyPointerData(e, t) {
		e instanceof G && t instanceof G && (t.pointerId = e.pointerId, t.width = e.width, t.height = e.height, t.isPrimary = e.isPrimary, t.pointerType = e.pointerType, t.pressure = e.pressure, t.tangentialPressure = e.tangentialPressure, t.tiltX = e.tiltX, t.tiltY = e.tiltY, t.twist = e.twist, t.persistentDeviceId = e.persistentDeviceId);
	}
	copyMouseData(e, t) {
		e instanceof W && t instanceof W && (t.altKey = e.altKey, t.button = e.button, t.buttons = e.buttons, t.client.copyFrom(e.client), t.ctrlKey = e.ctrlKey, t.metaKey = e.metaKey, t.movement.copyFrom(e.movement), t.screen.copyFrom(e.screen), t.shiftKey = e.shiftKey, t.global.copyFrom(e.global));
	}
	copyData(e, t) {
		t.isTrusted = e.isTrusted, t.srcElement = e.srcElement, t.timeStamp = performance.now(), t.type = e.type, t.detail = e.detail, t.view = e.view, t.which = e.which, t.layer.copyFrom(e.layer), t.page.copyFrom(e.page);
	}
	trackingData(e) {
		return this.mappingState.trackingData[e] || (this.mappingState.trackingData[e] = {
			pressTargetsByButton: {},
			clicksByButton: {},
			overTarget: null
		}), this.mappingState.trackingData[e];
	}
	allocateEvent(e) {
		this.eventPool.has(e) || this.eventPool.set(e, []);
		let t = this.eventPool.get(e).pop() || new e(this);
		return t.eventPhase = t.NONE, t.currentTarget = null, t.defaultPrevented = !1, t.path = null, t.target = null, t;
	}
	freeEvent(e) {
		if (e.manager !== this) throw Error("It is illegal to free an event not managed by this EventBoundary!");
		let t = e.constructor;
		this.eventPool.has(t) || this.eventPool.set(t, []), this.eventPool.get(t).push(e);
	}
	_notifyListeners(e, t) {
		let n = e.currentTarget._events[t];
		if (n) {
			if ("fn" in n) n.once && e.currentTarget.removeListener(t, n.fn, void 0, !0), n.fn.call(n.context, e);
			else for (let r = 0, i = n.length; r < i && !e.propagationImmediatelyStopped; r++) n[r].once && e.currentTarget.removeListener(t, n[r].fn, void 0, !0), n[r].fn.call(n[r].context, e);
		}
	}
}, Z = 1, ee = {
	touchstart: "pointerdown",
	touchend: "pointerup",
	touchendoutside: "pointerupoutside",
	touchmove: "pointermove",
	touchcancel: "pointercancel"
}, Q = class e {
	constructor(t) {
		this.supportsTouchEvents = "ontouchstart" in globalThis, this.supportsPointerEvents = !!globalThis.PointerEvent, this.domElement = null, this.resolution = 1, this.renderer = t, this.rootBoundary = new X(null), U.init(this), this.autoPreventDefault = !0, this._eventsAdded = !1, this._rootPointerEvent = new G(null), this._rootWheelEvent = new K(null), this.cursorStyles = {
			default: "inherit",
			pointer: "pointer"
		}, this.features = new Proxy({ ...e.defaultEventFeatures }, { set: (e, t, n) => (t === "globalMove" && (this.rootBoundary.enableGlobalMoveEvents = n), e[t] = n, !0) }), this._onPointerDown = this._onPointerDown.bind(this), this._onPointerMove = this._onPointerMove.bind(this), this._onPointerUp = this._onPointerUp.bind(this), this._onPointerOverOut = this._onPointerOverOut.bind(this), this.onWheel = this.onWheel.bind(this);
	}
	static get defaultEventMode() {
		return this._defaultEventMode;
	}
	init(t) {
		let { canvas: n, resolution: r } = this.renderer;
		this.setTargetElement(n), this.resolution = r, e._defaultEventMode = t.eventMode ?? "passive", Object.assign(this.features, t.eventFeatures ?? {}), this.rootBoundary.enableGlobalMoveEvents = this.features.globalMove;
	}
	resolutionChange(e) {
		this.resolution = e;
	}
	destroy() {
		U.destroy(), this.setTargetElement(null), this.renderer = null, this._currentCursor = null;
	}
	setCursor(e) {
		e ||= "default";
		let t = !0;
		if (globalThis.OffscreenCanvas && this.domElement instanceof OffscreenCanvas && (t = !1), this._currentCursor === e) return;
		this._currentCursor = e;
		let n = this.cursorStyles[e];
		if (n) switch (typeof n) {
			case "string":
				t && (this.domElement.style.cursor = n);
				break;
			case "function":
				n(e);
				break;
			case "object": t && Object.assign(this.domElement.style, n);
		}
		else t && typeof e == "string" && !Object.prototype.hasOwnProperty.call(this.cursorStyles, e) && (this.domElement.style.cursor = e);
	}
	get pointer() {
		return this._rootPointerEvent;
	}
	_onPointerDown(e) {
		if (!this.features.click) return;
		this.rootBoundary.rootTarget = this.renderer.lastObjectRendered;
		let t = this._normalizeToPointerData(e);
		this.autoPreventDefault && t[0].isNormalized && (e.cancelable || !("cancelable" in e)) && e.preventDefault();
		for (let e = 0, n = t.length; e < n; e++) {
			let n = t[e], r = this._bootstrapEvent(this._rootPointerEvent, n);
			this.rootBoundary.mapEvent(r);
		}
		this.setCursor(this.rootBoundary.cursor);
	}
	_onPointerMove(e) {
		if (!this.features.move) return;
		this.rootBoundary.rootTarget = this.renderer.lastObjectRendered, U.pointerMoved();
		let t = this._normalizeToPointerData(e);
		for (let e = 0, n = t.length; e < n; e++) {
			let n = this._bootstrapEvent(this._rootPointerEvent, t[e]);
			this.rootBoundary.mapEvent(n);
		}
		this.setCursor(this.rootBoundary.cursor);
	}
	_onPointerUp(e) {
		if (!this.features.click) return;
		this.rootBoundary.rootTarget = this.renderer.lastObjectRendered;
		let t = e.target;
		e.composedPath && e.composedPath().length > 0 && (t = e.composedPath()[0]);
		let n = t === this.domElement ? "" : "outside", r = this._normalizeToPointerData(e);
		for (let e = 0, t = r.length; e < t; e++) {
			let t = this._bootstrapEvent(this._rootPointerEvent, r[e]);
			t.type += n, this.rootBoundary.mapEvent(t);
		}
		this.setCursor(this.rootBoundary.cursor);
	}
	_onPointerOverOut(e) {
		if (!this.features.click) return;
		this.rootBoundary.rootTarget = this.renderer.lastObjectRendered;
		let t = this._normalizeToPointerData(e);
		for (let e = 0, n = t.length; e < n; e++) {
			let n = this._bootstrapEvent(this._rootPointerEvent, t[e]);
			this.rootBoundary.mapEvent(n);
		}
		this.setCursor(this.rootBoundary.cursor);
	}
	onWheel(e) {
		if (!this.features.wheel) return;
		let t = this.normalizeWheelEvent(e);
		this.rootBoundary.rootTarget = this.renderer.lastObjectRendered, this.rootBoundary.mapEvent(t);
	}
	setTargetElement(e) {
		this._removeEvents(), this.domElement = e, U.domElement = e, this._addEvents();
	}
	_addEvents() {
		if (this._eventsAdded || !this.domElement) return;
		U.addTickerListener();
		let e = this.domElement.style;
		e && (globalThis.navigator.msPointerEnabled ? (e.msContentZooming = "none", e.msTouchAction = "none") : this.supportsPointerEvents && (e.touchAction = "none")), this.supportsPointerEvents ? (globalThis.document.addEventListener("pointermove", this._onPointerMove, !0), this.domElement.addEventListener("pointerdown", this._onPointerDown, !0), this.domElement.addEventListener("pointerleave", this._onPointerOverOut, !0), this.domElement.addEventListener("pointerover", this._onPointerOverOut, !0), globalThis.addEventListener("pointerup", this._onPointerUp, !0)) : (globalThis.document.addEventListener("mousemove", this._onPointerMove, !0), this.domElement.addEventListener("mousedown", this._onPointerDown, !0), this.domElement.addEventListener("mouseout", this._onPointerOverOut, !0), this.domElement.addEventListener("mouseover", this._onPointerOverOut, !0), globalThis.addEventListener("mouseup", this._onPointerUp, !0), this.supportsTouchEvents && (this.domElement.addEventListener("touchstart", this._onPointerDown, !0), this.domElement.addEventListener("touchend", this._onPointerUp, !0), this.domElement.addEventListener("touchmove", this._onPointerMove, !0))), this.domElement.addEventListener("wheel", this.onWheel, {
			passive: !0,
			capture: !0
		}), this._eventsAdded = !0;
	}
	_removeEvents() {
		if (!this._eventsAdded || !this.domElement) return;
		U.removeTickerListener();
		let e = this.domElement.style;
		e && (globalThis.navigator.msPointerEnabled ? (e.msContentZooming = "", e.msTouchAction = "") : this.supportsPointerEvents && (e.touchAction = "")), this.supportsPointerEvents ? (globalThis.document.removeEventListener("pointermove", this._onPointerMove, !0), this.domElement.removeEventListener("pointerdown", this._onPointerDown, !0), this.domElement.removeEventListener("pointerleave", this._onPointerOverOut, !0), this.domElement.removeEventListener("pointerover", this._onPointerOverOut, !0), globalThis.removeEventListener("pointerup", this._onPointerUp, !0)) : (globalThis.document.removeEventListener("mousemove", this._onPointerMove, !0), this.domElement.removeEventListener("mousedown", this._onPointerDown, !0), this.domElement.removeEventListener("mouseout", this._onPointerOverOut, !0), this.domElement.removeEventListener("mouseover", this._onPointerOverOut, !0), globalThis.removeEventListener("mouseup", this._onPointerUp, !0), this.supportsTouchEvents && (this.domElement.removeEventListener("touchstart", this._onPointerDown, !0), this.domElement.removeEventListener("touchend", this._onPointerUp, !0), this.domElement.removeEventListener("touchmove", this._onPointerMove, !0))), this.domElement.removeEventListener("wheel", this.onWheel, !0), this.domElement = null, this._eventsAdded = !1;
	}
	mapPositionToPoint(e, t, n) {
		let r = this.domElement.isConnected ? this.domElement.getBoundingClientRect() : {
			x: 0,
			y: 0,
			width: this.domElement.width,
			height: this.domElement.height,
			left: 0,
			top: 0
		}, i = 1 / this.resolution;
		e.x = (t - r.left) * (this.domElement.width / r.width) * i, e.y = (n - r.top) * (this.domElement.height / r.height) * i;
	}
	_normalizeToPointerData(e) {
		let t = [];
		if (this.supportsTouchEvents && e instanceof TouchEvent) for (let n = 0, r = e.changedTouches.length; n < r; n++) {
			let r = e.changedTouches[n];
			r.button === void 0 && (r.button = 0), r.buttons === void 0 && (r.buttons = 1), r.isPrimary === void 0 && (r.isPrimary = e.touches.length === 1 && e.type === "touchstart"), r.width === void 0 && (r.width = r.radiusX || 1), r.height === void 0 && (r.height = r.radiusY || 1), r.tiltX === void 0 && (r.tiltX = 0), r.tiltY === void 0 && (r.tiltY = 0), r.pointerType === void 0 && (r.pointerType = "touch"), r.pointerId === void 0 && (r.pointerId = r.identifier || 0), r.pressure === void 0 && (r.pressure = r.force || .5), r.twist === void 0 && (r.twist = 0), r.tangentialPressure === void 0 && (r.tangentialPressure = 0), r.layerX === void 0 && (r.layerX = r.offsetX = r.clientX), r.layerY === void 0 && (r.layerY = r.offsetY = r.clientY), r.isNormalized = !0, r.type = e.type, r.altKey ??= e.altKey, r.ctrlKey ??= e.ctrlKey, r.metaKey ??= e.metaKey, r.shiftKey ??= e.shiftKey, t.push(r);
		}
		else if (!globalThis.MouseEvent || e instanceof MouseEvent && (!this.supportsPointerEvents || !(e instanceof globalThis.PointerEvent))) {
			let n = e;
			n.isPrimary === void 0 && (n.isPrimary = !0), n.width === void 0 && (n.width = 1), n.height === void 0 && (n.height = 1), n.tiltX === void 0 && (n.tiltX = 0), n.tiltY === void 0 && (n.tiltY = 0), n.pointerType === void 0 && (n.pointerType = "mouse"), n.pointerId === void 0 && (n.pointerId = Z), n.pressure === void 0 && (n.pressure = .5), n.twist === void 0 && (n.twist = 0), n.tangentialPressure === void 0 && (n.tangentialPressure = 0), n.isNormalized = !0, t.push(n);
		} else t.push(e);
		return t;
	}
	normalizeWheelEvent(e) {
		let t = this._rootWheelEvent;
		return this._transferMouseData(t, e), t.deltaX = e.deltaX, t.deltaY = e.deltaY, t.deltaZ = e.deltaZ, t.deltaMode = e.deltaMode, this.mapPositionToPoint(t.screen, e.clientX, e.clientY), t.global.copyFrom(t.screen), t.offset.copyFrom(t.screen), t.nativeEvent = e, t.type = e.type, t;
	}
	_bootstrapEvent(e, t) {
		return e.originalEvent = null, e.nativeEvent = t, e.pointerId = t.pointerId, e.width = t.width, e.height = t.height, e.isPrimary = t.isPrimary, e.pointerType = t.pointerType, e.pressure = t.pressure, e.tangentialPressure = t.tangentialPressure, e.tiltX = t.tiltX, e.tiltY = t.tiltY, e.twist = t.twist, this._transferMouseData(e, t), this.mapPositionToPoint(e.screen, t.clientX, t.clientY), e.global.copyFrom(e.screen), e.offset.copyFrom(e.screen), e.isTrusted = t.isTrusted, e.type === "pointerleave" && (e.type = "pointerout"), e.type.startsWith("mouse") && (e.type = e.type.replace("mouse", "pointer")), e.type.startsWith("touch") && (e.type = ee[e.type] || e.type), e;
	}
	_transferMouseData(e, t) {
		e.isTrusted = t.isTrusted, e.srcElement = t.srcElement, e.timeStamp = performance.now(), e.type = t.type, e.altKey = t.altKey, e.button = t.button, e.buttons = t.buttons, e.client.x = t.clientX, e.client.y = t.clientY, e.ctrlKey = t.ctrlKey, e.metaKey = t.metaKey, e.movement.x = t.movementX, e.movement.y = t.movementY, e.page.x = t.pageX, e.page.y = t.pageY, e.relatedTarget = null, e.shiftKey = t.shiftKey;
	}
};
Q.extension = {
	name: "events",
	type: [
		a.WebGLSystem,
		a.CanvasSystem,
		a.WebGPUSystem
	],
	priority: -1
}, Q.defaultEventFeatures = {
	move: !0,
	globalMove: !0,
	click: !0,
	wheel: !0
};
var $ = Q;
i.add(B), i.mixin(e, V), i.add(H), i.add($), i.mixin(e, {
	onclick: null,
	onmousedown: null,
	onmouseenter: null,
	onmouseleave: null,
	onmousemove: null,
	onglobalmousemove: null,
	onmouseout: null,
	onmouseover: null,
	onmouseup: null,
	onmouseupoutside: null,
	onpointercancel: null,
	onpointerdown: null,
	onpointerenter: null,
	onpointerleave: null,
	onpointermove: null,
	onglobalpointermove: null,
	onpointerout: null,
	onpointerover: null,
	onpointertap: null,
	onpointerup: null,
	onpointerupoutside: null,
	onrightclick: null,
	onrightdown: null,
	onrightup: null,
	onrightupoutside: null,
	ontap: null,
	ontouchcancel: null,
	ontouchend: null,
	ontouchendoutside: null,
	ontouchmove: null,
	onglobaltouchmove: null,
	ontouchstart: null,
	onwheel: null,
	get interactive() {
		return this.eventMode === "dynamic" || this.eventMode === "static";
	},
	set interactive(e) {
		this.eventMode = e ? "static" : "passive";
	},
	_internalEventMode: void 0,
	get eventMode() {
		return this._internalEventMode ?? $.defaultEventMode;
	},
	set eventMode(e) {
		this._internalEventMode = e;
	},
	isInteractive() {
		return this.eventMode === "static" || this.eventMode === "dynamic";
	},
	interactiveChildren: !0,
	hitArea: null,
	addEventListener(e, t, n) {
		let r = typeof n == "boolean" && n || typeof n == "object" && n.capture, i = typeof n == "object" ? n.signal : void 0, a = typeof n == "object" && n.once === !0, o = typeof t == "function" ? void 0 : t;
		e = r ? `${e}capture` : e;
		let s = typeof t == "function" ? t : t.handleEvent, c = this;
		i && i.addEventListener("abort", () => {
			c.off(e, s, o);
		}), a ? c.once(e, s, o) : c.on(e, s, o);
	},
	removeEventListener(e, t, n) {
		let r = typeof n == "boolean" && n || typeof n == "object" && n.capture, i = typeof t == "function" ? void 0 : t;
		e = r ? `${e}capture` : e, t = typeof t == "function" ? t : t.handleEvent, this.off(e, t, i);
	},
	dispatchEvent(e) {
		if (!(e instanceof u)) throw Error("Container cannot propagate events outside of the Federated Events API");
		return e.defaultPrevented = !1, e.path = null, e.target = this, e.manager.dispatchEvent(e), !e.defaultPrevented;
	}
});
//#endregion

//# sourceMappingURL=browserAll-D5DBqH_a.js.map