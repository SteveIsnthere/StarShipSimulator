import { L as e, b as t, q as n } from "./Geometry-CYPxRocb.js";
var r = new class {
	constructor(e) {
		this._canvasPool = /* @__PURE__ */ Object.create(null), this.canvasOptions = e || {}, this.enableFullScreen = !1;
	}
	_createCanvasAndContext(e, n) {
		let r = t.get().createCanvas();
		return r.width = e, r.height = n, {
			canvas: r,
			context: r.getContext("2d")
		};
	}
	getOptimalCanvasAndContext(e, t, r = 1) {
		e = Math.ceil(e * r - 1e-6), t = Math.ceil(t * r - 1e-6), e = n(e), t = n(t);
		let i = (e << 17) + (t << 1);
		this._canvasPool[i] || (this._canvasPool[i] = []);
		let a = this._canvasPool[i].pop();
		return a ||= this._createCanvasAndContext(e, t), a;
	}
	returnCanvasAndContext(e) {
		let { width: t, height: n } = e.canvas, r = (t << 17) + (n << 1);
		e.context.resetTransform(), e.context.clearRect(0, 0, t, n), this._canvasPool[r].push(e);
	}
	clear() {
		this._canvasPool = {};
	}
}();
e.register(r);
//#endregion
export { r as t };

//# sourceMappingURL=CanvasPool-4lFBuryO.js.map