//#region \0rolldown/runtime.js
var e = Object.create, t = Object.defineProperty, n = Object.getOwnPropertyDescriptor, r = Object.getOwnPropertyNames, i = Object.getPrototypeOf, a = Object.prototype.hasOwnProperty, o = (e, t) => () => (t || (e((t = { exports: {} }).exports, t), e = null), t.exports), s = (e, n) => {
	let r = {};
	for (var i in e) t(r, i, {
		get: e[i],
		enumerable: !0
	});
	return n || t(r, Symbol.toStringTag, { value: "Module" }), r;
}, c = (e, i, o, s) => {
	if (i && typeof i == "object" || typeof i == "function") for (var c = r(i), l = 0, u = c.length, d; l < u; l++) d = c[l], !a.call(e, d) && d !== o && t(e, d, {
		get: ((e) => i[e]).bind(null, d),
		enumerable: !(s = n(i, d)) || s.enumerable
	});
	return e;
}, l = (n, r, o) => (o = n == null ? {} : e(i(n)), c(r || !n || !n.__esModule || !a.call(n, "default") ? t(o, "default", {
	value: n,
	enumerable: !0
}) : o, n)), u = /* @__PURE__ */ ((e) => (e.Application = "application", e.WebGLPipes = "webgl-pipes", e.WebGLPipesAdaptor = "webgl-pipes-adaptor", e.WebGLSystem = "webgl-system", e.WebGPUPipes = "webgpu-pipes", e.WebGPUPipesAdaptor = "webgpu-pipes-adaptor", e.WebGPUSystem = "webgpu-system", e.CanvasSystem = "canvas-system", e.CanvasPipesAdaptor = "canvas-pipes-adaptor", e.CanvasPipes = "canvas-pipes", e.Asset = "asset", e.LoadParser = "load-parser", e.ResolveParser = "resolve-parser", e.CacheParser = "cache-parser", e.DetectionParser = "detection-parser", e.MaskEffect = "mask-effect", e.BlendMode = "blend-mode", e.TextureSource = "texture-source", e.TextureUploaderWebGL = "texture-uploader-webgl", e.TextureUploaderWebGPU = "texture-uploader-webgpu", e.Environment = "environment", e.ShapeBuilder = "shape-builder", e.Batcher = "batcher", e))(u || {}), d = (e) => {
	if (typeof e == "function" || typeof e == "object" && e.extension) {
		if (!e.extension) throw Error("Extension class must have an extension object");
		e = {
			...typeof e.extension == "object" ? e.extension : { type: e.extension },
			ref: e
		};
	}
	if (typeof e == "object") e = { ...e };
	else throw Error("Invalid extension type");
	return typeof e.type == "string" && (e.type = [e.type]), e;
}, f = (e, t) => d(e).priority ?? t, p = {
	_addHandlers: {},
	_removeHandlers: {},
	_queue: {},
	remove(...e) {
		return e.map(d).forEach((e) => {
			e.type.forEach((t) => this._removeHandlers[t]?.(e));
		}), this;
	},
	add(...e) {
		return e.map(d).forEach((e) => {
			e.type.forEach((t) => {
				let n = this._addHandlers, r = this._queue;
				n[t] ? n[t]?.(e) : (r[t] = r[t] || [], r[t]?.push(e));
			});
		}), this;
	},
	handle(e, t, n) {
		let r = this._addHandlers, i = this._removeHandlers;
		if (r[e] || i[e]) throw Error(`Extension type ${e} already has a handler`);
		r[e] = t, i[e] = n;
		let a = this._queue;
		return a[e] && (a[e]?.forEach((e) => t(e)), delete a[e]), this;
	},
	handleByMap(e, t) {
		return this.handle(e, (e) => {
			e.name && (t[e.name] = e.ref);
		}, (e) => {
			e.name && delete t[e.name];
		});
	},
	handleByNamedList(e, t, n = -1) {
		return this.handle(e, (e) => {
			t.findIndex((t) => t.name === e.name) >= 0 || (t.push({
				name: e.name,
				value: e.ref
			}), t.sort((e, t) => f(t.value, n) - f(e.value, n)));
		}, (e) => {
			let n = t.findIndex((t) => t.name === e.name);
			n !== -1 && t.splice(n, 1);
		});
	},
	handleByList(e, t, n = -1) {
		return this.handle(e, (e) => {
			t.includes(e.ref) || (t.push(e.ref), t.sort((e, t) => f(t, n) - f(e, n)));
		}, (e) => {
			let n = t.indexOf(e.ref);
			n !== -1 && t.splice(n, 1);
		});
	},
	mixin(e, ...t) {
		for (let n of t) Object.defineProperties(e.prototype, Object.getOwnPropertyDescriptors(n));
	}
}, m = class e {
	constructor(e, t, n) {
		this._x = t || 0, this._y = n || 0, this._observer = e;
	}
	clone(t) {
		return new e(t ?? this._observer, this._x, this._y);
	}
	set(e = 0, t = e) {
		return (this._x !== e || this._y !== t) && (this._x = e, this._y = t, this._observer._onUpdate(this)), this;
	}
	copyFrom(e) {
		return (this._x !== e.x || this._y !== e.y) && (this._x = e.x, this._y = e.y, this._observer._onUpdate(this)), this;
	}
	copyTo(e) {
		return e.set(this._x, this._y), e;
	}
	equals(e) {
		return e.x === this._x && e.y === this._y;
	}
	toString() {
		return `[pixi.js/math:ObservablePoint x=${this._x} y=${this._y} scope=${this._observer}]`;
	}
	get x() {
		return this._x;
	}
	set x(e) {
		this._x !== e && (this._x = e, this._observer._onUpdate(this));
	}
	get y() {
		return this._y;
	}
	set y(e) {
		this._y !== e && (this._y = e, this._observer._onUpdate(this));
	}
}, h = (/* @__PURE__ */ l((/* @__PURE__ */ o(((e, t) => {
	var n = Object.prototype.hasOwnProperty, r = "~";
	function i() {}
	Object.create && (i.prototype = Object.create(null), new i().__proto__ || (r = !1));
	function a(e, t, n) {
		this.fn = e, this.context = t, this.once = n || !1;
	}
	function o(e, t, n, i, o) {
		if (typeof n != "function") throw TypeError("The listener must be a function");
		var s = new a(n, i || e, o), c = r ? r + t : t;
		return e._events[c] ? e._events[c].fn ? e._events[c] = [e._events[c], s] : e._events[c].push(s) : (e._events[c] = s, e._eventsCount++), e;
	}
	function s(e, t) {
		--e._eventsCount === 0 ? e._events = new i() : delete e._events[t];
	}
	function c() {
		this._events = new i(), this._eventsCount = 0;
	}
	c.prototype.eventNames = function() {
		var e = [], t, i;
		if (this._eventsCount === 0) return e;
		for (i in t = this._events) n.call(t, i) && e.push(r ? i.slice(1) : i);
		return Object.getOwnPropertySymbols ? e.concat(Object.getOwnPropertySymbols(t)) : e;
	}, c.prototype.listeners = function(e) {
		var t = r ? r + e : e, n = this._events[t];
		if (!n) return [];
		if (n.fn) return [n.fn];
		for (var i = 0, a = n.length, o = Array(a); i < a; i++) o[i] = n[i].fn;
		return o;
	}, c.prototype.listenerCount = function(e) {
		var t = r ? r + e : e, n = this._events[t];
		return n ? n.fn ? 1 : n.length : 0;
	}, c.prototype.emit = function(e, t, n, i, a, o) {
		var s = r ? r + e : e;
		if (!this._events[s]) return !1;
		var c = this._events[s], l = arguments.length, u, d;
		if (c.fn) {
			switch (c.once && this.removeListener(e, c.fn, void 0, !0), l) {
				case 1: return c.fn.call(c.context), !0;
				case 2: return c.fn.call(c.context, t), !0;
				case 3: return c.fn.call(c.context, t, n), !0;
				case 4: return c.fn.call(c.context, t, n, i), !0;
				case 5: return c.fn.call(c.context, t, n, i, a), !0;
				case 6: return c.fn.call(c.context, t, n, i, a, o), !0;
			}
			for (d = 1, u = Array(l - 1); d < l; d++) u[d - 1] = arguments[d];
			c.fn.apply(c.context, u);
		} else {
			var f = c.length, p;
			for (d = 0; d < f; d++) switch (c[d].once && this.removeListener(e, c[d].fn, void 0, !0), l) {
				case 1:
					c[d].fn.call(c[d].context);
					break;
				case 2:
					c[d].fn.call(c[d].context, t);
					break;
				case 3:
					c[d].fn.call(c[d].context, t, n);
					break;
				case 4:
					c[d].fn.call(c[d].context, t, n, i);
					break;
				default:
					if (!u) for (p = 1, u = Array(l - 1); p < l; p++) u[p - 1] = arguments[p];
					c[d].fn.apply(c[d].context, u);
			}
		}
		return !0;
	}, c.prototype.on = function(e, t, n) {
		return o(this, e, t, n, !1);
	}, c.prototype.once = function(e, t, n) {
		return o(this, e, t, n, !0);
	}, c.prototype.removeListener = function(e, t, n, i) {
		var a = r ? r + e : e;
		if (!this._events[a]) return this;
		if (!t) return s(this, a), this;
		var o = this._events[a];
		if (o.fn) o.fn === t && (!i || o.once) && (!n || o.context === n) && s(this, a);
		else {
			for (var c = 0, l = [], u = o.length; c < u; c++) (o[c].fn !== t || i && !o[c].once || n && o[c].context !== n) && l.push(o[c]);
			l.length ? this._events[a] = l.length === 1 ? l[0] : l : s(this, a);
		}
		return this;
	}, c.prototype.removeAllListeners = function(e) {
		var t;
		return e ? (t = r ? r + e : e, this._events[t] && s(this, t)) : (this._events = new i(), this._eventsCount = 0), this;
	}, c.prototype.off = c.prototype.removeListener, c.prototype.addListener = c.prototype.on, c.prefixed = r, c.EventEmitter = c, t !== void 0 && (t.exports = c);
})))(), 1)).default, g = Math.PI * 2, _ = 180 / Math.PI, v = Math.PI / 180, y = class e {
	constructor(e = 0, t = 0) {
		this.x = 0, this.y = 0, this.x = e, this.y = t;
	}
	clone() {
		return new e(this.x, this.y);
	}
	copyFrom(e) {
		return this.set(e.x, e.y), this;
	}
	copyTo(e) {
		return e.set(this.x, this.y), e;
	}
	equals(e) {
		return e.x === this.x && e.y === this.y;
	}
	set(e = 0, t = e) {
		return this.x = e, this.y = t, this;
	}
	toString() {
		return `[pixi.js/math:Point x=${this.x} y=${this.y}]`;
	}
	static get shared() {
		return b.x = 0, b.y = 0, b;
	}
}, b = new y(), x = class e {
	constructor(e = 1, t = 0, n = 0, r = 1, i = 0, a = 0) {
		this.array = null, this.a = e, this.b = t, this.c = n, this.d = r, this.tx = i, this.ty = a;
	}
	fromArray(e) {
		this.a = e[0], this.b = e[1], this.c = e[3], this.d = e[4], this.tx = e[2], this.ty = e[5];
	}
	set(e, t, n, r, i, a) {
		return this.a = e, this.b = t, this.c = n, this.d = r, this.tx = i, this.ty = a, this;
	}
	toArray(e, t) {
		this.array ||= /* @__PURE__ */ new Float32Array(9);
		let n = t || this.array;
		return e ? (n[0] = this.a, n[1] = this.b, n[2] = 0, n[3] = this.c, n[4] = this.d, n[5] = 0, n[6] = this.tx, n[7] = this.ty, n[8] = 1) : (n[0] = this.a, n[1] = this.c, n[2] = this.tx, n[3] = this.b, n[4] = this.d, n[5] = this.ty, n[6] = 0, n[7] = 0, n[8] = 1), n;
	}
	apply(e, t) {
		t ||= new y();
		let n = e.x, r = e.y;
		return t.x = this.a * n + this.c * r + this.tx, t.y = this.b * n + this.d * r + this.ty, t;
	}
	applyInverse(e, t) {
		t ||= new y();
		let n = this.a, r = this.b, i = this.c, a = this.d, o = this.tx, s = this.ty, c = 1 / (n * a + i * -r), l = e.x, u = e.y;
		return t.x = a * c * l + -i * c * u + (s * i - o * a) * c, t.y = n * c * u + -r * c * l + (-s * n + o * r) * c, t;
	}
	translate(e, t) {
		return this.tx += e, this.ty += t, this;
	}
	scale(e, t) {
		return this.a *= e, this.d *= t, this.c *= e, this.b *= t, this.tx *= e, this.ty *= t, this;
	}
	rotate(e) {
		let t = Math.cos(e), n = Math.sin(e), r = this.a, i = this.c, a = this.tx;
		return this.a = r * t - this.b * n, this.b = r * n + this.b * t, this.c = i * t - this.d * n, this.d = i * n + this.d * t, this.tx = a * t - this.ty * n, this.ty = a * n + this.ty * t, this;
	}
	append(e) {
		let t = this.a, n = this.b, r = this.c, i = this.d;
		return this.a = e.a * t + e.b * r, this.b = e.a * n + e.b * i, this.c = e.c * t + e.d * r, this.d = e.c * n + e.d * i, this.tx = e.tx * t + e.ty * r + this.tx, this.ty = e.tx * n + e.ty * i + this.ty, this;
	}
	appendFrom(e, t) {
		let n = e.a, r = e.b, i = e.c, a = e.d, o = e.tx, s = e.ty, c = t.a, l = t.b, u = t.c, d = t.d;
		return this.a = n * c + r * u, this.b = n * l + r * d, this.c = i * c + a * u, this.d = i * l + a * d, this.tx = o * c + s * u + t.tx, this.ty = o * l + s * d + t.ty, this;
	}
	setTransform(e, t, n, r, i, a, o, s, c) {
		return this.a = Math.cos(o + c) * i, this.b = Math.sin(o + c) * i, this.c = -Math.sin(o - s) * a, this.d = Math.cos(o - s) * a, this.tx = e - (n * this.a + r * this.c), this.ty = t - (n * this.b + r * this.d), this;
	}
	prepend(e) {
		let t = this.tx;
		if (e.a !== 1 || e.b !== 0 || e.c !== 0 || e.d !== 1) {
			let t = this.a, n = this.c;
			this.a = t * e.a + this.b * e.c, this.b = t * e.b + this.b * e.d, this.c = n * e.a + this.d * e.c, this.d = n * e.b + this.d * e.d;
		}
		return this.tx = t * e.a + this.ty * e.c + e.tx, this.ty = t * e.b + this.ty * e.d + e.ty, this;
	}
	decompose(e) {
		let t = this.a, n = this.b, r = this.c, i = this.d, a = e.pivot, o = -Math.atan2(-r, i), s = Math.atan2(n, t), c = Math.abs(o + s);
		return c < 1e-5 || Math.abs(g - c) < 1e-5 ? (e.rotation = s, e.skew.x = e.skew.y = 0) : (e.rotation = 0, e.skew.x = o, e.skew.y = s), e.scale.x = Math.sqrt(t * t + n * n), e.scale.y = Math.sqrt(r * r + i * i), e.position.x = this.tx + (a.x * t + a.y * r), e.position.y = this.ty + (a.x * n + a.y * i), e;
	}
	invert() {
		let e = this.a, t = this.b, n = this.c, r = this.d, i = this.tx, a = e * r - t * n;
		return this.a = r / a, this.b = -t / a, this.c = -n / a, this.d = e / a, this.tx = (n * this.ty - r * i) / a, this.ty = -(e * this.ty - t * i) / a, this;
	}
	isIdentity() {
		return this.a === 1 && this.b === 0 && this.c === 0 && this.d === 1 && this.tx === 0 && this.ty === 0;
	}
	identity() {
		return this.a = 1, this.b = 0, this.c = 0, this.d = 1, this.tx = 0, this.ty = 0, this;
	}
	clone() {
		let t = new e();
		return t.a = this.a, t.b = this.b, t.c = this.c, t.d = this.d, t.tx = this.tx, t.ty = this.ty, t;
	}
	copyTo(e) {
		return e.a = this.a, e.b = this.b, e.c = this.c, e.d = this.d, e.tx = this.tx, e.ty = this.ty, e;
	}
	copyFrom(e) {
		return this.a = e.a, this.b = e.b, this.c = e.c, this.d = e.d, this.tx = e.tx, this.ty = e.ty, this;
	}
	equals(e) {
		return e.a === this.a && e.b === this.b && e.c === this.c && e.d === this.d && e.tx === this.tx && e.ty === this.ty;
	}
	toString() {
		return `[pixi.js:Matrix a=${this.a} b=${this.b} c=${this.c} d=${this.d} tx=${this.tx} ty=${this.ty}]`;
	}
	static get IDENTITY() {
		return te.identity();
	}
	static get shared() {
		return ee.identity();
	}
}, ee = new x(), te = new x(), S = [
	1,
	1,
	0,
	-1,
	-1,
	-1,
	0,
	1,
	1,
	1,
	0,
	-1,
	-1,
	-1,
	0,
	1
], C = [
	0,
	1,
	1,
	1,
	0,
	-1,
	-1,
	-1,
	0,
	1,
	1,
	1,
	0,
	-1,
	-1,
	-1
], w = [
	0,
	-1,
	-1,
	-1,
	0,
	1,
	1,
	1,
	0,
	1,
	1,
	1,
	0,
	-1,
	-1,
	-1
], T = [
	1,
	1,
	0,
	-1,
	-1,
	-1,
	0,
	1,
	-1,
	-1,
	0,
	1,
	1,
	1,
	0,
	-1
], ne = [], re = [], ie = Math.sign;
function ae() {
	for (let e = 0; e < 16; e++) {
		let t = [];
		ne.push(t);
		for (let n = 0; n < 16; n++) {
			let r = ie(S[e] * S[n] + w[e] * C[n]), i = ie(C[e] * S[n] + T[e] * C[n]), a = ie(S[e] * w[n] + w[e] * T[n]), o = ie(C[e] * w[n] + T[e] * T[n]);
			for (let e = 0; e < 16; e++) if (S[e] === r && C[e] === i && w[e] === a && T[e] === o) {
				t.push(e);
				break;
			}
		}
	}
	for (let e = 0; e < 16; e++) {
		let t = new x();
		t.set(S[e], C[e], w[e], T[e], 0, 0), re.push(t);
	}
}
ae();
var E = {
	E: 0,
	SE: 1,
	S: 2,
	SW: 3,
	W: 4,
	NW: 5,
	N: 6,
	NE: 7,
	MIRROR_VERTICAL: 8,
	MAIN_DIAGONAL: 10,
	MIRROR_HORIZONTAL: 12,
	REVERSE_DIAGONAL: 14,
	uX: (e) => S[e],
	uY: (e) => C[e],
	vX: (e) => w[e],
	vY: (e) => T[e],
	inv: (e) => e & 8 ? e & 15 : -e & 7,
	add: (e, t) => ne[e][t],
	sub: (e, t) => ne[e][E.inv(t)],
	rotate180: (e) => e ^ 4,
	isVertical: (e) => (e & 3) == 2,
	byDirection: (e, t) => Math.abs(e) * 2 <= Math.abs(t) ? t >= 0 ? E.S : E.N : Math.abs(t) * 2 <= Math.abs(e) ? e > 0 ? E.E : E.W : t > 0 ? e > 0 ? E.SE : E.SW : e > 0 ? E.NE : E.NW,
	matrixAppendRotationInv: (e, t, n = 0, r = 0, i = 0, a = 0) => {
		let o = re[E.inv(t)], s = o.a, c = o.b, l = o.c, u = o.d, d = n - Math.min(0, s * i, l * a, s * i + l * a), f = r - Math.min(0, c * i, u * a, c * i + u * a), p = e.a, m = e.b, h = e.c, g = e.d;
		e.a = s * p + c * h, e.b = s * m + c * g, e.c = l * p + u * h, e.d = l * m + u * g, e.tx = d * p + f * h + e.tx, e.ty = d * m + f * g + e.ty;
	},
	transformRectCoords: (e, t, n, r) => {
		let { x: i, y: a, width: o, height: s } = e, { x: c, y: l, width: u, height: d } = t;
		return n === E.E ? (r.set(i + c, a + l, o, s), r) : n === E.S ? r.set(u - a - s + c, i + l, s, o) : n === E.W ? r.set(u - i - o + c, d - a - s + l, o, s) : n === E.N ? r.set(a + c, d - i - o + l, s, o) : r.set(i + c, a + l, o, s);
	}
}, oe = [
	new y(),
	new y(),
	new y(),
	new y()
], se = class e {
	constructor(e = 0, t = 0, n = 0, r = 0) {
		this.type = "rectangle", this.x = Number(e), this.y = Number(t), this.width = Number(n), this.height = Number(r);
	}
	get left() {
		return this.x;
	}
	get right() {
		return this.x + this.width;
	}
	get top() {
		return this.y;
	}
	get bottom() {
		return this.y + this.height;
	}
	isEmpty() {
		return this.left === this.right || this.top === this.bottom;
	}
	static get EMPTY() {
		return new e(0, 0, 0, 0);
	}
	clone() {
		return new e(this.x, this.y, this.width, this.height);
	}
	copyFromBounds(e) {
		return this.x = e.minX, this.y = e.minY, this.width = e.maxX - e.minX, this.height = e.maxY - e.minY, this;
	}
	copyFrom(e) {
		return this.x = e.x, this.y = e.y, this.width = e.width, this.height = e.height, this;
	}
	copyTo(e) {
		return e.copyFrom(this), e;
	}
	contains(e, t) {
		return this.width <= 0 || this.height <= 0 ? !1 : e >= this.x && e < this.x + this.width && t >= this.y && t < this.y + this.height;
	}
	strokeContains(e, t, n, r = .5) {
		let { width: i, height: a } = this;
		if (i <= 0 || a <= 0) return !1;
		let o = this.x, s = this.y, c = n * (1 - r), l = n - c, u = o - c, d = o + i + c, f = s - c, p = s + a + c, m = o + l, h = o + i - l, g = s + l, _ = s + a - l;
		return e >= u && e <= d && t >= f && t <= p && !(e > m && e < h && t > g && t < _);
	}
	intersects(e, t) {
		if (!t) {
			let t = this.x < e.x ? e.x : this.x;
			if ((this.right > e.right ? e.right : this.right) <= t) return !1;
			let n = this.y < e.y ? e.y : this.y;
			return (this.bottom > e.bottom ? e.bottom : this.bottom) > n;
		}
		let n = this.left, r = this.right, i = this.top, a = this.bottom;
		if (r <= n || a <= i) return !1;
		let o = oe[0].set(e.left, e.top), s = oe[1].set(e.left, e.bottom), c = oe[2].set(e.right, e.top), l = oe[3].set(e.right, e.bottom);
		if (c.x <= o.x || s.y <= o.y) return !1;
		let u = Math.sign(t.a * t.d - t.b * t.c);
		if (u === 0 || (t.apply(o, o), t.apply(s, s), t.apply(c, c), t.apply(l, l), Math.max(o.x, s.x, c.x, l.x) <= n || Math.min(o.x, s.x, c.x, l.x) >= r || Math.max(o.y, s.y, c.y, l.y) <= i || Math.min(o.y, s.y, c.y, l.y) >= a)) return !1;
		let d = u * (s.y - o.y), f = u * (o.x - s.x), p = d * n + f * i, m = d * r + f * i, h = d * n + f * a, g = d * r + f * a;
		if (Math.max(p, m, h, g) <= d * o.x + f * o.y || Math.min(p, m, h, g) >= d * l.x + f * l.y) return !1;
		let _ = u * (o.y - c.y), v = u * (c.x - o.x), y = _ * n + v * i, b = _ * r + v * i, x = _ * n + v * a, ee = _ * r + v * a;
		return !(Math.max(y, b, x, ee) <= _ * o.x + v * o.y || Math.min(y, b, x, ee) >= _ * l.x + v * l.y);
	}
	pad(e = 0, t = e) {
		return this.x -= e, this.y -= t, this.width += e * 2, this.height += t * 2, this;
	}
	fit(e) {
		let t = Math.max(this.x, e.x), n = Math.min(this.x + this.width, e.x + e.width), r = Math.max(this.y, e.y), i = Math.min(this.y + this.height, e.y + e.height);
		return this.x = t, this.width = Math.max(n - t, 0), this.y = r, this.height = Math.max(i - r, 0), this;
	}
	ceil(e = 1, t = .001) {
		let n = Math.ceil((this.x + this.width - t) * e) / e, r = Math.ceil((this.y + this.height - t) * e) / e;
		return this.x = Math.floor((this.x + t) * e) / e, this.y = Math.floor((this.y + t) * e) / e, this.width = n - this.x, this.height = r - this.y, this;
	}
	scale(e, t = e) {
		return this.x *= e, this.y *= t, this.width *= e, this.height *= t, this;
	}
	enlarge(e) {
		let t = Math.min(this.x, e.x), n = Math.max(this.x + this.width, e.x + e.width), r = Math.min(this.y, e.y), i = Math.max(this.y + this.height, e.y + e.height);
		return this.x = t, this.width = n - t, this.y = r, this.height = i - r, this;
	}
	getBounds(t) {
		return t ||= new e(), t.copyFrom(this), t;
	}
	containsRect(e) {
		if (this.width <= 0 || this.height <= 0) return !1;
		let t = e.x, n = e.y, r = e.x + e.width, i = e.y + e.height;
		return t >= this.x && t < this.x + this.width && n >= this.y && n < this.y + this.height && r >= this.x && r <= this.x + this.width && i >= this.y && i <= this.y + this.height;
	}
	set(e, t, n, r) {
		return this.x = e, this.y = t, this.width = n, this.height = r, this;
	}
	toString() {
		return `[pixi.js/math:Rectangle x=${this.x} y=${this.y} width=${this.width} height=${this.height}]`;
	}
}, ce = { default: -1 };
function D(e = "default") {
	return ce[e] === void 0 && (ce[e] = -1), ++ce[e];
}
//#endregion
//#region node_modules/pixi.js/lib/utils/logging/deprecation.mjs
var le = /* @__PURE__ */ new Set(), O = "8.0.0", ue = "8.3.4", k = {
	quiet: !1,
	noColor: !1
}, A = ((e, t, n = 3) => {
	if (k.quiet || le.has(t)) return;
	let r = (/* @__PURE__ */ Error()).stack, i = `${t}
Deprecated since v${e}`, a = typeof console.groupCollapsed == "function" && !k.noColor;
	r === void 0 ? console.warn("PixiJS Deprecation Warning: ", i) : (r = r.split("\n").splice(n).join("\n"), a ? (console.groupCollapsed("%cPixiJS Deprecation Warning: %c%s", "color:#614108;background:#fffbe6", "font-weight:normal;color:#614108;background:#fffbe6", i), console.warn(r), console.groupEnd()) : (console.warn("PixiJS Deprecation Warning: ", i), console.warn(r))), le.add(t);
});
Object.defineProperties(A, {
	quiet: {
		get: () => k.quiet,
		set: (e) => {
			k.quiet = e;
		},
		enumerable: !0,
		configurable: !1
	},
	noColor: {
		get: () => k.noColor,
		set: (e) => {
			k.noColor = e;
		},
		enumerable: !0,
		configurable: !1
	}
});
//#endregion
//#region node_modules/pixi.js/lib/utils/misc/NOOP.mjs
var de = () => {};
//#endregion
//#region node_modules/pixi.js/lib/maths/misc/pow2.mjs
function fe(e) {
	return e += +(e === 0), --e, e |= e >>> 1, e |= e >>> 2, e |= e >>> 4, e |= e >>> 8, e |= e >>> 16, e + 1;
}
function pe(e) {
	return !(e & e - 1) && !!e;
}
//#endregion
//#region node_modules/pixi.js/lib/scene/container/utils/definedProps.mjs
function me(e) {
	let t = {};
	for (let n in e) e[n] !== void 0 && (t[n] = e[n]);
	return t;
}
//#endregion
//#region node_modules/pixi.js/lib/rendering/renderers/shared/texture/TextureStyle.mjs
var he = /* @__PURE__ */ Object.create(null);
function ge(e) {
	let t = he[e];
	return t === void 0 && (he[e] = D("resource")), t;
}
var _e = class e extends h {
	constructor(t = {}) {
		super(), this._resourceType = "textureSampler", this._touched = 0, this._maxAnisotropy = 1, this.destroyed = !1, t = {
			...e.defaultOptions,
			...t
		}, this.addressMode = t.addressMode, this.addressModeU = t.addressModeU ?? this.addressModeU, this.addressModeV = t.addressModeV ?? this.addressModeV, this.addressModeW = t.addressModeW ?? this.addressModeW, this.scaleMode = t.scaleMode, this.magFilter = t.magFilter ?? this.magFilter, this.minFilter = t.minFilter ?? this.minFilter, this.mipmapFilter = t.mipmapFilter ?? this.mipmapFilter, this.lodMinClamp = t.lodMinClamp, this.lodMaxClamp = t.lodMaxClamp, this.compare = t.compare, this.maxAnisotropy = t.maxAnisotropy ?? 1;
	}
	set addressMode(e) {
		this.addressModeU = e, this.addressModeV = e, this.addressModeW = e;
	}
	get addressMode() {
		return this.addressModeU;
	}
	set wrapMode(e) {
		A(O, "TextureStyle.wrapMode is now TextureStyle.addressMode"), this.addressMode = e;
	}
	get wrapMode() {
		return this.addressMode;
	}
	set scaleMode(e) {
		this.magFilter = e, this.minFilter = e, this.mipmapFilter = e;
	}
	get scaleMode() {
		return this.magFilter;
	}
	set maxAnisotropy(e) {
		this._maxAnisotropy = Math.min(e, 16), this._maxAnisotropy > 1 && (this.scaleMode = "linear");
	}
	get maxAnisotropy() {
		return this._maxAnisotropy;
	}
	get _resourceId() {
		return this._sharedResourceId || this._generateResourceId();
	}
	update() {
		this._sharedResourceId = null, this.emit("change", this);
	}
	_generateResourceId() {
		let e = `${this.addressModeU}-${this.addressModeV}-${this.addressModeW}-${this.magFilter}-${this.minFilter}-${this.mipmapFilter}-${this.lodMinClamp}-${this.lodMaxClamp}-${this.compare}-${this._maxAnisotropy}`;
		return this._sharedResourceId = ge(e), this._resourceId;
	}
	destroy() {
		this.destroyed = !0, this.emit("destroy", this), this.emit("change", this), this.removeAllListeners();
	}
};
_e.defaultOptions = {
	addressMode: "clamp-to-edge",
	scaleMode: "linear"
};
var ve = _e, ye = class e extends h {
	constructor(t = {}) {
		super(), this.options = t, this._gpuData = /* @__PURE__ */ Object.create(null), this._gcLastUsed = -1, this.uid = D("textureSource"), this._resourceType = "textureSource", this._resourceId = D("resource"), this.uploadMethodId = "unknown", this._resolution = 1, this.pixelWidth = 1, this.pixelHeight = 1, this.width = 1, this.height = 1, this.sampleCount = 1, this.mipLevelCount = 1, this.autoGenerateMipmaps = !1, this.format = "rgba8unorm", this.dimension = "2d", this.viewDimension = "2d", this.arrayLayerCount = 1, this._ownsStyle = !1, this.antialias = !1, this.transient = !1, this._touched = 0, this._batchTick = -1, this._textureBindLocation = -1, t = {
			...e.defaultOptions,
			...t
		}, this.label = t.label ?? "", this.resource = t.resource, this.autoGarbageCollect = t.autoGarbageCollect, this._resolution = t.resolution, this.pixelWidth = t.width ? t.width * this._resolution : this.resource ? this.resourceWidth ?? 1 : 1, this.pixelHeight = t.height ? t.height * this._resolution : this.resource ? this.resourceHeight ?? 1 : 1, this.width = this.pixelWidth / this._resolution, this.height = this.pixelHeight / this._resolution, this.format = t.format, this.dimension = t.dimensions, this.viewDimension = t.viewDimension ?? t.dimensions, this.arrayLayerCount = t.arrayLayerCount, this.mipLevelCount = t.mipLevelCount, this.autoGenerateMipmaps = t.autoGenerateMipmaps, this.sampleCount = t.sampleCount, this.antialias = t.antialias, this.transient = t.transient ?? !1, this.alphaMode = t.alphaMode, this.style = new ve(me(t)), this._ownsStyle = !0, this.destroyed = !1, this._refreshPOT();
	}
	get source() {
		return this;
	}
	get style() {
		return this._style;
	}
	set style(e) {
		this.style !== e && (this._ownsStyle = !1, this._style?.off("change", this._onStyleChange, this), this._style = e, this._style?.on("change", this._onStyleChange, this), this._onStyleChange());
	}
	set maxAnisotropy(e) {
		this._style.maxAnisotropy = e;
	}
	get maxAnisotropy() {
		return this._style.maxAnisotropy;
	}
	get addressMode() {
		return this._style.addressMode;
	}
	set addressMode(e) {
		this._style.addressMode = e;
	}
	get repeatMode() {
		return this._style.addressMode;
	}
	set repeatMode(e) {
		this._style.addressMode = e;
	}
	get magFilter() {
		return this._style.magFilter;
	}
	set magFilter(e) {
		this._style.magFilter = e;
	}
	get minFilter() {
		return this._style.minFilter;
	}
	set minFilter(e) {
		this._style.minFilter = e;
	}
	get mipmapFilter() {
		return this._style.mipmapFilter;
	}
	set mipmapFilter(e) {
		this._style.mipmapFilter = e;
	}
	get lodMinClamp() {
		return this._style.lodMinClamp;
	}
	set lodMinClamp(e) {
		this._style.lodMinClamp = e;
	}
	get lodMaxClamp() {
		return this._style.lodMaxClamp;
	}
	set lodMaxClamp(e) {
		this._style.lodMaxClamp = e;
	}
	_onStyleChange() {
		this.emit("styleChange", this);
	}
	update() {
		if (this.resource) {
			let e = this._resolution;
			if (this.resize(this.resourceWidth / e, this.resourceHeight / e)) return;
		}
		this.emit("update", this);
	}
	destroy() {
		this.destroyed = !0, this.unload(), this.emit("destroy", this), this._style &&= (this._ownsStyle && this._style.destroy(), null), this.uploadMethodId = null, this.resource = null, this.removeAllListeners();
	}
	unload() {
		this._resourceId = D("resource"), this.emit("change", this), this.emit("unload", this);
		for (let e in this._gpuData) this._gpuData[e]?.destroy?.();
		this._gpuData = /* @__PURE__ */ Object.create(null);
	}
	get resourceWidth() {
		let { resource: e } = this;
		return e.naturalWidth || e.videoWidth || e.displayWidth || e.width;
	}
	get resourceHeight() {
		let { resource: e } = this;
		return e.naturalHeight || e.videoHeight || e.displayHeight || e.height;
	}
	get resolution() {
		return this._resolution;
	}
	set resolution(e) {
		this._resolution !== e && (this._resolution = e, this.width = this.pixelWidth / e, this.height = this.pixelHeight / e);
	}
	resize(e, t, n) {
		n ||= this._resolution, e ||= this.width, t ||= this.height;
		let r = Math.round(e * n), i = Math.round(t * n);
		return this.width = r / n, this.height = i / n, this._resolution = n, this.pixelWidth === r && this.pixelHeight === i ? !1 : (this._refreshPOT(), this.pixelWidth = r, this.pixelHeight = i, this.emit("resize", this), this._resourceId = D("resource"), this.emit("change", this), !0);
	}
	updateMipmaps() {
		this.autoGenerateMipmaps && this.mipLevelCount > 1 && this.emit("updateMipmaps", this);
	}
	set wrapMode(e) {
		this._style.wrapMode = e;
	}
	get wrapMode() {
		return this._style.wrapMode;
	}
	set scaleMode(e) {
		this._style.scaleMode = e;
	}
	get scaleMode() {
		return this._style.scaleMode;
	}
	_refreshPOT() {
		this.isPowerOfTwo = pe(this.pixelWidth) && pe(this.pixelHeight);
	}
	static test(e) {
		throw Error("Unimplemented");
	}
};
ye.defaultOptions = {
	resolution: 1,
	format: "bgra8unorm",
	alphaMode: "premultiply-alpha-on-upload",
	dimensions: "2d",
	viewDimension: "2d",
	arrayLayerCount: 1,
	mipLevelCount: 1,
	autoGenerateMipmaps: !1,
	sampleCount: 1,
	antialias: !1,
	autoGarbageCollect: !1
};
var j = ye, be = class extends j {
	constructor(e) {
		let t = e.resource || new Float32Array(e.width * e.height * 4), n = e.format;
		n ||= t instanceof Float32Array ? "rgba32float" : t instanceof Int32Array || t instanceof Uint32Array ? "rgba32uint" : t instanceof Int16Array || t instanceof Uint16Array ? "rgba16uint" : (t instanceof Int8Array, "bgra8unorm"), super({
			...e,
			resource: t,
			format: n
		}), this.uploadMethodId = "buffer";
	}
	static test(e) {
		return e instanceof Int8Array || e instanceof Uint8Array || e instanceof Uint8ClampedArray || e instanceof Int16Array || e instanceof Uint16Array || e instanceof Int32Array || e instanceof Uint32Array || e instanceof Float32Array;
	}
};
be.extension = u.TextureSource;
//#endregion
//#region node_modules/pixi.js/lib/rendering/renderers/shared/texture/TextureMatrix.mjs
var xe = new x(), Se = class {
	constructor(e, t) {
		this.mapCoord = new x(), this.uClampFrame = /* @__PURE__ */ new Float32Array(4), this.uClampOffset = /* @__PURE__ */ new Float32Array(2), this._updateID = 0, this.clampOffset = 0, this.clampMargin = t === void 0 ? e.width < 10 ? 0 : .5 : t, this.isSimple = !1, this.texture = e;
	}
	get texture() {
		return this._texture;
	}
	set texture(e) {
		this._texture !== e && (this._texture?.removeListener("update", this.update, this), this._texture = e, this._texture.addListener("update", this.update, this)), this.update();
	}
	destroy() {
		this._texture?.removeListener("update", this.update, this), this._texture = null;
	}
	multiplyUvs(e, t) {
		t === void 0 && (t = e);
		let n = this.mapCoord;
		for (let r = 0; r < e.length; r += 2) {
			let i = e[r], a = e[r + 1];
			t[r] = i * n.a + a * n.c + n.tx, t[r + 1] = i * n.b + a * n.d + n.ty;
		}
		return t;
	}
	update() {
		let e = this._texture;
		this._updateID++;
		let t = e.uvs;
		this.mapCoord.set(t.x1 - t.x0, t.y1 - t.y0, t.x3 - t.x0, t.y3 - t.y0, t.x0, t.y0);
		let n = e.orig, r = e.trim;
		r && (xe.set(n.width / r.width, 0, 0, n.height / r.height, -r.x / r.width, -r.y / r.height), this.mapCoord.append(xe));
		let i = e.source, a = this.uClampFrame, o = this.clampMargin / i._resolution, s = this.clampOffset / i._resolution;
		return a[0] = (e.frame.x + o + s) / i.width, a[1] = (e.frame.y + o + s) / i.height, a[2] = (e.frame.x + e.frame.width - o + s) / i.width, a[3] = (e.frame.y + e.frame.height - o + s) / i.height, this.uClampOffset[0] = this.clampOffset / i.pixelWidth, this.uClampOffset[1] = this.clampOffset / i.pixelHeight, this.isSimple = e.frame.width === i.width && e.frame.height === i.height && e.rotate === 0, !0;
	}
}, M = class extends h {
	constructor({ source: e, label: t, frame: n, orig: r, trim: i, defaultAnchor: a, defaultBorders: o, rotate: s, dynamic: c } = {}) {
		if (super(), this.uid = D("texture"), this.uvs = {
			x0: 0,
			y0: 0,
			x1: 0,
			y1: 0,
			x2: 0,
			y2: 0,
			x3: 0,
			y3: 0
		}, this.frame = new se(), this.noFrame = !1, this.dynamic = !1, this.isTexture = !0, this.label = t, this.source = e?.source ?? new j(), this.noFrame = !n, n) this.frame.copyFrom(n);
		else {
			let { width: e, height: t } = this._source;
			this.frame.width = e, this.frame.height = t;
		}
		this.orig = r || this.frame, this.trim = i, this.rotate = s ?? 0, this.defaultAnchor = a, this.defaultBorders = o, this.destroyed = !1, this.dynamic = c || !1, this.updateUvs();
	}
	set source(e) {
		this._source && this._source.off("resize", this.update, this), this._source = e, e.on("resize", this.update, this), this.emit("update", this);
	}
	get source() {
		return this._source;
	}
	get textureMatrix() {
		return this._textureMatrix ||= new Se(this), this._textureMatrix;
	}
	get width() {
		return this.orig.width;
	}
	get height() {
		return this.orig.height;
	}
	updateUvs() {
		let { uvs: e, frame: t } = this, { width: n, height: r } = this._source, i = t.x / n, a = t.y / r, o = t.width / n, s = t.height / r, c = this.rotate;
		if (c) {
			let t = o / 2, n = s / 2, r = i + t, l = a + n;
			c = E.add(c, E.NW), e.x0 = r + t * E.uX(c), e.y0 = l + n * E.uY(c), c = E.add(c, 2), e.x1 = r + t * E.uX(c), e.y1 = l + n * E.uY(c), c = E.add(c, 2), e.x2 = r + t * E.uX(c), e.y2 = l + n * E.uY(c), c = E.add(c, 2), e.x3 = r + t * E.uX(c), e.y3 = l + n * E.uY(c);
		} else e.x0 = i, e.y0 = a, e.x1 = i + o, e.y1 = a, e.x2 = i + o, e.y2 = a + s, e.x3 = i, e.y3 = a + s;
	}
	destroy(e = !1) {
		this._source && (this._source.off("resize", this.update, this), e && (this._source.destroy(), this._source = null)), this._textureMatrix = null, this.destroyed = !0, this.emit("destroy", this), this.removeAllListeners();
	}
	update() {
		this.noFrame && (this.frame.width = this._source.width, this.frame.height = this._source.height), this.updateUvs(), this.emit("update", this);
	}
	get baseTexture() {
		return A(O, "Texture.baseTexture is now Texture.source"), this._source;
	}
};
M.EMPTY = new M({
	label: "EMPTY",
	source: new j({ label: "EMPTY" })
}), M.EMPTY.destroy = de, M.WHITE = new M({
	source: new be({
		resource: new Uint8Array([
			255,
			255,
			255,
			255
		]),
		width: 1,
		height: 1,
		alphaMode: "premultiply-alpha-on-upload",
		label: "WHITE"
	}),
	label: "WHITE"
}), M.WHITE.destroy = de;
//#endregion
//#region node_modules/pixi.js/lib/utils/data/updateQuadBounds.mjs
function Ce(e, t, n) {
	let { width: r, height: i } = n.orig, a = n.trim;
	if (a) {
		let n = a.width, o = a.height;
		e.minX = a.x - t._x * r, e.maxX = e.minX + n, e.minY = a.y - t._y * i, e.maxY = e.minY + o;
	} else e.minX = -t._x * r, e.maxX = e.minX + r, e.minY = -t._y * i, e.maxY = e.minY + i;
}
//#endregion
//#region node_modules/pixi.js/lib/scene/container/bounds/Bounds.mjs
var we = new x(), N = class e {
	constructor(e = Infinity, t = Infinity, n = -Infinity, r = -Infinity) {
		this.minX = Infinity, this.minY = Infinity, this.maxX = -Infinity, this.maxY = -Infinity, this.matrix = we, this.minX = e, this.minY = t, this.maxX = n, this.maxY = r;
	}
	isEmpty() {
		return this.minX > this.maxX || this.minY > this.maxY;
	}
	get rectangle() {
		this._rectangle ||= new se();
		let e = this._rectangle;
		return this.minX > this.maxX || this.minY > this.maxY ? (e.x = 0, e.y = 0, e.width = 0, e.height = 0) : e.copyFromBounds(this), e;
	}
	clear() {
		return this.minX = Infinity, this.minY = Infinity, this.maxX = -Infinity, this.maxY = -Infinity, this.matrix = we, this;
	}
	set(e, t, n, r) {
		this.minX = e, this.minY = t, this.maxX = n, this.maxY = r;
	}
	addFrame(e, t, n, r, i) {
		i ||= this.matrix;
		let a = i.a, o = i.b, s = i.c, c = i.d, l = i.tx, u = i.ty, d = this.minX, f = this.minY, p = this.maxX, m = this.maxY, h = a * e + s * t + l, g = o * e + c * t + u;
		h < d && (d = h), g < f && (f = g), h > p && (p = h), g > m && (m = g), h = a * n + s * t + l, g = o * n + c * t + u, h < d && (d = h), g < f && (f = g), h > p && (p = h), g > m && (m = g), h = a * e + s * r + l, g = o * e + c * r + u, h < d && (d = h), g < f && (f = g), h > p && (p = h), g > m && (m = g), h = a * n + s * r + l, g = o * n + c * r + u, h < d && (d = h), g < f && (f = g), h > p && (p = h), g > m && (m = g), this.minX = d, this.minY = f, this.maxX = p, this.maxY = m;
	}
	addRect(e, t) {
		this.addFrame(e.x, e.y, e.x + e.width, e.y + e.height, t);
	}
	addBounds(e, t) {
		this.addFrame(e.minX, e.minY, e.maxX, e.maxY, t);
	}
	addBoundsMask(e) {
		this.minX = this.minX > e.minX ? this.minX : e.minX, this.minY = this.minY > e.minY ? this.minY : e.minY, this.maxX = this.maxX < e.maxX ? this.maxX : e.maxX, this.maxY = this.maxY < e.maxY ? this.maxY : e.maxY;
	}
	applyMatrix(e) {
		let t = this.minX, n = this.minY, r = this.maxX, i = this.maxY, { a, b: o, c: s, d: c, tx: l, ty: u } = e, d = a * t + s * n + l, f = o * t + c * n + u;
		this.minX = d, this.minY = f, this.maxX = d, this.maxY = f, d = a * r + s * n + l, f = o * r + c * n + u, this.minX = d < this.minX ? d : this.minX, this.minY = f < this.minY ? f : this.minY, this.maxX = d > this.maxX ? d : this.maxX, this.maxY = f > this.maxY ? f : this.maxY, d = a * t + s * i + l, f = o * t + c * i + u, this.minX = d < this.minX ? d : this.minX, this.minY = f < this.minY ? f : this.minY, this.maxX = d > this.maxX ? d : this.maxX, this.maxY = f > this.maxY ? f : this.maxY, d = a * r + s * i + l, f = o * r + c * i + u, this.minX = d < this.minX ? d : this.minX, this.minY = f < this.minY ? f : this.minY, this.maxX = d > this.maxX ? d : this.maxX, this.maxY = f > this.maxY ? f : this.maxY;
	}
	fit(e) {
		return this.minX < e.left && (this.minX = e.left), this.maxX > e.right && (this.maxX = e.right), this.minY < e.top && (this.minY = e.top), this.maxY > e.bottom && (this.maxY = e.bottom), this;
	}
	fitBounds(e, t, n, r) {
		return this.minX < e && (this.minX = e), this.maxX > t && (this.maxX = t), this.minY < n && (this.minY = n), this.maxY > r && (this.maxY = r), this;
	}
	pad(e, t = e) {
		return this.minX -= e, this.maxX += e, this.minY -= t, this.maxY += t, this;
	}
	ceil() {
		return this.minX = Math.floor(this.minX), this.minY = Math.floor(this.minY), this.maxX = Math.ceil(this.maxX), this.maxY = Math.ceil(this.maxY), this;
	}
	clone() {
		return new e(this.minX, this.minY, this.maxX, this.maxY);
	}
	scale(e, t = e) {
		return this.minX *= e, this.minY *= t, this.maxX *= e, this.maxY *= t, this;
	}
	get x() {
		return this.minX;
	}
	set x(e) {
		let t = this.maxX - this.minX;
		this.minX = e, this.maxX = e + t;
	}
	get y() {
		return this.minY;
	}
	set y(e) {
		let t = this.maxY - this.minY;
		this.minY = e, this.maxY = e + t;
	}
	get width() {
		return this.maxX - this.minX;
	}
	set width(e) {
		this.maxX = this.minX + e;
	}
	get height() {
		return this.maxY - this.minY;
	}
	set height(e) {
		this.maxY = this.minY + e;
	}
	get left() {
		return this.minX;
	}
	get right() {
		return this.maxX;
	}
	get top() {
		return this.minY;
	}
	get bottom() {
		return this.maxY;
	}
	get isPositive() {
		return this.maxX - this.minX > 0 && this.maxY - this.minY > 0;
	}
	get isValid() {
		return this.minX + this.minY !== Infinity;
	}
	addVertexData(e, t, n, r) {
		let i = this.minX, a = this.minY, o = this.maxX, s = this.maxY;
		r ||= this.matrix;
		let c = r.a, l = r.b, u = r.c, d = r.d, f = r.tx, p = r.ty;
		for (let r = t; r < n; r += 2) {
			let t = e[r], n = e[r + 1], m = c * t + u * n + f, h = l * t + d * n + p;
			i = m < i ? m : i, a = h < a ? h : a, o = m > o ? m : o, s = h > s ? h : s;
		}
		this.minX = i, this.minY = a, this.maxX = o, this.maxY = s;
	}
	containsPoint(e, t) {
		return this.minX <= e && this.minY <= t && this.maxX >= e && this.maxY >= t;
	}
	toString() {
		return `[pixi.js:Bounds minX=${this.minX} minY=${this.minY} maxX=${this.maxX} maxY=${this.maxY} width=${this.width} height=${this.height}]`;
	}
	copyFrom(e) {
		return this.minX = e.minX, this.minY = e.minY, this.maxX = e.maxX, this.maxY = e.maxY, this;
	}
}, Te = {
	grad: .9,
	turn: 360,
	rad: 360 / (2 * Math.PI)
}, P = function(e) {
	return typeof e == "string" ? e.length > 0 : typeof e == "number";
}, F = function(e, t, n) {
	return t === void 0 && (t = 0), n === void 0 && (n = 10 ** t), Math.round(n * e) / n + 0;
}, I = function(e, t, n) {
	return t === void 0 && (t = 0), n === void 0 && (n = 1), e > n ? n : e > t ? e : t;
}, Ee = function(e) {
	return (e = isFinite(e) ? e % 360 : 0) > 0 ? e : e + 360;
}, De = function(e) {
	return {
		r: I(e.r, 0, 255),
		g: I(e.g, 0, 255),
		b: I(e.b, 0, 255),
		a: I(e.a)
	};
}, Oe = function(e) {
	return {
		r: F(e.r),
		g: F(e.g),
		b: F(e.b),
		a: F(e.a, 3)
	};
}, ke = /^#([0-9a-f]{3,8})$/i, L = function(e) {
	var t = e.toString(16);
	return t.length < 2 ? "0" + t : t;
}, Ae = function(e) {
	var t = e.r, n = e.g, r = e.b, i = e.a, a = Math.max(t, n, r), o = a - Math.min(t, n, r), s = o ? a === t ? (n - r) / o : a === n ? 2 + (r - t) / o : 4 + (t - n) / o : 0;
	return {
		h: 60 * (s < 0 ? s + 6 : s),
		s: a ? o / a * 100 : 0,
		v: a / 255 * 100,
		a: i
	};
}, je = function(e) {
	var t = e.h, n = e.s, r = e.v, i = e.a;
	t = t / 360 * 6, n /= 100, r /= 100;
	var a = Math.floor(t), o = r * (1 - n), s = r * (1 - (t - a) * n), c = r * (1 - (1 - t + a) * n), l = a % 6;
	return {
		r: 255 * [
			r,
			s,
			o,
			o,
			c,
			r
		][l],
		g: 255 * [
			c,
			r,
			r,
			s,
			o,
			o
		][l],
		b: 255 * [
			o,
			o,
			c,
			r,
			r,
			s
		][l],
		a: i
	};
}, Me = function(e) {
	return {
		h: Ee(e.h),
		s: I(e.s, 0, 100),
		l: I(e.l, 0, 100),
		a: I(e.a)
	};
}, Ne = function(e) {
	return {
		h: F(e.h),
		s: F(e.s),
		l: F(e.l),
		a: F(e.a, 3)
	};
}, Pe = function(e) {
	return je((n = (t = e).s, {
		h: t.h,
		s: (n *= ((r = t.l) < 50 ? r : 100 - r) / 100) > 0 ? 2 * n / (r + n) * 100 : 0,
		v: r + n,
		a: t.a
	}));
	var t, n, r;
}, R = function(e) {
	return {
		h: (t = Ae(e)).h,
		s: (i = (200 - (n = t.s)) * (r = t.v) / 100) > 0 && i < 200 ? n * r / 100 / (i <= 100 ? i : 200 - i) * 100 : 0,
		l: i / 2,
		a: t.a
	};
	var t, n, r, i;
}, Fe = /^hsla?\(\s*([+-]?\d*\.?\d+)(deg|rad|grad|turn)?\s*,\s*([+-]?\d*\.?\d+)%\s*,\s*([+-]?\d*\.?\d+)%\s*(?:,\s*([+-]?\d*\.?\d+)(%)?\s*)?\)$/i, Ie = /^hsla?\(\s*([+-]?\d*\.?\d+)(deg|rad|grad|turn)?\s+([+-]?\d*\.?\d+)%\s+([+-]?\d*\.?\d+)%\s*(?:\/\s*([+-]?\d*\.?\d+)(%)?\s*)?\)$/i, Le = /^rgba?\(\s*([+-]?\d*\.?\d+)(%)?\s*,\s*([+-]?\d*\.?\d+)(%)?\s*,\s*([+-]?\d*\.?\d+)(%)?\s*(?:,\s*([+-]?\d*\.?\d+)(%)?\s*)?\)$/i, Re = /^rgba?\(\s*([+-]?\d*\.?\d+)(%)?\s+([+-]?\d*\.?\d+)(%)?\s+([+-]?\d*\.?\d+)(%)?\s*(?:\/\s*([+-]?\d*\.?\d+)(%)?\s*)?\)$/i, ze = {
	string: [
		[function(e) {
			var t = ke.exec(e);
			return t ? (e = t[1]).length <= 4 ? {
				r: parseInt(e[0] + e[0], 16),
				g: parseInt(e[1] + e[1], 16),
				b: parseInt(e[2] + e[2], 16),
				a: e.length === 4 ? F(parseInt(e[3] + e[3], 16) / 255, 2) : 1
			} : e.length === 6 || e.length === 8 ? {
				r: parseInt(e.substr(0, 2), 16),
				g: parseInt(e.substr(2, 2), 16),
				b: parseInt(e.substr(4, 2), 16),
				a: e.length === 8 ? F(parseInt(e.substr(6, 2), 16) / 255, 2) : 1
			} : null : null;
		}, "hex"],
		[function(e) {
			var t = Le.exec(e) || Re.exec(e);
			return t ? t[2] !== t[4] || t[4] !== t[6] ? null : De({
				r: Number(t[1]) / (t[2] ? 100 / 255 : 1),
				g: Number(t[3]) / (t[4] ? 100 / 255 : 1),
				b: Number(t[5]) / (t[6] ? 100 / 255 : 1),
				a: t[7] === void 0 ? 1 : Number(t[7]) / (t[8] ? 100 : 1)
			}) : null;
		}, "rgb"],
		[function(e) {
			var t = Fe.exec(e) || Ie.exec(e);
			if (!t) return null;
			var n, r;
			return Pe(Me({
				h: (n = t[1], r = t[2], r === void 0 && (r = "deg"), Number(n) * (Te[r] || 1)),
				s: Number(t[3]),
				l: Number(t[4]),
				a: t[5] === void 0 ? 1 : Number(t[5]) / (t[6] ? 100 : 1)
			}));
		}, "hsl"]
	],
	object: [
		[function(e) {
			var t = e.r, n = e.g, r = e.b, i = e.a, a = i === void 0 ? 1 : i;
			return P(t) && P(n) && P(r) ? De({
				r: Number(t),
				g: Number(n),
				b: Number(r),
				a: Number(a)
			}) : null;
		}, "rgb"],
		[function(e) {
			var t = e.h, n = e.s, r = e.l, i = e.a, a = i === void 0 ? 1 : i;
			return !P(t) || !P(n) || !P(r) ? null : Pe(Me({
				h: Number(t),
				s: Number(n),
				l: Number(r),
				a: Number(a)
			}));
		}, "hsl"],
		[function(e) {
			var t = e.h, n = e.s, r = e.v, i = e.a, a = i === void 0 ? 1 : i;
			return !P(t) || !P(n) || !P(r) ? null : je(function(e) {
				return {
					h: Ee(e.h),
					s: I(e.s, 0, 100),
					v: I(e.v, 0, 100),
					a: I(e.a)
				};
			}({
				h: Number(t),
				s: Number(n),
				v: Number(r),
				a: Number(a)
			}));
		}, "hsv"]
	]
}, Be = function(e, t) {
	for (var n = 0; n < t.length; n++) {
		var r = t[n][0](e);
		if (r) return [r, t[n][1]];
	}
	return [null, void 0];
}, Ve = function(e) {
	return typeof e == "string" ? Be(e.trim(), ze.string) : typeof e == "object" && e ? Be(e, ze.object) : [null, void 0];
}, He = function(e, t) {
	var n = R(e);
	return {
		h: n.h,
		s: I(n.s + 100 * t, 0, 100),
		l: n.l,
		a: n.a
	};
}, Ue = function(e) {
	return (299 * e.r + 587 * e.g + 114 * e.b) / 1e3 / 255;
}, We = function(e, t) {
	var n = R(e);
	return {
		h: n.h,
		s: n.s,
		l: I(n.l + 100 * t, 0, 100),
		a: n.a
	};
}, Ge = function() {
	function e(e) {
		this.parsed = Ve(e)[0], this.rgba = this.parsed || {
			r: 0,
			g: 0,
			b: 0,
			a: 1
		};
	}
	return e.prototype.isValid = function() {
		return this.parsed !== null;
	}, e.prototype.brightness = function() {
		return F(Ue(this.rgba), 2);
	}, e.prototype.isDark = function() {
		return Ue(this.rgba) < .5;
	}, e.prototype.isLight = function() {
		return Ue(this.rgba) >= .5;
	}, e.prototype.toHex = function() {
		return e = Oe(this.rgba), t = e.r, n = e.g, r = e.b, a = (i = e.a) < 1 ? L(F(255 * i)) : "", "#" + L(t) + L(n) + L(r) + a;
		var e, t, n, r, i, a;
	}, e.prototype.toRgb = function() {
		return Oe(this.rgba);
	}, e.prototype.toRgbString = function() {
		return e = Oe(this.rgba), t = e.r, n = e.g, r = e.b, (i = e.a) < 1 ? "rgba(" + t + ", " + n + ", " + r + ", " + i + ")" : "rgb(" + t + ", " + n + ", " + r + ")";
		var e, t, n, r, i;
	}, e.prototype.toHsl = function() {
		return Ne(R(this.rgba));
	}, e.prototype.toHslString = function() {
		return e = Ne(R(this.rgba)), t = e.h, n = e.s, r = e.l, (i = e.a) < 1 ? "hsla(" + t + ", " + n + "%, " + r + "%, " + i + ")" : "hsl(" + t + ", " + n + "%, " + r + "%)";
		var e, t, n, r, i;
	}, e.prototype.toHsv = function() {
		return e = Ae(this.rgba), {
			h: F(e.h),
			s: F(e.s),
			v: F(e.v),
			a: F(e.a, 3)
		};
		var e;
	}, e.prototype.invert = function() {
		return z({
			r: 255 - (e = this.rgba).r,
			g: 255 - e.g,
			b: 255 - e.b,
			a: e.a
		});
		var e;
	}, e.prototype.saturate = function(e) {
		return e === void 0 && (e = .1), z(He(this.rgba, e));
	}, e.prototype.desaturate = function(e) {
		return e === void 0 && (e = .1), z(He(this.rgba, -e));
	}, e.prototype.grayscale = function() {
		return z(He(this.rgba, -1));
	}, e.prototype.lighten = function(e) {
		return e === void 0 && (e = .1), z(We(this.rgba, e));
	}, e.prototype.darken = function(e) {
		return e === void 0 && (e = .1), z(We(this.rgba, -e));
	}, e.prototype.rotate = function(e) {
		return e === void 0 && (e = 15), this.hue(this.hue() + e);
	}, e.prototype.alpha = function(e) {
		return typeof e == "number" ? z({
			r: (t = this.rgba).r,
			g: t.g,
			b: t.b,
			a: e
		}) : F(this.rgba.a, 3);
		var t;
	}, e.prototype.hue = function(e) {
		var t = R(this.rgba);
		return typeof e == "number" ? z({
			h: e,
			s: t.s,
			l: t.l,
			a: t.a
		}) : F(t.h);
	}, e.prototype.isEqual = function(e) {
		return this.toHex() === z(e).toHex();
	}, e;
}(), z = function(e) {
	return e instanceof Ge ? e : new Ge(e);
}, Ke = [], qe = function(e) {
	e.forEach(function(e) {
		Ke.indexOf(e) < 0 && (e(Ge, ze), Ke.push(e));
	});
};
//#endregion
//#region node_modules/@pixi/colord/plugins/names.mjs
function Je(e, t) {
	var n = {
		white: "#ffffff",
		bisque: "#ffe4c4",
		blue: "#0000ff",
		cadetblue: "#5f9ea0",
		chartreuse: "#7fff00",
		chocolate: "#d2691e",
		coral: "#ff7f50",
		antiquewhite: "#faebd7",
		aqua: "#00ffff",
		azure: "#f0ffff",
		whitesmoke: "#f5f5f5",
		papayawhip: "#ffefd5",
		plum: "#dda0dd",
		blanchedalmond: "#ffebcd",
		black: "#000000",
		gold: "#ffd700",
		goldenrod: "#daa520",
		gainsboro: "#dcdcdc",
		cornsilk: "#fff8dc",
		cornflowerblue: "#6495ed",
		burlywood: "#deb887",
		aquamarine: "#7fffd4",
		beige: "#f5f5dc",
		crimson: "#dc143c",
		cyan: "#00ffff",
		darkblue: "#00008b",
		darkcyan: "#008b8b",
		darkgoldenrod: "#b8860b",
		darkkhaki: "#bdb76b",
		darkgray: "#a9a9a9",
		darkgreen: "#006400",
		darkgrey: "#a9a9a9",
		peachpuff: "#ffdab9",
		darkmagenta: "#8b008b",
		darkred: "#8b0000",
		darkorchid: "#9932cc",
		darkorange: "#ff8c00",
		darkslateblue: "#483d8b",
		gray: "#808080",
		darkslategray: "#2f4f4f",
		darkslategrey: "#2f4f4f",
		deeppink: "#ff1493",
		deepskyblue: "#00bfff",
		wheat: "#f5deb3",
		firebrick: "#b22222",
		floralwhite: "#fffaf0",
		ghostwhite: "#f8f8ff",
		darkviolet: "#9400d3",
		magenta: "#ff00ff",
		green: "#008000",
		dodgerblue: "#1e90ff",
		grey: "#808080",
		honeydew: "#f0fff0",
		hotpink: "#ff69b4",
		blueviolet: "#8a2be2",
		forestgreen: "#228b22",
		lawngreen: "#7cfc00",
		indianred: "#cd5c5c",
		indigo: "#4b0082",
		fuchsia: "#ff00ff",
		brown: "#a52a2a",
		maroon: "#800000",
		mediumblue: "#0000cd",
		lightcoral: "#f08080",
		darkturquoise: "#00ced1",
		lightcyan: "#e0ffff",
		ivory: "#fffff0",
		lightyellow: "#ffffe0",
		lightsalmon: "#ffa07a",
		lightseagreen: "#20b2aa",
		linen: "#faf0e6",
		mediumaquamarine: "#66cdaa",
		lemonchiffon: "#fffacd",
		lime: "#00ff00",
		khaki: "#f0e68c",
		mediumseagreen: "#3cb371",
		limegreen: "#32cd32",
		mediumspringgreen: "#00fa9a",
		lightskyblue: "#87cefa",
		lightblue: "#add8e6",
		midnightblue: "#191970",
		lightpink: "#ffb6c1",
		mistyrose: "#ffe4e1",
		moccasin: "#ffe4b5",
		mintcream: "#f5fffa",
		lightslategray: "#778899",
		lightslategrey: "#778899",
		navajowhite: "#ffdead",
		navy: "#000080",
		mediumvioletred: "#c71585",
		powderblue: "#b0e0e6",
		palegoldenrod: "#eee8aa",
		oldlace: "#fdf5e6",
		paleturquoise: "#afeeee",
		mediumturquoise: "#48d1cc",
		mediumorchid: "#ba55d3",
		rebeccapurple: "#663399",
		lightsteelblue: "#b0c4de",
		mediumslateblue: "#7b68ee",
		thistle: "#d8bfd8",
		tan: "#d2b48c",
		orchid: "#da70d6",
		mediumpurple: "#9370db",
		purple: "#800080",
		pink: "#ffc0cb",
		skyblue: "#87ceeb",
		springgreen: "#00ff7f",
		palegreen: "#98fb98",
		red: "#ff0000",
		yellow: "#ffff00",
		slateblue: "#6a5acd",
		lavenderblush: "#fff0f5",
		peru: "#cd853f",
		palevioletred: "#db7093",
		violet: "#ee82ee",
		teal: "#008080",
		slategray: "#708090",
		slategrey: "#708090",
		aliceblue: "#f0f8ff",
		darkseagreen: "#8fbc8f",
		darkolivegreen: "#556b2f",
		greenyellow: "#adff2f",
		seagreen: "#2e8b57",
		seashell: "#fff5ee",
		tomato: "#ff6347",
		silver: "#c0c0c0",
		sienna: "#a0522d",
		lavender: "#e6e6fa",
		lightgreen: "#90ee90",
		orange: "#ffa500",
		orangered: "#ff4500",
		steelblue: "#4682b4",
		royalblue: "#4169e1",
		turquoise: "#40e0d0",
		yellowgreen: "#9acd32",
		salmon: "#fa8072",
		saddlebrown: "#8b4513",
		sandybrown: "#f4a460",
		rosybrown: "#bc8f8f",
		darksalmon: "#e9967a",
		lightgoldenrodyellow: "#fafad2",
		snow: "#fffafa",
		lightgrey: "#d3d3d3",
		lightgray: "#d3d3d3",
		dimgray: "#696969",
		dimgrey: "#696969",
		olivedrab: "#6b8e23",
		olive: "#808000"
	}, r = {};
	for (var i in n) r[n[i]] = i;
	var a = {};
	e.prototype.toName = function(t) {
		if (!(this.rgba.a || this.rgba.r || this.rgba.g || this.rgba.b)) return "transparent";
		var i, o, s = r[this.toHex()];
		if (s) return s;
		if (t?.closest) {
			var c = this.toRgb(), l = 1 / 0, u = "black";
			if (!a.length) for (var d in n) a[d] = new e(n[d]).toRgb();
			for (var f in n) {
				var p = (i = c, o = a[f], (i.r - o.r) ** 2 + (i.g - o.g) ** 2 + (i.b - o.b) ** 2);
				p < l && (l = p, u = f);
			}
			return u;
		}
	}, t.string.push([function(t) {
		var r = t.toLowerCase(), i = r === "transparent" ? "#0000" : n[r];
		return i ? new e(i).toRgb() : null;
	}, "name"]);
}
//#endregion
//#region node_modules/pixi.js/lib/color/Color.mjs
qe([Je]);
var B = class e {
	constructor(e = 16777215) {
		this._value = null, this._components = /* @__PURE__ */ new Float32Array(4), this._components.fill(1), this._int = 16777215, this.value = e;
	}
	get red() {
		return this._components[0];
	}
	get green() {
		return this._components[1];
	}
	get blue() {
		return this._components[2];
	}
	get alpha() {
		return this._components[3];
	}
	setValue(e) {
		return this.value = e, this;
	}
	set value(t) {
		if (t instanceof e) this._value = this._cloneSource(t._value), this._int = t._int, this._components.set(t._components);
		else if (t === null) throw Error("Cannot set Color#value to null");
		else (this._value === null || !this._isSourceEqual(this._value, t)) && (this._value = this._cloneSource(t), this._normalize(this._value));
	}
	get value() {
		return this._value;
	}
	_cloneSource(e) {
		return typeof e == "string" || typeof e == "number" || e instanceof Number || e === null ? e : Array.isArray(e) || ArrayBuffer.isView(e) ? e.slice(0) : typeof e == "object" && e ? { ...e } : e;
	}
	_isSourceEqual(e, t) {
		let n = typeof e;
		if (n !== typeof t) return !1;
		if (n === "number" || n === "string" || e instanceof Number) return e === t;
		if (Array.isArray(e) && Array.isArray(t) || ArrayBuffer.isView(e) && ArrayBuffer.isView(t)) return e.length === t.length && e.every((e, n) => e === t[n]);
		if (e !== null && t !== null) {
			let n = Object.keys(e), r = Object.keys(t);
			return n.length === r.length && n.every((n) => e[n] === t[n]);
		}
		return e === t;
	}
	toRgba() {
		let [e, t, n, r] = this._components;
		return {
			r: e,
			g: t,
			b: n,
			a: r
		};
	}
	toRgb() {
		let [e, t, n] = this._components;
		return {
			r: e,
			g: t,
			b: n
		};
	}
	toRgbaString() {
		let [e, t, n] = this.toUint8RgbArray();
		return `rgba(${e},${t},${n},${this.alpha})`;
	}
	toUint8RgbArray(e) {
		let [t, n, r] = this._components;
		return this._arrayRgb ||= [], e ||= this._arrayRgb, e[0] = Math.round(t * 255), e[1] = Math.round(n * 255), e[2] = Math.round(r * 255), e;
	}
	toArray(e) {
		this._arrayRgba ||= [], e ||= this._arrayRgba;
		let [t, n, r, i] = this._components;
		return e[0] = t, e[1] = n, e[2] = r, e[3] = i, e;
	}
	toRgbArray(e) {
		this._arrayRgb ||= [], e ||= this._arrayRgb;
		let [t, n, r] = this._components;
		return e[0] = t, e[1] = n, e[2] = r, e;
	}
	toNumber() {
		return this._int;
	}
	toBgrNumber() {
		let [e, t, n] = this.toUint8RgbArray();
		return (n << 16) + (t << 8) + e;
	}
	toLittleEndianNumber() {
		let e = this._int;
		return (e >> 16) + (e & 65280) + ((e & 255) << 16);
	}
	multiply(t) {
		let [n, r, i, a] = e._temp.setValue(t)._components;
		return this._components[0] *= n, this._components[1] *= r, this._components[2] *= i, this._components[3] *= a, this._refreshInt(), this._value = null, this;
	}
	premultiply(e, t = !0) {
		return t && (this._components[0] *= e, this._components[1] *= e, this._components[2] *= e), this._components[3] = e, this._refreshInt(), this._value = null, this;
	}
	toPremultiplied(e, t = !0) {
		if (e === 1) return (255 << 24) + this._int;
		if (e === 0) return t ? 0 : this._int;
		let n = this._int >> 16 & 255, r = this._int >> 8 & 255, i = this._int & 255;
		return t && (n = n * e + .5 | 0, r = r * e + .5 | 0, i = i * e + .5 | 0), (e * 255 << 24) + (n << 16) + (r << 8) + i;
	}
	toHex() {
		let e = this._int.toString(16);
		return `#${"000000".substring(0, 6 - e.length) + e}`;
	}
	toHexa() {
		let e = Math.round(this._components[3] * 255).toString(16);
		return this.toHex() + "00".substring(0, 2 - e.length) + e;
	}
	setAlpha(e) {
		return this._components[3] = this._clamp(e), this._value = null, this;
	}
	_normalize(t) {
		let n, r, i, a;
		if ((typeof t == "number" || t instanceof Number) && t >= 0 && t <= 16777215) {
			let e = t;
			n = (e >> 16 & 255) / 255, r = (e >> 8 & 255) / 255, i = (e & 255) / 255, a = 1;
		} else if ((Array.isArray(t) || t instanceof Float32Array) && t.length >= 3 && t.length <= 4) t = this._clamp(t), [n, r, i, a = 1] = t;
		else if ((t instanceof Uint8Array || t instanceof Uint8ClampedArray) && t.length >= 3 && t.length <= 4) t = this._clamp(t, 0, 255), [n, r, i, a = 255] = t, n /= 255, r /= 255, i /= 255, a /= 255;
		else if (typeof t == "string" || typeof t == "object") {
			if (typeof t == "string") {
				let n = e.HEX_PATTERN.exec(t);
				n && (t = `#${n[2]}`);
			}
			let o = z(t);
			o.isValid() && ({r: n, g: r, b: i, a} = o.rgba, n /= 255, r /= 255, i /= 255);
		}
		if (n !== void 0) this._components[0] = n, this._components[1] = r, this._components[2] = i, this._components[3] = a, this._refreshInt();
		else throw Error(`Unable to convert color ${t}`);
	}
	_refreshInt() {
		this._clamp(this._components);
		let [e, t, n] = this._components;
		this._int = (e * 255 << 16) + (t * 255 << 8) + (n * 255 | 0);
	}
	_clamp(e, t = 0, n = 1) {
		return typeof e == "number" ? Math.min(Math.max(e, t), n) : (e.forEach((r, i) => {
			e[i] = Math.min(Math.max(r, t), n);
		}), e);
	}
	static isColorLike(t) {
		return typeof t == "number" || typeof t == "string" || t instanceof Number || t instanceof e || Array.isArray(t) || t instanceof Uint8Array || t instanceof Uint8ClampedArray || t instanceof Float32Array || t.r !== void 0 && t.g !== void 0 && t.b !== void 0 || t.r !== void 0 && t.g !== void 0 && t.b !== void 0 && t.a !== void 0 || t.h !== void 0 && t.s !== void 0 && t.l !== void 0 || t.h !== void 0 && t.s !== void 0 && t.l !== void 0 && t.a !== void 0 || t.h !== void 0 && t.s !== void 0 && t.v !== void 0 || t.h !== void 0 && t.s !== void 0 && t.v !== void 0 && t.a !== void 0;
	}
};
B.shared = new B(), B._temp = new B(), B.HEX_PATTERN = /^(#|0x)?(([a-f0-9]{3}){1,2}([a-f0-9]{2})?)$/i;
var Ye = B, Xe = {
	cullArea: null,
	cullable: !1,
	cullableChildren: !0
}, Ze = 0, Qe = 500;
function V(...e) {
	Ze !== Qe && (Ze++, Ze === Qe ? console.warn("PixiJS Warning: too many warnings, no more warnings will be reported to the console by PixiJS.") : console.warn("PixiJS Warning: ", ...e));
}
//#endregion
//#region node_modules/pixi.js/lib/utils/pool/GlobalResourceRegistry.mjs
var $e = {
	_registeredResources: /* @__PURE__ */ new Set(),
	register(e) {
		this._registeredResources.add(e);
	},
	unregister(e) {
		this._registeredResources.delete(e);
	},
	release() {
		this._registeredResources.forEach((e) => e.clear());
	},
	get registeredCount() {
		return this._registeredResources.size;
	},
	isRegistered(e) {
		return this._registeredResources.has(e);
	},
	reset() {
		this._registeredResources.clear();
	}
}, et = class {
	constructor(e, t) {
		this._pool = [], this._count = 0, this._index = 0, this._classType = e, t && this.prepopulate(t);
	}
	prepopulate(e) {
		for (let t = 0; t < e; t++) this._pool[this._index++] = new this._classType();
		this._count += e;
	}
	get(e) {
		let t;
		return this._index > 0 ? t = this._pool[--this._index] : (t = new this._classType(), this._count++), t.init?.(e), t;
	}
	return(e) {
		e.reset?.(), this._pool[this._index++] = e;
	}
	get totalSize() {
		return this._count;
	}
	get totalFree() {
		return this._index;
	}
	get totalUsed() {
		return this._count - this._index;
	}
	clear() {
		if (this._pool.length > 0 && this._pool[0].destroy) for (let e = 0; e < this._index; e++) this._pool[e].destroy();
		this._pool.length = 0, this._count = 0, this._index = 0;
	}
}, H = new class {
	constructor() {
		this._poolsByClass = /* @__PURE__ */ new Map();
	}
	prepopulate(e, t) {
		this.getPool(e).prepopulate(t);
	}
	get(e, t) {
		return this.getPool(e).get(t);
	}
	return(e) {
		this.getPool(e.constructor).return(e);
	}
	getPool(e) {
		return this._poolsByClass.has(e) || this._poolsByClass.set(e, new et(e)), this._poolsByClass.get(e);
	}
	stats() {
		let e = {};
		return this._poolsByClass.forEach((t) => {
			let n = e[t._classType.name] ? t._classType.name + t._classType.ID : t._classType.name;
			e[n] = {
				free: t.totalFree,
				used: t.totalUsed,
				size: t.totalSize
			};
		}), e;
	}
	clear() {
		this._poolsByClass.forEach((e) => e.clear()), this._poolsByClass.clear();
	}
}();
$e.register(H);
//#endregion
//#region node_modules/pixi.js/lib/scene/container/container-mixins/cacheAsTextureMixin.mjs
var tt = {
	get isCachedAsTexture() {
		return !!this.renderGroup?.isCachedAsTexture;
	},
	cacheAsTexture(e) {
		typeof e == "boolean" && e === !1 ? this.disableRenderGroup() : (this.enableRenderGroup(), this.renderGroup.enableCacheAsTexture(e === !0 ? {} : e));
	},
	updateCacheTexture() {
		this.renderGroup?.updateCacheTexture();
	},
	get cacheAsBitmap() {
		return this.isCachedAsTexture;
	},
	set cacheAsBitmap(e) {
		A("v8.6.0", "cacheAsBitmap is deprecated, use cacheAsTexture instead."), this.cacheAsTexture(e);
	}
};
//#endregion
//#region node_modules/pixi.js/lib/utils/data/removeItems.mjs
function nt(e, t, n) {
	let r = e.length, i;
	if (t >= r || n === 0) return;
	n = t + n > r ? r - t : n;
	let a = r - n;
	for (i = t; i < a; ++i) e[i] = e[i + n];
	e.length = a;
}
//#endregion
//#region node_modules/pixi.js/lib/scene/container/container-mixins/childrenHelperMixin.mjs
var rt = {
	allowChildren: !0,
	removeChildren(e = 0, t) {
		let n = t ?? this.children.length, r = n - e, i = [];
		if (r > 0 && r <= n) {
			for (let t = n - 1; t >= e; t--) {
				let e = this.children[t];
				e && (i.push(e), e.parent = null);
			}
			nt(this.children, e, n);
			let t = this.renderGroup || this.parentRenderGroup;
			t && t.removeChildren(i);
			for (let e = 0; e < i.length; ++e) {
				let t = i[e];
				t.parentRenderLayer?.detach(t), this.emit("childRemoved", t, this, e), i[e].emit("removed", this);
			}
			return i.length > 0 && this._didViewChangeTick++, i;
		}
		if (r === 0 && this.children.length === 0) return i;
		throw RangeError("removeChildren: numeric values are outside the acceptable range.");
	},
	removeChildAt(e) {
		let t = this.getChildAt(e);
		return this.removeChild(t);
	},
	getChildAt(e) {
		if (e < 0 || e >= this.children.length) throw Error(`getChildAt: Index (${e}) does not exist.`);
		return this.children[e];
	},
	setChildIndex(e, t) {
		if (t < 0 || t >= this.children.length) throw Error(`The index ${t} supplied is out of bounds ${this.children.length}`);
		this.getChildIndex(e), this.addChildAt(e, t);
	},
	getChildIndex(e) {
		let t = this.children.indexOf(e);
		if (t === -1) throw Error("The supplied Container must be a child of the caller");
		return t;
	},
	addChildAt(e, t) {
		this.allowChildren || A(O, "addChildAt: Only Containers will be allowed to add children in v8.0.0");
		let { children: n } = this;
		if (t < 0 || t > n.length) throw Error(`${e}addChildAt: The index ${t} supplied is out of bounds ${n.length}`);
		let r = e.parent === this;
		if (e.parent) {
			let n = e.parent.children.indexOf(e);
			if (r) {
				if (n === t) return e;
				e.parent.children.splice(n, 1);
			} else e.removeFromParent();
		}
		t === n.length ? n.push(e) : n.splice(t, 0, e);
		let i = this.renderGroup || this.parentRenderGroup;
		return this.sortableChildren && (this.sortDirty = !0), r ? (i && (i.structureDidChange = !0), e) : (e.parent = this, e.didChange = !0, e._updateFlags = 15, i && i.addChild(e), this.emit("childAdded", e, this, t), e.emit("added", this), e);
	},
	swapChildren(e, t) {
		if (e === t) return;
		let n = this.getChildIndex(e), r = this.getChildIndex(t);
		this.children[n] = t, this.children[r] = e;
		let i = this.renderGroup || this.parentRenderGroup;
		i && (i.structureDidChange = !0), this._didContainerChangeTick++;
	},
	removeFromParent() {
		this.parent?.removeChild(this);
	},
	reparentChild(...e) {
		return e.length === 1 ? this.reparentChildAt(e[0], this.children.length) : (e.forEach((e) => this.reparentChildAt(e, this.children.length)), e[0]);
	},
	reparentChildAt(e, t) {
		if (e.parent === this) return this.setChildIndex(e, t), e;
		let n = e.worldTransform.clone();
		e.removeFromParent(), this.addChildAt(e, t);
		let r = this.worldTransform.clone();
		return r.invert(), n.prepend(r), e.setFromMatrix(n), e;
	},
	replaceChild(e, t) {
		e.updateLocalTransform(), this.addChildAt(t, this.getChildIndex(e)), t.setFromMatrix(e.localTransform), t.updateLocalTransform(), this.removeChild(e);
	}
}, it = {
	collectRenderables(e, t, n) {
		this.parentRenderLayer && this.parentRenderLayer !== n || this.globalDisplayStatus < 7 || !this.includeInBuild || (this.sortableChildren && this.sortChildren(), this.isSimple ? this.collectRenderablesSimple(e, t, n) : this.renderGroup ? t.renderPipes.renderGroup.addRenderGroup(this.renderGroup, e) : this.collectRenderablesWithEffects(e, t, n));
	},
	collectRenderablesSimple(e, t, n) {
		let r = this.children, i = r.length;
		for (let a = 0; a < i; a++) r[a].collectRenderables(e, t, n);
	},
	collectRenderablesWithEffects(e, t, n) {
		let { renderPipes: r } = t;
		for (let t = 0; t < this.effects.length; t++) {
			let n = this.effects[t];
			r[n.pipe].push(n, this, e);
		}
		this.collectRenderablesSimple(e, t, n);
		for (let t = this.effects.length - 1; t >= 0; t--) {
			let n = this.effects[t];
			r[n.pipe].pop(n, this, e);
		}
	}
}, at = class {
	constructor() {
		this.pipe = "filter", this.priority = 1;
	}
	destroy() {
		for (let e = 0; e < this.filters.length; e++) this.filters[e].destroy();
		this.filters = null, this.filterArea = null;
	}
}, ot = new class {
	constructor() {
		this._effectClasses = [], this._tests = [], this._initialized = !1;
	}
	init() {
		this._initialized || (this._initialized = !0, this._effectClasses.forEach((e) => {
			this.add({
				test: e.test,
				maskClass: e
			});
		}));
	}
	add(e) {
		this._tests.push(e);
	}
	getMaskEffect(e) {
		this._initialized || this.init();
		for (let t = 0; t < this._tests.length; t++) {
			let n = this._tests[t];
			if (n.test(e)) return H.get(n.maskClass, e);
		}
		return e;
	}
	returnMaskEffect(e) {
		H.return(e);
	}
}();
p.handleByList(u.MaskEffect, ot._effectClasses);
//#endregion
//#region node_modules/pixi.js/lib/scene/container/container-mixins/effectsMixin.mjs
var st = {
	_maskEffect: null,
	_maskOptions: {
		inverse: !1,
		channel: "red"
	},
	_filterEffect: null,
	effects: [],
	_markStructureAsChanged() {
		let e = this.renderGroup || this.parentRenderGroup;
		e && (e.structureDidChange = !0);
	},
	addEffect(e) {
		this.effects.indexOf(e) === -1 && (this.effects.push(e), this.effects.sort((e, t) => e.priority - t.priority), this._markStructureAsChanged(), this._updateIsSimple());
	},
	removeEffect(e) {
		let t = this.effects.indexOf(e);
		t !== -1 && (this.effects.splice(t, 1), this._markStructureAsChanged(), this._updateIsSimple());
	},
	set mask(e) {
		let t = this._maskEffect;
		t?.mask !== e && (t && (this.removeEffect(t), ot.returnMaskEffect(t), this._maskEffect = null), e != null && (this._maskEffect = ot.getMaskEffect(e), this.addEffect(this._maskEffect)));
	},
	get mask() {
		return this._maskEffect?.mask;
	},
	setMask(e) {
		this._maskOptions = {
			...this._maskOptions,
			...e
		}, e.mask && (this.mask = e.mask), this._markStructureAsChanged();
	},
	set filters(e) {
		!Array.isArray(e) && e && (e = [e]);
		let t = this._filterEffect ||= new at();
		e = e;
		let n = e?.length > 0, r = n !== t.filters?.length > 0;
		e = Array.isArray(e) ? e.slice(0) : e, t.filters = Object.freeze(e), r && (n ? this.addEffect(t) : (this.removeEffect(t), t.filters = e ?? null));
	},
	get filters() {
		return this._filterEffect?.filters;
	},
	set filterArea(e) {
		this._filterEffect ||= new at(), this._filterEffect.filterArea = e;
	},
	get filterArea() {
		return this._filterEffect?.filterArea;
	}
}, ct = {
	label: null,
	get name() {
		return A(O, "Container.name property has been removed, use Container.label instead"), this.label;
	},
	set name(e) {
		A(O, "Container.name property has been removed, use Container.label instead"), this.label = e;
	},
	getChildByName(e, t = !1) {
		return this.getChildByLabel(e, t);
	},
	getChildByLabel(e, t = !1) {
		let n = this.children;
		for (let t = 0; t < n.length; t++) {
			let r = n[t];
			if (r.label === e || e instanceof RegExp && e.test(r.label)) return r;
		}
		if (t) for (let t = 0; t < n.length; t++) {
			let r = n[t].getChildByLabel(e, !0);
			if (r) return r;
		}
		return null;
	},
	getChildrenByLabel(e, t = !1, n = []) {
		let r = this.children;
		for (let t = 0; t < r.length; t++) {
			let i = r[t];
			(i.label === e || e instanceof RegExp && e.test(i.label)) && n.push(i);
		}
		if (t) for (let t = 0; t < r.length; t++) r[t].getChildrenByLabel(e, !0, n);
		return n;
	}
}, U = H.getPool(x), W = H.getPool(N), lt = new x(), ut = {
	getFastGlobalBounds(e, t) {
		t ||= new N(), t.clear(), this._getGlobalBoundsRecursive(!!e, t, this.parentRenderLayer), t.isValid || t.set(0, 0, 0, 0);
		let n = this.renderGroup || this.parentRenderGroup;
		return t.applyMatrix(n.worldTransform), t;
	},
	_getGlobalBoundsRecursive(e, t, n) {
		let r = t;
		if (e && this.parentRenderLayer && this.parentRenderLayer !== n || this.localDisplayStatus !== 7 || !this.measurable) return;
		let i = !!this.effects.length;
		if ((this.renderGroup || i) && (r = W.get().clear()), this.boundsArea) t.addRect(this.boundsArea, this.worldTransform);
		else {
			if (this.renderPipeId) {
				let e = this.bounds;
				r.addFrame(e.minX, e.minY, e.maxX, e.maxY, this.groupTransform);
			}
			let t = this.children;
			for (let i = 0; i < t.length; i++) t[i]._getGlobalBoundsRecursive(e, r, n);
		}
		if (i) {
			let e = !1, n = this.renderGroup || this.parentRenderGroup;
			for (let t = 0; t < this.effects.length; t++) this.effects[t].addBounds && (e || (e = !0, r.applyMatrix(n.worldTransform)), this.effects[t].addBounds(r, !0));
			e && r.applyMatrix(n.worldTransform.copyTo(lt).invert()), t.addBounds(r), W.return(r);
		} else this.renderGroup && (t.addBounds(r, this.relativeGroupTransform), W.return(r));
	}
};
//#endregion
//#region node_modules/pixi.js/lib/scene/container/bounds/getGlobalBounds.mjs
function dt(e, t, n) {
	n.clear();
	let r, i;
	return e.parent ? t ? r = e.parent.worldTransform : (i = U.get().identity(), r = pt(e, i)) : r = x.IDENTITY, ft(e, n, r, t), i && U.return(i), n.isValid || n.set(0, 0, 0, 0), n;
}
function ft(e, t, n, r) {
	if (!e.visible || !e.measurable) return;
	let i;
	r ? i = e.worldTransform : (e.updateLocalTransform(), i = U.get(), i.appendFrom(e.localTransform, n));
	let a = t, o = !!e.effects.length;
	if (o && (t = W.get().clear()), e.boundsArea) t.addRect(e.boundsArea, i);
	else {
		let n = e.bounds;
		n && !n.isEmpty() && (t.matrix = i, t.addBounds(n));
		for (let n = 0; n < e.children.length; n++) ft(e.children[n], t, i, r);
	}
	if (o) {
		for (let n = 0; n < e.effects.length; n++) e.effects[n].addBounds?.(t);
		a.addBounds(t, x.IDENTITY), W.return(t);
	}
	r || U.return(i);
}
function pt(e, t) {
	let n = e.parent;
	return n && (pt(n, t), n.updateLocalTransform(), t.append(n.localTransform)), t;
}
//#endregion
//#region node_modules/pixi.js/lib/scene/container/utils/multiplyHexColors.mjs
function mt(e, t) {
	if (e === 16777215 || !t) return t;
	if (t === 16777215 || !e) return e;
	let n = e >> 16 & 255, r = e >> 8 & 255, i = e & 255, a = t >> 16 & 255, o = t >> 8 & 255, s = t & 255, c = n * a / 255 | 0, l = r * o / 255 | 0, u = i * s / 255 | 0;
	return (c << 16) + (l << 8) + u;
}
//#endregion
//#region node_modules/pixi.js/lib/scene/container/utils/multiplyColors.mjs
var ht = 16777215;
function gt(e, t) {
	return e === ht ? t : t === ht ? e : mt(e, t);
}
//#endregion
//#region node_modules/pixi.js/lib/scene/container/container-mixins/getGlobalMixin.mjs
function G(e) {
	return ((e & 255) << 16) + (e & 65280) + (e >> 16 & 255);
}
var _t = {
	getGlobalAlpha(e) {
		if (e) return this.renderGroup ? this.renderGroup.worldAlpha : this.parentRenderGroup ? this.parentRenderGroup.worldAlpha * this.alpha : this.alpha;
		let t = this.alpha, n = this.parent;
		for (; n;) t *= n.alpha, n = n.parent;
		return t;
	},
	getGlobalTransform(e = new x(), t) {
		if (t) return e.copyFrom(this.worldTransform);
		this.updateLocalTransform();
		let n = pt(this, U.get().identity());
		return e.appendFrom(this.localTransform, n), U.return(n), e;
	},
	getGlobalTint(e) {
		if (e) return this.renderGroup ? G(this.renderGroup.worldColor) : this.parentRenderGroup ? G(gt(this.localColor, this.parentRenderGroup.worldColor)) : this.tint;
		let t = this.localColor, n = this.parent;
		for (; n;) t = gt(t, n.localColor), n = n.parent;
		return G(t);
	}
};
//#endregion
//#region node_modules/pixi.js/lib/scene/container/bounds/getLocalBounds.mjs
function vt(e, t, n) {
	return t.clear(), n ||= x.IDENTITY, yt(e, t, n, e, !0), t.isValid || t.set(0, 0, 0, 0), t;
}
function yt(e, t, n, r, i) {
	let a;
	if (i) a = U.get(), a = n.copyTo(a);
	else {
		if (!e.visible || !e.measurable) return;
		e.updateLocalTransform();
		let t = e.localTransform;
		a = U.get(), a.appendFrom(t, n);
	}
	let o = t, s = !!e.effects.length;
	if (s && (t = W.get().clear()), e.boundsArea) t.addRect(e.boundsArea, a);
	else {
		e.renderPipeId && (t.matrix = a, t.addBounds(e.bounds));
		let n = e.children;
		for (let e = 0; e < n.length; e++) yt(n[e], t, a, r, !1);
	}
	if (s) {
		for (let n = 0; n < e.effects.length; n++) e.effects[n].addLocalBounds?.(t, r);
		o.addBounds(t, x.IDENTITY), W.return(t);
	}
	U.return(a);
}
//#endregion
//#region node_modules/pixi.js/lib/scene/container/utils/checkChildrenDidChange.mjs
function bt(e, t) {
	let n = e.children;
	for (let e = 0; e < n.length; e++) {
		let r = n[e], i = r.uid, a = (r._didViewChangeTick & 65535) << 16 | r._didContainerChangeTick & 65535, o = t.index;
		(t.data[o] !== i || t.data[o + 1] !== a) && (t.data[t.index] = i, t.data[t.index + 1] = a, t.didChange = !0), t.index = o + 2, r.children.length && bt(r, t);
	}
	return t.didChange;
}
//#endregion
//#region node_modules/pixi.js/lib/scene/container/container-mixins/measureMixin.mjs
var xt = new x(), St = {
	_localBoundsCacheId: -1,
	_localBoundsCacheData: null,
	_setWidth(e, t) {
		let n = Math.sign(this.scale.x) || 1;
		t === 0 ? this.scale.x = n : this.scale.x = e / t * n;
	},
	_setHeight(e, t) {
		let n = Math.sign(this.scale.y) || 1;
		t === 0 ? this.scale.y = n : this.scale.y = e / t * n;
	},
	getLocalBounds() {
		this._localBoundsCacheData ||= {
			data: [],
			index: 1,
			didChange: !1,
			localBounds: new N()
		};
		let e = this._localBoundsCacheData;
		return e.index = 1, e.didChange = !1, e.data[0] !== this._didViewChangeTick && (e.didChange = !0, e.data[0] = this._didViewChangeTick), bt(this, e), e.didChange && vt(this, e.localBounds, xt), e.localBounds;
	},
	getBounds(e, t) {
		return dt(this, e, t || new N());
	}
}, Ct = {
	_onRender: null,
	set onRender(e) {
		let t = this.renderGroup || this.parentRenderGroup;
		if (!e) {
			this._onRender && t?.removeOnRender(this), this._onRender = null;
			return;
		}
		this._onRender || t?.addOnRender(this), this._onRender = e;
	},
	get onRender() {
		return this._onRender;
	}
}, wt = {
	_zIndex: 0,
	sortDirty: !1,
	sortableChildren: !1,
	get zIndex() {
		return this._zIndex;
	},
	set zIndex(e) {
		this._zIndex !== e && (this._zIndex = e, this.depthOfChildModified());
	},
	depthOfChildModified() {
		this.parent && (this.parent.sortableChildren = !0, this.parent.sortDirty = !0), this.parentRenderGroup && (this.parentRenderGroup.structureDidChange = !0);
	},
	sortChildren() {
		this.sortDirty && (this.sortDirty = !1, this.children.sort(Tt));
	}
};
function Tt(e, t) {
	return e._zIndex - t._zIndex;
}
//#endregion
//#region node_modules/pixi.js/lib/scene/container/container-mixins/toLocalGlobalMixin.mjs
var Et = {
	getGlobalPosition(e = new y(), t = !1) {
		return this.parent ? this.parent.toGlobal(this._position, e, t) : (e.x = this._position.x, e.y = this._position.y), e;
	},
	toGlobal(e, t, n = !1) {
		let r = this.getGlobalTransform(U.get(), n);
		return t = r.apply(e, t), U.return(r), t;
	},
	toLocal(e, t, n, r) {
		t && (e = t.toGlobal(e, n, r));
		let i = this.getGlobalTransform(U.get(), r);
		return n = i.applyInverse(e, n), U.return(i), n;
	}
}, Dt = class {
	constructor() {
		this.uid = D("instructionSet"), this.instructions = [], this.instructionSize = 0, this.renderables = [], this.gcTick = 0;
	}
	reset() {
		this.instructionSize = 0;
	}
	destroy() {
		this.instructions.length = 0, this.renderables.length = 0, this.renderPipes = null, this.gcTick = 0;
	}
	add(e) {
		this.instructions[this.instructionSize++] = e;
	}
	log() {
		this.instructions.length = this.instructionSize, console.table(this.instructions, ["type", "action"]);
	}
}, Ot = 0, kt = new class {
	constructor(e) {
		this._poolKeyHash = /* @__PURE__ */ Object.create(null), this._texturePool = {}, this.textureOptions = e || {}, this.enableFullScreen = !1, this.textureStyle = new ve(this.textureOptions);
	}
	createTexture(e, t, n, r) {
		return new M({
			source: new j({
				...this.textureOptions,
				width: e,
				height: t,
				resolution: 1,
				antialias: n,
				autoGarbageCollect: !1,
				autoGenerateMipmaps: r
			}),
			label: `texturePool_${Ot++}`
		});
	}
	getOptimalTexture(e, t, n = 1, r, i = !1) {
		let a = Math.ceil(e * n - 1e-6), o = Math.ceil(t * n - 1e-6);
		a = fe(a), o = fe(o);
		let s = +!!r, c = +!!i, l = (a << 17) + (o << 2) + (c << 1) + s;
		this._texturePool[l] || (this._texturePool[l] = []);
		let u = this._texturePool[l].pop();
		return u ||= this.createTexture(a, o, r, i), u.source._resolution = n, u.source.width = a / n, u.source.height = o / n, u.source.pixelWidth = a, u.source.pixelHeight = o, u.frame.x = 0, u.frame.y = 0, u.frame.width = e, u.frame.height = t, u.updateUvs(), this._poolKeyHash[u.uid] = l, u;
	}
	getSameSizeTexture(e, t = !1) {
		let n = e.source;
		return this.getOptimalTexture(e.width, e.height, n._resolution, t);
	}
	returnTexture(e, t = !1) {
		let n = this._poolKeyHash[e.uid];
		t && (e.source.style = this.textureStyle), this._texturePool[n].push(e);
	}
	clear(e) {
		if (e = e !== !1, e) for (let e in this._texturePool) {
			let t = this._texturePool[e];
			if (t) for (let e = 0; e < t.length; e++) t[e].destroy(!0);
		}
		this._texturePool = {};
	}
}();
$e.register(kt);
//#endregion
//#region node_modules/pixi.js/lib/scene/container/RenderGroup.mjs
var At = class {
	constructor() {
		this.renderPipeId = "renderGroup", this.root = null, this.canBundle = !1, this.renderGroupParent = null, this.renderGroupChildren = [], this.worldTransform = new x(), this.worldColorAlpha = 4294967295, this.worldColor = 16777215, this.worldAlpha = 1, this.childrenToUpdate = /* @__PURE__ */ Object.create(null), this.updateTick = 0, this.gcTick = 0, this.childrenRenderablesToUpdate = {
			list: [],
			index: 0
		}, this.structureDidChange = !0, this.instructionSet = new Dt(), this._onRenderContainers = [], this.textureNeedsUpdate = !0, this.isCachedAsTexture = !1, this._matrixDirty = 7;
	}
	init(e) {
		this.root = e, e._onRender && this.addOnRender(e), e.didChange = !0;
		let t = e.children;
		for (let e = 0; e < t.length; e++) {
			let n = t[e];
			n._updateFlags = 15, this.addChild(n);
		}
	}
	enableCacheAsTexture(e = {}) {
		this.textureOptions = e, this.isCachedAsTexture = !0, this.textureNeedsUpdate = !0;
	}
	disableCacheAsTexture() {
		this.isCachedAsTexture = !1, this.texture &&= (kt.returnTexture(this.texture, !0), null);
	}
	updateCacheTexture() {
		this.textureNeedsUpdate = !0;
		let e = this._parentCacheAsTextureRenderGroup;
		e && !e.textureNeedsUpdate && e.updateCacheTexture();
	}
	reset() {
		this.renderGroupChildren.length = 0;
		for (let e in this.childrenToUpdate) {
			let t = this.childrenToUpdate[e];
			t.list.fill(null), t.index = 0;
		}
		this.childrenRenderablesToUpdate.index = 0, this.childrenRenderablesToUpdate.list.fill(null), this.root = null, this.updateTick = 0, this.structureDidChange = !0, this._onRenderContainers.length = 0, this.renderGroupParent = null, this.disableCacheAsTexture();
	}
	get localTransform() {
		return this.root.localTransform;
	}
	addRenderGroupChild(e) {
		e.renderGroupParent && e.renderGroupParent._removeRenderGroupChild(e), e.renderGroupParent = this, this.renderGroupChildren.push(e);
	}
	_removeRenderGroupChild(e) {
		let t = this.renderGroupChildren.indexOf(e);
		t > -1 && this.renderGroupChildren.splice(t, 1), e.renderGroupParent = null;
	}
	addChild(e) {
		if (this.structureDidChange = !0, e.parentRenderGroup = this, e.updateTick = -1, e.relativeRenderGroupDepth = e.parent === this.root ? 1 : e.parent.relativeRenderGroupDepth + 1, e.didChange = !0, this.onChildUpdate(e), e.renderGroup) {
			this.addRenderGroupChild(e.renderGroup);
			return;
		}
		e._onRender && this.addOnRender(e);
		let t = e.children;
		for (let e = 0; e < t.length; e++) this.addChild(t[e]);
	}
	removeChild(e) {
		if (this.structureDidChange = !0, e._onRender && (e.renderGroup || this.removeOnRender(e)), e.parentRenderGroup = null, e.renderGroup) {
			this._removeRenderGroupChild(e.renderGroup);
			return;
		}
		let t = e.children;
		for (let e = 0; e < t.length; e++) this.removeChild(t[e]);
	}
	removeChildren(e) {
		for (let t = 0; t < e.length; t++) this.removeChild(e[t]);
	}
	onChildUpdate(e) {
		let t = this.childrenToUpdate[e.relativeRenderGroupDepth];
		t ||= this.childrenToUpdate[e.relativeRenderGroupDepth] = {
			index: 0,
			list: []
		}, t.list[t.index++] = e;
	}
	updateRenderable(e) {
		e.globalDisplayStatus < 7 || (this.instructionSet.renderPipes[e.renderPipeId].updateRenderable(e), e.didViewUpdate = !1);
	}
	onChildViewUpdate(e) {
		this.childrenRenderablesToUpdate.list[this.childrenRenderablesToUpdate.index++] = e;
	}
	get isRenderable() {
		return this.root.localDisplayStatus === 7 && this.worldAlpha > 0;
	}
	addOnRender(e) {
		this._onRenderContainers.indexOf(e) === -1 && this._onRenderContainers.push(e);
	}
	removeOnRender(e) {
		let t = this._onRenderContainers.indexOf(e);
		t !== -1 && this._onRenderContainers.splice(t, 1);
	}
	runOnRender(e) {
		for (let t = 0; t < this._onRenderContainers.length; t++) this._onRenderContainers[t]._onRender(e);
	}
	destroy() {
		this.disableCacheAsTexture(), this.renderGroupParent = null, this.root = null, this.childrenRenderablesToUpdate = null, this.childrenToUpdate = null, this.renderGroupChildren = null, this._onRenderContainers = null, this.instructionSet = null;
	}
	getChildren(e = []) {
		let t = this.root.children;
		for (let n = 0; n < t.length; n++) this._getChildren(t[n], e);
		return e;
	}
	_getChildren(e, t = []) {
		if (t.push(e), e.renderGroup) return t;
		let n = e.children;
		for (let e = 0; e < n.length; e++) this._getChildren(n[e], t);
		return t;
	}
	invalidateMatrices() {
		this._matrixDirty = 7;
	}
	get inverseWorldTransform() {
		return this._matrixDirty & 1 ? (this._matrixDirty &= -2, this._inverseWorldTransform ||= new x(), this._inverseWorldTransform.copyFrom(this.worldTransform).invert()) : this._inverseWorldTransform;
	}
	get textureOffsetInverseTransform() {
		return this._matrixDirty & 2 ? (this._matrixDirty &= -3, this._textureOffsetInverseTransform ||= new x(), this._textureOffsetInverseTransform.copyFrom(this.inverseWorldTransform).translate(-this._textureBounds.x, -this._textureBounds.y)) : this._textureOffsetInverseTransform;
	}
	get inverseParentTextureTransform() {
		if (!(this._matrixDirty & 4)) return this._inverseParentTextureTransform;
		this._matrixDirty &= -5;
		let e = this._parentCacheAsTextureRenderGroup;
		return e ? (this._inverseParentTextureTransform ||= new x(), this._inverseParentTextureTransform.copyFrom(this.worldTransform).prepend(e.inverseWorldTransform).translate(-e._textureBounds.x, -e._textureBounds.y)) : this.worldTransform;
	}
	get cacheToLocalTransform() {
		return this.isCachedAsTexture ? this.textureOffsetInverseTransform : this._parentCacheAsTextureRenderGroup ? this._parentCacheAsTextureRenderGroup.textureOffsetInverseTransform : null;
	}
};
//#endregion
//#region node_modules/pixi.js/lib/scene/container/utils/assignWithIgnore.mjs
function jt(e, t, n = {}) {
	for (let r in t) !n[r] && t[r] !== void 0 && (e[r] = t[r]);
}
//#endregion
//#region node_modules/pixi.js/lib/scene/container/Container.mjs
var Mt = new m(null), K = new m(null), Nt = new m(null, 1, 1), q = new m(null), Pt = class e extends h {
	constructor(e = {}) {
		super(), this.uid = D("renderable"), this._updateFlags = 15, this.renderGroup = null, this.parentRenderGroup = null, this.parentRenderGroupIndex = 0, this.didChange = !1, this.didViewUpdate = !1, this.relativeRenderGroupDepth = 0, this.children = [], this.parent = null, this.includeInBuild = !0, this.measurable = !0, this.isSimple = !0, this.parentRenderLayer = null, this.updateTick = -1, this.localTransform = new x(), this.relativeGroupTransform = new x(), this.groupTransform = this.relativeGroupTransform, this.destroyed = !1, this._position = new m(this, 0, 0), this._scale = Nt, this._pivot = K, this._origin = q, this._skew = Mt, this._cx = 1, this._sx = 0, this._cy = 0, this._sy = 1, this._rotation = 0, this.localColor = 16777215, this.localAlpha = 1, this.groupAlpha = 1, this.groupColor = 16777215, this.groupColorAlpha = 4294967295, this.localBlendMode = "inherit", this.groupBlendMode = "normal", this.localDisplayStatus = 7, this.globalDisplayStatus = 7, this._didContainerChangeTick = 0, this._didViewChangeTick = 0, this._didLocalTransformChangeId = -1, this.effects = [], jt(this, e, {
			children: !0,
			parent: !0,
			effects: !0
		}), e.children?.forEach((e) => this.addChild(e)), e.parent?.addChild(this);
	}
	static mixin(t) {
		A("8.8.0", "Container.mixin is deprecated, please use extensions.mixin instead."), p.mixin(e, t);
	}
	set _didChangeId(e) {
		this._didViewChangeTick = e >> 12 & 4095, this._didContainerChangeTick = e & 4095;
	}
	get _didChangeId() {
		return this._didContainerChangeTick & 4095 | (this._didViewChangeTick & 4095) << 12;
	}
	addChild(...e) {
		if (this.allowChildren || A(O, "addChild: Only Containers will be allowed to add children in v8.0.0"), e.length > 1) {
			for (let t = 0; t < e.length; t++) this.addChild(e[t]);
			return e[0];
		}
		let t = e[0], n = this.renderGroup || this.parentRenderGroup;
		return t.parent === this ? (this.children.splice(this.children.indexOf(t), 1), this.children.push(t), n && (n.structureDidChange = !0), t) : (t.parent && t.parent.removeChild(t), this.children.push(t), this.sortableChildren && (this.sortDirty = !0), t.parent = this, t.didChange = !0, t._updateFlags = 15, n && n.addChild(t), this.emit("childAdded", t, this, this.children.length - 1), t.emit("added", this), this._didViewChangeTick++, t._zIndex !== 0 && t.depthOfChildModified(), t);
	}
	removeChild(...e) {
		if (e.length > 1) {
			for (let t = 0; t < e.length; t++) this.removeChild(e[t]);
			return e[0];
		}
		let t = e[0], n = this.children.indexOf(t);
		return n > -1 && (this._didViewChangeTick++, this.children.splice(n, 1), this.renderGroup ? this.renderGroup.removeChild(t) : this.parentRenderGroup && this.parentRenderGroup.removeChild(t), t.parentRenderLayer && t.parentRenderLayer.detach(t), t.parent = null, this.emit("childRemoved", t, this, n), t.emit("removed", this)), t;
	}
	_onUpdate(e) {
		e && e === this._skew && this._updateSkew(), this._didContainerChangeTick++, !this.didChange && (this.didChange = !0, this.parentRenderGroup && this.parentRenderGroup.onChildUpdate(this));
	}
	set isRenderGroup(e) {
		!!this.renderGroup !== e && (e ? this.enableRenderGroup() : this.disableRenderGroup());
	}
	get isRenderGroup() {
		return !!this.renderGroup;
	}
	enableRenderGroup() {
		if (this.renderGroup) return;
		let e = this.parentRenderGroup;
		e?.removeChild(this), this.renderGroup = H.get(At, this), this.groupTransform = x.IDENTITY, e?.addChild(this), this._updateIsSimple();
	}
	disableRenderGroup() {
		if (!this.renderGroup) return;
		let e = this.parentRenderGroup;
		e?.removeChild(this), H.return(this.renderGroup), this.renderGroup = null, this.groupTransform = this.relativeGroupTransform, e?.addChild(this), this._updateIsSimple();
	}
	_updateIsSimple() {
		this.isSimple = !this.renderGroup && this.effects.length === 0;
	}
	get worldTransform() {
		return this._worldTransform ||= new x(), this.renderGroup ? this._worldTransform.copyFrom(this.renderGroup.worldTransform) : this.parentRenderGroup && this._worldTransform.appendFrom(this.relativeGroupTransform, this.parentRenderGroup.worldTransform), this._worldTransform;
	}
	get x() {
		return this._position.x;
	}
	set x(e) {
		this._position.x = e;
	}
	get y() {
		return this._position.y;
	}
	set y(e) {
		this._position.y = e;
	}
	get position() {
		return this._position;
	}
	set position(e) {
		this._position.copyFrom(e);
	}
	get rotation() {
		return this._rotation;
	}
	set rotation(e) {
		this._rotation !== e && (this._rotation = e, this._onUpdate(this._skew));
	}
	get angle() {
		return this.rotation * _;
	}
	set angle(e) {
		this.rotation = e * v;
	}
	get pivot() {
		return this._pivot === K && (this._pivot = new m(this, 0, 0)), this._pivot;
	}
	set pivot(e) {
		this._pivot === K && (this._pivot = new m(this, 0, 0), this._origin !== q && V("Setting both a pivot and origin on a Container is not recommended. This can lead to unexpected behavior if not handled carefully.")), typeof e == "number" ? this._pivot.set(e) : this._pivot.copyFrom(e);
	}
	get skew() {
		return this._skew === Mt && (this._skew = new m(this, 0, 0)), this._skew;
	}
	set skew(e) {
		this._skew === Mt && (this._skew = new m(this, 0, 0)), this._skew.copyFrom(e);
	}
	get scale() {
		return this._scale === Nt && (this._scale = new m(this, 1, 1)), this._scale;
	}
	set scale(e) {
		this._scale === Nt && (this._scale = new m(this, 0, 0)), typeof e == "string" && (e = parseFloat(e)), typeof e == "number" ? this._scale.set(e) : this._scale.copyFrom(e);
	}
	get origin() {
		return this._origin === q && (this._origin = new m(this, 0, 0)), this._origin;
	}
	set origin(e) {
		this._origin === q && (this._origin = new m(this, 0, 0), this._pivot !== K && V("Setting both a pivot and origin on a Container is not recommended. This can lead to unexpected behavior if not handled carefully.")), typeof e == "number" ? this._origin.set(e) : this._origin.copyFrom(e);
	}
	get width() {
		return Math.abs(this.scale.x * this.getLocalBounds().width);
	}
	set width(e) {
		let t = this.getLocalBounds().width;
		this._setWidth(e, t);
	}
	get height() {
		return Math.abs(this.scale.y * this.getLocalBounds().height);
	}
	set height(e) {
		let t = this.getLocalBounds().height;
		this._setHeight(e, t);
	}
	getSize(e) {
		e ||= {};
		let t = this.getLocalBounds();
		return e.width = Math.abs(this.scale.x * t.width), e.height = Math.abs(this.scale.y * t.height), e;
	}
	setSize(e, t) {
		let n = this.getLocalBounds();
		typeof e == "object" ? (t = e.height ?? e.width, e = e.width) : t ??= e, e !== void 0 && this._setWidth(e, n.width), t !== void 0 && this._setHeight(t, n.height);
	}
	_updateSkew() {
		let e = this._rotation, t = this._skew;
		this._cx = Math.cos(e + t._y), this._sx = Math.sin(e + t._y), this._cy = -Math.sin(e - t._x), this._sy = Math.cos(e - t._x);
	}
	updateTransform(e) {
		return this.position.set(typeof e.x == "number" ? e.x : this.position.x, typeof e.y == "number" ? e.y : this.position.y), this.scale.set(typeof e.scaleX == "number" ? e.scaleX : this.scale.x, typeof e.scaleY == "number" ? e.scaleY : this.scale.y), this.rotation = typeof e.rotation == "number" ? e.rotation : this.rotation, this.skew.set(typeof e.skewX == "number" ? e.skewX : this.skew.x, typeof e.skewY == "number" ? e.skewY : this.skew.y), this.pivot.set(typeof e.pivotX == "number" ? e.pivotX : this.pivot.x, typeof e.pivotY == "number" ? e.pivotY : this.pivot.y), this.origin.set(typeof e.originX == "number" ? e.originX : this.origin.x, typeof e.originY == "number" ? e.originY : this.origin.y), this;
	}
	setFromMatrix(e) {
		e.decompose(this);
	}
	updateLocalTransform() {
		let e = this._didContainerChangeTick;
		if (this._didLocalTransformChangeId === e) return;
		this._didLocalTransformChangeId = e;
		let t = this.localTransform, n = this._scale, r = this._pivot, i = this._origin, a = this._position, o = n._x, s = n._y, c = r._x, l = r._y, u = -i._x, d = -i._y;
		t.a = this._cx * o, t.b = this._sx * o, t.c = this._cy * s, t.d = this._sy * s, t.tx = a._x - (c * t.a + l * t.c) + (u * t.a + d * t.c) - u, t.ty = a._y - (c * t.b + l * t.d) + (u * t.b + d * t.d) - d;
	}
	set alpha(e) {
		e !== this.localAlpha && (this.localAlpha = e, this._updateFlags |= 1, this._onUpdate());
	}
	get alpha() {
		return this.localAlpha;
	}
	set tint(e) {
		let t = Ye.shared.setValue(e ?? 16777215).toBgrNumber();
		t !== this.localColor && (this.localColor = t, this._updateFlags |= 1, this._onUpdate());
	}
	get tint() {
		return G(this.localColor);
	}
	set blendMode(e) {
		this.localBlendMode !== e && (this.parentRenderGroup && (this.parentRenderGroup.structureDidChange = !0), this._updateFlags |= 2, this.localBlendMode = e, this._onUpdate());
	}
	get blendMode() {
		return this.localBlendMode;
	}
	get visible() {
		return !!(this.localDisplayStatus & 2);
	}
	set visible(e) {
		let t = e ? 2 : 0;
		(this.localDisplayStatus & 2) !== t && (this.parentRenderGroup && (this.parentRenderGroup.structureDidChange = !0), this._updateFlags |= 4, this.localDisplayStatus ^= 2, this._onUpdate(), this.emit("visibleChanged", e));
	}
	get culled() {
		return !(this.localDisplayStatus & 4);
	}
	set culled(e) {
		let t = e ? 0 : 4;
		(this.localDisplayStatus & 4) !== t && (this.parentRenderGroup && (this.parentRenderGroup.structureDidChange = !0), this._updateFlags |= 4, this.localDisplayStatus ^= 4, this._onUpdate());
	}
	get renderable() {
		return !!(this.localDisplayStatus & 1);
	}
	set renderable(e) {
		let t = +!!e;
		(this.localDisplayStatus & 1) !== t && (this._updateFlags |= 4, this.localDisplayStatus ^= 1, this.parentRenderGroup && (this.parentRenderGroup.structureDidChange = !0), this._onUpdate());
	}
	get isRenderable() {
		return this.localDisplayStatus === 7 && this.groupAlpha > 0;
	}
	destroy(e = !1) {
		if (this.destroyed) return;
		this.destroyed = !0;
		let t;
		if (this.children.length && (t = this.removeChildren(0, this.children.length)), this.removeFromParent(), this.parent = null, this._maskEffect = null, this._filterEffect = null, this.effects = null, this._position = null, this._scale = null, this._pivot = null, this._origin = null, this._skew = null, this.emit("destroyed", this), this.removeAllListeners(), (typeof e == "boolean" ? e : e?.children) && t) for (let n = 0; n < t.length; ++n) t[n].destroy(e);
		this.renderGroup?.destroy(), this.renderGroup = null;
	}
};
p.mixin(Pt, rt, ut, Et, Ct, St, st, ct, wt, Xe, tt, _t, it);
//#endregion
//#region node_modules/pixi.js/lib/scene/view/ViewContainer.mjs
var Ft = class extends Pt {
	constructor(e) {
		super(e), this.canBundle = !0, this.allowChildren = !1, this._roundPixels = 0, this._lastUsed = -1, this._gpuData = /* @__PURE__ */ Object.create(null), this.autoGarbageCollect = !0, this._gcLastUsed = -1, this._bounds = new N(0, 1, 0, 0), this._boundsDirty = !0, this.autoGarbageCollect = e.autoGarbageCollect ?? !0;
	}
	get bounds() {
		return this._boundsDirty ? (this.updateBounds(), this._boundsDirty = !1, this._bounds) : this._bounds;
	}
	get roundPixels() {
		return !!this._roundPixels;
	}
	set roundPixels(e) {
		this._roundPixels = +!!e;
	}
	containsPoint(e) {
		let t = this.bounds, { x: n, y: r } = e;
		return n >= t.minX && n <= t.maxX && r >= t.minY && r <= t.maxY;
	}
	onViewUpdate() {
		if (this._didViewChangeTick++, this._boundsDirty = !0, this.didViewUpdate) return;
		this.didViewUpdate = !0;
		let e = this.renderGroup || this.parentRenderGroup;
		e && e.onChildViewUpdate(this);
	}
	unload() {
		this.emit("unload", this);
		for (let e in this._gpuData) this._gpuData[e]?.destroy();
		this._gpuData = /* @__PURE__ */ Object.create(null), this.onViewUpdate();
	}
	destroy(e) {
		this.unload(), super.destroy(e), this._bounds = null;
	}
	collectRenderablesSimple(e, t, n) {
		let { renderPipes: r } = t;
		r.blendMode.pushBlendMode(this, this.groupBlendMode, e);
		let i = r[this.renderPipeId];
		i?.addRenderable && i.addRenderable(this, e), this.didViewUpdate = !1;
		let a = this.children, o = a.length;
		for (let r = 0; r < o; r++) a[r].collectRenderables(e, t, n);
		r.blendMode.popBlendMode(e);
	}
}, It = class e extends Ft {
	constructor(e = M.EMPTY) {
		e instanceof M && (e = { texture: e });
		let { texture: t = M.EMPTY, anchor: n, roundPixels: r, width: i, height: a, ...o } = e;
		super({
			label: "Sprite",
			...o
		}), this.renderPipeId = "sprite", this.batched = !0, this._visualBounds = {
			minX: 0,
			maxX: 1,
			minY: 0,
			maxY: 0
		}, this._anchor = new m({ _onUpdate: () => {
			this.onViewUpdate();
		} }), n ? this.anchor = n : t.defaultAnchor && (this.anchor = t.defaultAnchor), this.texture = t, this.allowChildren = !1, this.roundPixels = r ?? !1, i !== void 0 && (this.width = i), a !== void 0 && (this.height = a);
	}
	static from(t, n = !1) {
		return t instanceof M ? new e(t) : new e(M.from(t, n));
	}
	set texture(e) {
		e ||= M.EMPTY;
		let t = this._texture;
		t !== e && (t && t.dynamic && t.off("update", this.onViewUpdate, this), e.dynamic && e.on("update", this.onViewUpdate, this), this._texture = e, this._width && this._setWidth(this._width, this._texture.orig.width), this._height && this._setHeight(this._height, this._texture.orig.height), this.onViewUpdate());
	}
	get texture() {
		return this._texture;
	}
	get visualBounds() {
		return Ce(this._visualBounds, this._anchor, this._texture), this._visualBounds;
	}
	get sourceBounds() {
		return A("8.6.1", "Sprite.sourceBounds is deprecated, use visualBounds instead."), this.visualBounds;
	}
	updateBounds() {
		let e = this._anchor, t = this._texture, n = this._bounds, { width: r, height: i } = t.orig;
		n.minX = -e._x * r, n.maxX = n.minX + r, n.minY = -e._y * i, n.maxY = n.minY + i;
	}
	destroy(e = !1) {
		if (super.destroy(e), typeof e == "boolean" ? e : e?.texture) {
			let t = typeof e == "boolean" ? e : e?.textureSource;
			this._texture.destroy(t);
		}
		this._texture = null, this._visualBounds = null, this._bounds = null, this._anchor = null;
	}
	get anchor() {
		return this._anchor;
	}
	set anchor(e) {
		typeof e == "number" ? this._anchor.set(e) : this._anchor.copyFrom(e);
	}
	get width() {
		return Math.abs(this.scale.x) * this._texture.orig.width;
	}
	set width(e) {
		this._setWidth(e, this._texture.orig.width), this._width = e;
	}
	get height() {
		return Math.abs(this.scale.y) * this._texture.orig.height;
	}
	set height(e) {
		this._setHeight(e, this._texture.orig.height), this._height = e;
	}
	getSize(e) {
		return e ||= {}, e.width = Math.abs(this.scale.x) * this._texture.orig.width, e.height = Math.abs(this.scale.y) * this._texture.orig.height, e;
	}
	setSize(e, t) {
		typeof e == "object" ? (t = e.height ?? e.width, e = e.width) : t ??= e, e !== void 0 && this._setWidth(e, this._texture.orig.width), t !== void 0 && this._setHeight(t, this._texture.orig.height);
	}
}, Lt = {
	createCanvas: (e, t) => {
		let n = document.createElement("canvas");
		return n.width = e, n.height = t, n;
	},
	createImage: () => new Image(),
	getCanvasRenderingContext2D: () => CanvasRenderingContext2D,
	getWebGLRenderingContext: () => WebGLRenderingContext,
	getNavigator: () => navigator,
	getBaseUrl: () => document.baseURI ?? window.location.href,
	getFontFaceSet: () => document.fonts,
	fetch: (e, t) => fetch(e, t),
	parseXML: (e) => new DOMParser().parseFromString(e, "text/xml")
}, Rt = {
	get() {
		return Lt;
	},
	set(e) {
		Lt = e;
	}
}, zt = class extends j {
	constructor(e) {
		e.resource ||= Rt.get().createCanvas(), e.width || (e.width = e.resource.width, e.autoDensity || (e.width /= e.resolution)), e.height || (e.height = e.resource.height, e.autoDensity || (e.height /= e.resolution)), super(e), this.uploadMethodId = "image", this.autoDensity = e.autoDensity, this.resizeCanvas(), this.transparent = !!e.transparent;
	}
	resizeCanvas() {
		this.autoDensity && "style" in this.resource && (this.resource.style.width = `${this.width}px`, this.resource.style.height = `${this.height}px`), (this.resource.width !== this.pixelWidth || this.resource.height !== this.pixelHeight) && (this.resource.width = this.pixelWidth, this.resource.height = this.pixelHeight);
	}
	resize(e = this.width, t = this.height, n = this._resolution) {
		let r = super.resize(e, t, n);
		return r && this.resizeCanvas(), r;
	}
	static test(e) {
		return globalThis.HTMLCanvasElement && e instanceof HTMLCanvasElement || globalThis.OffscreenCanvas && e instanceof OffscreenCanvas;
	}
	get context2D() {
		return this._context2D ||= this.resource.getContext("2d");
	}
};
zt.extension = u.TextureSource;
//#endregion
//#region node_modules/pixi.js/lib/ticker/const.mjs
var Bt = /* @__PURE__ */ ((e) => (e[e.INTERACTION = 50] = "INTERACTION", e[e.HIGH = 25] = "HIGH", e[e.NORMAL = 0] = "NORMAL", e[e.LOW = -25] = "LOW", e[e.UTILITY = -50] = "UTILITY", e))(Bt || {}), Vt = class {
	constructor(e, t = null, n = 0, r = !1) {
		this.next = null, this.previous = null, this._destroyed = !1, this._fn = e, this._context = t, this.priority = n, this._once = r;
	}
	match(e, t = null) {
		return this._fn === e && this._context === t;
	}
	emit(e) {
		this._fn && (this._context ? this._fn.call(this._context, e) : this._fn(e));
		let t = this.next;
		return this._once && this.destroy(!0), this._destroyed && (this.next = null), t;
	}
	connect(e) {
		this.previous = e, e.next && (e.next.previous = this), this.next = e.next, e.next = this;
	}
	destroy(e = !1) {
		this._destroyed = !0, this._fn = null, this._context = null, this.previous && (this.previous.next = this.next), this.next && (this.next.previous = this.previous);
		let t = this.next;
		return this.next = e ? null : t, this.previous = null, t;
	}
}, Ht = class e {
	constructor() {
		this.autoStart = !1, this.deltaTime = 1, this.lastTime = -1, this.speed = 1, this.started = !1, this._requestId = null, this._maxElapsedMS = 100, this._minElapsedMS = 0, this._protected = !1, this._lastFrame = -1, this._head = new Vt(null, null, Infinity), this.deltaMS = 1 / e.targetFPMS, this.elapsedMS = 1 / e.targetFPMS, this._tick = (e) => {
			this._requestId = null, this.started && (this.update(e), this.started && this._requestId === null && this._head.next && (this._requestId = requestAnimationFrame(this._tick)));
		};
	}
	_requestIfNeeded() {
		this._requestId === null && this._head.next && (this.lastTime = performance.now(), this._lastFrame = this.lastTime, this._requestId = requestAnimationFrame(this._tick));
	}
	_cancelIfNeeded() {
		this._requestId !== null && (cancelAnimationFrame(this._requestId), this._requestId = null);
	}
	_startIfPossible() {
		this.started ? this._requestIfNeeded() : this.autoStart && this.start();
	}
	add(e, t, n = Bt.NORMAL) {
		return this._addListener(new Vt(e, t, n));
	}
	addOnce(e, t, n = Bt.NORMAL) {
		return this._addListener(new Vt(e, t, n, !0));
	}
	_addListener(e) {
		let t = this._head.next, n = this._head;
		if (!t) e.connect(n);
		else {
			for (; t;) {
				if (e.priority > t.priority) {
					e.connect(n);
					break;
				}
				n = t, t = t.next;
			}
			e.previous || e.connect(n);
		}
		return this._startIfPossible(), this;
	}
	remove(e, t) {
		let n = this._head.next;
		for (; n;) n = n.match(e, t) ? n.destroy() : n.next;
		return this._head.next || this._cancelIfNeeded(), this;
	}
	get count() {
		if (!this._head) return 0;
		let e = 0, t = this._head;
		for (; t = t.next;) e++;
		return e;
	}
	start() {
		this.started || (this.started = !0, this._requestIfNeeded());
	}
	stop() {
		this.started && (this.started = !1, this._cancelIfNeeded());
	}
	destroy() {
		if (!this._protected) {
			this.stop();
			let e = this._head.next;
			for (; e;) e = e.destroy(!0);
			this._head.destroy(), this._head = null;
		}
	}
	update(t = performance.now()) {
		let n;
		if (t > this.lastTime) {
			if (n = this.elapsedMS = t - this.lastTime, n > this._maxElapsedMS && (n = this._maxElapsedMS), n *= this.speed, this._minElapsedMS) {
				let e = t - this._lastFrame | 0;
				if (e < this._minElapsedMS) return;
				this._lastFrame = t - e % this._minElapsedMS;
			}
			this.deltaMS = n, this.deltaTime = this.deltaMS * e.targetFPMS;
			let r = this._head, i = r.next;
			for (; i;) i = i.emit(this);
			r.next || this._cancelIfNeeded();
		} else this.deltaTime = this.deltaMS = this.elapsedMS = 0;
		this.lastTime = t;
	}
	get FPS() {
		return 1e3 / this.elapsedMS;
	}
	get minFPS() {
		return 1e3 / this._maxElapsedMS;
	}
	set minFPS(t) {
		let n = Math.min(Math.max(0, t) / 1e3, e.targetFPMS);
		this._maxElapsedMS = 1 / n, this._minElapsedMS && t > this.maxFPS && (this.maxFPS = t);
	}
	get maxFPS() {
		return this._minElapsedMS ? Math.round(1e3 / this._minElapsedMS) : 0;
	}
	set maxFPS(e) {
		e === 0 ? this._minElapsedMS = 0 : (e < this.minFPS && (this.minFPS = e), this._minElapsedMS = 1 / (e / 1e3));
	}
	static get shared() {
		if (!e._shared) {
			let t = e._shared = new e();
			t.autoStart = !0, t._protected = !0;
		}
		return e._shared;
	}
	static get system() {
		if (!e._system) {
			let t = e._system = new e();
			t.autoStart = !0, t._protected = !0;
		}
		return e._system;
	}
};
Ht.targetFPMS = .06;
var Ut = Ht, Wt = /* @__PURE__ */ Object.create(null), Gt = /* @__PURE__ */ Object.create(null);
function J(e, t) {
	let n = Gt[e];
	return n === void 0 && (Wt[t] === void 0 && (Wt[t] = 1), Gt[e] = n = Wt[t]++), n;
}
//#endregion
//#region node_modules/pixi.js/lib/rendering/renderers/gl/shader/program/getTestContext.mjs
var Kt;
function qt() {
	return (!Kt || Kt?.isContextLost()) && (Kt = Rt.get().createCanvas().getContext("webgl", {})), Kt;
}
//#endregion
//#region node_modules/pixi.js/lib/rendering/renderers/gl/shader/program/getMaxFragmentPrecision.mjs
var Jt;
function Yt() {
	if (!Jt) {
		Jt = "mediump";
		let e = qt();
		e && e.getShaderPrecisionFormat && (Jt = e.getShaderPrecisionFormat(e.FRAGMENT_SHADER, e.HIGH_FLOAT).precision ? "highp" : "mediump");
	}
	return Jt;
}
//#endregion
//#region node_modules/pixi.js/lib/rendering/renderers/gl/shader/program/preprocessors/addProgramDefines.mjs
function Xt(e, t, n) {
	return t ? e : n ? (e = e.replace("out vec4 finalColor;", ""), `

        #ifdef GL_ES // This checks if it is WebGL1
        #define in varying
        #define finalColor gl_FragColor
        #define texture texture2D
        #endif
        ${e}
        `) : `

        #ifdef GL_ES // This checks if it is WebGL1
        #define in attribute
        #define out varying
        #endif
        ${e}
        `;
}
//#endregion
//#region node_modules/pixi.js/lib/rendering/renderers/gl/shader/program/preprocessors/ensurePrecision.mjs
function Zt(e, t, n) {
	let r = n ? t.maxSupportedFragmentPrecision : t.maxSupportedVertexPrecision;
	if (e.substring(0, 9) !== "precision") {
		let i = n ? t.requestedFragmentPrecision : t.requestedVertexPrecision;
		return i === "highp" && r !== "highp" && (i = "mediump"), `precision ${i} float;
${e}`;
	}
	return r !== "highp" && e.substring(0, 15) === "precision highp" ? e.replace("precision highp", "precision mediump") : e;
}
//#endregion
//#region node_modules/pixi.js/lib/rendering/renderers/gl/shader/program/preprocessors/insertVersion.mjs
function Qt(e, t) {
	return t ? `#version 300 es
${e}` : e;
}
//#endregion
//#region node_modules/pixi.js/lib/rendering/renderers/gl/shader/program/preprocessors/setProgramName.mjs
var $t = {}, en = {};
function tn(e, { name: t = "pixi-program" }, n = !0) {
	t = t.replace(/\s+/g, "-"), t += n ? "-fragment" : "-vertex";
	let r = n ? $t : en;
	return r[t] ? (r[t]++, t += `-${r[t]}`) : r[t] = 1, e.indexOf("#define SHADER_NAME") === -1 ? `${`#define SHADER_NAME ${t}`}
${e}` : e;
}
//#endregion
//#region node_modules/pixi.js/lib/rendering/renderers/gl/shader/program/preprocessors/stripVersion.mjs
function nn(e, t) {
	return t ? e.replace("#version 300 es", "") : e;
}
//#endregion
//#region node_modules/pixi.js/lib/rendering/renderers/gl/shader/GlProgram.mjs
var rn = {
	stripVersion: nn,
	ensurePrecision: Zt,
	addProgramDefines: Xt,
	setProgramName: tn,
	insertVersion: Qt
}, Y = /* @__PURE__ */ Object.create(null), an = class e {
	constructor(t) {
		t = {
			...e.defaultOptions,
			...t
		};
		let n = t.fragment.indexOf("#version 300 es") !== -1, r = {
			stripVersion: n,
			ensurePrecision: {
				requestedFragmentPrecision: t.preferredFragmentPrecision,
				requestedVertexPrecision: t.preferredVertexPrecision,
				maxSupportedVertexPrecision: "highp",
				maxSupportedFragmentPrecision: Yt()
			},
			setProgramName: { name: t.name },
			addProgramDefines: n,
			insertVersion: n
		}, i = t.fragment, a = t.vertex;
		Object.keys(rn).forEach((e) => {
			let t = r[e];
			i = rn[e](i, t, !0), a = rn[e](a, t, !1);
		}), this.fragment = i, this.vertex = a, this.transformFeedbackVaryings = t.transformFeedbackVaryings, this._key = J(`${this.vertex}:${this.fragment}`, "gl-program");
	}
	destroy() {
		this.fragment = null, this.vertex = null, this._attributeData = null, this._uniformData = null, this._uniformBlockData = null, this.transformFeedbackVaryings = null, Y[this._cacheKey] = null;
	}
	static from(t) {
		let n = `${t.vertex}:${t.fragment}`;
		return Y[n] || (Y[n] = new e(t), Y[n]._cacheKey = n), Y[n];
	}
};
an.defaultOptions = {
	preferredVertexPrecision: "highp",
	preferredFragmentPrecision: "mediump"
};
var on = an, sn = {
	uint8x2: {
		size: 2,
		stride: 2,
		normalised: !1
	},
	uint8x4: {
		size: 4,
		stride: 4,
		normalised: !1
	},
	sint8x2: {
		size: 2,
		stride: 2,
		normalised: !1
	},
	sint8x4: {
		size: 4,
		stride: 4,
		normalised: !1
	},
	unorm8x2: {
		size: 2,
		stride: 2,
		normalised: !0
	},
	unorm8x4: {
		size: 4,
		stride: 4,
		normalised: !0
	},
	snorm8x2: {
		size: 2,
		stride: 2,
		normalised: !0
	},
	snorm8x4: {
		size: 4,
		stride: 4,
		normalised: !0
	},
	uint16x2: {
		size: 2,
		stride: 4,
		normalised: !1
	},
	uint16x4: {
		size: 4,
		stride: 8,
		normalised: !1
	},
	sint16x2: {
		size: 2,
		stride: 4,
		normalised: !1
	},
	sint16x4: {
		size: 4,
		stride: 8,
		normalised: !1
	},
	unorm16x2: {
		size: 2,
		stride: 4,
		normalised: !0
	},
	unorm16x4: {
		size: 4,
		stride: 8,
		normalised: !0
	},
	snorm16x2: {
		size: 2,
		stride: 4,
		normalised: !0
	},
	snorm16x4: {
		size: 4,
		stride: 8,
		normalised: !0
	},
	float16x2: {
		size: 2,
		stride: 4,
		normalised: !1
	},
	float16x4: {
		size: 4,
		stride: 8,
		normalised: !1
	},
	float32: {
		size: 1,
		stride: 4,
		normalised: !1
	},
	float32x2: {
		size: 2,
		stride: 8,
		normalised: !1
	},
	float32x3: {
		size: 3,
		stride: 12,
		normalised: !1
	},
	float32x4: {
		size: 4,
		stride: 16,
		normalised: !1
	},
	uint32: {
		size: 1,
		stride: 4,
		normalised: !1
	},
	uint32x2: {
		size: 2,
		stride: 8,
		normalised: !1
	},
	uint32x3: {
		size: 3,
		stride: 12,
		normalised: !1
	},
	uint32x4: {
		size: 4,
		stride: 16,
		normalised: !1
	},
	sint32: {
		size: 1,
		stride: 4,
		normalised: !1
	},
	sint32x2: {
		size: 2,
		stride: 8,
		normalised: !1
	},
	sint32x3: {
		size: 3,
		stride: 12,
		normalised: !1
	},
	sint32x4: {
		size: 4,
		stride: 16,
		normalised: !1
	}
};
function cn(e) {
	return sn[e] ?? sn.float32;
}
//#endregion
//#region node_modules/pixi.js/lib/rendering/renderers/gpu/shader/utils/extractAttributesFromGpuProgram.mjs
var ln = {
	f32: "float32",
	"vec2<f32>": "float32x2",
	"vec3<f32>": "float32x3",
	"vec4<f32>": "float32x4",
	vec2f: "float32x2",
	vec3f: "float32x3",
	vec4f: "float32x4",
	i32: "sint32",
	"vec2<i32>": "sint32x2",
	"vec3<i32>": "sint32x3",
	"vec4<i32>": "sint32x4",
	vec2i: "sint32x2",
	vec3i: "sint32x3",
	vec4i: "sint32x4",
	u32: "uint32",
	"vec2<u32>": "uint32x2",
	"vec3<u32>": "uint32x3",
	"vec4<u32>": "uint32x4",
	vec2u: "uint32x2",
	vec3u: "uint32x3",
	vec4u: "uint32x4",
	bool: "uint32",
	"vec2<bool>": "uint32x2",
	"vec3<bool>": "uint32x3",
	"vec4<bool>": "uint32x4"
}, un = /@location\((\d+)\)\s+([a-zA-Z0-9_]+)\s*:\s*([a-zA-Z0-9_<>]+)(?:,|\s|\)|$)/g;
function dn(e, t) {
	let n;
	for (; (n = un.exec(e)) !== null;) {
		let e = ln[n[3]] ?? "float32";
		t[n[2]] = {
			location: parseInt(n[1], 10),
			format: e,
			stride: cn(e).stride,
			offset: 0,
			instance: !1,
			start: 0
		};
	}
	un.lastIndex = 0;
}
function fn(e) {
	return e.replace(/\/\/.*$/gm, "").replace(/\/\*[\s\S]*?\*\//g, "");
}
function pn({ source: e, entryPoint: t }) {
	let n = {}, r = fn(e), i = r.indexOf(`fn ${t}(`);
	if (i === -1) return n;
	let a = r.indexOf("->", i);
	if (a === -1) return n;
	let o = r.substring(i, a);
	if (dn(o, n), Object.keys(n).length === 0) {
		let e = o.match(/\(\s*\w+\s*:\s*(\w+)/);
		if (e) {
			let t = e[1], i = RegExp(`struct\\s+${t}\\s*\\{([^}]+)\\}`, "s"), a = r.match(i);
			a && dn(a[1], n);
		}
	}
	return n;
}
//#endregion
//#region node_modules/pixi.js/lib/rendering/renderers/gpu/shader/utils/extractStructAndGroups.mjs
function mn(e) {
	let t = /(^|[^/])@(group|binding)\(\d+\)[^;]+;/g, n = /@group\((\d+)\)/, r = /@binding\((\d+)\)/, i = /var(<[^>]+>)? (\w+)/, a = /:\s*([\w<>]+)/, o = /struct\s+(\w+)\s*{([^}]+)}/g, s = /(\w+)\s*:\s*([\w\<\>]+)/g, c = /struct\s+(\w+)/, l = e.match(t)?.map((e) => {
		let t = e.match(i), o = t?.[1] ?? "", s;
		return o === "<uniform>" ? s = "uniform" : o.startsWith("<storage") && (s = "storage"), {
			group: parseInt(e.match(n)[1], 10),
			binding: parseInt(e.match(r)[1], 10),
			name: t[2],
			accessMode: s,
			type: e.match(a)[1]
		};
	});
	return l ? {
		groups: l,
		structs: e.match(o)?.map((e) => {
			let t = e.match(c)[1], n = e.match(s).reduce((e, t) => {
				let [n, r] = t.split(":");
				return e[n.trim()] = r.trim(), e;
			}, {});
			return n ? {
				name: t,
				members: n
			} : null;
		}).filter(({ name: e }) => l.some((t) => t.type === e || t.type.includes(`<${e}>`))) ?? []
	} : {
		groups: [],
		structs: []
	};
}
//#endregion
//#region node_modules/pixi.js/lib/rendering/renderers/shared/shader/const.mjs
var X = /* @__PURE__ */ ((e) => (e[e.VERTEX = 1] = "VERTEX", e[e.FRAGMENT = 2] = "FRAGMENT", e[e.COMPUTE = 4] = "COMPUTE", e))(X || {});
//#endregion
//#region node_modules/pixi.js/lib/rendering/renderers/gpu/shader/utils/generateGpuLayoutGroups.mjs
function hn({ groups: e }) {
	let t = [];
	for (let n = 0; n < e.length; n++) {
		let r = e[n];
		t[r.group] || (t[r.group] = []), r.accessMode === "uniform" ? t[r.group].push({
			binding: r.binding,
			visibility: X.VERTEX | X.FRAGMENT,
			buffer: { type: "uniform" }
		}) : r.accessMode === "storage" ? t[r.group].push({
			binding: r.binding,
			visibility: X.VERTEX | X.FRAGMENT,
			buffer: { type: "read-only-storage" }
		}) : r.type === "sampler" ? t[r.group].push({
			binding: r.binding,
			visibility: X.VERTEX | X.FRAGMENT,
			sampler: { type: "filtering" }
		}) : r.type === "sampler_comparison" ? t[r.group].push({
			binding: r.binding,
			visibility: X.VERTEX | X.FRAGMENT,
			sampler: { type: "comparison" }
		}) : r.type === "texture_2d" || r.type.startsWith("texture_2d<") ? t[r.group].push({
			binding: r.binding,
			visibility: X.VERTEX | X.FRAGMENT,
			texture: {
				sampleType: "float",
				viewDimension: "2d",
				multisampled: !1
			}
		}) : r.type === "texture_depth_2d" ? t[r.group].push({
			binding: r.binding,
			visibility: X.VERTEX | X.FRAGMENT,
			texture: {
				sampleType: "depth",
				viewDimension: "2d",
				multisampled: !1
			}
		}) : r.type === "texture_depth_2d_array" ? t[r.group].push({
			binding: r.binding,
			visibility: X.VERTEX | X.FRAGMENT,
			texture: {
				sampleType: "depth",
				viewDimension: "2d-array",
				multisampled: !1
			}
		}) : r.type === "texture_2d_array" || r.type.startsWith("texture_2d_array<") ? t[r.group].push({
			binding: r.binding,
			visibility: X.VERTEX | X.FRAGMENT,
			texture: {
				sampleType: "float",
				viewDimension: "2d-array",
				multisampled: !1
			}
		}) : (r.type === "texture_cube" || r.type.startsWith("texture_cube<")) && t[r.group].push({
			binding: r.binding,
			visibility: X.VERTEX | X.FRAGMENT,
			texture: {
				sampleType: "float",
				viewDimension: "cube",
				multisampled: !1
			}
		});
	}
	for (let e = 0; e < t.length; e++) t[e] || (t[e] = []);
	return t;
}
//#endregion
//#region node_modules/pixi.js/lib/rendering/renderers/gpu/shader/utils/generateLayoutHash.mjs
function gn({ groups: e }) {
	let t = [];
	for (let n = 0; n < e.length; n++) {
		let r = e[n];
		t[r.group] || (t[r.group] = {}), t[r.group][r.name] = r.binding;
	}
	return t;
}
//#endregion
//#region node_modules/pixi.js/lib/rendering/renderers/gpu/shader/utils/removeStructAndGroupDuplicates.mjs
function _n(e, t) {
	let n = /* @__PURE__ */ new Set(), r = /* @__PURE__ */ new Set();
	return {
		structs: [...e.structs, ...t.structs].filter((e) => !n.has(e.name) && (n.add(e.name), !0)),
		groups: [...e.groups, ...t.groups].filter((e) => {
			let t = `${e.name}-${e.binding}`;
			return !r.has(t) && (r.add(t), !0);
		})
	};
}
//#endregion
//#region node_modules/pixi.js/lib/rendering/renderers/gpu/shader/GpuProgram.mjs
var Z = /* @__PURE__ */ Object.create(null), vn = class e {
	constructor(e) {
		this._layoutKey = 0, this._attributeLocationsKey = 0;
		let { fragment: t, vertex: n, layout: r, gpuLayout: i, name: a } = e;
		if (this.name = a, this.fragment = t, this.vertex = n, t.source === n.source) {
			let e = mn(t.source);
			this.structsAndGroups = e;
		} else {
			let e = mn(n.source), r = mn(t.source);
			this.structsAndGroups = _n(e, r);
		}
		this.layout = r ?? gn(this.structsAndGroups), this.gpuLayout = i ?? hn(this.structsAndGroups), this.autoAssignGlobalUniforms = this.layout[0]?.globalUniforms !== void 0, this.autoAssignLocalUniforms = this.layout[1]?.localUniforms !== void 0, this._generateProgramKey();
	}
	_generateProgramKey() {
		let { vertex: e, fragment: t } = this, n = e.source + t.source + e.entryPoint + t.entryPoint;
		this._layoutKey = J(n, "program");
	}
	get attributeData() {
		return this._attributeData ??= pn(this.vertex), this._attributeData;
	}
	destroy() {
		this.gpuLayout = null, this.layout = null, this.structsAndGroups = null, this.fragment = null, this.vertex = null, Z[this._cacheKey] = null;
	}
	static from(t) {
		let n = `${t.vertex.source}:${t.fragment.source}:${t.fragment.entryPoint}:${t.vertex.entryPoint}`;
		return Z[n] || (Z[n] = new e(t), Z[n]._cacheKey = n), Z[n];
	}
}, yn = [
	"f32",
	"i32",
	"u32",
	"vec2<f32>",
	"vec3<f32>",
	"vec4<f32>",
	"mat2x2<f32>",
	"mat3x3<f32>",
	"mat4x4<f32>",
	"mat3x2<f32>",
	"mat4x2<f32>",
	"mat2x3<f32>",
	"mat4x3<f32>",
	"mat2x4<f32>",
	"mat3x4<f32>",
	"vec2<i32>",
	"vec3<i32>",
	"vec4<i32>",
	"vec2<u32>",
	"vec3<u32>",
	"vec4<u32>"
], bn = yn.reduce((e, t) => (e[t] = !0, e), {});
//#endregion
//#region node_modules/pixi.js/lib/rendering/renderers/shared/shader/utils/getDefaultUniformValue.mjs
function xn(e, t) {
	switch (e) {
		case "f32": return 0;
		case "vec2<f32>": return new Float32Array(2 * t);
		case "vec3<f32>": return new Float32Array(3 * t);
		case "vec4<f32>": return new Float32Array(4 * t);
		case "mat2x2<f32>": return new Float32Array([
			1,
			0,
			0,
			1
		]);
		case "mat3x3<f32>": return new Float32Array([
			1,
			0,
			0,
			0,
			1,
			0,
			0,
			0,
			1
		]);
		case "mat4x4<f32>": return new Float32Array([
			1,
			0,
			0,
			0,
			0,
			1,
			0,
			0,
			0,
			0,
			1,
			0,
			0,
			0,
			0,
			1
		]);
	}
	return null;
}
//#endregion
//#region node_modules/pixi.js/lib/rendering/renderers/shared/shader/UniformGroup.mjs
var Sn = class e extends h {
	constructor(t, n) {
		super(), this._touched = 0, this.uid = D("uniform"), this._resourceType = "uniformGroup", this._resourceId = D("resource"), this.isUniformGroup = !0, this._dirtyId = 0, this.destroyed = !1, n = {
			...e.defaultOptions,
			...n
		}, this.uniformStructures = t;
		let r = {};
		for (let e in t) {
			let n = t[e];
			if (n.name = e, n.size = n.size ?? 1, !bn[n.type]) {
				let e = n.type.match(/^array<(\w+(?:<\w+>)?),\s*(\d+)>$/);
				if (e) {
					let [, t, r] = e;
					throw Error(`Uniform type ${n.type} is not supported. Use type: '${t}', size: ${r} instead.`);
				}
				throw Error(`Uniform type ${n.type} is not supported. Supported uniform types are: ${yn.join(", ")}`);
			}
			n.value ??= xn(n.type, n.size), r[e] = n.value;
		}
		this.uniforms = r, this._dirtyId = 1, this.ubo = n.ubo, this.isStatic = n.isStatic, this._signature = J(Object.keys(r).map((e) => `${e}-${t[e].type}`).join("-"), "uniform-group");
	}
	get buffer() {
		return this._buffer;
	}
	set buffer(e) {
		this._buffer !== e && (this._buffer?.off("change", this.onBufferChange, this), this._buffer = e, e?.on("change", this.onBufferChange, this));
	}
	get _gcLastUsed() {
		return this._buffer?._gcLastUsed ?? -1;
	}
	set _gcLastUsed(e) {
		this._buffer && (this._buffer._gcLastUsed = e);
	}
	onBufferChange() {
		this._resourceId = D("resource"), this.emit("change", this);
	}
	update() {
		this._dirtyId++;
	}
};
Sn.defaultOptions = {
	ubo: !1,
	isStatic: !1
};
var Cn = Sn, wn = class {
	constructor(e) {
		this.resources = /* @__PURE__ */ Object.create(null), this._dirty = !0;
		let t = 0;
		for (let n in e) {
			let r = e[n];
			this.setResource(r, t++);
		}
	}
	get _key() {
		if (this._dirty) {
			this._dirty = !1;
			let e = [], t = 0;
			for (let n in this.resources) e[t++] = this.resources[n] ? this.resources[n]._resourceId : -1;
			this._keyValue = e.join("|");
		}
		return this._keyValue;
	}
	setResource(e, t) {
		let n = this.resources[t];
		e !== n && (n && n.off?.("change", this.onResourceChange, this), e.on?.("change", this.onResourceChange, this), this.resources[t] = e, this._dirty = !0);
	}
	getResource(e) {
		return this.resources[e];
	}
	_touch(e, t) {
		let n = this.resources;
		for (let r in n) {
			let i = n[r];
			i && (i._gcLastUsed = e, i._touched = t);
		}
	}
	destroy() {
		let e = this.resources;
		for (let t in e) e[t]?.off?.("change", this.onResourceChange, this);
		this.resources = null;
	}
	onResourceChange(e) {
		if (this._dirty = !0, e.destroyed) {
			let t = this.resources;
			for (let n in t) t[n] === e && (t[n] = null);
			V(`[BindGroup] a '${e._resourceType}' was destroyed while still bound to a shader. Remove it from the shader before destroying it.`);
		}
	}
}, Tn = /* @__PURE__ */ ((e) => (e[e.WEBGL = 1] = "WEBGL", e[e.WEBGPU = 2] = "WEBGPU", e[e.CANVAS = 4] = "CANVAS", e[e.BOTH = 3] = "BOTH", e))(Tn || {}), En = class e {
	constructor(e) {
		this.data = { ...e };
		let t = Object.keys(e).sort().map((t) => `${t}:${e[t]}`).join("|");
		this.id = J(t, "shader-overrides");
	}
	static from(t) {
		return t instanceof e ? t : new e(t);
	}
}, Dn = class e extends h {
	constructor(e) {
		super(), this.uid = D("shader"), this._uniformBindMap = /* @__PURE__ */ Object.create(null), this._ownedBindGroups = [], this._destroyed = !1;
		let { gpuProgram: t, glProgram: n, groups: r, resources: i, compatibleRenderers: a, groupMap: o, overrides: s } = e;
		this._overrides = s ? En.from(s) : null, this.gpuProgram = t, this.glProgram = n, a === void 0 && (a = 0, t && (a |= Tn.WEBGPU), n && (a |= Tn.WEBGL)), this.compatibleRenderers = a;
		let c = {};
		if (o) for (let e in o) for (let t in o[e]) {
			let n = o[e][t];
			c[n] = {
				group: e,
				binding: t,
				name: n
			};
		}
		if (!i && !r && (i = {}), i && r) throw Error("[Shader] Cannot have both resources and groups");
		if (!t && r && !o) throw Error("[Shader] No group map or WebGPU shader provided - consider using resources instead.");
		if (t && r && !o) {
			let e = t.structsAndGroups.groups;
			o = {}, e.forEach((e) => {
				o[e.group] = o[e.group] || {}, o[e.group][e.binding] = e.name, c[e.name] = e;
			});
		} else if (i) {
			r = {}, o ||= {}, t && t.structsAndGroups.groups.forEach((e) => {
				o[e.group] = o[e.group] || {}, o[e.group][e.binding] = e.name, c[e.name] = e;
			});
			let e = 0;
			for (let a in i) c[a] || (t && !n && V(`[Shader] the resource '${a}' matches no binding in the WGSL source \u2014 is the name correct?`), r[99] || (r[99] = new wn(), this._ownedBindGroups.push(r[99])), c[a] = {
				group: 99,
				binding: e,
				name: a
			}, o[99] = o[99] || {}, o[99][e] = a, e++);
			for (let e in i) {
				let t = e, n = i[e];
				!n.source && !n._resourceType && (n = new Cn(n));
				let a = c[t];
				a && (r[a.group] || (r[a.group] = new wn(), this._ownedBindGroups.push(r[a.group])), r[a.group].setResource(n, a.binding));
			}
		}
		this.groups = r, this._uniformBindMap = o, this.resources = this._buildResourceAccessor(r, c);
	}
	addResource(e, t, n) {
		var r, i;
		(r = this._uniformBindMap)[t] || (r[t] = {}), (i = this._uniformBindMap[t])[n] || (i[n] = e), this.groups[t] || (this.groups[t] = new wn(), this._ownedBindGroups.push(this.groups[t]));
	}
	_buildResourceAccessor(e, t) {
		let n = {};
		for (let r in t) {
			let i = t[r];
			Object.defineProperty(n, i.name, {
				get() {
					return e[i.group].getResource(i.binding);
				},
				set(t) {
					e[i.group].setResource(t, i.binding);
				}
			});
		}
		return n;
	}
	destroy(e = !1) {
		this._destroyed || (this._destroyed = !0, this.emit("destroy", this), e && (this.gpuProgram?.destroy(), this.glProgram?.destroy()), this.gpuProgram = null, this.glProgram = null, this.removeAllListeners(), this._uniformBindMap = null, this._ownedBindGroups.forEach((e) => {
			e.destroy();
		}), this._ownedBindGroups = null, this.resources = null, this.groups = null, this._overrides = null);
	}
	static from(t) {
		let { gpu: n, gl: r, ...i } = t, a, o;
		return n && (a = vn.from(n)), r && (o = on.from(r)), new e({
			gpuProgram: a,
			glProgram: o,
			...i
		});
	}
}, On = {
	normal: 0,
	add: 1,
	multiply: 2,
	screen: 3,
	overlay: 4,
	erase: 5,
	"normal-npm": 6,
	"add-npm": 7,
	"screen-npm": 8,
	min: 9,
	max: 10
}, kn = {
	BLEND: 0,
	OFFSET: 1,
	CULLING: 2,
	DEPTH_TEST: 3,
	WINDING: 4,
	DEPTH_MASK: 5
}, { BLEND: An, OFFSET: jn, CULLING: Mn, DEPTH_TEST: Nn, WINDING: Pn, DEPTH_MASK: Fn } = kn, In = class e {
	constructor() {
		this.data = 0, this.blendMode = "normal", this.polygonOffset = 0, this.blend = !0, this.depthMask = !0;
	}
	get blend() {
		return !!(this.data & 1 << An);
	}
	set blend(e) {
		!!(this.data & 1 << An) !== e && (this.data ^= 1 << An);
	}
	get offsets() {
		return !!(this.data & 1 << jn);
	}
	set offsets(e) {
		!!(this.data & 1 << jn) !== e && (this.data ^= 1 << jn);
	}
	set cullMode(e) {
		if (e === "none") {
			this.culling = !1;
			return;
		}
		this.culling = !0, this.clockwiseFrontFace = e === "front";
	}
	get cullMode() {
		return this.culling ? this.clockwiseFrontFace ? "front" : "back" : "none";
	}
	get culling() {
		return !!(this.data & 1 << Mn);
	}
	set culling(e) {
		!!(this.data & 1 << Mn) !== e && (this.data ^= 1 << Mn);
	}
	get depthTest() {
		return !!(this.data & 1 << Nn);
	}
	set depthTest(e) {
		!!(this.data & 1 << Nn) !== e && (this.data ^= 1 << Nn);
	}
	get depthMask() {
		return !!(this.data & 1 << Fn);
	}
	set depthMask(e) {
		!!(this.data & 1 << Fn) !== e && (this.data ^= 1 << Fn);
	}
	get clockwiseFrontFace() {
		return !!(this.data & 1 << Pn);
	}
	set clockwiseFrontFace(e) {
		!!(this.data & 1 << Pn) !== e && (this.data ^= 1 << Pn);
	}
	get blendMode() {
		return this._blendMode;
	}
	set blendMode(e) {
		this.blend = e !== "none", this._blendMode = e, this._blendModeId = On[e] || 0;
	}
	get polygonOffset() {
		return this._polygonOffset;
	}
	set polygonOffset(e) {
		this.offsets = !!e, this._polygonOffset = e;
	}
	toString() {
		return `[pixi.js/core:State blendMode=${this.blendMode} clockwiseFrontFace=${this.clockwiseFrontFace} culling=${this.culling} depthMask=${this.depthMask} polygonOffset=${this.polygonOffset}]`;
	}
	static for2d() {
		let t = new e();
		return t.depthTest = !1, t.depthMask = !1, t.blend = !0, t;
	}
};
In.default2d = In.for2d();
var Ln = In, Rn = class e extends Dn {
	constructor(t) {
		t = {
			...e.defaultOptions,
			...t
		}, super(t), this.enabled = !0, this._state = Ln.for2d(), this.blendMode = t.blendMode, this.padding = t.padding, this.antialias = typeof t.antialias == "boolean" ? t.antialias ? "on" : "off" : t.antialias, this.resolution = t.resolution, this.blendRequired = t.blendRequired, this.clipToViewport = t.clipToViewport, this.addResource("uTexture", 0, 1), t.blendRequired && this.addResource("uBackTexture", 0, 3);
	}
	apply(e, t, n, r) {
		e.applyFilter(this, t, n, r);
	}
	get blendMode() {
		return this._state.blendMode;
	}
	set blendMode(e) {
		this._state.blendMode = e;
	}
	static from(t) {
		let { gpu: n, gl: r, ...i } = t, a, o;
		return n && (a = vn.from(n)), r && (o = on.from(r)), new e({
			gpuProgram: a,
			glProgram: o,
			...i
		});
	}
};
Rn.defaultOptions = {
	blendMode: "normal",
	resolution: 1,
	padding: 0,
	antialias: "off",
	blendRequired: !1,
	clipToViewport: !0
};
var zn = Rn, Q = /* @__PURE__ */ ((e) => (e[e.MAP_READ = 1] = "MAP_READ", e[e.MAP_WRITE = 2] = "MAP_WRITE", e[e.COPY_SRC = 4] = "COPY_SRC", e[e.COPY_DST = 8] = "COPY_DST", e[e.INDEX = 16] = "INDEX", e[e.VERTEX = 32] = "VERTEX", e[e.UNIFORM = 64] = "UNIFORM", e[e.STORAGE = 128] = "STORAGE", e[e.INDIRECT = 256] = "INDIRECT", e[e.QUERY_RESOLVE = 512] = "QUERY_RESOLVE", e[e.STATIC = 1024] = "STATIC", e))(Q || {}), $ = class extends h {
	constructor(e) {
		let { data: t, size: n } = e, { usage: r, label: i, shrinkToFit: a } = e;
		super(), this._gpuData = /* @__PURE__ */ Object.create(null), this._gcLastUsed = -1, this.autoGarbageCollect = !0, this.uid = D("buffer"), this._resourceType = "buffer", this._resourceId = D("resource"), this._touched = 0, this._updateID = 1, this._updateOffset = 0, this._dataInt32 = null, this.shrinkToFit = !0, this.destroyed = !1, t instanceof Array && (t = new Float32Array(t)), this._data = t, n ??= t?.byteLength;
		let o = !!t;
		this.descriptor = {
			size: n,
			usage: r,
			mappedAtCreation: o,
			label: i
		}, this.shrinkToFit = a ?? !0;
	}
	get data() {
		return this._data;
	}
	set data(e) {
		this.setDataWithSize(e, e.length, !0);
	}
	get dataInt32() {
		return this._dataInt32 ||= new Int32Array(this.data.buffer), this._dataInt32;
	}
	get static() {
		return !!(this.descriptor.usage & Q.STATIC);
	}
	set static(e) {
		e ? this.descriptor.usage |= Q.STATIC : this.descriptor.usage &= ~Q.STATIC;
	}
	setDataWithSize(e, t, n) {
		if (this._updateID++, this._updateSize = t * e.BYTES_PER_ELEMENT, this._updateOffset = 0, this._data === e) {
			n && this.emit("update", this);
			return;
		}
		let r = this._data;
		if (this._data = e, this._dataInt32 = null, !r || r.length !== e.length) {
			!this.shrinkToFit && r && e.byteLength < r.byteLength ? n && this.emit("update", this) : (this.descriptor.size = e.byteLength, this._resourceId = D("resource"), this.emit("change", this));
			return;
		}
		n && this.emit("update", this);
	}
	update(e, t) {
		this._updateSize = e ?? this._updateSize, this._updateOffset = t || 0, this._updateID++, this.emit("update", this);
	}
	unload() {
		this.emit("unload", this);
		for (let e in this._gpuData) this._gpuData[e]?.destroy();
		this._gpuData = /* @__PURE__ */ Object.create(null), this.destroyed || (this._resourceId = D("resource"), this.emit("change", this));
	}
	destroy() {
		this.destroyed = !0, this.unload(), this.emit("destroy", this), this.emit("change", this), this._data = null, this.descriptor = null, this.removeAllListeners();
	}
};
//#endregion
//#region node_modules/pixi.js/lib/rendering/renderers/shared/geometry/utils/ensureIsBuffer.mjs
function Bn(e, t) {
	if (!(e instanceof $)) {
		let n = t ? Q.INDEX : Q.VERTEX;
		e instanceof Array && (t ? (e = new Uint32Array(e), n = Q.INDEX | Q.COPY_DST) : (e = new Float32Array(e), n = Q.VERTEX | Q.COPY_DST)), e = new $({
			data: e,
			label: t ? "index-mesh-buffer" : "vertex-mesh-buffer",
			usage: n
		});
	}
	return e;
}
//#endregion
//#region node_modules/pixi.js/lib/rendering/renderers/shared/geometry/utils/getGeometryBounds.mjs
function Vn(e, t, n) {
	let r = e.getAttribute(t);
	if (!r) return n.minX = 0, n.minY = 0, n.maxX = 0, n.maxY = 0, n;
	let i = r.buffer.data, a = Infinity, o = Infinity, s = -Infinity, c = -Infinity, l = i.BYTES_PER_ELEMENT, u = (r.offset || 0) / l, d = (r.stride || 8) / l;
	for (let e = u; e < i.length; e += d) {
		let t = i[e], n = i[e + 1];
		t > s && (s = t), n > c && (c = n), t < a && (a = t), n < o && (o = n);
	}
	return n.minX = a, n.minY = o, n.maxX = s, n.maxY = c, n;
}
//#endregion
//#region node_modules/pixi.js/lib/rendering/renderers/shared/geometry/Geometry.mjs
function Hn(e) {
	return (e instanceof $ || Array.isArray(e) || e.BYTES_PER_ELEMENT) && (e = { buffer: e }), e.buffer = Bn(e.buffer, !1), e;
}
var Un = class extends h {
	constructor(e = {}) {
		super(), this._gpuData = /* @__PURE__ */ Object.create(null), this.autoGarbageCollect = !0, this._gcLastUsed = -1, this.uid = D("geometry"), this._layoutKey = 0, this.instanceCount = 1, this._bounds = new N(), this._boundsDirty = !0, this._vertexCount = 0, this._vertexCountDirty = !0;
		let { attributes: t, indexBuffer: n, topology: r } = e;
		if (this.buffers = [], this.attributes = {}, t) for (let e in t) this.addAttribute(e, t[e]);
		this.instanceCount = e.instanceCount ?? 1, n && this.addIndex(n), this.topology = r || "triangle-list";
	}
	onBufferUpdate() {
		this._boundsDirty = !0, this._vertexCountDirty = !0, this.emit("update", this);
	}
	getAttribute(e) {
		return this.attributes[e];
	}
	getIndex() {
		return this.indexBuffer;
	}
	getBuffer(e) {
		return this.getAttribute(e).buffer;
	}
	get vertexCount() {
		if (!this._vertexCountDirty) return this._vertexCount;
		this._vertexCountDirty = !1;
		let e = this.attributes;
		for (let t in e) {
			let n = e[t];
			if (n.instance) continue;
			let r = n.buffer;
			return this._vertexCount = r.data.length / (n.stride / 4 || n.size), this._vertexCount;
		}
		return this._vertexCount = 0, 0;
	}
	getSize() {
		return A("8.20.0", "Geometry.getSize is deprecated, please use Geometry.vertexCount instead."), this.vertexCount;
	}
	addAttribute(e, t) {
		let n = Hn(t);
		this.buffers.indexOf(n.buffer) === -1 && (this.buffers.push(n.buffer), n.buffer.on("update", this.onBufferUpdate, this), n.buffer.on("change", this.onBufferUpdate, this)), this.attributes[e] = n, this._vertexCountDirty = !0;
	}
	addIndex(e) {
		this.indexBuffer = Bn(e, !0), this.buffers.push(this.indexBuffer);
	}
	get bounds() {
		return this._boundsDirty ? (this._boundsDirty = !1, Vn(this, "aPosition", this._bounds)) : this._bounds;
	}
	unload() {
		this.emit("unload", this);
		for (let e in this._gpuData) this._gpuData[e]?.destroy();
		this._gpuData = /* @__PURE__ */ Object.create(null);
	}
	destroy(e = !1) {
		this.emit("destroy", this), this.removeAllListeners(), e && this.buffers.forEach((e) => e.destroy()), this.unload(), this.attributes = null, this.buffers = null, this.indexBuffer = null, this._bounds = null;
	}
};
//#endregion
export { E as $, mt as A, N as B, Pt as C, vt as D, Dt as E, nt as F, ve as G, Se as H, H as I, A as J, me as K, $e as L, W as M, U as N, G as O, at as P, se as Q, V as R, Ft as S, kt as T, be as U, M as V, j as W, ue as X, O as Y, D as Z, Ut as _, kn as a, p as at, Rt as b, En as c, Cn as d, x as et, vn as f, J as g, qt as h, zn as i, u as it, dt as j, gt as k, Tn as l, on as m, $ as n, h as nt, Ln as o, s as ot, cn as p, fe as q, Q as r, m as rt, Dn as s, Un as t, y as tt, wn as u, Bt as v, At as w, It as x, zt as y, Ye as z };

//# sourceMappingURL=Geometry-CYPxRocb.js.map