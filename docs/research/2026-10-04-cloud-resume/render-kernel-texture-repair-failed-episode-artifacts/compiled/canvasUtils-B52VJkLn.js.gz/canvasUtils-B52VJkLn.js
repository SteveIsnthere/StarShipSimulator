import { $ as e, W as t, b as n, it as r, z as i } from "./Geometry-CYPxRocb.js";
//#region node_modules/pixi.js/lib/rendering/renderers/shared/texture/sources/ImageSource.mjs
var a = class extends t {
	constructor(e) {
		super(e), this.uploadMethodId = "image", this.autoGarbageCollect = !0;
	}
	static test(e) {
		return globalThis.HTMLImageElement && e instanceof HTMLImageElement || typeof ImageBitmap < "u" && e instanceof ImageBitmap || globalThis.VideoFrame && e instanceof VideoFrame;
	}
};
a.extension = r.TextureSource;
//#endregion
//#region node_modules/pixi.js/lib/rendering/renderers/canvas/utils/canUseNewCanvasBlendModes.mjs
var o;
function s(e) {
	let t = n.get().createCanvas(6, 1), r = t.getContext("2d");
	return r.fillStyle = e, r.fillRect(0, 0, 6, 1), t;
}
function c() {
	if (o !== void 0) return o;
	try {
		let e = s("#ff00ff"), t = s("#ffff00"), r = n.get().createCanvas(6, 1).getContext("2d");
		r.globalCompositeOperation = "multiply", r.drawImage(e, 0, 0), r.drawImage(t, 2, 0);
		let i = r.getImageData(2, 0, 1, 1);
		if (!i) o = !1;
		else {
			let e = i.data;
			o = e[0] === 255 && e[1] === 0 && e[2] === 0;
		}
	} catch {
		o = !1;
	}
	return o;
}
//#endregion
//#region node_modules/pixi.js/lib/rendering/renderers/canvas/utils/canvasUtils.mjs
var l = {
	canvas: null,
	convertTintToImage: !1,
	cacheStepsPerColorChannel: 8,
	canUseMultiply: c(),
	tintMethod: null,
	_canvasSourceCache: /* @__PURE__ */ new WeakMap(),
	_unpremultipliedCache: /* @__PURE__ */ new WeakMap(),
	getCanvasSource: (e) => {
		let t = e.source, r = t?.resource;
		if (!r) return null;
		let i = t.alphaMode === "premultiplied-alpha", a = t.resourceWidth ?? t.pixelWidth, o = t.resourceHeight ?? t.pixelHeight, s = a !== t.pixelWidth || o !== t.pixelHeight;
		if (i) {
			if ((r instanceof HTMLCanvasElement || typeof OffscreenCanvas < "u" && r instanceof OffscreenCanvas) && !s) return r;
			let e = l._unpremultipliedCache.get(t);
			if (e?.resourceId === t._resourceId) return e.canvas;
		}
		if (r instanceof Uint8Array || r instanceof Uint8ClampedArray || r instanceof Int8Array || r instanceof Uint16Array || r instanceof Int16Array || r instanceof Uint32Array || r instanceof Int32Array || r instanceof Float32Array || r instanceof ArrayBuffer) {
			let e = l._canvasSourceCache.get(t);
			if (e?.resourceId === t._resourceId) return e.canvas;
			let i = n.get().createCanvas(t.pixelWidth, t.pixelHeight), a = i.getContext("2d"), o = a.createImageData(t.pixelWidth, t.pixelHeight), s = o.data, c = r instanceof ArrayBuffer ? new Uint8Array(r) : new Uint8Array(r.buffer, r.byteOffset, r.byteLength);
			if (t.format === "bgra8unorm") for (let e = 0; e < s.length && e + 3 < c.length; e += 4) s[e] = c[e + 2], s[e + 1] = c[e + 1], s[e + 2] = c[e], s[e + 3] = c[e + 3];
			else s.set(c.subarray(0, s.length));
			return a.putImageData(o, 0, 0), l._canvasSourceCache.set(t, {
				canvas: i,
				resourceId: t._resourceId
			}), i;
		}
		if (i) {
			let e = n.get().createCanvas(t.pixelWidth, t.pixelHeight), i = e.getContext("2d", { willReadFrequently: !0 });
			e.width = t.pixelWidth, e.height = t.pixelHeight, i.drawImage(r, 0, 0);
			let a = i.getImageData(0, 0, e.width, e.height), o = a.data;
			for (let e = 0; e < o.length; e += 4) {
				let t = o[e + 3];
				if (t > 0) {
					let n = 255 / t;
					o[e] = Math.min(255, o[e] * n + .5), o[e + 1] = Math.min(255, o[e + 1] * n + .5), o[e + 2] = Math.min(255, o[e + 2] * n + .5);
				}
			}
			return i.putImageData(a, 0, 0), l._unpremultipliedCache.set(t, {
				canvas: e,
				resourceId: t._resourceId
			}), e;
		}
		if (s) {
			let e = l._canvasSourceCache.get(t);
			if (e?.resourceId === t._resourceId) return e.canvas;
			let i = n.get().createCanvas(t.pixelWidth, t.pixelHeight), a = i.getContext("2d");
			return i.width = t.pixelWidth, i.height = t.pixelHeight, a.drawImage(r, 0, 0), l._canvasSourceCache.set(t, {
				canvas: i,
				resourceId: t._resourceId
			}), i;
		}
		return r;
	},
	getTintedCanvas: (e, t) => {
		let r = e.texture, a = i.shared.setValue(t).toHex(), o = r.tintCache ||= {}, s = o[a], c = r.source._resourceId;
		if (s?.tintId === c) return s;
		let u = s && "getContext" in s ? s : n.get().createCanvas();
		if (l.tintMethod(r, t, u), u.tintId = c, l.convertTintToImage && u.toDataURL !== void 0) {
			let e = n.get().createImage();
			e.src = u.toDataURL(), e.tintId = c, o[a] = e;
		} else o[a] = u;
		return o[a];
	},
	getTintedPattern: (e, t) => {
		let r = i.shared.setValue(t).toHex(), a = e.patternCache ||= {}, o = e.source._resourceId, s = a[r];
		return s?.tintId === o ? s : (l.canvas ||= n.get().createCanvas(), l.tintMethod(e, t, l.canvas), s = l.canvas.getContext("2d").createPattern(l.canvas, "repeat"), s.tintId = o, a[r] = s, s);
	},
	applyPatternTransform: (e, t, n = !0) => {
		if (!t) return;
		let r = e;
		if (!r.setTransform) return;
		let i = globalThis.DOMMatrix;
		if (!i) return;
		let a = new i([
			t.a,
			t.b,
			t.c,
			t.d,
			t.tx,
			t.ty
		]);
		r.setTransform(n ? a.inverse() : a);
	},
	tintWithMultiply: (t, n, r) => {
		let a = r.getContext("2d"), o = t.frame.clone(), s = t.source._resolution ?? t.source.resolution ?? 1, c = t.rotate;
		o.x *= s, o.y *= s, o.width *= s, o.height *= s;
		let u = e.isVertical(c), d = u ? o.height : o.width, f = u ? o.width : o.height;
		r.width = Math.ceil(d), r.height = Math.ceil(f), a.save(), a.fillStyle = i.shared.setValue(n).toHex(), a.fillRect(0, 0, d, f), a.globalCompositeOperation = "multiply";
		let p = l.getCanvasSource(t);
		if (!p) {
			a.restore();
			return;
		}
		c && l._applyInverseRotation(a, c, o.width, o.height), a.drawImage(p, o.x, o.y, o.width, o.height, 0, 0, o.width, o.height), a.globalCompositeOperation = "destination-atop", a.drawImage(p, o.x, o.y, o.width, o.height, 0, 0, o.width, o.height), a.restore();
	},
	tintWithOverlay: (t, n, r) => {
		let a = r.getContext("2d"), o = t.frame.clone(), s = t.source._resolution ?? t.source.resolution ?? 1, c = t.rotate;
		o.x *= s, o.y *= s, o.width *= s, o.height *= s;
		let u = e.isVertical(c), d = u ? o.height : o.width, f = u ? o.width : o.height;
		r.width = Math.ceil(d), r.height = Math.ceil(f), a.save(), a.globalCompositeOperation = "copy", a.fillStyle = i.shared.setValue(n).toHex(), a.fillRect(0, 0, d, f), a.globalCompositeOperation = "destination-atop";
		let p = l.getCanvasSource(t);
		if (!p) {
			a.restore();
			return;
		}
		c && l._applyInverseRotation(a, c, o.width, o.height), a.drawImage(p, o.x, o.y, o.width, o.height, 0, 0, o.width, o.height), a.restore();
	},
	tintWithPerPixel: (t, n, r) => {
		let i = r.getContext("2d"), a = t.frame.clone(), o = t.source._resolution ?? t.source.resolution ?? 1, s = t.rotate;
		a.x *= o, a.y *= o, a.width *= o, a.height *= o;
		let c = e.isVertical(s), u = c ? a.height : a.width, d = c ? a.width : a.height;
		r.width = Math.ceil(u), r.height = Math.ceil(d), i.save(), i.globalCompositeOperation = "copy";
		let f = l.getCanvasSource(t);
		if (!f) {
			i.restore();
			return;
		}
		s && l._applyInverseRotation(i, s, a.width, a.height), i.drawImage(f, a.x, a.y, a.width, a.height, 0, 0, a.width, a.height), i.restore();
		let p = n >> 16 & 255, m = n >> 8 & 255, h = n & 255, g = i.getImageData(0, 0, u, d), _ = g.data;
		for (let e = 0; e < _.length; e += 4) _[e] = _[e] * p / 255, _[e + 1] = _[e + 1] * m / 255, _[e + 2] = _[e + 2] * h / 255;
		i.putImageData(g, 0, 0);
	},
	_applyInverseRotation: (t, n, r, i) => {
		let a = e.inv(n), o = e.uX(a), s = e.uY(a), c = e.vX(a), l = e.vY(a), u = -Math.min(0, o * r, c * i, o * r + c * i), d = -Math.min(0, s * r, l * i, s * r + l * i);
		t.transform(o, s, c, l, u, d);
	}
};
l.tintMethod = l.canUseMultiply ? l.tintWithMultiply : l.tintWithPerPixel;
//#endregion
export { c as n, a as r, l as t };

//# sourceMappingURL=canvasUtils-B52VJkLn.js.map