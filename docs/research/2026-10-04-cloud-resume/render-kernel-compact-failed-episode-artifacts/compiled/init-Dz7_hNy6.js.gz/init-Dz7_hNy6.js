import { B as e, C as t, D as n, M as r, N as i, Q as a, R as o, U as s, V as c, W as l, _ as u, at as d, b as f, it as p, j as m, x as h, y as g } from "./Geometry-CYPxRocb.js";
import { r as _ } from "./canvasUtils-B52VJkLn.js";
//#region node_modules/pixi.js/lib/rendering/mask/utils/addMaskBounds.mjs
var v = new e();
function y(e, t, n) {
	let r = v;
	e.measurable = !0, m(e, n, r), t.addBoundsMask(r), e.measurable = !1;
}
//#endregion
//#region node_modules/pixi.js/lib/rendering/mask/utils/addMaskLocalBounds.mjs
function b(e, t, a) {
	let o = r.get();
	e.measurable = !0;
	let s = i.get().identity(), c = x(e, a, s);
	n(e, o, c), e.measurable = !1, t.addBoundsMask(o), i.return(s), r.return(o);
}
function x(e, t, n) {
	return e ? (e !== t && (x(e.parent, t, n), e.updateLocalTransform(), n.append(e.localTransform)), n) : (o("Mask bounds, renderable is not inside the root container"), n);
}
//#endregion
//#region node_modules/pixi.js/lib/rendering/mask/alpha/AlphaMask.mjs
var S = class {
	constructor(e) {
		this.priority = 0, this.inverse = !1, this.channel = "red", this.pipe = "alphaMask", e?.mask && this.init(e.mask);
	}
	init(e) {
		this.mask = e, this.renderMaskToTexture = !(e instanceof h), this.mask.renderable = this.renderMaskToTexture, this.mask.includeInBuild = !this.renderMaskToTexture, this.mask.measurable = !1;
	}
	reset() {
		this.mask !== null && (this.mask.measurable = !0, this.mask = null);
	}
	addBounds(e, t) {
		this.inverse || y(this.mask, e, t);
	}
	addLocalBounds(e, t) {
		b(this.mask, e, t);
	}
	containsPoint(e, t) {
		let n = this.mask;
		return t(n, e);
	}
	destroy() {
		this.reset();
	}
	static test(e) {
		return e instanceof h;
	}
};
S.extension = p.MaskEffect;
//#endregion
//#region node_modules/pixi.js/lib/rendering/mask/color/ColorMask.mjs
var C = class {
	constructor(e) {
		this.priority = 0, this.pipe = "colorMask", e?.mask && this.init(e.mask);
	}
	init(e) {
		this.mask = e;
	}
	destroy() {}
	static test(e) {
		return typeof e == "number";
	}
};
C.extension = p.MaskEffect;
//#endregion
//#region node_modules/pixi.js/lib/rendering/mask/stencil/StencilMask.mjs
var w = class {
	constructor(e) {
		this.priority = 0, this.pipe = "stencilMask", e?.mask && this.init(e.mask);
	}
	init(e) {
		this.mask = e, this.mask.includeInBuild = !1, this.mask.measurable = !1;
	}
	reset() {
		this.mask !== null && (this.mask.measurable = !0, this.mask.includeInBuild = !0, this.mask = null);
	}
	addBounds(e, t) {
		y(this.mask, e, t);
	}
	addLocalBounds(e, t) {
		b(this.mask, e, t);
	}
	containsPoint(e, t) {
		let n = this.mask;
		return t(n, e);
	}
	destroy() {
		this.reset();
	}
	static test(e) {
		return e instanceof t;
	}
};
w.extension = p.MaskEffect;
//#endregion
//#region node_modules/pixi.js/lib/utils/browser/detectVideoAlphaMode.mjs
var T;
async function E() {
	return T ??= (async () => {
		let e = f.get().createCanvas(1, 1).getContext("webgl");
		if (!e) return "premultiply-alpha-on-upload";
		let t = await new Promise((e) => {
			let t = document.createElement("video");
			t.onloadeddata = () => e(t), t.onerror = () => e(null), t.autoplay = !1, t.crossOrigin = "anonymous", t.preload = "auto", t.src = "data:video/webm;base64,GkXfo59ChoEBQveBAULygQRC84EIQoKEd2VibUKHgQJChYECGFOAZwEAAAAAAAHTEU2bdLpNu4tTq4QVSalmU6yBoU27i1OrhBZUrmtTrIHGTbuMU6uEElTDZ1OsggEXTbuMU6uEHFO7a1OsggG97AEAAAAAAABZAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAVSalmoCrXsYMPQkBNgIRMYXZmV0GETGF2ZkSJiEBEAAAAAAAAFlSua8yuAQAAAAAAAEPXgQFzxYgAAAAAAAAAAZyBACK1nIN1bmSIgQCGhVZfVlA5g4EBI+ODhAJiWgDglLCBArqBApqBAlPAgQFVsIRVuYEBElTDZ9Vzc9JjwItjxYgAAAAAAAAAAWfInEWjh0VOQ09ERVJEh49MYXZjIGxpYnZweC12cDlnyKJFo4hEVVJBVElPTkSHlDAwOjAwOjAwLjA0MDAwMDAwMAAAH0O2dcfngQCgwqGggQAAAIJJg0IAABAAFgA4JBwYSgAAICAAEb///4r+AAB1oZ2mm+6BAaWWgkmDQgAAEAAWADgkHBhKAAAgIABIQBxTu2uRu4+zgQC3iveBAfGCAXHwgQM=", t.load();
		});
		if (!t) return "premultiply-alpha-on-upload";
		let n = e.createTexture();
		e.bindTexture(e.TEXTURE_2D, n);
		let r = e.createFramebuffer();
		e.bindFramebuffer(e.FRAMEBUFFER, r), e.framebufferTexture2D(e.FRAMEBUFFER, e.COLOR_ATTACHMENT0, e.TEXTURE_2D, n, 0), e.pixelStorei(e.UNPACK_PREMULTIPLY_ALPHA_WEBGL, !1), e.pixelStorei(e.UNPACK_COLORSPACE_CONVERSION_WEBGL, e.NONE), e.texImage2D(e.TEXTURE_2D, 0, e.RGBA, e.RGBA, e.UNSIGNED_BYTE, t);
		let i = /* @__PURE__ */ new Uint8Array(4);
		return e.readPixels(0, 0, 1, 1, e.RGBA, e.UNSIGNED_BYTE, i), e.deleteFramebuffer(r), e.deleteTexture(n), e.getExtension("WEBGL_lose_context")?.loseContext(), i[0] <= i[3] ? "premultiplied-alpha" : "premultiply-alpha-on-upload";
	})(), T;
}
//#endregion
//#region node_modules/pixi.js/lib/rendering/renderers/shared/texture/sources/VideoSource.mjs
var D = class e extends l {
	constructor(t) {
		super(t), this.isReady = !1, this.uploadMethodId = "video", t = {
			...e.defaultOptions,
			...t
		}, this._autoUpdate = !0, this._isConnectedToTicker = !1, this._updateFPS = t.updateFPS || 0, this._msToNextUpdate = 0, this.autoPlay = t.autoPlay !== !1, this.alphaMode = t.alphaMode ?? "premultiply-alpha-on-upload", this._videoFrameRequestCallback = this._videoFrameRequestCallback.bind(this), this._videoFrameRequestCallbackHandle = null, this._load = null, this._resolve = null, this._reject = null, this._onCanPlay = this._onCanPlay.bind(this), this._onCanPlayThrough = this._onCanPlayThrough.bind(this), this._onError = this._onError.bind(this), this._onPlayStart = this._onPlayStart.bind(this), this._onPlayStop = this._onPlayStop.bind(this), this._onSeeked = this._onSeeked.bind(this), this._onLoadedMetadata = this._onLoadedMetadata.bind(this), t.autoLoad !== !1 && this.load();
	}
	updateFrame() {
		if (!this.destroyed) {
			if (this._updateFPS) {
				let e = u.shared.elapsedMS * this.resource.playbackRate;
				this._msToNextUpdate = Math.floor(this._msToNextUpdate - e);
			}
			(!this._updateFPS || this._msToNextUpdate <= 0) && (this._msToNextUpdate = this._updateFPS ? Math.floor(1e3 / this._updateFPS) : 0), this.isValid && this.update();
		}
	}
	_videoFrameRequestCallback() {
		this.updateFrame(), this._videoFrameRequestCallbackHandle = this.destroyed ? null : this.resource.requestVideoFrameCallback(this._videoFrameRequestCallback);
	}
	get isValid() {
		return !!this.resource.videoWidth && !!this.resource.videoHeight;
	}
	async load() {
		if (this._load) return this._load;
		let e = this.resource, t = this.options;
		return (e.readyState === e.HAVE_ENOUGH_DATA || e.readyState === e.HAVE_FUTURE_DATA) && e.width && e.height && (e.complete = !0), e.addEventListener("play", this._onPlayStart), e.addEventListener("pause", this._onPlayStop), e.addEventListener("seeked", this._onSeeked), this._isSourceReady() ? this._mediaReady() : (t.preload || e.addEventListener("canplay", this._onCanPlay), e.addEventListener("canplaythrough", this._onCanPlayThrough), e.addEventListener("error", this._onError, !0)), this.isValid || e.addEventListener("loadedmetadata", this._onLoadedMetadata), this.alphaMode = await E(), this._load = new Promise((n, r) => {
			this.isValid ? n(this) : (this._resolve = n, this._reject = r, t.preloadTimeoutMs !== void 0 && (this._preloadTimeout = setTimeout(() => {
				this._onError(new ErrorEvent(`Preload exceeded timeout of ${t.preloadTimeoutMs}ms`));
			})), e.load());
		}), this._load;
	}
	_onError(e) {
		this.resource.removeEventListener("error", this._onError, !0), this.emit("error", e), this._reject && (this._reject(e), this._reject = null, this._resolve = null);
	}
	_isSourcePlaying() {
		let e = this.resource;
		return !e.paused && !e.ended;
	}
	_isSourceReady() {
		return this.resource.readyState > 2;
	}
	_onPlayStart() {
		this._configureAutoUpdate();
	}
	_onPlayStop() {
		this._configureAutoUpdate();
	}
	_onSeeked() {
		this._autoUpdate && !this._isSourcePlaying() && (this._msToNextUpdate = 0, this.updateFrame(), this._msToNextUpdate = 0);
	}
	_onLoadedMetadata() {
		this.isValid && this._mediaReady();
	}
	_onCanPlay() {
		this.resource.removeEventListener("canplay", this._onCanPlay), this._mediaReady();
	}
	_onCanPlayThrough() {
		this.resource.removeEventListener("canplaythrough", this._onCanPlayThrough), this._preloadTimeout &&= (clearTimeout(this._preloadTimeout), void 0), this._mediaReady();
	}
	_mediaReady() {
		let e = this.resource;
		this.isValid && (this.isReady = !0, this.resize(e.videoWidth, e.videoHeight)), this._msToNextUpdate = 0, this.updateFrame(), this._msToNextUpdate = 0, this._resolve && this.isValid && (this._resolve(this), this._resolve = null, this._reject = null), this._isSourcePlaying() ? this._onPlayStart() : this.autoPlay && this.resource.play();
	}
	destroy() {
		this._configureAutoUpdate();
		let e = this.resource;
		e && (e.removeEventListener("play", this._onPlayStart), e.removeEventListener("pause", this._onPlayStop), e.removeEventListener("seeked", this._onSeeked), e.removeEventListener("canplay", this._onCanPlay), e.removeEventListener("canplaythrough", this._onCanPlayThrough), e.removeEventListener("loadedmetadata", this._onLoadedMetadata), e.removeEventListener("error", this._onError, !0), e.pause(), e.src = "", e.load()), super.destroy();
	}
	get autoUpdate() {
		return this._autoUpdate;
	}
	set autoUpdate(e) {
		e !== this._autoUpdate && (this._autoUpdate = e, this._configureAutoUpdate());
	}
	get updateFPS() {
		return this._updateFPS;
	}
	set updateFPS(e) {
		e !== this._updateFPS && (this._updateFPS = e, this._configureAutoUpdate());
	}
	_configureAutoUpdate() {
		this._autoUpdate && this._isSourcePlaying() ? !this._updateFPS && this.resource.requestVideoFrameCallback ? (this._isConnectedToTicker && (u.shared.remove(this.updateFrame, this), this._isConnectedToTicker = !1, this._msToNextUpdate = 0), this._videoFrameRequestCallbackHandle === null && (this._videoFrameRequestCallbackHandle = this.resource.requestVideoFrameCallback(this._videoFrameRequestCallback))) : (this._videoFrameRequestCallbackHandle !== null && (this.resource.cancelVideoFrameCallback(this._videoFrameRequestCallbackHandle), this._videoFrameRequestCallbackHandle = null), this._isConnectedToTicker || (u.shared.add(this.updateFrame, this), this._isConnectedToTicker = !0, this._msToNextUpdate = 0)) : (this._videoFrameRequestCallbackHandle !== null && (this.resource.cancelVideoFrameCallback(this._videoFrameRequestCallbackHandle), this._videoFrameRequestCallbackHandle = null), this._isConnectedToTicker && (u.shared.remove(this.updateFrame, this), this._isConnectedToTicker = !1, this._msToNextUpdate = 0));
	}
	static test(e) {
		return globalThis.HTMLVideoElement && e instanceof HTMLVideoElement;
	}
};
D.extension = p.TextureSource, D.defaultOptions = {
	...l.defaultOptions,
	autoLoad: !0,
	autoPlay: !0,
	updateFPS: 0,
	crossorigin: !0,
	loop: !1,
	muted: !0,
	playsinline: !0,
	preload: !1
}, D.MIME_TYPES = {
	ogv: "video/ogg",
	mov: "video/quicktime",
	m4v: "video/mp4"
};
var O = D, k = (e, t, n = !1) => (Array.isArray(e) || (e = [e]), t ? e.map((e) => typeof e == "string" || n ? t(e) : e) : e), A = new class {
	constructor() {
		this._parsers = [], this._cache = /* @__PURE__ */ new Map(), this._cacheMap = /* @__PURE__ */ new Map();
	}
	reset() {
		this._cacheMap.clear(), this._cache.clear();
	}
	has(e) {
		return this._cache.has(e);
	}
	get(e) {
		let t = this._cache.get(e);
		return t || o(`[Assets] Asset id ${e} was not found in the Cache`), t;
	}
	set(e, t) {
		let n = k(e), r;
		for (let e = 0; e < this.parsers.length; e++) {
			let i = this.parsers[e];
			if (i.test(t)) {
				r = i.getCacheableAssets(n, t);
				break;
			}
		}
		let i = new Map(Object.entries(r || {}));
		r || n.forEach((e) => {
			i.set(e, t);
		});
		let a = [...i.keys()], s = {
			cacheKeys: a,
			keys: n
		};
		n.forEach((e) => {
			this._cacheMap.set(e, s);
		}), a.forEach((e) => {
			let n = r ? r[e] : t;
			this._cache.has(e) && this._cache.get(e) !== n && o("[Cache] already has key:", e), this._cache.set(e, i.get(e));
		});
	}
	remove(e) {
		if (!this._cacheMap.has(e)) {
			o(`[Assets] Asset id ${e} was not found in the Cache`);
			return;
		}
		let t = this._cacheMap.get(e);
		t.cacheKeys.forEach((e) => {
			this._cache.delete(e);
		}), t.keys.forEach((e) => {
			this._cacheMap.delete(e);
		});
	}
	get parsers() {
		return this._parsers;
	}
}(), j = [];
d.handleByList(p.TextureSource, j);
function M(e = {}) {
	let t = e && e.resource, n = t ? e.resource : e, r = t ? e : { resource: e };
	for (let e = 0; e < j.length; e++) {
		let t = j[e];
		if (t.test(n)) return new t(r);
	}
	throw Error(`Could not find a source type for resource: ${r.resource}`);
}
function N(e = {}, t = !1) {
	let n = e && e.resource, r = n ? e.resource : e, i = n ? e : { resource: e };
	if (!t && A.has(r)) return A.get(r);
	let a = new c({ source: M(i) });
	return a.on("destroy", () => {
		A.has(r) && A.remove(r);
	}), t || A.set(r, a), a;
}
function P(e, t = !1) {
	return typeof e == "string" ? A.get(e) : e instanceof l ? new c({ source: e }) : N(e, t);
}
//#endregion
//#region node_modules/pixi.js/lib/rendering/init.mjs
c.from = P, l.from = M, d.add(S, C, w, O, _, g, s);
//#endregion
//#region node_modules/pixi.js/lib/assets/loader/parsers/LoaderParser.mjs
var F = /* @__PURE__ */ ((e) => (e[e.Low = 0] = "Low", e[e.Normal = 1] = "Normal", e[e.High = 2] = "High", e))(F || {});
//#endregion
//#region node_modules/pixi.js/lib/utils/path.mjs
function I(e) {
	if (typeof e != "string") throw TypeError(`Path must be a string. Received ${JSON.stringify(e)}`);
}
function L(e) {
	return e.split("?")[0].split("#")[0];
}
function R(e) {
	return e.replace(/[.*+?^${}()|[\]\\]/g, "\\$&");
}
function z(e, t, n) {
	return e.replace(new RegExp(R(t), "g"), n);
}
function B(e, t) {
	let n = "", r = 0, i = -1, a = 0, o = -1;
	for (let s = 0; s <= e.length; ++s) {
		if (s < e.length) o = e.charCodeAt(s);
		else if (o === 47) break;
		else o = 47;
		if (o === 47) {
			if (i !== s - 1 && a !== 1) {
				if (i !== s - 1 && a === 2) {
					if (n.length < 2 || r !== 2 || n.charCodeAt(n.length - 1) !== 46 || n.charCodeAt(n.length - 2) !== 46) {
						if (n.length > 2) {
							let e = n.lastIndexOf("/");
							if (e !== n.length - 1) {
								e === -1 ? (n = "", r = 0) : (n = n.slice(0, e), r = n.length - 1 - n.lastIndexOf("/")), i = s, a = 0;
								continue;
							}
						} else if (n.length === 2 || n.length === 1) {
							n = "", r = 0, i = s, a = 0;
							continue;
						}
					}
					t && (n.length > 0 ? n += "/.." : n = "..", r = 2);
				} else n.length > 0 ? n += `/${e.slice(i + 1, s)}` : n = e.slice(i + 1, s), r = s - i - 1;
			}
			i = s, a = 0;
		} else o === 46 && a !== -1 ? ++a : a = -1;
	}
	return n;
}
var V = {
	toPosix(e) {
		return z(e, "\\", "/");
	},
	isUrl(e) {
		return /^https?:/.test(this.toPosix(e));
	},
	isDataUrl(e) {
		return /^data:([a-z]+\/[a-z0-9-+.]+(;[a-z0-9-.!#$%*+.{}|~`]+=[a-z0-9-.!#$%*+.{}()_|~`]+)*)?(;base64)?,([a-z0-9!$&',()*+;=\-._~:@\/?%\s<>]*?)$/i.test(e);
	},
	isBlobUrl(e) {
		return e.startsWith("blob:");
	},
	hasProtocol(e) {
		return /^[^/:]+:/.test(this.toPosix(e));
	},
	getProtocol(e) {
		I(e), e = this.toPosix(e);
		let t = /^file:\/\/\//.exec(e);
		if (t) return t[0];
		let n = /^[^/:]+:\/{0,2}/.exec(e);
		return n ? n[0] : "";
	},
	toAbsolute(e, t, n) {
		if (I(e), this.isDataUrl(e) || this.isBlobUrl(e)) return e;
		let r = L(this.toPosix(t ?? f.get().getBaseUrl())), i = L(this.toPosix(n ?? this.rootname(r)));
		return e = this.toPosix(e), e.startsWith("/") ? V.join(i, e.slice(1)) : this.isAbsolute(e) ? e : this.join(r, e);
	},
	normalize(e) {
		if (I(e), e.length === 0) return ".";
		if (this.isDataUrl(e) || this.isBlobUrl(e)) return e;
		e = this.toPosix(e);
		let t = "", n = e.startsWith("/");
		this.hasProtocol(e) && (t = this.rootname(e), e = e.slice(t.length));
		let r = e.endsWith("/");
		return e = B(e, !1), e.length > 0 && r && (e += "/"), n ? `/${e}` : t + e;
	},
	isAbsolute(e) {
		return I(e), e = this.toPosix(e), this.hasProtocol(e) ? !0 : e.startsWith("/");
	},
	join(...e) {
		if (e.length === 0) return ".";
		let t;
		for (let n = 0; n < e.length; ++n) {
			let r = e[n];
			if (I(r), r.length > 0) {
				if (t === void 0) t = r;
				else {
					let i = e[n - 1] ?? "";
					this.joinExtensions.includes(this.extname(i).toLowerCase()) ? t += `/../${r}` : t += `/${r}`;
				}
			}
		}
		return t === void 0 ? "." : this.normalize(t);
	},
	dirname(e) {
		if (I(e), e.length === 0) return ".";
		e = this.toPosix(e);
		let t = e.charCodeAt(0), n = t === 47, r = -1, i = !0, a = this.getProtocol(e), o = e;
		e = e.slice(a.length);
		for (let n = e.length - 1; n >= 1; --n) if (t = e.charCodeAt(n), t === 47) {
			if (!i) {
				r = n;
				break;
			}
		} else i = !1;
		return r === -1 ? n ? "/" : this.isUrl(o) ? a + e : a : n && r === 1 ? "//" : a + e.slice(0, r);
	},
	rootname(e) {
		I(e), e = this.toPosix(e);
		let t = "";
		if (t = e.startsWith("/") ? "/" : this.getProtocol(e), this.isUrl(e)) {
			let n = e.indexOf("/", t.length);
			t = n === -1 ? e : e.slice(0, n), t.endsWith("/") || (t += "/");
		}
		return t;
	},
	basename(e, t) {
		I(e), t && I(t), e = L(this.toPosix(e));
		let n = 0, r = -1, i = !0, a;
		if (t !== void 0 && t.length > 0 && t.length <= e.length) {
			if (t.length === e.length && t === e) return "";
			let o = t.length - 1, s = -1;
			for (a = e.length - 1; a >= 0; --a) {
				let c = e.charCodeAt(a);
				if (c === 47) {
					if (!i) {
						n = a + 1;
						break;
					}
				} else s === -1 && (i = !1, s = a + 1), o >= 0 && (c === t.charCodeAt(o) ? --o === -1 && (r = a) : (o = -1, r = s));
			}
			return n === r ? r = s : r === -1 && (r = e.length), e.slice(n, r);
		}
		for (a = e.length - 1; a >= 0; --a) if (e.charCodeAt(a) === 47) {
			if (!i) {
				n = a + 1;
				break;
			}
		} else r === -1 && (i = !1, r = a + 1);
		return r === -1 ? "" : e.slice(n, r);
	},
	extname(e) {
		I(e), e = L(this.toPosix(e));
		let t = -1, n = 0, r = -1, i = !0, a = 0;
		for (let o = e.length - 1; o >= 0; --o) {
			let s = e.charCodeAt(o);
			if (s === 47) {
				if (!i) {
					n = o + 1;
					break;
				}
				continue;
			}
			r === -1 && (i = !1, r = o + 1), s === 46 ? t === -1 ? t = o : a !== 1 && (a = 1) : t !== -1 && (a = -1);
		}
		return t === -1 || r === -1 || a === 0 || a === 1 && t === r - 1 && t === n + 1 ? "" : e.slice(t, r);
	},
	parse(e) {
		I(e);
		let t = {
			root: "",
			dir: "",
			base: "",
			ext: "",
			name: ""
		};
		if (e.length === 0) return t;
		e = L(this.toPosix(e));
		let n = e.charCodeAt(0), r = this.isAbsolute(e), i;
		t.root = this.rootname(e), i = r || this.hasProtocol(e) ? 1 : 0;
		let a = -1, o = 0, s = -1, c = !0, l = e.length - 1, u = 0;
		for (; l >= i; --l) {
			if (n = e.charCodeAt(l), n === 47) {
				if (!c) {
					o = l + 1;
					break;
				}
				continue;
			}
			s === -1 && (c = !1, s = l + 1), n === 46 ? a === -1 ? a = l : u !== 1 && (u = 1) : a !== -1 && (u = -1);
		}
		return a === -1 || s === -1 || u === 0 || u === 1 && a === s - 1 && a === o + 1 ? s !== -1 && (t.base = t.name = o === 0 && r ? e.slice(1, s) : e.slice(o, s)) : (o === 0 && r ? (t.name = e.slice(1, a), t.base = e.slice(1, s)) : (t.name = e.slice(o, a), t.base = e.slice(o, s)), t.ext = e.slice(a, s)), t.dir = this.dirname(e), t;
	},
	sep: "/",
	delimiter: ":",
	joinExtensions: [".html"]
};
//#endregion
//#region node_modules/pixi.js/lib/assets/utils/createStringVariations.mjs
function H(e, t, n, r, i) {
	let a = t[n];
	for (let o = 0; o < a.length; o++) {
		let s = a[o];
		n < t.length - 1 ? H(e.replace(r[n], s), t, n + 1, r, i) : i.push(e.replace(r[n], s));
	}
}
function U(e) {
	let t = e.match(/\{(.*?)\}/g), n = [];
	if (t) {
		let r = [];
		t.forEach((e) => {
			let t = e.substring(1, e.length - 1).split(",");
			r.push(t);
		}), H(e, r, 0, t, n);
	} else n.push(e);
	return n;
}
//#endregion
//#region node_modules/pixi.js/lib/assets/utils/isSingleItem.mjs
var W = (e) => !Array.isArray(e), G = class {
	constructor() {
		this._defaultBundleIdentifierOptions = {
			connector: "-",
			createBundleAssetId: (e, t) => `${e}${this._bundleIdConnector}${t}`,
			extractAssetIdFromBundle: (e, t) => t.replace(`${e}${this._bundleIdConnector}`, "")
		}, this._bundleIdConnector = this._defaultBundleIdentifierOptions.connector, this._createBundleAssetId = this._defaultBundleIdentifierOptions.createBundleAssetId, this._extractAssetIdFromBundle = this._defaultBundleIdentifierOptions.extractAssetIdFromBundle, this._assetMap = {}, this._preferredOrder = [], this._parsers = [], this._resolverHash = {}, this._bundles = {};
	}
	setBundleIdentifier(e) {
		if (this._bundleIdConnector = e.connector ?? this._bundleIdConnector, this._createBundleAssetId = e.createBundleAssetId ?? this._createBundleAssetId, this._extractAssetIdFromBundle = e.extractAssetIdFromBundle ?? this._extractAssetIdFromBundle, this._extractAssetIdFromBundle("foo", this._createBundleAssetId("foo", "bar")) !== "bar") throw Error("[Resolver] GenerateBundleAssetId are not working correctly");
	}
	prefer(...e) {
		e.forEach((e) => {
			this._preferredOrder.push(e), e.priority ||= Object.keys(e.params);
		}), this._resolverHash = {};
	}
	set basePath(e) {
		this._basePath = e;
	}
	get basePath() {
		return this._basePath;
	}
	set rootPath(e) {
		this._rootPath = e;
	}
	get rootPath() {
		return this._rootPath;
	}
	get parsers() {
		return this._parsers;
	}
	reset() {
		this.setBundleIdentifier(this._defaultBundleIdentifierOptions), this._assetMap = {}, this._preferredOrder = [], this._resolverHash = {}, this._rootPath = null, this._basePath = null, this._manifest = null, this._bundles = {}, this._defaultSearchParams = null;
	}
	setDefaultSearchParams(e) {
		if (typeof e == "string") this._defaultSearchParams = e;
		else {
			let t = e;
			this._defaultSearchParams = Object.keys(t).map((e) => `${encodeURIComponent(e)}=${encodeURIComponent(t[e])}`).join("&");
		}
	}
	getAlias(e) {
		let { alias: t, src: n } = e;
		return k(t || n, (e) => typeof e == "string" ? e : Array.isArray(e) ? e.map((e) => e?.src ?? e) : e?.src ? e.src : e, !0);
	}
	removeAlias(e, t) {
		this._assetMap[e] && (t && t !== this._resolverHash[e] || (delete this._resolverHash[e], delete this._assetMap[e]));
	}
	addManifest(e) {
		this._manifest && o("[Resolver] Manifest already exists, this will be overwritten"), this._manifest = e, e.bundles.forEach((e) => {
			this.addBundle(e.name, e.assets);
		});
	}
	addBundle(e, t) {
		let n = [], r = t;
		Array.isArray(t) || (r = Object.entries(t).map(([e, t]) => typeof t == "string" || Array.isArray(t) ? {
			alias: e,
			src: t
		} : {
			alias: e,
			...t
		})), r.forEach((t) => {
			let r = t.src, i = t.alias, a;
			if (typeof i == "string") {
				let t = this._createBundleAssetId(e, i);
				n.push(t), a = [i, t];
			} else {
				let t = i.map((t) => this._createBundleAssetId(e, t));
				n.push(...t), a = [...i, ...t];
			}
			this.add({
				...t,
				alias: a,
				src: r
			});
		}), this._bundles[e] = n;
	}
	add(e) {
		let t = [];
		Array.isArray(e) ? t.push(...e) : t.push(e);
		let n = (e) => {
			this.hasKey(e) && o(`[Resolver] already has key: ${e} overwriting`);
		};
		k(t).forEach((e) => {
			let { src: t } = e, { data: r, format: i, loadParser: a, parser: o } = e, s = k(t).map((e) => typeof e == "string" ? U(e) : Array.isArray(e) ? e : [e]), c = this.getAlias(e);
			Array.isArray(c) ? c.forEach(n) : n(c);
			let l = [], u = (e) => ({
				src: e,
				...this._parsers.find((t) => t.test(e))?.parse(e)
			});
			s.forEach((t) => {
				t.forEach((t) => {
					let n = {};
					if (typeof t == "object" ? (r = t.data ?? r, i = t.format ?? i, (t.loadParser || t.parser) && (a = t.loadParser ?? a, o = t.parser ?? o), n = {
						...u(t.src),
						...t
					}) : n = u(t), !c) throw Error(`[Resolver] alias is undefined for this asset: ${n.src}`);
					n = this._buildResolvedAsset(n, {
						aliases: c,
						data: r,
						format: i,
						loadParser: a,
						parser: o,
						progressSize: e.progressSize
					}), l.push(n);
				});
			}), c.forEach((e) => {
				this._assetMap[e] = l;
			});
		});
	}
	resolveBundle(e) {
		let t = W(e);
		e = k(e);
		let n = {};
		return e.forEach((e) => {
			let t = this._bundles[e];
			if (t) {
				let r = this.resolve(t), i = {};
				for (let t in r) {
					let n = r[t];
					i[this._extractAssetIdFromBundle(e, t)] = n;
				}
				n[e] = i;
			}
		}), t ? n[e[0]] : n;
	}
	resolveUrl(e) {
		let t = this.resolve(e);
		if (typeof e != "string") {
			let e = {};
			for (let n in t) e[n] = t[n].src;
			return e;
		}
		return t.src;
	}
	resolve(e) {
		let t = W(e);
		e = k(e);
		let n = {};
		return e.forEach((e) => {
			if (!this._resolverHash[e]) {
				if (this._assetMap[e]) {
					let t = this._assetMap[e], n = this._getPreferredOrder(t);
					n?.priority.forEach((e) => {
						n.params[e].forEach((n) => {
							let r = t.filter((t) => t[e] ? t[e] === n : !1);
							r.length && (t = r);
						});
					}), this._resolverHash[e] = t[0];
				} else this._resolverHash[e] = this._buildResolvedAsset({
					alias: [e],
					src: e
				}, {});
			}
			n[e] = this._resolverHash[e];
		}), t ? n[e[0]] : n;
	}
	hasKey(e) {
		return !!this._assetMap[e];
	}
	hasBundle(e) {
		return !!this._bundles[e];
	}
	_getPreferredOrder(e) {
		for (let t = 0; t < e.length; t++) {
			let n = e[t], r = this._preferredOrder.find((e) => e.params.format.includes(n.format));
			if (r) return r;
		}
		return this._preferredOrder[0];
	}
	_appendDefaultSearchParams(e) {
		return this._defaultSearchParams ? `${e}${/\?/.test(e) ? "&" : "?"}${this._defaultSearchParams}` : e;
	}
	_buildResolvedAsset(e, t) {
		let { aliases: n, data: r, loadParser: i, parser: a, format: o, progressSize: s } = t;
		return (this._basePath || this._rootPath) && (e.src = V.toAbsolute(e.src, this._basePath, this._rootPath)), e.alias = n ?? e.alias ?? [e.src], e.src = this._appendDefaultSearchParams(e.src), e.data = {
			...r || {},
			...e.data
		}, e.loadParser = i ?? e.loadParser, e.parser = a ?? e.parser, e.format = o ?? e.format ?? K(e.src), s !== void 0 && (e.progressSize = s), e;
	}
};
G.RETINA_PREFIX = /@([0-9\.]+)x/;
function K(e) {
	return e.split(".").pop().split("?").shift().split("#").shift();
}
//#endregion
//#region node_modules/pixi.js/lib/assets/utils/copySearchParams.mjs
var q = (e, t) => {
	let n = t.split("?")[1];
	return n && (e += `?${n}`), e;
}, J = class e {
	constructor(e, t) {
		this.linkedSheets = [];
		let n = e;
		e?.source instanceof l && (n = {
			texture: e,
			data: t
		});
		let { texture: r, data: i, cachePrefix: a = "" } = n;
		this.cachePrefix = a, this._texture = r instanceof c ? r : null, this.textureSource = r.source, this.textures = {}, this.animations = {}, this.data = i;
		let o = parseFloat(i.meta.scale);
		o ? (this.resolution = o, r.source.resolution = this.resolution) : this.resolution = r.source._resolution, this._frames = this.data.frames, this._frameKeys = Object.keys(this._frames), this._batchIndex = 0, this._callback = null;
	}
	parse() {
		return new Promise((t) => {
			this._callback = t, this._batchIndex = 0, this._frameKeys.length <= e.BATCH_SIZE ? (this._processFrames(0), this._processAnimations(), this._parseComplete()) : this._nextBatch();
		});
	}
	parseSync() {
		return this._processFrames(0, !0), this._processAnimations(), this.textures;
	}
	_processFrames(t, n = !1) {
		let r = t, i = n ? Infinity : e.BATCH_SIZE;
		for (; r - t < i && r < this._frameKeys.length;) {
			let e = this._frameKeys[r], t = this._frames[e], n = t.frame;
			if (n) {
				let r = null, i = null, o = t.trimmed !== !1 && t.sourceSize ? t.sourceSize : t.frame, s = new a(0, 0, Math.floor(o.w) / this.resolution, Math.floor(o.h) / this.resolution);
				r = t.rotated ? new a(Math.floor(n.x) / this.resolution, Math.floor(n.y) / this.resolution, Math.floor(n.h) / this.resolution, Math.floor(n.w) / this.resolution) : new a(Math.floor(n.x) / this.resolution, Math.floor(n.y) / this.resolution, Math.floor(n.w) / this.resolution, Math.floor(n.h) / this.resolution), t.trimmed !== !1 && t.spriteSourceSize && (i = new a(Math.floor(t.spriteSourceSize.x) / this.resolution, Math.floor(t.spriteSourceSize.y) / this.resolution, Math.floor(n.w) / this.resolution, Math.floor(n.h) / this.resolution)), this.textures[e] = new c({
					source: this.textureSource,
					frame: r,
					orig: s,
					trim: i,
					rotate: t.rotated ? 2 : 0,
					defaultAnchor: t.anchor,
					defaultBorders: t.borders,
					label: e.toString()
				});
			}
			r++;
		}
	}
	_processAnimations() {
		let e = this.data.animations || {};
		for (let t in e) {
			this.animations[t] = [];
			for (let n = 0; n < e[t].length; n++) {
				let r = e[t][n];
				this.animations[t].push(this.textures[r]);
			}
		}
	}
	_parseComplete() {
		let e = this._callback;
		this._callback = null, this._batchIndex = 0, e.call(this, this.textures);
	}
	_nextBatch() {
		this._processFrames(this._batchIndex * e.BATCH_SIZE), this._batchIndex++, setTimeout(() => {
			this._batchIndex * e.BATCH_SIZE < this._frameKeys.length ? this._nextBatch() : (this._processAnimations(), this._parseComplete());
		}, 0);
	}
	destroy(e = !1) {
		for (let e in this.textures) this.textures[e].destroy();
		this._frames = null, this._frameKeys = null, this.data = null, this.textures = null, e && (this._texture?.destroy(), this.textureSource.destroy()), this._texture = null, this.textureSource = null, this.linkedSheets = [];
	}
};
J.BATCH_SIZE = 1e3;
var Y = J, X = [
	"jpg",
	"png",
	"jpeg",
	"avif",
	"webp",
	"basis",
	"etc2",
	"bc7",
	"bc6h",
	"bc5",
	"bc4",
	"bc3",
	"bc2",
	"bc1",
	"eac",
	"astc"
];
function Z(e, t, n) {
	let r = {};
	if (e.forEach((e) => {
		r[e] = t;
	}), Object.keys(t.textures).forEach((e) => {
		r[`${t.cachePrefix}${e}`] = t.textures[e];
	}), !n) {
		let n = V.dirname(e[0]);
		t.linkedSheets.forEach((e, i) => {
			let a = Z([`${n}/${t.data.meta.related_multi_packs[i]}`], e, !0);
			Object.assign(r, a);
		});
	}
	return r;
}
var Q = {
	extension: p.Asset,
	cache: {
		test: (e) => e instanceof Y,
		getCacheableAssets: (e, t) => Z(e, t, !1)
	},
	resolver: {
		extension: {
			type: p.ResolveParser,
			name: "resolveSpritesheet"
		},
		test: (e) => {
			let t = e.split("?")[0].split("."), n = t.pop(), r = t.pop();
			return n === "json" && X.includes(r);
		},
		parse: (e) => {
			let t = e.split(".");
			return {
				resolution: parseFloat(G.RETINA_PREFIX.exec(e)?.[1] ?? "1"),
				format: t[t.length - 2],
				src: e
			};
		}
	},
	loader: {
		name: "spritesheetLoader",
		id: "spritesheet",
		extension: {
			type: p.LoadParser,
			priority: F.Normal,
			name: "spritesheetLoader"
		},
		async testParse(e, t) {
			return V.extname(t.src).toLowerCase() === ".json" && !!e.frames;
		},
		async parse(e, t, n) {
			let { texture: r, imageFilename: i, textureOptions: a, cachePrefix: o } = t?.data ?? {}, s = V.dirname(t.src);
			s && s.lastIndexOf("/") !== s.length - 1 && (s += "/");
			let l;
			if (r instanceof c) l = r;
			else {
				let r = q(s + (i ?? e.meta.image), t.src);
				l = (await n.load([{
					src: r,
					data: a
				}]))[r];
			}
			let u = new Y({
				texture: l.source,
				data: e,
				cachePrefix: o
			});
			await u.parse();
			let d = e?.meta?.related_multi_packs;
			if (Array.isArray(d)) {
				let e = [];
				for (let r of d) {
					if (typeof r != "string") continue;
					let i = s + r;
					t.data?.ignoreMultiPack || (i = q(i, t.src), e.push(n.load({
						src: i,
						data: {
							textureOptions: a,
							ignoreMultiPack: !0
						}
					})));
				}
				let r = await Promise.all(e);
				u.linkedSheets = r, r.forEach((e) => {
					e.linkedSheets = [u].concat(u.linkedSheets.filter((t) => t !== e));
				});
			}
			return u;
		},
		async unload(e, t, n) {
			await n.unload(e.textureSource._sourceOrigin), e.destroy(!1);
		}
	}
};
//#endregion
//#region node_modules/pixi.js/lib/spritesheet/init.mjs
d.add(Q);
//#endregion
export { A as t };

//# sourceMappingURL=init-Dz7_hNy6.js.map