import { B as e, C as t, D as n, G as r, H as i, I as a, J as o, L as s, P as c, Q as l, R as u, T as d, V as f, W as p, Y as m, Z as h, _ as g, at as _, b as v, d as y, et as b, f as ee, h as te, i as ne, it as x, j as re, k as ie, l as S, m as ae, n as oe, nt as se, o as ce, r as C, s as le, t as ue, tt as de, u as fe, w as pe, x as me, y as w, z as T } from "./Geometry-CYPxRocb.js";
//#region node_modules/pixi.js/lib/environment/autoDetectEnvironment.mjs
var E = [];
_.handleByNamedList(x.Environment, E);
async function he(e) {
	if (!e) for (let e = 0; e < E.length; e++) {
		let t = E[e];
		if (t.value.test()) {
			await t.value.load();
			return;
		}
	}
}
//#endregion
//#region node_modules/pixi.js/lib/utils/browser/unsafeEvalSupported.mjs
var D;
function ge() {
	if (typeof D == "boolean") return D;
	try {
		D = Function("param1", "param2", "param3", "return param1[param2] === param3;")({ a: "b" }, "a", "b") === !0;
	} catch {
		D = !1;
	}
	return D;
}
//#endregion
//#region node_modules/pixi.js/lib/rendering/renderers/gl/const.mjs
var O = /* @__PURE__ */ ((e) => (e[e.NONE = 0] = "NONE", e[e.COLOR = 16384] = "COLOR", e[e.STENCIL = 1024] = "STENCIL", e[e.DEPTH = 256] = "DEPTH", e[e.COLOR_DEPTH = 16640] = "COLOR_DEPTH", e[e.COLOR_STENCIL = 17408] = "COLOR_STENCIL", e[e.DEPTH_STENCIL = 1280] = "DEPTH_STENCIL", e[e.ALL = 17664] = "ALL", e))(O || {}), _e = class {
	constructor(e) {
		this.items = [], this._name = e;
	}
	emit(e, t, n, r, i, a, o, s) {
		let { name: c, items: l } = this;
		for (let u = 0, d = l.length; u < d; u++) l[u][c](e, t, n, r, i, a, o, s);
		return this;
	}
	add(e) {
		return e[this._name] && (this.remove(e), this.items.push(e)), this;
	}
	remove(e) {
		let t = this.items.indexOf(e);
		return t !== -1 && this.items.splice(t, 1), this;
	}
	contains(e) {
		return this.items.indexOf(e) !== -1;
	}
	removeAll() {
		return this.items.length = 0, this;
	}
	destroy() {
		this.removeAll(), this.items = null, this._name = null;
	}
	get empty() {
		return this.items.length === 0;
	}
	get name() {
		return this._name;
	}
}, ve = [
	"init",
	"destroy",
	"contextChange",
	"resolutionChange",
	"resetState",
	"renderEnd",
	"renderStart",
	"render",
	"update",
	"postrender",
	"prerender"
], ye = class e extends se {
	constructor(e) {
		super(), this.tick = 0, this.uid = h("renderer"), this.runners = /* @__PURE__ */ Object.create(null), this.renderPipes = /* @__PURE__ */ Object.create(null), this._initOptions = {}, this._systemsHash = /* @__PURE__ */ Object.create(null), this.type = e.type, this.name = e.name, this.config = e;
		let t = [...ve, ...this.config.runners ?? []];
		this._addRunners(...t), this._unsafeEvalCheck();
	}
	async init(t = {}) {
		await he(t.skipExtensionImports === !0 || t.manageImports === !1), this._addSystems(this.config.systems), this._addPipes(this.config.renderPipes, this.config.renderPipeAdaptors);
		for (let e in this._systemsHash) t = {
			...this._systemsHash[e].constructor.defaultOptions,
			...t
		};
		t = {
			...e.defaultOptions,
			...t
		}, this._roundPixels = +!!t.roundPixels;
		for (let e = 0; e < this.runners.init.items.length; e++) await this.runners.init.items[e].init(t);
		this._initOptions = t;
	}
	render(e, n) {
		this.tick++;
		let r = e;
		if (r instanceof t && (r = { container: r }, n && (o(m, "passing a second argument is deprecated, please use render options instead"), r.target = n.renderTexture)), r.target || (r.target = this.view.renderTarget), r.target === this.view.renderTarget && (this._lastObjectRendered = r.container, r.clearColor ?? (r.clearColor = this.background.colorRgba), r.clear ?? (r.clear = this.background.clearBeforeRender)), r.clearColor) {
			let e = Array.isArray(r.clearColor) && r.clearColor.length === 4;
			r.clearColor = e ? r.clearColor : T.shared.setValue(r.clearColor).toArray();
		}
		r.transform || (r.container.updateLocalTransform(), r.transform = r.container.localTransform), r.container.visible && (r.container.enableRenderGroup(), this.runners.prerender.emit(r), this.runners.renderStart.emit(r), this.runners.render.emit(r), this.runners.renderEnd.emit(r), this.runners.postrender.emit(r));
	}
	resize(e, t, n) {
		let r = this.view.resolution;
		this.view.resize(e, t, n), this.emit("resize", this.view.screen.width, this.view.screen.height, this.view.resolution), n !== void 0 && n !== r && this.runners.resolutionChange.emit(n);
	}
	clear(e = {}) {
		let t = this;
		e.target ||= t.renderTarget.renderTarget, e.clearColor ||= this.background.colorRgba, e.clear ??= O.ALL;
		let { clear: n, clearColor: r, target: i, mipLevel: a, layer: o } = e;
		T.shared.setValue(r ?? this.background.colorRgba), t.renderTarget.clear(i, n, T.shared.toArray(), a ?? 0, o ?? 0);
	}
	get resolution() {
		return this.view.resolution;
	}
	set resolution(e) {
		this.view.resolution = e, this.runners.resolutionChange.emit(e);
	}
	get width() {
		return this.view.texture.frame.width;
	}
	get height() {
		return this.view.texture.frame.height;
	}
	get canvas() {
		return this.view.canvas;
	}
	get lastObjectRendered() {
		return this._lastObjectRendered;
	}
	get renderingToScreen() {
		return this.renderTarget.renderingToScreen;
	}
	get screen() {
		return this.view.screen;
	}
	_addRunners(...e) {
		e.forEach((e) => {
			this.runners[e] = new _e(e);
		});
	}
	_addSystems(e) {
		let t;
		for (t in e) {
			let n = e[t];
			this._addSystem(n.value, n.name);
		}
	}
	_addSystem(e, t) {
		let n = new e(this);
		if (this[t]) throw Error(`Whoops! The name "${t}" is already in use`);
		this[t] = n, this._systemsHash[t] = n;
		for (let e in this.runners) this.runners[e].add(n);
		return this;
	}
	_addPipes(e, t) {
		let n = t.reduce((e, t) => (e[t.name] = t.value, e), {});
		e.forEach((e) => {
			let t = e.value, r = e.name, i = n[r];
			this.renderPipes[r] = new t(this, i ? new i() : null), this.runners.destroy.add(this.renderPipes[r]);
		});
	}
	destroy(e = !1) {
		this.runners.destroy.items.reverse(), this.runners.destroy.emit(e), (e === !0 || typeof e == "object" && e.releaseGlobalResources) && s.release(), Object.values(this.runners).forEach((e) => {
			e.destroy();
		}), this._systemsHash = null, this.renderPipes = null, this.removeAllListeners();
	}
	generateTexture(e) {
		return this.textureGenerator.generateTexture(e);
	}
	get roundPixels() {
		return !!this._roundPixels;
	}
	_unsafeEvalCheck() {
		if (!ge()) throw Error("Current environment does not allow unsafe-eval, please use pixi.js/unsafe-eval module to enable support.");
	}
	resetState() {
		this.runners.resetState.emit();
	}
};
ye.defaultOptions = {
	resolution: 1,
	failIfMajorPerformanceCaveat: !1,
	roundPixels: !1
};
var be = ye, k = "8.20.0", xe = class {
	static init() {
		globalThis.__PIXI_APP_INIT__?.(this, k);
	}
	static destroy() {}
};
xe.extension = x.Application;
var Se = class {
	constructor(e) {
		this._renderer = e;
	}
	init() {
		globalThis.__PIXI_RENDERER_INIT__?.(this._renderer, k);
	}
	destroy() {
		this._renderer = null;
	}
};
Se.extension = {
	type: [x.WebGLSystem, x.WebGPUSystem],
	name: "initHook",
	priority: -10
};
//#endregion
//#region node_modules/pixi.js/lib/utils/data/ViewableBuffer.mjs
var Ce = class {
	constructor(e) {
		this.rawBinaryData = typeof e == "number" ? new ArrayBuffer(e) : e instanceof Uint8Array ? e.buffer : e, this.uint32View = new Uint32Array(this.rawBinaryData), this.float32View = new Float32Array(this.rawBinaryData), this.size = this.rawBinaryData.byteLength;
	}
	get int8View() {
		return this._int8View ||= new Int8Array(this.rawBinaryData), this._int8View;
	}
	get uint8View() {
		return this._uint8View ||= new Uint8Array(this.rawBinaryData), this._uint8View;
	}
	get int16View() {
		return this._int16View ||= new Int16Array(this.rawBinaryData), this._int16View;
	}
	get int32View() {
		return this._int32View ||= new Int32Array(this.rawBinaryData), this._int32View;
	}
	get float64View() {
		return this._float64Array ||= new Float64Array(this.rawBinaryData), this._float64Array;
	}
	get bigUint64View() {
		return this._bigUint64Array ||= new BigUint64Array(this.rawBinaryData), this._bigUint64Array;
	}
	view(e) {
		return this[`${e}View`];
	}
	destroy() {
		this.rawBinaryData = null, this.uint32View = null, this.float32View = null, this.uint16View = null, this._int8View = null, this._uint8View = null, this._int16View = null, this._int32View = null, this._float64Array = null, this._bigUint64Array = null;
	}
	static sizeOf(e) {
		switch (e) {
			case "int8":
			case "uint8": return 1;
			case "int16":
			case "uint16": return 2;
			case "int32":
			case "uint32":
			case "float32": return 4;
			default: throw Error(`${e} isn't a valid view type`);
		}
	}
};
//#endregion
//#region node_modules/pixi.js/lib/rendering/renderers/shared/buffer/utils/fastCopy.mjs
function A(e, t, n, r) {
	if (n ??= 0, r ??= Math.min(e.byteLength - n, t.byteLength), !(n & 7) && !(r & 7)) {
		let i = r / 8;
		new Float64Array(t, 0, i).set(new Float64Array(e, n, i));
	} else if (!(n & 3) && !(r & 3)) {
		let i = r / 4;
		new Float32Array(t, 0, i).set(new Float32Array(e, n, i));
	} else new Uint8Array(t).set(new Uint8Array(e, n, r));
}
//#endregion
//#region node_modules/pixi.js/lib/rendering/renderers/shared/state/const.mjs
var we = {
	normal: "normal-npm",
	add: "add-npm",
	screen: "screen-npm"
}, j = /* @__PURE__ */ ((e) => (e[e.DISABLED = 0] = "DISABLED", e[e.RENDERING_MASK_ADD = 1] = "RENDERING_MASK_ADD", e[e.MASK_ACTIVE = 2] = "MASK_ACTIVE", e[e.INVERSE_MASK_ACTIVE = 3] = "INVERSE_MASK_ACTIVE", e[e.RENDERING_MASK_REMOVE = 4] = "RENDERING_MASK_REMOVE", e[e.NONE = 5] = "NONE", e))(j || {});
//#endregion
//#region node_modules/pixi.js/lib/rendering/renderers/shared/state/getAdjustedBlendModeBlend.mjs
function M(e, t) {
	return t.alphaMode === "no-premultiply-alpha" && we[e] || e;
}
//#endregion
//#region node_modules/pixi.js/lib/rendering/batcher/gl/utils/checkMaxIfStatementsInShader.mjs
var Te = [
	"precision mediump float;",
	"void main(void){",
	"float test = 0.1;",
	"%forloop%",
	"gl_FragColor = vec4(0.0);",
	"}"
].join("\n");
function Ee(e) {
	let t = "";
	for (let n = 0; n < e; ++n) n > 0 && (t += "\nelse "), n < e - 1 && (t += `if(test == ${n}.0){}`);
	return t;
}
function De(e, t) {
	if (e === 0) throw Error("Invalid value of `0` passed to `checkMaxIfStatementsInShader`");
	let n = t.createShader(t.FRAGMENT_SHADER);
	try {
		for (;;) {
			let r = Te.replace(/%forloop%/gi, Ee(e));
			if (t.shaderSource(n, r), t.compileShader(n), !t.getShaderParameter(n, t.COMPILE_STATUS)) e = e / 2 | 0;
			else break;
		}
	} finally {
		t.deleteShader(n);
	}
	return e;
}
//#endregion
//#region node_modules/pixi.js/lib/rendering/batcher/gl/utils/maxRecommendedTextures.mjs
var N = null;
function Oe() {
	if (N) return N;
	let e = te();
	return N = e.getParameter(e.MAX_TEXTURE_IMAGE_UNITS), N = De(N, e), e.getExtension("WEBGL_lose_context")?.loseContext(), N;
}
//#endregion
//#region node_modules/pixi.js/lib/rendering/batcher/shared/BatchTextureArray.mjs
var ke = class {
	constructor() {
		this.ids = /* @__PURE__ */ Object.create(null), this.textures = [], this.count = 0;
	}
	clear() {
		for (let e = 0; e < this.count; e++) {
			let t = this.textures[e];
			this.textures[e] = null, this.ids[t.uid] = null;
		}
		this.count = 0;
	}
}, Ae = class {
	constructor() {
		this.renderPipeId = "batch", this.action = "startBatch", this.start = 0, this.size = 0, this.textures = new ke(), this.blendMode = "normal", this.topology = "triangle-strip", this.canBundle = !0;
	}
	destroy() {
		this.textures = null, this.gpuBindGroup = null, this.bindGroup = null, this.batcher = null, this.elements = null;
	}
}, P = [], F = 0;
s.register({ clear: () => {
	if (P.length > 0) for (let e of P) e && e.destroy();
	P.length = 0, F = 0;
} });
function je() {
	return F > 0 ? P[--F] : new Ae();
}
function Me(e) {
	e.elements = null, P[F++] = e;
}
var I = 0, Ne = class e {
	constructor(t) {
		this.uid = h("batcher"), this.dirty = !0, this.batchIndex = 0, this.batches = [], this._elements = [], t = {
			...e.defaultOptions,
			...t
		}, t.maxTextures || (o("v8.8.0", "maxTextures is a required option for Batcher now, please pass it in the options"), t.maxTextures = Oe());
		let { maxTextures: n, attributesInitialSize: r, indicesInitialSize: i } = t;
		this.attributeBuffer = new Ce(r * 4), this.indexBuffer = new Uint16Array(i), this.maxTextures = n;
	}
	begin() {
		this.elementSize = 0, this.elementStart = 0, this.indexSize = 0, this.attributeSize = 0;
		for (let e = 0; e < this.batchIndex; e++) Me(this.batches[e]);
		this.batchIndex = 0, this._batchIndexStart = 0, this._batchIndexSize = 0, this.dirty = !0;
	}
	add(e) {
		this._elements[this.elementSize++] = e, e._indexStart = this.indexSize, e._attributeStart = this.attributeSize, e._batcher = this, this.indexSize += e.indexSize, this.attributeSize += e.attributeSize * this.vertexSize;
	}
	checkAndUpdateTexture(e, t) {
		let n = e._batch.textures.ids[t._source.uid];
		return !n && n !== 0 ? !1 : (e._textureId = n, e.texture = t, !0);
	}
	updateElement(e) {
		this.dirty = !0;
		let t = this.attributeBuffer;
		e.packAsQuad ? this.packQuadAttributes(e, t.float32View, t.uint32View, e._attributeStart, e._textureId) : this.packAttributes(e, t.float32View, t.uint32View, e._attributeStart, e._textureId);
	}
	break(e) {
		let t = this._elements;
		if (!t[this.elementStart]) return;
		let n = je(), r = n.textures;
		r.clear();
		let i = t[this.elementStart], a = M(i.blendMode, i.texture._source), o = i.topology;
		this.attributeSize * 4 > this.attributeBuffer.size && this._resizeAttributeBuffer(this.attributeSize * 4), this.indexSize > this.indexBuffer.length && this._resizeIndexBuffer(this.indexSize);
		let s = this.attributeBuffer.float32View, c = this.attributeBuffer.uint32View, l = this.indexBuffer, u = this._batchIndexSize, d = this._batchIndexStart, f = "startBatch", p = [], m = this.maxTextures;
		for (let i = this.elementStart; i < this.elementSize; ++i) {
			let h = t[i];
			t[i] = null;
			let g = h.texture._source, _ = M(h.blendMode, g), v = a !== _ || o !== h.topology;
			if (g._batchTick === I && !v) {
				h._textureId = g._textureBindLocation, u += h.indexSize, h.packAsQuad ? (this.packQuadAttributes(h, s, c, h._attributeStart, h._textureId), this.packQuadIndex(l, h._indexStart, h._attributeStart / this.vertexSize)) : (this.packAttributes(h, s, c, h._attributeStart, h._textureId), this.packIndex(h, l, h._indexStart, h._attributeStart / this.vertexSize)), h._batch = n, p.push(h);
				continue;
			}
			g._batchTick = I, (r.count >= m || v) && (this._finishBatch(n, d, u - d, r, a, o, e, f, p), f = "renderBatch", d = u, a = _, o = h.topology, n = je(), r = n.textures, r.clear(), p = [], ++I), h._textureId = g._textureBindLocation = r.count, r.ids[g.uid] = r.count, r.textures[r.count++] = g, h._batch = n, p.push(h), u += h.indexSize, h.packAsQuad ? (this.packQuadAttributes(h, s, c, h._attributeStart, h._textureId), this.packQuadIndex(l, h._indexStart, h._attributeStart / this.vertexSize)) : (this.packAttributes(h, s, c, h._attributeStart, h._textureId), this.packIndex(h, l, h._indexStart, h._attributeStart / this.vertexSize));
		}
		r.count > 0 && (this._finishBatch(n, d, u - d, r, a, o, e, f, p), d = u, ++I), this.elementStart = this.elementSize, this._batchIndexStart = d, this._batchIndexSize = u;
	}
	_finishBatch(e, t, n, r, i, a, o, s, c) {
		e.gpuBindGroup = null, e.bindGroup = null, e.action = s, e.batcher = this, e.textures = r, e.blendMode = i, e.topology = a, e.start = t, e.size = n, e.elements = c, ++I, this.batches[this.batchIndex++] = e, o.add(e);
	}
	finish(e) {
		this.break(e);
	}
	ensureAttributeBuffer(e) {
		e * 4 <= this.attributeBuffer.size || this._resizeAttributeBuffer(e * 4);
	}
	ensureIndexBuffer(e) {
		e <= this.indexBuffer.length || this._resizeIndexBuffer(e);
	}
	_resizeAttributeBuffer(e) {
		let t = new Ce(Math.max(e, this.attributeBuffer.size * 2));
		A(this.attributeBuffer.rawBinaryData, t.rawBinaryData), this.attributeBuffer = t;
	}
	_resizeIndexBuffer(e) {
		let t = this.indexBuffer, n = Math.max(e, t.length * 1.5);
		n += n % 2;
		let r = n > 65535 ? new Uint32Array(n) : new Uint16Array(n);
		if (r.BYTES_PER_ELEMENT !== t.BYTES_PER_ELEMENT) for (let e = 0; e < t.length; e++) r[e] = t[e];
		else A(t.buffer, r.buffer);
		this.indexBuffer = r;
	}
	packQuadIndex(e, t, n) {
		e[t] = n + 0, e[t + 1] = n + 1, e[t + 2] = n + 2, e[t + 3] = n + 0, e[t + 4] = n + 2, e[t + 5] = n + 3;
	}
	packIndex(e, t, n, r) {
		let i = e.indices, a = e.indexSize, o = e.indexOffset, s = e.attributeOffset;
		for (let e = 0; e < a; e++) t[n++] = r + i[e + o] - s;
	}
	destroy(e = {}) {
		if (this.batches !== null) {
			for (let e = 0; e < this.batchIndex; e++) Me(this.batches[e]);
			this.batches = null, this.geometry.destroy(!0), this.geometry = null, e.shader && (this.shader?.destroy(), this.shader = null);
			for (let e = 0; e < this._elements.length; e++) this._elements[e] && (this._elements[e]._batch = null);
			this._elements = null, this.indexBuffer = null, this.attributeBuffer.destroy(), this.attributeBuffer = null;
		}
	}
};
Ne.defaultOptions = {
	maxTextures: null,
	attributesInitialSize: 4,
	indicesInitialSize: 6
};
var Pe = Ne, Fe = /* @__PURE__ */ new Float32Array(1), Ie = /* @__PURE__ */ new Uint32Array(1), Le = class extends ue {
	constructor() {
		let e = new oe({
			data: Fe,
			label: "attribute-batch-buffer",
			usage: C.VERTEX | C.COPY_DST,
			shrinkToFit: !1
		}), t = new oe({
			data: Ie,
			label: "index-batch-buffer",
			usage: C.INDEX | C.COPY_DST,
			shrinkToFit: !1
		});
		super({
			attributes: {
				aPosition: {
					buffer: e,
					format: "float32x2",
					stride: 24,
					offset: 0
				},
				aUV: {
					buffer: e,
					format: "float32x2",
					stride: 24,
					offset: 8
				},
				aColor: {
					buffer: e,
					format: "unorm8x4",
					stride: 24,
					offset: 16
				},
				aTextureIdAndRound: {
					buffer: e,
					format: "uint16x2",
					stride: 24,
					offset: 20
				}
			},
			indexBuffer: t
		});
	}
};
//#endregion
//#region node_modules/pixi.js/lib/rendering/high-shader/compiler/utils/addBits.mjs
function Re(e, t, n) {
	if (e) for (let r in e) {
		let i = t[r.toLocaleLowerCase()];
		if (i) {
			let t = e[r];
			r === "header" && (t = t.replace(/@in\s+[^;]+;\s*/g, "").replace(/@out\s+[^;]+;\s*/g, "")), n && i.push(`//----${n}----//`), i.push(t);
		} else u(`${r} placement hook does not exist in shader`);
	}
}
//#endregion
//#region node_modules/pixi.js/lib/rendering/high-shader/compiler/utils/compileHooks.mjs
var ze = /\{\{(.*?)\}\}/g;
function Be(e) {
	let t = {};
	return (e.match(ze)?.map((e) => e.replace(/[{()}]/g, "")) ?? []).forEach((e) => {
		t[e] = [];
	}), t;
}
//#endregion
//#region node_modules/pixi.js/lib/rendering/high-shader/compiler/utils/compileInputs.mjs
function Ve(e, t) {
	let n, r = /@in\s+([^;]+);/g;
	for (; (n = r.exec(e)) !== null;) t.push(n[1]);
}
function He(e, t, n = !1) {
	let r = [];
	Ve(t, r), e.forEach((e) => {
		e.header && Ve(e.header, r);
	});
	let i = r;
	n && i.sort();
	let a = i.map((e, t) => `       @location(${t}) ${e},`).join("\n"), o = t.replace(/@in\s+[^;]+;\s*/g, "");
	return o = o.replace("{{in}}", `
${a}
`), o;
}
//#endregion
//#region node_modules/pixi.js/lib/rendering/high-shader/compiler/utils/compileOutputs.mjs
function Ue(e, t) {
	let n, r = /@out\s+([^;]+);/g;
	for (; (n = r.exec(e)) !== null;) t.push(n[1]);
}
function We(e) {
	let t = /\b(\w+)\s*:/g.exec(e);
	return t ? t[1] : "";
}
function Ge(e) {
	return e.replace(/@.*?\s+/g, "");
}
function Ke(e, t) {
	let n = [];
	Ue(t, n), e.forEach((e) => {
		e.header && Ue(e.header, n);
	});
	let r = 0, i = n.sort().map((e) => e.indexOf("builtin") > -1 ? e : `@location(${r++}) ${e}`).join(",\n"), a = n.sort().map((e) => `       var ${Ge(e)};`).join("\n"), o = `return VSOutput(
            ${n.sort().map((e) => ` ${We(e)}`).join(",\n")});`, s = t.replace(/@out\s+[^;]+;\s*/g, "");
	return s = s.replace("{{struct}}", `
${i}
`), s = s.replace("{{start}}", `
${a}
`), s = s.replace("{{return}}", `
${o}
`), s;
}
//#endregion
//#region node_modules/pixi.js/lib/rendering/high-shader/compiler/utils/injectBits.mjs
function qe(e, t) {
	let n = e;
	for (let e in t) {
		let r = t[e];
		n = r.join("\n").length ? n.replace(`{{${e}}}`, `//-----${e} START-----//
${r.join("\n")}
//----${e} FINISH----//`) : n.replace(`{{${e}}}`, "");
	}
	return n;
}
//#endregion
//#region node_modules/pixi.js/lib/rendering/high-shader/compiler/compileHighShader.mjs
var L = /* @__PURE__ */ Object.create(null), Je = /* @__PURE__ */ new Map(), Ye = 0;
function Xe({ template: e, bits: t }) {
	let n = $e(e, t);
	if (L[n]) return L[n];
	let { vertex: r, fragment: i } = Qe(e, t);
	return L[n] = et(r, i, t), L[n];
}
function Ze({ template: e, bits: t }) {
	let n = $e(e, t);
	return L[n] || (L[n] = et(e.vertex, e.fragment, t)), L[n];
}
function Qe(e, t) {
	let n = t.map((e) => e.vertex).filter((e) => !!e), r = t.map((e) => e.fragment).filter((e) => !!e), i = He(n, e.vertex, !0);
	i = Ke(n, i);
	let a = He(r, e.fragment, !0);
	return {
		vertex: i,
		fragment: a
	};
}
function $e(e, t) {
	return t.map((e) => (Je.has(e) || Je.set(e, Ye++), Je.get(e))).sort((e, t) => e - t).join("-") + e.vertex + e.fragment;
}
function et(e, t, n) {
	let r = Be(e), i = Be(t);
	return n.forEach((e) => {
		Re(e.vertex, r, e.name), Re(e.fragment, i, e.name);
	}), {
		vertex: qe(e, r),
		fragment: qe(t, i)
	};
}
//#endregion
//#region node_modules/pixi.js/lib/rendering/high-shader/defaultProgramTemplate.mjs
var tt = "\n    @in aPosition: vec2<f32>;\n    @in aUV: vec2<f32>;\n\n    @out @builtin(position) vPosition: vec4<f32>;\n    @out vUV : vec2<f32>;\n    @out vColor : vec4<f32>;\n\n    {{header}}\n\n    struct VSOutput {\n        {{struct}}\n    };\n\n    @vertex\n    fn main( {{in}} ) -> VSOutput {\n\n        var worldTransformMatrix = globalUniforms.uWorldTransformMatrix;\n        var modelMatrix = mat3x3<f32>(\n            1.0, 0.0, 0.0,\n            0.0, 1.0, 0.0,\n            0.0, 0.0, 1.0\n          );\n        var position = aPosition;\n        var uv = aUV;\n\n        {{start}}\n\n        vColor = vec4<f32>(1., 1., 1., 1.);\n\n        {{main}}\n\n        vUV = uv;\n\n        var modelViewProjectionMatrix = globalUniforms.uProjectionMatrix * worldTransformMatrix * modelMatrix;\n\n        vPosition =  vec4<f32>((modelViewProjectionMatrix *  vec3<f32>(position, 1.0)).xy, 0.0, 1.0);\n\n        vColor *= globalUniforms.uWorldColorAlpha;\n\n        {{end}}\n\n        {{return}}\n    };\n", nt = "\n    @in vUV : vec2<f32>;\n    @in vColor : vec4<f32>;\n\n    {{header}}\n\n    @fragment\n    fn main(\n        {{in}}\n      ) -> @location(0) vec4<f32> {\n\n        {{start}}\n\n        var outColor:vec4<f32>;\n\n        {{main}}\n\n        var finalColor:vec4<f32> = outColor * vColor;\n\n        {{end}}\n\n        return finalColor;\n      };\n", rt = "\n    in vec2 aPosition;\n    in vec2 aUV;\n\n    out vec4 vColor;\n    out vec2 vUV;\n\n    {{header}}\n\n    void main(void){\n\n        mat3 worldTransformMatrix = uWorldTransformMatrix;\n        mat3 modelMatrix = mat3(\n            1.0, 0.0, 0.0,\n            0.0, 1.0, 0.0,\n            0.0, 0.0, 1.0\n          );\n        vec2 position = aPosition;\n        vec2 uv = aUV;\n\n        {{start}}\n\n        vColor = vec4(1.);\n\n        {{main}}\n\n        vUV = uv;\n\n        mat3 modelViewProjectionMatrix = uProjectionMatrix * worldTransformMatrix * modelMatrix;\n\n        gl_Position = vec4((modelViewProjectionMatrix * vec3(position, 1.0)).xy, 0.0, 1.0);\n\n        vColor *= uWorldColorAlpha;\n\n        {{end}}\n    }\n", it = "\n\n    in vec4 vColor;\n    in vec2 vUV;\n\n    out vec4 finalColor;\n\n    {{header}}\n\n    void main(void) {\n\n        {{start}}\n\n        vec4 outColor;\n\n        {{main}}\n\n        finalColor = outColor * vColor;\n\n        {{end}}\n    }\n", at = {
	name: "global-uniforms-bit",
	vertex: { header: "\n        struct GlobalUniforms {\n            uProjectionMatrix:mat3x3<f32>,\n            uWorldTransformMatrix:mat3x3<f32>,\n            uWorldColorAlpha: vec4<f32>,\n            uResolution: vec2<f32>,\n        }\n\n        @group(0) @binding(0) var<uniform> globalUniforms : GlobalUniforms;\n        " }
}, ot = {
	name: "global-uniforms-bit",
	vertex: { header: "\n          uniform mat3 uProjectionMatrix;\n          uniform mat3 uWorldTransformMatrix;\n          uniform vec4 uWorldColorAlpha;\n          uniform vec2 uResolution;\n        " }
};
//#endregion
//#region node_modules/pixi.js/lib/rendering/high-shader/compileHighShaderToProgram.mjs
function st({ bits: e, name: t }) {
	let n = Xe({
		template: {
			fragment: nt,
			vertex: tt
		},
		bits: [at, ...e]
	});
	return ee.from({
		name: t,
		vertex: {
			source: n.vertex,
			entryPoint: "main"
		},
		fragment: {
			source: n.fragment,
			entryPoint: "main"
		}
	});
}
function ct({ bits: e, name: t }) {
	return new ae({
		name: t,
		...Ze({
			template: {
				vertex: rt,
				fragment: it
			},
			bits: [ot, ...e]
		})
	});
}
//#endregion
//#region node_modules/pixi.js/lib/rendering/high-shader/shader-bits/colorBit.mjs
var lt = {
	name: "color-bit",
	vertex: {
		header: "\n            @in aColor: vec4<f32>;\n        ",
		main: "\n            vColor *= vec4<f32>(aColor.rgb * aColor.a, aColor.a);\n        "
	}
}, ut = {
	name: "color-bit",
	vertex: {
		header: "\n            in vec4 aColor;\n        ",
		main: "\n            vColor *= vec4(aColor.rgb * aColor.a, aColor.a);\n        "
	}
}, dt = {};
function ft(e) {
	let t = [];
	if (e === 1) t.push("@group(1) @binding(0) var textureSource1: texture_2d<f32>;"), t.push("@group(1) @binding(1) var textureSampler1: sampler;");
	else {
		let n = 0;
		for (let r = 0; r < e; r++) t.push(`@group(1) @binding(${n++}) var textureSource${r + 1}: texture_2d<f32>;`), t.push(`@group(1) @binding(${n++}) var textureSampler${r + 1}: sampler;`);
	}
	return t.join("\n");
}
function pt(e) {
	let t = [];
	if (e === 1) t.push("outColor = textureSampleGrad(textureSource1, textureSampler1, vUV, uvDx, uvDy);");
	else {
		t.push("switch vTextureId {");
		for (let n = 0; n < e; n++) n === e - 1 ? t.push("  default:{") : t.push(`  case ${n}:{`), t.push(`      outColor = textureSampleGrad(textureSource${n + 1}, textureSampler${n + 1}, vUV, uvDx, uvDy);`), t.push("      break;}");
		t.push("}");
	}
	return t.join("\n");
}
function mt(e) {
	return dt[e] || (dt[e] = {
		name: "texture-batch-bit",
		vertex: {
			header: "\n                @in aTextureIdAndRound: vec2<u32>;\n                @out @interpolate(flat) vTextureId : u32;\n            ",
			main: "\n                vTextureId = aTextureIdAndRound.y;\n            ",
			end: "\n                if(aTextureIdAndRound.x == 1)\n                {\n                    vPosition = vec4<f32>(roundPixels(vPosition.xy, globalUniforms.uResolution), vPosition.zw);\n                }\n            "
		},
		fragment: {
			header: `
                @in @interpolate(flat) vTextureId: u32;

                ${ft(e)}
            `,
			main: `
                var uvDx = dpdx(vUV);
                var uvDy = dpdy(vUV);

                ${pt(e)}
            `
		}
	}), dt[e];
}
var ht = {};
function gt(e) {
	let t = [];
	for (let n = 0; n < e; n++) n > 0 && t.push("else"), n < e - 1 && t.push(`if(vTextureId < ${n}.5)`), t.push("{"), t.push(`	outColor = texture(uTextures[${n}], vUV);`), t.push("}");
	return t.join("\n");
}
function _t(e) {
	return ht[e] || (ht[e] = {
		name: "texture-batch-bit",
		vertex: {
			header: "\n                in vec2 aTextureIdAndRound;\n                out float vTextureId;\n\n            ",
			main: "\n                vTextureId = aTextureIdAndRound.y;\n            ",
			end: "\n                if(aTextureIdAndRound.x == 1.)\n                {\n                    gl_Position.xy = roundPixels(gl_Position.xy, uResolution);\n                }\n            "
		},
		fragment: {
			header: `
                in float vTextureId;

                uniform sampler2D uTextures[${e}];

            `,
			main: `

                ${gt(e)}
            `
		}
	}), ht[e];
}
//#endregion
//#region node_modules/pixi.js/lib/rendering/high-shader/shader-bits/roundPixelsBit.mjs
var vt = {
	name: "round-pixels-bit",
	vertex: { header: "\n            fn roundPixels(position: vec2<f32>, targetSize: vec2<f32>) -> vec2<f32>\n            {\n                return (floor(((position * 0.5 + 0.5) * targetSize) + 0.5) / targetSize) * 2.0 - 1.0;\n            }\n        " }
}, yt = {
	name: "round-pixels-bit",
	vertex: { header: "\n            vec2 roundPixels(vec2 position, vec2 targetSize)\n            {\n                return (floor(((position * 0.5 + 0.5) * targetSize) + 0.5) / targetSize) * 2.0 - 1.0;\n            }\n        " }
}, bt = {};
function xt(e) {
	let t = bt[e];
	if (t) return t;
	let n = new Int32Array(e);
	for (let t = 0; t < e; t++) n[t] = t;
	return t = bt[e] = new y({ uTextures: {
		value: n,
		type: "i32",
		size: e
	} }, { isStatic: !0 }), t;
}
//#endregion
//#region node_modules/pixi.js/lib/rendering/batcher/shared/DefaultShader.mjs
var St = class extends le {
	constructor(e) {
		let t = ct({
			name: "batch",
			bits: [
				ut,
				_t(e),
				yt
			]
		}), n = st({
			name: "batch",
			bits: [
				lt,
				mt(e),
				vt
			]
		});
		super({
			glProgram: t,
			gpuProgram: n,
			resources: { batchSamplers: xt(e) }
		}), this.maxTextures = e;
	}
}, R = null, Ct = class e extends Pe {
	constructor(t) {
		super(t), this.geometry = new Le(), this.name = e.extension.name, this.vertexSize = 6, R ??= new St(t.maxTextures), this.shader = R;
	}
	packAttributes(e, t, n, r, i) {
		let a = i << 16 | e.roundPixels & 65535, o = e.transform, s = o.a, c = o.b, l = o.c, u = o.d, d = o.tx, f = o.ty, { positions: p, uvs: m } = e, h = e.color, g = e.attributeOffset, _ = g + e.attributeSize;
		for (let e = g; e < _; e++) {
			let i = e * 2, o = p[i], g = p[i + 1];
			t[r++] = s * o + l * g + d, t[r++] = u * g + c * o + f, t[r++] = m[i], t[r++] = m[i + 1], n[r++] = h, n[r++] = a;
		}
	}
	packQuadAttributes(e, t, n, r, i) {
		let a = e.texture, o = e.transform, s = o.a, c = o.b, l = o.c, u = o.d, d = o.tx, f = o.ty, p = e.bounds, m = p.maxX, h = p.minX, g = p.maxY, _ = p.minY, v = a.uvs, y = e.color, b = i << 16 | e.roundPixels & 65535;
		t[r + 0] = s * h + l * _ + d, t[r + 1] = u * _ + c * h + f, t[r + 2] = v.x0, t[r + 3] = v.y0, n[r + 4] = y, n[r + 5] = b, t[r + 6] = s * m + l * _ + d, t[r + 7] = u * _ + c * m + f, t[r + 8] = v.x1, t[r + 9] = v.y1, n[r + 10] = y, n[r + 11] = b, t[r + 12] = s * m + l * g + d, t[r + 13] = u * g + c * m + f, t[r + 14] = v.x2, t[r + 15] = v.y2, n[r + 16] = y, n[r + 17] = b, t[r + 18] = s * h + l * g + d, t[r + 19] = u * g + c * h + f, t[r + 20] = v.x3, t[r + 21] = v.y3, n[r + 22] = y, n[r + 23] = b;
	}
	_updateMaxTextures(e) {
		this.shader.maxTextures !== e && (R = new St(e), this.shader = R);
	}
	destroy() {
		this.shader = null, super.destroy();
	}
};
Ct.extension = {
	type: [x.Batcher],
	name: "default"
};
var z = Ct, wt = class {
	constructor(e) {
		this.items = /* @__PURE__ */ Object.create(null);
		let { renderer: t, type: n, onUnload: r, priority: i, name: a } = e;
		this._renderer = t, t.gc.addResourceHash(this, "items", n, i ?? 0), this._onUnload = r, this.name = a;
	}
	add(e) {
		return !this.items[e.uid] && (this.items[e.uid] = e, e.once("unload", this.remove, this), e._gcLastUsed = this._renderer.gc.now, !0);
	}
	remove(e, ...t) {
		if (!this.items[e.uid]) return;
		let n = e._gpuData[this._renderer.uid];
		n && (this._onUnload?.(e, ...t), n.destroy(), e._gpuData[this._renderer.uid] = null, this.items[e.uid] = null);
	}
	removeAll(...e) {
		Object.values(this.items).forEach((t) => t && this.remove(t, ...e));
	}
	destroy(...e) {
		this.removeAll(...e), this.items = /* @__PURE__ */ Object.create(null), this._renderer = null, this._onUnload = null;
	}
}, Tt = "in vec2 vMaskCoord;\nin vec2 vTextureCoord;\n\nuniform sampler2D uTexture;\nuniform sampler2D uMaskTexture;\n\nuniform float uAlpha;\nuniform vec4 uMaskClamp;\nuniform float uInverse;\nuniform float uChannel;\n\nout vec4 finalColor;\n\nvoid main(void)\n{\n    float clip = step(3.5,\n        step(uMaskClamp.x, vMaskCoord.x) +\n        step(uMaskClamp.y, vMaskCoord.y) +\n        step(vMaskCoord.x, uMaskClamp.z) +\n        step(vMaskCoord.y, uMaskClamp.w));\n\n    // TODO look into why this is needed\n    float npmAlpha = uAlpha;\n    vec4 original = texture(uTexture, vTextureCoord);\n    vec4 masky = texture(uMaskTexture, vMaskCoord);\n\n    float a;\n    if (uChannel == 1.0) {\n        a = masky.a * npmAlpha * clip;\n    } else {\n        float alphaMul = 1.0 - npmAlpha * (1.0 - masky.a);\n        a = alphaMul * masky.r * npmAlpha * clip;\n    }\n\n    if (uInverse == 1.0) {\n        a = 1.0 - a;\n    }\n\n    finalColor = original * a;\n}\n", Et = "in vec2 aPosition;\n\nout vec2 vTextureCoord;\nout vec2 vMaskCoord;\n\n\nuniform vec4 uInputSize;\nuniform vec4 uOutputFrame;\nuniform vec4 uOutputTexture;\nuniform mat3 uFilterMatrix;\n\nvec4 filterVertexPosition(  vec2 aPosition )\n{\n    vec2 position = aPosition * uOutputFrame.zw + uOutputFrame.xy;\n       \n    position.x = position.x * (2.0 / uOutputTexture.x) - 1.0;\n    position.y = position.y * (2.0*uOutputTexture.z / uOutputTexture.y) - uOutputTexture.z;\n\n    return vec4(position, 0.0, 1.0);\n}\n\nvec2 filterTextureCoord(  vec2 aPosition )\n{\n    return aPosition * (uOutputFrame.zw * uInputSize.zw);\n}\n\nvec2 getFilterCoord( vec2 aPosition )\n{\n    return  ( uFilterMatrix * vec3( filterTextureCoord(aPosition), 1.0)  ).xy;\n}   \n\nvoid main(void)\n{\n    gl_Position = filterVertexPosition(aPosition);\n    vTextureCoord = filterTextureCoord(aPosition);\n    vMaskCoord = getFilterCoord(aPosition);\n}\n", Dt = "struct GlobalFilterUniforms {\n  uInputSize:vec4<f32>,\n  uInputPixel:vec4<f32>,\n  uInputClamp:vec4<f32>,\n  uOutputFrame:vec4<f32>,\n  uGlobalFrame:vec4<f32>,\n  uOutputTexture:vec4<f32>,\n};\n\nstruct MaskUniforms {\n  uFilterMatrix:mat3x3<f32>,\n  uMaskClamp:vec4<f32>,\n  uAlpha:f32,\n  uInverse:f32,\n  uChannel:f32,\n};\n\n@group(0) @binding(0) var<uniform> gfu: GlobalFilterUniforms;\n@group(0) @binding(1) var uTexture: texture_2d<f32>;\n@group(0) @binding(2) var uSampler : sampler;\n\n@group(1) @binding(0) var<uniform> filterUniforms : MaskUniforms;\n@group(1) @binding(1) var uMaskTexture: texture_2d<f32>;\n\nstruct VSOutput {\n    @builtin(position) position: vec4<f32>,\n    @location(0) uv : vec2<f32>,\n    @location(1) filterUv : vec2<f32>,\n};\n\nfn filterVertexPosition(aPosition:vec2<f32>) -> vec4<f32>\n{\n    var position = aPosition * gfu.uOutputFrame.zw + gfu.uOutputFrame.xy;\n\n    position.x = position.x * (2.0 / gfu.uOutputTexture.x) - 1.0;\n    position.y = position.y * (2.0*gfu.uOutputTexture.z / gfu.uOutputTexture.y) - gfu.uOutputTexture.z;\n\n    return vec4(position, 0.0, 1.0);\n}\n\nfn filterTextureCoord( aPosition:vec2<f32> ) -> vec2<f32>\n{\n    return aPosition * (gfu.uOutputFrame.zw * gfu.uInputSize.zw);\n}\n\nfn globalTextureCoord( aPosition:vec2<f32> ) -> vec2<f32>\n{\n  return  (aPosition.xy / gfu.uGlobalFrame.zw) + (gfu.uGlobalFrame.xy / gfu.uGlobalFrame.zw);\n}\n\nfn getFilterCoord(aPosition:vec2<f32> ) -> vec2<f32>\n{\n  return ( filterUniforms.uFilterMatrix * vec3( filterTextureCoord(aPosition), 1.0)  ).xy;\n}\n\nfn getSize() -> vec2<f32>\n{\n  return gfu.uGlobalFrame.zw;\n}\n\n@vertex\nfn mainVertex(\n  @location(0) aPosition : vec2<f32>,\n) -> VSOutput {\n  return VSOutput(\n   filterVertexPosition(aPosition),\n   filterTextureCoord(aPosition),\n   getFilterCoord(aPosition)\n  );\n}\n\n@fragment\nfn mainFragment(\n  @location(0) uv: vec2<f32>,\n  @location(1) filterUv: vec2<f32>,\n  @builtin(position) position: vec4<f32>\n) -> @location(0) vec4<f32> {\n\n    var maskClamp = filterUniforms.uMaskClamp;\n    var uAlpha = filterUniforms.uAlpha;\n\n    var clip = step(3.5,\n      step(maskClamp.x, filterUv.x) +\n      step(maskClamp.y, filterUv.y) +\n      step(filterUv.x, maskClamp.z) +\n      step(filterUv.y, maskClamp.w));\n\n    var mask = textureSample(uMaskTexture, uSampler, filterUv);\n    var source = textureSample(uTexture, uSampler, uv);\n\n    var a: f32;\n    if (filterUniforms.uChannel == 1.0) {\n        a = mask.a * uAlpha * clip;\n    } else {\n        var alphaMul = 1.0 - uAlpha * (1.0 - mask.a);\n        a = alphaMul * mask.r * uAlpha * clip;\n    }\n\n    if (filterUniforms.uInverse == 1.0) {\n        a = 1.0 - a;\n    }\n\n    return source * a;\n}\n", Ot = class extends ne {
	constructor(e) {
		let { sprite: t, ...n } = e, r = new i(t.texture), a = new y({
			uFilterMatrix: {
				value: new b(),
				type: "mat3x3<f32>"
			},
			uMaskClamp: {
				value: r.uClampFrame,
				type: "vec4<f32>"
			},
			uAlpha: {
				value: 1,
				type: "f32"
			},
			uInverse: {
				value: +!!e.inverse,
				type: "f32"
			},
			uChannel: {
				value: +(e.channel === "alpha"),
				type: "f32"
			}
		}), o = ee.from({
			vertex: {
				source: Dt,
				entryPoint: "mainVertex"
			},
			fragment: {
				source: Dt,
				entryPoint: "mainFragment"
			}
		}), s = ae.from({
			vertex: Et,
			fragment: Tt,
			name: "mask-filter"
		});
		super({
			...n,
			gpuProgram: o,
			glProgram: s,
			clipToViewport: !1,
			resources: {
				filterUniforms: a,
				uMaskTexture: t.texture.source
			}
		}), this.sprite = t, this._textureMatrix = r;
	}
	setSprite(e) {
		this.sprite = e;
		let t = this._getSafeTexture();
		this._textureMatrix.texture = t, this.resources.uMaskTexture = t.source;
	}
	set inverse(e) {
		this.resources.filterUniforms.uniforms.uInverse = +!!e;
	}
	get inverse() {
		return this.resources.filterUniforms.uniforms.uInverse === 1;
	}
	set channel(e) {
		this.resources.filterUniforms.uniforms.uChannel = +(e === "alpha");
	}
	get channel() {
		return this.resources.filterUniforms.uniforms.uChannel === 1 ? "alpha" : "red";
	}
	apply(e, t, n, r) {
		let i = this._getSafeTexture();
		this._textureMatrix.texture = i, e.calculateSpriteMatrix(this.resources.filterUniforms.uniforms.uFilterMatrix, this.sprite).prepend(this._textureMatrix.mapCoord), this.resources.uMaskTexture = i.source, e.applyFilter(this, t, n, r);
	}
	_getSafeTexture() {
		let e = this.sprite.texture;
		return e.destroyed || !e.source || e.source.destroyed ? (u("[MaskFilter] The mask texture was destroyed while the mask is still in use. Remove the mask before destroying its texture."), f.EMPTY) : e;
	}
	destroy(e = !1) {
		this._textureMatrix.destroy(), super.destroy(e);
	}
};
//#endregion
//#region node_modules/pixi.js/lib/scene/graphics/gpu/colorToUniform.mjs
function kt(e, t, n) {
	let r = (e >> 24 & 255) / 255;
	t[n++] = (e & 255) / 255 * r, t[n++] = (e >> 8 & 255) / 255 * r, t[n++] = (e >> 16 & 255) / 255 * r, t[n++] = r;
}
//#endregion
//#region node_modules/pixi.js/lib/scene/sprite/BatchableSprite.mjs
var At = class {
	constructor() {
		this.batcherName = "default", this.topology = "triangle-list", this.attributeSize = 4, this.indexSize = 6, this.packAsQuad = !0, this.roundPixels = 0, this._attributeStart = 0, this._batcher = null, this._batch = null;
	}
	get blendMode() {
		return this.renderable.groupBlendMode;
	}
	get color() {
		return this.renderable.groupColorAlpha;
	}
	reset() {
		this.renderable = null, this.texture = null, this._batcher = null, this._batch = null, this.bounds = null;
	}
	destroy() {
		this.reset();
	}
}, B = class e {
	constructor(e, t) {
		this.state = ce.for2d(), this._batchersByInstructionSet = /* @__PURE__ */ Object.create(null), this._activeBatches = /* @__PURE__ */ Object.create(null), this.renderer = e, this._adaptor = t, this._adaptor.init?.(this);
	}
	static getBatcher(e, t) {
		return new this._availableBatchers[e]({ maxTextures: t });
	}
	buildStart(e) {
		let t = this._batchersByInstructionSet[e.uid];
		t || (t = this._batchersByInstructionSet[e.uid] = /* @__PURE__ */ Object.create(null), t.default || (t.default = new z({ maxTextures: this.renderer.limits.maxBatchableTextures }))), this._activeBatches = t, this._activeBatch = this._activeBatches.default;
		for (let e in this._activeBatches) this._activeBatches[e].begin();
	}
	addToBatch(t, n) {
		if (this._activeBatch.name !== t.batcherName) {
			this._activeBatch.break(n);
			let r = this._activeBatches[t.batcherName];
			r || (r = this._activeBatches[t.batcherName] = e.getBatcher(t.batcherName, this.renderer.limits.maxBatchableTextures), r.begin()), this._activeBatch = r;
		}
		this._activeBatch.add(t);
	}
	break(e) {
		this._activeBatch.break(e);
	}
	buildEnd(e) {
		this._activeBatch.break(e);
		let t = this._activeBatches;
		for (let e in t) {
			let n = t[e], r = n.geometry;
			r.indexBuffer.setDataWithSize(n.indexBuffer, n.indexSize, !0), r.buffers[0].setDataWithSize(n.attributeBuffer.float32View, n.attributeSize, !1);
		}
	}
	upload(e) {
		let t = this._batchersByInstructionSet[e.uid];
		for (let e in t) {
			let n = t[e], r = n.geometry;
			n.dirty && (n.dirty = !1, r.buffers[0].update(n.attributeSize * 4));
		}
	}
	execute(e) {
		if (e.action === "startBatch") {
			let t = e.batcher, n = t.geometry, r = t.shader;
			this._adaptor.start(this, n, r);
		}
		this._adaptor.execute(this, e);
	}
	destroy() {
		this.state = null, this.renderer = null, this._adaptor = null;
		for (let e in this._activeBatches) this._activeBatches[e].destroy();
		this._activeBatches = null;
	}
};
B.extension = {
	type: [
		x.WebGLPipes,
		x.WebGPUPipes,
		x.CanvasPipes
	],
	name: "batch"
}, B._availableBatchers = /* @__PURE__ */ Object.create(null);
var V = B;
_.handleByMap(x.Batcher, V._availableBatchers), _.add(z);
//#endregion
//#region node_modules/pixi.js/lib/rendering/mask/alpha/AlphaMaskPipe.mjs
var jt = new e(), Mt = class extends c {
	constructor() {
		super(), this._placeholderSprite = new me(f.EMPTY), this.filters = [new Ot({
			sprite: this._placeholderSprite,
			inverse: !1,
			resolution: "inherit",
			antialias: "inherit"
		})];
	}
	get sprite() {
		return this.filters[0].sprite;
	}
	set sprite(e) {
		this.filters[0].setSprite(e);
	}
	get inverse() {
		return this.filters[0].inverse;
	}
	set inverse(e) {
		this.filters[0].inverse = e;
	}
	get channel() {
		return this.filters[0].channel;
	}
	set channel(e) {
		this.filters[0].channel = e;
	}
	reset() {
		this._placeholderSprite.texture = f.EMPTY, this.sprite = this._placeholderSprite;
	}
}, H = class {
	constructor(e) {
		this._activeMaskStage = [], this._usedEffects = [], this._renderer = e, e.runners.postrender.add(this);
	}
	push(e, t, n) {
		let r = this._renderer;
		if (r.renderPipes.batch.break(n), n.add({
			renderPipeId: "alphaMask",
			action: "pushMaskBegin",
			mask: e,
			inverse: t._maskOptions.inverse,
			canBundle: !1,
			maskedContainer: t
		}), e.inverse = t._maskOptions.inverse, e.channel = t._maskOptions.channel ?? "red", e.renderMaskToTexture) {
			let t = e.mask;
			t.includeInBuild = !0, t.collectRenderables(n, r, null), t.includeInBuild = !1;
		}
		r.renderPipes.batch.break(n), n.add({
			renderPipeId: "alphaMask",
			action: "pushMaskEnd",
			mask: e,
			maskedContainer: t,
			inverse: t._maskOptions.inverse,
			canBundle: !1
		});
	}
	pop(e, t, n) {
		this._renderer.renderPipes.batch.break(n), n.add({
			renderPipeId: "alphaMask",
			action: "popMaskEnd",
			mask: e,
			inverse: t._maskOptions.inverse,
			canBundle: !1
		});
	}
	execute(e) {
		let t = this._renderer, n = e.mask.renderMaskToTexture;
		if (e.action === "pushMaskBegin") {
			let r = a.get(Mt);
			if (r.inverse = e.inverse, r.channel = e.mask.channel, n) {
				e.mask.mask.measurable = !0;
				let n = re(e.mask.mask, !0, jt);
				e.mask.mask.measurable = !1, n.ceil();
				let i = t.renderTarget.renderTarget.colorTexture.source, a = d.getOptimalTexture(n.width, n.height, i._resolution, i.antialias);
				t.renderTarget.push({
					target: a,
					clear: !0
				}), t.globalUniforms.push({
					offset: n,
					worldColor: 4294967295
				});
				let o = r.sprite;
				o.texture = a, o.worldTransform.tx = n.minX, o.worldTransform.ty = n.minY, this._activeMaskStage.push({
					filterEffect: r,
					maskedContainer: e.maskedContainer,
					filterTexture: a
				});
			} else r.sprite = e.mask.mask, this._activeMaskStage.push({
				filterEffect: r,
				maskedContainer: e.maskedContainer
			});
		} else if (e.action === "pushMaskEnd") {
			let e = this._activeMaskStage[this._activeMaskStage.length - 1];
			n && (t.type === S.WEBGL && t.renderTarget.finishRenderPass(), t.renderTarget.pop(), t.globalUniforms.pop()), t.filter.push({
				renderPipeId: "filter",
				action: "pushFilter",
				container: e.maskedContainer,
				filterEffect: e.filterEffect,
				canBundle: !1
			});
		} else if (e.action === "popMaskEnd") {
			t.filter.pop();
			let e = this._activeMaskStage.pop();
			n && d.returnTexture(e.filterTexture), this._usedEffects.push(e.filterEffect);
		}
	}
	postrender() {
		let e = this._usedEffects;
		for (let t = 0; t < e.length; t++) a.return(e[t]);
		e.length = 0;
	}
	destroy() {
		this.postrender(), this._renderer.runners.postrender.remove(this), this._renderer = null, this._activeMaskStage = null, this._usedEffects = null;
	}
};
H.extension = {
	type: [
		x.WebGLPipes,
		x.WebGPUPipes,
		x.CanvasPipes
	],
	name: "alphaMask"
};
//#endregion
//#region node_modules/pixi.js/lib/rendering/mask/color/ColorMaskPipe.mjs
var Nt = class {
	constructor(e) {
		this._colorStack = [], this._colorStackIndex = 0, this._currentColor = 0, this._renderer = e;
	}
	buildStart() {
		this._colorStack[0] = 15, this._colorStackIndex = 1, this._currentColor = 15;
	}
	push(e, t, n) {
		this._renderer.renderPipes.batch.break(n);
		let r = this._colorStack;
		r[this._colorStackIndex] = r[this._colorStackIndex - 1] & e.mask;
		let i = this._colorStack[this._colorStackIndex];
		i !== this._currentColor && (this._currentColor = i, n.add({
			renderPipeId: "colorMask",
			colorMask: i,
			canBundle: !1
		})), this._colorStackIndex++;
	}
	pop(e, t, n) {
		this._renderer.renderPipes.batch.break(n);
		let r = this._colorStack;
		this._colorStackIndex--;
		let i = r[this._colorStackIndex - 1];
		i !== this._currentColor && (this._currentColor = i, n.add({
			renderPipeId: "colorMask",
			colorMask: i,
			canBundle: !1
		}));
	}
	execute(e) {
		this._renderer.colorMask.setMask(e.colorMask);
	}
	destroy() {
		this._renderer = null, this._colorStack = null;
	}
};
Nt.extension = {
	type: [x.WebGLPipes, x.WebGPUPipes],
	name: "colorMask"
};
//#endregion
//#region node_modules/pixi.js/lib/rendering/mask/stencil/StencilMaskPipe.mjs
var Pt = class {
	constructor(e) {
		this._maskStackHash = {}, this._maskHash = /* @__PURE__ */ new WeakMap(), this._renderer = e;
	}
	push(e, t, n) {
		var r;
		let i = e, a = this._renderer;
		a.renderPipes.batch.break(n), a.renderPipes.blendMode.setBlendMode(i.mask, "none", n), n.add({
			renderPipeId: "stencilMask",
			action: "pushMaskBegin",
			mask: e,
			inverse: t._maskOptions.inverse,
			canBundle: !1
		});
		let o = i.mask;
		o.includeInBuild = !0, this._maskHash.has(i) || this._maskHash.set(i, {
			instructionsStart: 0,
			instructionsLength: 0
		});
		let s = this._maskHash.get(i);
		s.instructionsStart = n.instructionSize, o.collectRenderables(n, a, null), o.includeInBuild = !1, a.renderPipes.batch.break(n), n.add({
			renderPipeId: "stencilMask",
			action: "pushMaskEnd",
			mask: e,
			inverse: t._maskOptions.inverse,
			canBundle: !1
		}), s.instructionsLength = n.instructionSize - s.instructionsStart - 1;
		let c = a.renderTarget.renderTarget.uid;
		(r = this._maskStackHash)[c] ?? (r[c] = 0);
	}
	pop(e, t, n) {
		let r = e, i = this._renderer;
		i.renderPipes.batch.break(n), i.renderPipes.blendMode.setBlendMode(r.mask, "none", n), n.add({
			renderPipeId: "stencilMask",
			action: "popMaskBegin",
			inverse: t._maskOptions.inverse,
			canBundle: !1
		});
		let a = this._maskHash.get(e);
		for (let e = 0; e < a.instructionsLength; e++) n.instructions[n.instructionSize++] = n.instructions[a.instructionsStart++];
		n.add({
			renderPipeId: "stencilMask",
			action: "popMaskEnd",
			canBundle: !1
		});
	}
	execute(e) {
		var t;
		let n = this._renderer, r = n, i = n.renderTarget.renderTarget.uid, a = (t = this._maskStackHash)[i] ?? (t[i] = 0);
		e.action === "pushMaskBegin" ? (r.renderTarget.ensureDepthStencil(), r.stencil.setStencilMode(j.RENDERING_MASK_ADD, a), a++, r.colorMask.setMask(0)) : e.action === "pushMaskEnd" ? (e.inverse ? r.stencil.setStencilMode(j.INVERSE_MASK_ACTIVE, a) : r.stencil.setStencilMode(j.MASK_ACTIVE, a), r.colorMask.setMask(15)) : e.action === "popMaskBegin" ? (r.colorMask.setMask(0), a === 0 ? (r.renderTarget.clear(null, O.STENCIL), r.stencil.setStencilMode(j.DISABLED, a)) : r.stencil.setStencilMode(j.RENDERING_MASK_REMOVE, a), a--) : e.action === "popMaskEnd" && (e.inverse ? r.stencil.setStencilMode(j.INVERSE_MASK_ACTIVE, a) : r.stencil.setStencilMode(j.MASK_ACTIVE, a), r.colorMask.setMask(15)), this._maskStackHash[i] = a;
	}
	destroy() {
		this._renderer = null, this._maskStackHash = null, this._maskHash = null;
	}
};
Pt.extension = {
	type: [x.WebGLPipes, x.WebGPUPipes],
	name: "stencilMask"
};
//#endregion
//#region node_modules/pixi.js/lib/scene/container/CustomRenderPipe.mjs
var U = class {
	constructor(e) {
		this._renderer = e;
	}
	updateRenderable() {}
	destroyRenderable() {}
	validateRenderable() {
		return !1;
	}
	addRenderable(e, t) {
		this._renderer.renderPipes.batch.break(t), t.add(e);
	}
	execute(e) {
		e.isRenderable && e.render(this._renderer);
	}
	destroy() {
		this._renderer = null;
	}
};
U.extension = {
	type: [
		x.WebGLPipes,
		x.WebGPUPipes,
		x.CanvasPipes
	],
	name: "customRender"
};
//#endregion
//#region node_modules/pixi.js/lib/scene/container/utils/executeInstructions.mjs
function W(e, t) {
	let n = e.instructionSet, r = n.instructions;
	for (let e = 0; e < n.instructionSize; e++) {
		let n = r[e];
		t[n.renderPipeId].execute(n);
	}
}
//#endregion
//#region node_modules/pixi.js/lib/scene/container/RenderGroupPipe.mjs
var G = class {
	constructor(e) {
		this._renderer = e;
	}
	addRenderGroup(e, t) {
		e.isCachedAsTexture ? this._addRenderableCacheAsTexture(e, t) : this._addRenderableDirect(e, t);
	}
	execute(e) {
		e.isRenderable && (e.isCachedAsTexture ? this._executeCacheAsTexture(e) : this._executeDirect(e));
	}
	destroy() {
		this._renderer = null;
	}
	_addRenderableDirect(e, t) {
		this._renderer.renderPipes.batch.break(t), e._batchableRenderGroup &&= (a.return(e._batchableRenderGroup), null), t.add(e);
	}
	_addRenderableCacheAsTexture(e, t) {
		let n = e._batchableRenderGroup ??= a.get(At);
		n.renderable = e.root, n.transform = e.root.relativeGroupTransform, n.texture = e.texture, n.bounds = e._textureBounds, t.add(e), this._renderer.renderPipes.blendMode.pushBlendMode(e, e.root.groupBlendMode, t), this._renderer.renderPipes.batch.addToBatch(n, t), this._renderer.renderPipes.blendMode.popBlendMode(t);
	}
	_executeCacheAsTexture(e) {
		if (e.textureNeedsUpdate) {
			e.textureNeedsUpdate = !1;
			let t = new b().translate(-e._textureBounds.x, -e._textureBounds.y);
			this._renderer.renderTarget.push({
				target: e.texture,
				clear: !0,
				frame: e.texture.frame
			}), this._renderer.globalUniforms.push({
				worldTransformMatrix: t,
				worldColor: 4294967295,
				offset: {
					x: 0,
					y: 0
				}
			}), W(e, this._renderer.renderPipes), this._renderer.renderTarget.finishRenderPass(), this._renderer.renderTarget.pop(), this._renderer.globalUniforms.pop();
		}
		e._batchableRenderGroup._batcher.updateElement(e._batchableRenderGroup), e._batchableRenderGroup._batcher.geometry.buffers[0].update();
	}
	_executeDirect(e) {
		this._renderer.globalUniforms.push({
			worldTransformMatrix: e.inverseParentTextureTransform,
			worldColor: e.worldColorAlpha
		}), W(e, this._renderer.renderPipes), this._renderer.globalUniforms.pop();
	}
};
G.extension = {
	type: [
		x.WebGLPipes,
		x.WebGPUPipes,
		x.CanvasPipes
	],
	name: "renderGroup"
};
//#endregion
//#region node_modules/pixi.js/lib/scene/sprite/SpritePipe.mjs
var K = class {
	constructor(e) {
		this._renderer = e;
	}
	addRenderable(e, t) {
		let n = this._getGpuSprite(e);
		e.didViewUpdate && this._updateBatchableSprite(e, n), this._renderer.renderPipes.batch.addToBatch(n, t);
	}
	updateRenderable(e) {
		let t = this._getGpuSprite(e);
		e.didViewUpdate && this._updateBatchableSprite(e, t), t._batcher.updateElement(t);
	}
	validateRenderable(e) {
		let t = this._getGpuSprite(e);
		return !t._batcher.checkAndUpdateTexture(t, e._texture);
	}
	_updateBatchableSprite(e, t) {
		t.bounds = e.visualBounds, t.texture = e._texture;
	}
	_getGpuSprite(e) {
		return e._gpuData[this._renderer.uid] || this._initGPUSprite(e);
	}
	_initGPUSprite(e) {
		let t = new At();
		return t.renderable = e, t.transform = e.groupTransform, t.texture = e._texture, t.bounds = e.visualBounds, t.roundPixels = this._renderer._roundPixels | e._roundPixels, e._gpuData[this._renderer.uid] = t, t;
	}
	destroy() {
		this._renderer = null;
	}
};
K.extension = {
	type: [
		x.WebGLPipes,
		x.WebGPUPipes,
		x.CanvasPipes
	],
	name: "sprite"
};
//#endregion
//#region node_modules/pixi.js/lib/rendering/renderers/shared/blendModes/BlendModePipe.mjs
var q = {};
_.handle(x.BlendMode, (e) => {
	if (!e.name) throw Error("BlendMode extension must have a name property");
	q[e.name] = e.ref;
}, (e) => {
	delete q[e.name];
});
var J = class {
	constructor(e) {
		this._blendModeStack = [], this._isAdvanced = !1, this._filterHash = /* @__PURE__ */ Object.create(null), this._renderer = e, this._renderer.runners.prerender.add(this);
	}
	prerender() {
		this._activeBlendMode = "normal", this._isAdvanced = !1;
	}
	pushBlendMode(e, t, n) {
		this._blendModeStack.push(t), this.setBlendMode(e, t, n);
	}
	popBlendMode(e) {
		this._blendModeStack.pop();
		let t = this._blendModeStack[this._activeBlendMode.length - 1] ?? "normal";
		this.setBlendMode(null, t, e);
	}
	setBlendMode(e, t, n) {
		let r = e instanceof pe;
		if (this._activeBlendMode === t) {
			this._isAdvanced && e && !r && this._renderableList?.push(e);
			return;
		}
		this._isAdvanced && this._endAdvancedBlendMode(n), this._activeBlendMode = t, e && (this._isAdvanced = !!q[t], this._isAdvanced && this._beginAdvancedBlendMode(e, n));
	}
	_beginAdvancedBlendMode(e, t) {
		this._renderer.renderPipes.batch.break(t);
		let n = this._activeBlendMode;
		if (!q[n]) {
			u(`Unable to assign BlendMode: '${n}'. You may want to include: import 'pixi.js/advanced-blend-modes'`);
			return;
		}
		let r = this._ensureFilterEffect(n), i = e instanceof pe, a = {
			renderPipeId: "filter",
			action: "pushFilter",
			filterEffect: r,
			renderables: i ? null : [e],
			container: i ? e.root : null,
			canBundle: !1
		};
		this._renderableList = a.renderables, t.add(a);
	}
	_ensureFilterEffect(e) {
		let t = this._filterHash[e];
		return t || (t = this._filterHash[e] = new c(), t.filters = [new q[e]()]), t;
	}
	_endAdvancedBlendMode(e) {
		this._isAdvanced = !1, this._renderableList = null, this._renderer.renderPipes.batch.break(e), e.add({
			renderPipeId: "filter",
			action: "popFilter",
			canBundle: !1
		});
	}
	buildStart() {
		this._isAdvanced = !1;
	}
	buildEnd(e) {
		this._isAdvanced && this._endAdvancedBlendMode(e);
	}
	destroy() {
		this._renderer = null, this._renderableList = null;
		for (let e in this._filterHash) this._filterHash[e].destroy();
		this._filterHash = null;
	}
};
J.extension = {
	type: [
		x.WebGLPipes,
		x.WebGPUPipes,
		x.CanvasPipes
	],
	name: "blendMode"
};
//#endregion
//#region node_modules/pixi.js/lib/scene/container/utils/clearList.mjs
function Y(e, t) {
	t ||= 0;
	for (let n = t; n < e.length && e[n]; n++) e[n] = null;
}
//#endregion
//#region node_modules/pixi.js/lib/scene/container/utils/updateRenderGroupTransforms.mjs
var Ft = new t(), It = 7;
function Lt(e, t = !1) {
	Rt(e);
	let n = e.childrenToUpdate, r = e.updateTick++;
	for (let t in n) {
		let i = Number(t), a = n[t], o = a.list, s = a.index;
		for (let t = 0; t < s; t++) {
			let n = o[t];
			n.parentRenderGroup === e && n.relativeRenderGroupDepth === i && zt(n, r, 0);
		}
		Y(o, s), a.index = 0;
	}
	if (t) for (let n = 0; n < e.renderGroupChildren.length; n++) Lt(e.renderGroupChildren[n], t);
}
function Rt(e) {
	let t = e.root, n;
	if (e.renderGroupParent) {
		let r = e.renderGroupParent;
		e.worldTransform.appendFrom(t.relativeGroupTransform, r.worldTransform), e.worldColor = ie(t.groupColor, r.worldColor), n = t.groupAlpha * r.worldAlpha;
	} else e.worldTransform.copyFrom(t.localTransform), e.worldColor = t.localColor, n = t.localAlpha;
	n = n < 0 ? 0 : n > 1 ? 1 : n, e.worldAlpha = n, e.worldColorAlpha = e.worldColor + ((n * 255 | 0) << 24);
}
function zt(e, t, n) {
	if (t === e.updateTick) return;
	e.updateTick = t, e.didChange = !1;
	let r = e.localTransform;
	e.updateLocalTransform();
	let i = e.parent;
	if (i && !i.renderGroup ? (n |= e._updateFlags, e.relativeGroupTransform.appendFrom(r, i.relativeGroupTransform), n & It && Bt(e, i, n)) : (n = e._updateFlags, e.relativeGroupTransform.copyFrom(r), n & It && Bt(e, Ft, n)), !e.renderGroup) {
		let r = e.children, i = r.length;
		for (let e = 0; e < i; e++) zt(r[e], t, n);
		let a = e.parentRenderGroup, o = e;
		o.renderPipeId && !a.structureDidChange && a.updateRenderable(o);
	}
}
function Bt(e, t, n) {
	if (n & 1) {
		e.groupColor = ie(e.localColor, t.groupColor);
		let n = e.localAlpha * t.groupAlpha;
		n = n < 0 ? 0 : n > 1 ? 1 : n, e.groupAlpha = n, e.groupColorAlpha = e.groupColor + ((n * 255 | 0) << 24);
	}
	n & 2 && (e.groupBlendMode = e.localBlendMode === "inherit" ? t.groupBlendMode : e.localBlendMode), n & 4 && (e.globalDisplayStatus = e.localDisplayStatus & t.globalDisplayStatus), e._updateFlags = 0;
}
//#endregion
//#region node_modules/pixi.js/lib/scene/container/utils/validateRenderables.mjs
function Vt(e, t) {
	let { list: n } = e.childrenRenderablesToUpdate, r = !1;
	for (let i = 0; i < e.childrenRenderablesToUpdate.index; i++) {
		let e = n[i];
		if (r = t[e.renderPipeId].validateRenderable(e), r) break;
	}
	return e.structureDidChange = r, r;
}
//#endregion
//#region node_modules/pixi.js/lib/scene/container/RenderGroupSystem.mjs
var Ht = new b(), Ut = class {
	constructor(e) {
		this._renderer = e;
	}
	render({ container: e, transform: t }) {
		let n = e.parent, r = e.renderGroup.renderGroupParent;
		e.parent = null, e.renderGroup.renderGroupParent = null;
		let i = this._renderer, a = Ht;
		t && (a.copyFrom(e.renderGroup.localTransform), e.renderGroup.localTransform.copyFrom(t));
		let o = i.renderPipes;
		this._updateCachedRenderGroups(e.renderGroup, null), this._updateRenderGroups(e.renderGroup), i.globalUniforms.start({
			worldTransformMatrix: t ? e.renderGroup.localTransform : e.renderGroup.worldTransform,
			worldColor: e.renderGroup.worldColorAlpha
		}), W(e.renderGroup, o), o.uniformBatch && o.uniformBatch.renderEnd(), t && e.renderGroup.localTransform.copyFrom(a), e.parent = n, e.renderGroup.renderGroupParent = r;
	}
	destroy() {
		this._renderer = null;
	}
	_updateCachedRenderGroups(t, n) {
		if (t._parentCacheAsTextureRenderGroup = n, t.isCachedAsTexture) {
			if (!t.textureNeedsUpdate) return;
			n = t;
		}
		for (let e = t.renderGroupChildren.length - 1; e >= 0; e--) this._updateCachedRenderGroups(t.renderGroupChildren[e], n);
		if (t.invalidateMatrices(), t.isCachedAsTexture) {
			if (t.textureNeedsUpdate) {
				let n = t.root.getLocalBounds(), i = this._renderer, a = t.textureOptions.resolution || i.view.resolution, o = t.textureOptions.antialias ?? i.view.antialias, s = t.textureOptions.scaleMode ?? "linear", c = t.texture;
				n.ceil(), t.texture && d.returnTexture(t.texture, !0);
				let l = d.getOptimalTexture(n.width, n.height, a, o);
				l._source.style = new r({ scaleMode: s }), t.texture = l, t._textureBounds ||= new e(), t._textureBounds.copyFrom(n), c !== t.texture && t.renderGroupParent && (t.renderGroupParent.structureDidChange = !0);
			}
		} else t.texture &&= (d.returnTexture(t.texture, !0), null);
	}
	_updateRenderGroups(e) {
		let t = this._renderer, n = t.renderPipes;
		if (e.runOnRender(t), e.instructionSet.renderPipes = n, e.structureDidChange ? Y(e.childrenRenderablesToUpdate.list, 0) : Vt(e, n), Lt(e), e.structureDidChange ? (e.structureDidChange = !1, this._buildInstructions(e, t)) : this._updateRenderables(e), e.childrenRenderablesToUpdate.index = 0, t.renderPipes.batch.upload(e.instructionSet), !(e.isCachedAsTexture && !e.textureNeedsUpdate)) for (let t = 0; t < e.renderGroupChildren.length; t++) this._updateRenderGroups(e.renderGroupChildren[t]);
	}
	_updateRenderables(e) {
		let { list: t, index: n } = e.childrenRenderablesToUpdate;
		for (let r = 0; r < n; r++) {
			let n = t[r];
			n.didViewUpdate && e.updateRenderable(n);
		}
		Y(t, n);
	}
	_buildInstructions(e, t) {
		let n = e.root, r = e.instructionSet;
		r.reset();
		let i = t.renderPipes ? t : t.batch.renderer, a = i.renderPipes;
		a.batch.buildStart(r), a.blendMode.buildStart(), a.colorMask.buildStart(), n.sortableChildren && n.sortChildren(), n.collectRenderablesWithEffects(r, i, null), a.batch.buildEnd(r), a.blendMode.buildEnd(r);
	}
};
Ut.extension = {
	type: [
		x.WebGLSystem,
		x.WebGPUSystem,
		x.CanvasSystem
	],
	name: "renderGroup"
};
//#endregion
//#region node_modules/pixi.js/lib/rendering/renderers/shared/background/BackgroundSystem.mjs
var X = class e {
	constructor() {
		this.clearBeforeRender = !0, this._backgroundColor = new T(0), this.color = this._backgroundColor, this.alpha = 1;
	}
	init(t) {
		t = {
			...e.defaultOptions,
			...t
		}, this.clearBeforeRender = t.clearBeforeRender, this.color = t.background || t.backgroundColor || this._backgroundColor, this.alpha = t.backgroundAlpha, this._backgroundColor.setAlpha(t.backgroundAlpha);
	}
	get color() {
		return this._backgroundColor;
	}
	set color(e) {
		T.shared.setValue(e).alpha < 1 && this._backgroundColor.alpha === 1 && u("Cannot set a transparent background on an opaque canvas. To enable transparency, set backgroundAlpha < 1 when initializing your Application."), this._backgroundColor.setValue(e);
	}
	get alpha() {
		return this._backgroundColor.alpha;
	}
	set alpha(e) {
		this._backgroundColor.setAlpha(e);
	}
	get colorRgba() {
		return this._backgroundColor.toArray();
	}
	destroy() {}
};
X.extension = {
	type: [
		x.WebGLSystem,
		x.WebGPUSystem,
		x.CanvasSystem
	],
	name: "background",
	priority: 0
}, X.defaultOptions = {
	backgroundAlpha: 1,
	backgroundColor: 0,
	clearBeforeRender: !0
};
var Wt = X, Z = {
	png: "image/png",
	jpg: "image/jpeg",
	webp: "image/webp"
}, Gt = class e {
	constructor(e) {
		this._renderer = e;
	}
	_normalizeOptions(e, n = {}) {
		return e instanceof t || e instanceof f ? {
			target: e,
			...n
		} : {
			...n,
			...e
		};
	}
	async image(e) {
		let t = v.get().createImage();
		return t.src = await this.base64(e), t;
	}
	async base64(t) {
		t = this._normalizeOptions(t, e.defaultImageOptions);
		let { format: n, quality: r } = t, i = this.canvas(t);
		if (i.toBlob !== void 0) return new Promise((e, t) => {
			i.toBlob((n) => {
				if (!n) {
					t(/* @__PURE__ */ Error("ICanvas.toBlob failed!"));
					return;
				}
				let r = new FileReader();
				r.onload = () => e(r.result), r.onerror = t, r.readAsDataURL(n);
			}, Z[n], r);
		});
		if (i.toDataURL !== void 0) return i.toDataURL(Z[n], r);
		if (i.convertToBlob !== void 0) {
			let e = await i.convertToBlob({
				type: Z[n],
				quality: r
			});
			return new Promise((t, n) => {
				let r = new FileReader();
				r.onload = () => t(r.result), r.onerror = n, r.readAsDataURL(e);
			});
		}
		throw Error("Extract.base64() requires ICanvas.toDataURL, ICanvas.toBlob, or ICanvas.convertToBlob to be implemented");
	}
	canvas(e) {
		e = this._normalizeOptions(e);
		let t = e.target, n = this._renderer;
		if (t instanceof f) return n.texture.generateCanvas(t);
		let r = n.textureGenerator.generateTexture(e), i = n.texture.generateCanvas(r);
		return r.destroy(!0), i;
	}
	pixels(e) {
		e = this._normalizeOptions(e);
		let n = e.target, r = this._renderer, i = n instanceof f ? n : r.textureGenerator.generateTexture(e), a = r.texture.getPixels(i);
		return n instanceof t && i.destroy(!0), a;
	}
	texture(e) {
		return e = this._normalizeOptions(e), e.target instanceof f ? e.target : this._renderer.textureGenerator.generateTexture(e);
	}
	download(e) {
		e = this._normalizeOptions(e);
		let t = this.canvas(e), n = document.createElement("a");
		n.download = e.filename ?? "image.png", n.href = t.toDataURL("image/png"), document.body.appendChild(n), n.click(), document.body.removeChild(n);
	}
	log(e) {
		let t = e.width ?? 200;
		e = this._normalizeOptions(e);
		let n = this.canvas(e), r = n.toDataURL();
		console.log(`[Pixi Texture] ${n.width}px ${n.height}px`);
		let i = [
			"font-size: 1px;",
			`padding: ${t}px 300px;`,
			`background: url(${r}) no-repeat;`,
			"background-size: contain;"
		].join(" ");
		console.log("%c ", i);
	}
	destroy() {
		this._renderer = null;
	}
};
Gt.extension = {
	type: [
		x.WebGLSystem,
		x.WebGPUSystem,
		x.CanvasSystem
	],
	name: "extract"
}, Gt.defaultImageOptions = {
	format: "png",
	quality: 1
};
var Kt = Gt, qt = class e extends f {
	static create(t) {
		let { dynamic: n, textureOptions: r, ...i } = t;
		return new e({
			...r,
			source: new p(i),
			dynamic: n ?? !1
		});
	}
	resize(e, t, n) {
		return this.source.resize(e, t, n), this;
	}
}, Jt = new l(), Yt = new e(), Xt = [
	0,
	0,
	0,
	0
], Zt = class {
	constructor(e) {
		this._renderer = e;
	}
	generateTexture(e) {
		e instanceof t && (e = {
			target: e,
			frame: void 0,
			textureSourceOptions: {},
			resolution: void 0
		});
		let r = e.resolution || this._renderer.resolution, i = e.antialias || this._renderer.view.antialias, a = e.target, o = e.clearColor;
		o = o ? Array.isArray(o) && o.length === 4 ? o : T.shared.setValue(o).toArray() : Xt;
		let s = e.frame?.copyTo(Jt) || n(a, Yt).rectangle, c = e.defaultAnchor && { defaultAnchor: e.defaultAnchor };
		s.width = Math.max(s.width, 1 / r) | 0, s.height = Math.max(s.height, 1 / r) | 0;
		let l = qt.create({
			...e.textureSourceOptions,
			width: s.width,
			height: s.height,
			resolution: r,
			antialias: i,
			textureOptions: c
		}), u = b.shared.translate(-s.x, -s.y);
		return this._renderer.render({
			container: a,
			transform: u,
			target: l,
			clearColor: o
		}), l.source.updateMipmaps(), l;
	}
	destroy() {
		this._renderer = null;
	}
};
Zt.extension = {
	type: [
		x.WebGLSystem,
		x.WebGPUSystem,
		x.CanvasSystem
	],
	name: "textureGenerator"
};
//#endregion
//#region node_modules/pixi.js/lib/utils/data/clean.mjs
function Qt(e) {
	let t = !1;
	for (let n in e) if (e[n] == null) {
		t = !0;
		break;
	}
	if (!t) return e;
	let n = /* @__PURE__ */ Object.create(null);
	for (let t in e) {
		let r = e[t];
		r && (n[t] = r);
	}
	return n;
}
function $t(e) {
	let t = 0;
	for (let n = 0; n < e.length; n++) e[n] == null ? t++ : e[n - t] = e[n];
	return e.length -= t, e;
}
//#endregion
//#region node_modules/pixi.js/lib/rendering/renderers/shared/GCSystem.mjs
var en = class e {
	constructor(e) {
		this._managedResources = [], this._managedResourceHashes = [], this._managedCollections = [], this._ready = !1, this._renderer = e;
	}
	init(t) {
		t = {
			...e.defaultOptions,
			...t
		}, this.maxUnusedTime = t.gcMaxUnusedTime, this._frequency = t.gcFrequency, this.enabled = t.gcActive, this.now = performance.now();
	}
	get enabled() {
		return !!this._handler;
	}
	set enabled(e) {
		this.enabled !== e && (e ? (this._handler = this._renderer.scheduler.repeat(() => {
			this._ready = !0;
		}, this._frequency, !1), this._collectionsHandler = this._renderer.scheduler.repeat(() => {
			for (let e of this._managedCollections) {
				let { context: t, collection: n, type: r } = e;
				t[n] = r === "hash" ? Qt(t[n]) : $t(t[n]);
			}
		}, this._frequency)) : (this._renderer.scheduler.cancel(this._handler), this._renderer.scheduler.cancel(this._collectionsHandler), this._handler = 0, this._collectionsHandler = 0));
	}
	prerender({ container: e }) {
		this.now = performance.now(), e.renderGroup.gcTick = this._renderer.tick++, this._updateInstructionGCTick(e.renderGroup, e.renderGroup.gcTick);
	}
	postrender() {
		!this._ready || !this.enabled || (this.run(), this._ready = !1);
	}
	_updateInstructionGCTick(e, t) {
		e.instructionSet.gcTick = t, e.gcTick = t;
		for (let n of e.renderGroupChildren) this._updateInstructionGCTick(n, t);
	}
	addCollection(e, t, n) {
		this._managedCollections.push({
			context: e,
			collection: t,
			type: n
		});
	}
	addResource(e, t) {
		if (e._gcLastUsed !== -1) {
			e._gcLastUsed = this.now, e._onTouch?.(this.now);
			return;
		}
		e._gcData = {
			index: this._managedResources.length,
			type: t
		}, e._gcLastUsed = this.now, e._onTouch?.(this.now), e.once("unload", this.removeResource, this), this._managedResources.push(e);
	}
	removeResource(e) {
		let t = e._gcData;
		if (!t) return;
		let n = t.index, r = this._managedResources.length - 1;
		if (n !== r) {
			let e = this._managedResources[r];
			this._managedResources[n] = e, e._gcData.index = n;
		}
		this._managedResources.length--, e._gcData = null, e._gcLastUsed = -1;
	}
	addResourceHash(e, t, n, r = 0) {
		this._managedResourceHashes.push({
			context: e,
			hash: t,
			type: n,
			priority: r
		}), this._managedResourceHashes.sort((e, t) => e.priority - t.priority);
	}
	run() {
		let e = performance.now(), t = this._managedResourceHashes;
		for (let n of t) this.runOnHash(n, e);
		let n = 0;
		for (let t = 0; t < this._managedResources.length; t++) {
			let r = this._managedResources[t];
			n = this.runOnResource(r, e, n);
		}
		this._managedResources.length = n;
	}
	updateRenderableGCTick(e, t) {
		let n = e.renderGroup ?? e.parentRenderGroup, r = n?.instructionSet?.gcTick ?? -1;
		(n?.gcTick ?? 0) === r && (e._gcLastUsed = t, e._onTouch?.(t));
	}
	runOnResource(e, t, n) {
		let r = e._gcData;
		return r.type === "renderable" && this.updateRenderableGCTick(e, t), t - e._gcLastUsed < this.maxUnusedTime || !e.autoGarbageCollect ? (this._managedResources[n] = e, r.index = n, n++) : (e.unload(), e._gcData = null, e._gcLastUsed = -1, e.off("unload", this.removeResource, this)), n;
	}
	_createHashClone(e, t) {
		let n = /* @__PURE__ */ Object.create(null);
		for (let r in e) {
			if (r === t) break;
			e[r] !== null && (n[r] = e[r]);
		}
		return n;
	}
	runOnHash(e, t) {
		let { context: n, hash: r, type: i } = e, a = n[r], o = null, s = 0;
		for (let e in a) {
			let n = a[e];
			if (n === null) {
				s++, s === 1e4 && !o && (o = this._createHashClone(a, e));
				continue;
			}
			if (n._gcLastUsed === -1) {
				n._gcLastUsed = t, n._onTouch?.(t), o && (o[e] = n);
				continue;
			}
			if (i === "renderable" && this.updateRenderableGCTick(n, t), !(t - n._gcLastUsed < this.maxUnusedTime) && n.autoGarbageCollect) {
				if (i === "renderable") {
					let e = n, t = e.renderGroup ?? e.parentRenderGroup;
					t && (t.structureDidChange = !0);
				}
				n.unload(), n._gcData = null, n._gcLastUsed = -1, o || (s + 1 === 1e4 ? o = this._createHashClone(a, e) : (a[e] = null, s++));
			} else o && (o[e] = n);
		}
		o && (n[r] = o);
	}
	destroy() {
		this.enabled = !1, this._managedResources.forEach((e) => {
			e.off("unload", this.removeResource, this);
		}), this._managedResources.length = 0, this._managedResourceHashes.length = 0, this._managedCollections.length = 0, this._renderer = null;
	}
};
en.extension = {
	type: [
		x.WebGLSystem,
		x.WebGPUSystem,
		x.CanvasSystem
	],
	name: "gc",
	priority: 0
}, en.defaultOptions = {
	gcActive: !0,
	gcMaxUnusedTime: 6e4,
	gcFrequency: 3e4
};
var tn = en, nn = class {
	constructor(e) {
		this._stackIndex = 0, this._globalUniformDataStack = [], this._uniformsPool = [], this._activeUniforms = [], this._bindGroupPool = [], this._activeBindGroups = [], this._renderer = e;
	}
	reset() {
		this._stackIndex = 0;
		for (let e = 0; e < this._activeUniforms.length; e++) this._uniformsPool.push(this._activeUniforms[e]);
		for (let e = 0; e < this._activeBindGroups.length; e++) this._bindGroupPool.push(this._activeBindGroups[e]);
		this._activeUniforms.length = 0, this._activeBindGroups.length = 0;
	}
	start(e) {
		this.reset(), this.push(e);
	}
	bind({ size: e, projectionMatrix: t, worldTransformMatrix: n, worldColor: r, offset: i }) {
		let a = this._renderer.renderTarget.renderTarget, o = this._stackIndex ? this._globalUniformDataStack[this._stackIndex - 1] : {
			projectionData: a,
			worldTransformMatrix: new b(),
			worldColor: 4294967295,
			offset: new de()
		}, s = {
			projectionMatrix: t || this._renderer.renderTarget.projectionMatrix,
			resolution: e || a.size,
			worldTransformMatrix: n || o.worldTransformMatrix,
			worldColor: r || o.worldColor,
			offset: i || o.offset,
			bindGroup: null
		}, c = this._uniformsPool.pop() || this._createUniforms();
		this._activeUniforms.push(c);
		let l = c.uniforms;
		l.uProjectionMatrix = s.projectionMatrix, l.uResolution = s.resolution, l.uWorldTransformMatrix.copyFrom(s.worldTransformMatrix), l.uWorldTransformMatrix.tx -= s.offset.x, l.uWorldTransformMatrix.ty -= s.offset.y, kt(s.worldColor, l.uWorldColorAlpha, 0), c.update();
		let u;
		this._renderer.renderPipes.uniformBatch ? u = this._renderer.renderPipes.uniformBatch.getUniformBindGroup(c, !1) : (u = this._bindGroupPool.pop() || new fe(), this._activeBindGroups.push(u), u.setResource(c, 0)), s.bindGroup = u, this._currentGlobalUniformData = s;
	}
	push(e) {
		this.bind(e), this._globalUniformDataStack[this._stackIndex++] = this._currentGlobalUniformData;
	}
	pop() {
		this._currentGlobalUniformData = this._globalUniformDataStack[--this._stackIndex - 1], this._renderer.type === S.WEBGL && this._currentGlobalUniformData.bindGroup.resources[0].update();
	}
	get bindGroup() {
		return this._currentGlobalUniformData.bindGroup;
	}
	get globalUniformData() {
		return this._currentGlobalUniformData;
	}
	get uniformGroup() {
		return this._currentGlobalUniformData.bindGroup.resources[0];
	}
	_createUniforms() {
		return new y({
			uProjectionMatrix: {
				value: new b(),
				type: "mat3x3<f32>"
			},
			uWorldTransformMatrix: {
				value: new b(),
				type: "mat3x3<f32>"
			},
			uWorldColorAlpha: {
				value: /* @__PURE__ */ new Float32Array(4),
				type: "vec4<f32>"
			},
			uResolution: {
				value: [0, 0],
				type: "vec2<f32>"
			}
		}, { isStatic: !0 });
	}
	destroy() {
		this._renderer = null, this._globalUniformDataStack.length = 0, this._uniformsPool.length = 0, this._activeUniforms.length = 0, this._bindGroupPool.length = 0, this._activeBindGroups.length = 0, this._currentGlobalUniformData = null;
	}
};
nn.extension = {
	type: [
		x.WebGLSystem,
		x.WebGPUSystem,
		x.CanvasSystem
	],
	name: "globalUniforms"
};
//#endregion
//#region node_modules/pixi.js/lib/rendering/renderers/shared/SchedulerSystem.mjs
var rn = 1, an = class {
	constructor() {
		this._tasks = [], this._offset = 0;
	}
	init() {
		g.system.add(this._update, this);
	}
	repeat(e, t, n = !0) {
		let r = rn++, i = 0;
		return n && (this._offset += 1e3, i = this._offset), this._tasks.push({
			func: e,
			duration: t,
			start: performance.now(),
			offset: i,
			last: performance.now(),
			repeat: !0,
			id: r
		}), r;
	}
	cancel(e) {
		for (let t = 0; t < this._tasks.length; t++) if (this._tasks[t].id === e) {
			this._tasks.splice(t, 1);
			return;
		}
	}
	_update() {
		let e = performance.now();
		for (let t = 0; t < this._tasks.length; t++) {
			let n = this._tasks[t];
			if (e - n.offset - n.last >= n.duration) {
				let t = e - n.start;
				n.func(t), n.last = e;
			}
		}
	}
	destroy() {
		g.system.remove(this._update, this), this._tasks.length = 0;
	}
};
an.extension = {
	type: [
		x.WebGLSystem,
		x.WebGPUSystem,
		x.CanvasSystem
	],
	name: "scheduler",
	priority: 0
};
//#endregion
//#region node_modules/pixi.js/lib/utils/sayHello.mjs
var on = !1;
function sn(e) {
	if (!on) {
		if (v.get().getNavigator().userAgent.toLowerCase().indexOf("chrome") > -1) {
			let t = [
				`%c  %c  %c  %c  %c PixiJS %c v${k} (${e}) http://www.pixijs.com/

`,
				"background: #E72264; padding:5px 0;",
				"background: #6CA2EA; padding:5px 0;",
				"background: #B5D33D; padding:5px 0;",
				"background: #FED23F; padding:5px 0;",
				"color: #FFFFFF; background: #E72264; padding:5px 0;",
				"color: #E72264; background: #FFFFFF; padding:5px 0;"
			];
			globalThis.console.log(...t);
		} else globalThis.console && globalThis.console.log(`PixiJS ${k} - ${e} - http://www.pixijs.com/`);
		on = !0;
	}
}
//#endregion
//#region node_modules/pixi.js/lib/rendering/renderers/shared/startup/HelloSystem.mjs
var cn = class {
	constructor(e) {
		this._renderer = e;
	}
	init(e) {
		if (e.hello) {
			let e = this._renderer.name;
			this._renderer.type === S.WEBGL && (e += ` ${this._renderer.context.webGLVersion}`), sn(e);
		}
	}
};
cn.extension = {
	type: [
		x.WebGLSystem,
		x.WebGPUSystem,
		x.CanvasSystem
	],
	name: "hello",
	priority: -2
}, cn.defaultOptions = { hello: !1 };
//#endregion
//#region node_modules/pixi.js/lib/rendering/renderers/shared/texture/RenderableGCSystem.mjs
var ln = class e {
	constructor(e) {
		this._renderer = e;
	}
	init(t) {
		t = {
			...e.defaultOptions,
			...t
		}, this.maxUnusedTime = t.renderableGCMaxUnusedTime;
	}
	get enabled() {
		return o("8.15.0", "RenderableGCSystem.enabled is deprecated, please use the GCSystem.enabled instead."), this._renderer.gc.enabled;
	}
	set enabled(e) {
		o("8.15.0", "RenderableGCSystem.enabled is deprecated, please use the GCSystem.enabled instead."), this._renderer.gc.enabled = e;
	}
	addManagedHash(e, t) {
		o("8.15.0", "RenderableGCSystem.addManagedHash is deprecated, please use the GCSystem.addCollection instead."), this._renderer.gc.addCollection(e, t, "hash");
	}
	addManagedArray(e, t) {
		o("8.15.0", "RenderableGCSystem.addManagedArray is deprecated, please use the GCSystem.addCollection instead."), this._renderer.gc.addCollection(e, t, "array");
	}
	addRenderable(e) {
		o("8.15.0", "RenderableGCSystem.addRenderable is deprecated, please use the GCSystem instead."), this._renderer.gc.addResource(e, "renderable");
	}
	run() {
		o("8.15.0", "RenderableGCSystem.run is deprecated, please use the GCSystem instead."), this._renderer.gc.run();
	}
	destroy() {
		this._renderer = null;
	}
};
ln.extension = {
	type: [
		x.WebGLSystem,
		x.WebGPUSystem,
		x.CanvasSystem
	],
	name: "renderableGC",
	priority: 0
}, ln.defaultOptions = {
	renderableGCActive: !0,
	renderableGCMaxUnusedTime: 6e4,
	renderableGCFrequency: 3e4
};
var un = ln, dn = class e {
	get count() {
		return this._renderer.tick;
	}
	get checkCount() {
		return this._checkCount;
	}
	set checkCount(e) {
		o("8.15.0", "TextureGCSystem.run is deprecated, please use the GCSystem instead."), this._checkCount = e;
	}
	get maxIdle() {
		return this._renderer.gc.maxUnusedTime / 1e3 * 60;
	}
	set maxIdle(e) {
		o("8.15.0", "TextureGCSystem.run is deprecated, please use the GCSystem instead."), this._renderer.gc.maxUnusedTime = e / 60 * 1e3;
	}
	get checkCountMax() {
		return Math.floor(this._renderer.gc._frequency / 1e3);
	}
	set checkCountMax(e) {
		o("8.15.0", "TextureGCSystem.run is deprecated, please use the GCSystem instead.");
	}
	get active() {
		return this._renderer.gc.enabled;
	}
	set active(e) {
		o("8.15.0", "TextureGCSystem.run is deprecated, please use the GCSystem instead."), this._renderer.gc.enabled = e;
	}
	constructor(e) {
		this._renderer = e, this._checkCount = 0;
	}
	init(t) {
		t.textureGCActive !== e.defaultOptions.textureGCActive && (this.active = t.textureGCActive), t.textureGCMaxIdle !== e.defaultOptions.textureGCMaxIdle && (this.maxIdle = t.textureGCMaxIdle), t.textureGCCheckCountMax !== e.defaultOptions.textureGCCheckCountMax && (this.checkCountMax = t.textureGCCheckCountMax);
	}
	run() {
		o("8.15.0", "TextureGCSystem.run is deprecated, please use the GCSystem instead."), this._renderer.gc.run();
	}
	destroy() {
		this._renderer = null;
	}
};
dn.extension = {
	type: [x.WebGLSystem, x.WebGPUSystem],
	name: "textureGC"
}, dn.defaultOptions = {
	textureGCActive: !0,
	textureGCAMaxIdle: null,
	textureGCMaxIdle: 3600,
	textureGCCheckCountMax: 600
};
var fn = dn, pn = class e {
	constructor(e = {}) {
		this.uid = h("renderTarget"), this.colorAttachments = [], this.dirtyId = 0, this.isRoot = !1, this._size = /* @__PURE__ */ new Float32Array(2), this._managedColorTextures = !1, this._depth = !1, this._stencil = !1, this._colorTextures = null;
		let t = "colorAttachments" in e ? e : this._normalizeOptions(e);
		if (this.isRoot = t.isRoot ?? !1, this.label = t.label, this.colorAttachments = t.colorAttachments, this.depthStencilAttachment = t.depthStencilAttachment, this.depthStencilAttachment) {
			let e = this.depthStencilAttachment.texture.format;
			this._depth ||= e.includes("depth"), this._stencil ||= e.includes("stencil");
		}
		if (this.colorAttachments.length === 0 && !this.depthStencilAttachment) throw Error("[RenderTarget] no color textures or depth textures were provided. Provide a depthStencilTexture or set depth/stencil to true when using colorTextures: 0.");
		if (this.colorAttachments.length > 0) {
			let e = this.colorTexture;
			this.resize(e.width, e.height, e._resolution);
		}
		this.sizeSource && this.sizeSource.on("resize", this.onSourceResize, this);
	}
	_normalizeOptions(t) {
		let n = {
			...e.defaultOptions,
			...t
		}, r = [], i;
		if (typeof n.colorTextures == "number") {
			if (n.colorTextures > 0) {
				this._managedColorTextures = !0;
				for (let e = 0; e < n.colorTextures; e++) r.push({
					texture: new p({
						width: n.width,
						height: n.height,
						resolution: n.resolution,
						antialias: n.antialias
					}),
					loadOp: "clear",
					storeOp: "store"
				});
			}
		} else n.colorTextures.forEach((e) => {
			r.push({
				texture: e.source,
				loadOp: "clear",
				storeOp: "store"
			});
		});
		let a = n.depthStencilTexture === !0;
		if (this._depth = !!(n.depth || a), this._stencil = !!(n.stencil || a), n.depthStencilTexture instanceof f || n.depthStencilTexture instanceof p) {
			if (n.isRoot) throw Error("[RenderTarget] cannot attach a depth-stencil texture to the screen — the canvas owns its own depth/stencil buffers. Render to a texture target instead.");
			i = { texture: n.depthStencilTexture.source };
		} else (a && !n.isRoot || (n.stencil || n.depth) && r.length === 0) && (i = this._createDepthStencilTexture(n.width, n.height, n.resolution));
		return {
			colorAttachments: r,
			depthStencilAttachment: i,
			isRoot: n.isRoot,
			label: n.label
		};
	}
	get size() {
		let e = this._size;
		return e[0] = this.pixelWidth, e[1] = this.pixelHeight, e;
	}
	get width() {
		return this.sizeSource.width;
	}
	get height() {
		return this.sizeSource.height;
	}
	get pixelWidth() {
		return this.sizeSource.pixelWidth;
	}
	get pixelHeight() {
		return this.sizeSource.pixelHeight;
	}
	get resolution() {
		return this.sizeSource._resolution;
	}
	get colorTextures() {
		return this._colorTextures ||= this.colorAttachments.map((e) => e.texture), this._colorTextures;
	}
	get depthStencilTexture() {
		return this.depthStencilAttachment?.texture ?? null;
	}
	get depth() {
		return this._depth;
	}
	get stencil() {
		return this._stencil;
	}
	get colorTexture() {
		return this.colorAttachments[0]?.texture;
	}
	get sizeSource() {
		return this.colorAttachments[0]?.texture ?? this.depthStencilAttachment?.texture;
	}
	onSourceResize(e) {
		this.resize(e.width, e.height, e._resolution, !0);
	}
	ensureDepthStencilTexture() {
		this._createDepthStencilTexture(this.sizeSource.width, this.sizeSource.height, this.sizeSource._resolution), this._depth = !0, this._stencil = !0;
	}
	resize(e, t, n = this.resolution, r = !1) {
		if (this.dirtyId++, this.colorAttachments.forEach((i, a) => {
			r && a === 0 || i.texture.resize(e, t, n);
		}), this.depthStencilAttachment) {
			if (r && this.colorAttachments.length === 0) return;
			this.depthStencilAttachment.texture.resize(e, t, n);
		}
	}
	destroy() {
		!this.colorAttachments && !this.depthStencilAttachment || (this.sizeSource.off("resize", this.onSourceResize, this), this._managedColorTextures && this.colorAttachments.forEach((e) => {
			e.texture.destroy();
		}), this.depthStencilAttachment && (this.depthStencilAttachment.texture.destroy(), delete this.depthStencilAttachment), this.colorAttachments = null, this._colorTextures = null);
	}
	_createDepthStencilTexture(e, t, n) {
		return this.depthStencilAttachment ??= { texture: new p({
			width: e,
			height: t,
			resolution: n,
			format: "depth24plus-stencil8",
			autoGenerateMipmaps: !1,
			antialias: !1,
			mipLevelCount: 1
		}) }, this.depthStencilAttachment;
	}
};
pn.defaultOptions = {
	width: 0,
	height: 0,
	resolution: 1,
	colorTextures: 1,
	stencil: !1,
	depth: !1,
	antialias: !1,
	isRoot: !1
};
var Q = pn, $ = /* @__PURE__ */ new Map();
s.register($);
function mn(e, t) {
	if (!$.has(e)) {
		let n = new f({ source: new w({
			resource: e,
			...t
		}) }), r = () => {
			$.get(e) === n && $.delete(e);
		};
		n.once("destroy", r), n.source.once("destroy", r), $.set(e, n);
	}
	return $.get(e);
}
//#endregion
//#region node_modules/pixi.js/lib/rendering/renderers/shared/view/ViewSystem.mjs
var hn = class e {
	get autoDensity() {
		return this.texture.source.autoDensity;
	}
	set autoDensity(e) {
		this.texture.source.autoDensity = e;
	}
	get resolution() {
		return this.texture.source._resolution;
	}
	set resolution(e) {
		this.texture.source.resize(this.texture.source.width, this.texture.source.height, e);
	}
	init(t) {
		t = {
			...e.defaultOptions,
			...t
		}, t.view && (o(m, "ViewSystem.view has been renamed to ViewSystem.canvas"), t.canvas = t.view), this.screen = new l(0, 0, t.width, t.height), this.canvas = t.canvas || v.get().createCanvas(), this.antialias = !!t.antialias, this.texture = mn(this.canvas, t), this.renderTarget = new Q({
			colorTextures: [this.texture],
			depth: !!t.depth,
			isRoot: !0
		}), this.texture.source.transparent = t.backgroundAlpha < 1, this.resolution = t.resolution;
	}
	resize(e, t, n) {
		this.texture.source.resize(e, t, n), this.screen.width = this.texture.frame.width, this.screen.height = this.texture.frame.height;
	}
	destroy(e = !1) {
		(typeof e == "boolean" ? e : e?.removeView) && this.canvas.parentNode && this.canvas.parentNode.removeChild(this.canvas), this.texture.destroy();
	}
};
hn.extension = {
	type: [
		x.WebGLSystem,
		x.WebGPUSystem,
		x.CanvasSystem
	],
	name: "view",
	priority: 0
}, hn.defaultOptions = {
	width: 800,
	height: 600,
	autoDensity: !1,
	antialias: !1
};
//#endregion
//#region node_modules/pixi.js/lib/rendering/renderers/shared/system/SharedSystems.mjs
var gn = [
	Wt,
	nn,
	cn,
	hn,
	Ut,
	tn,
	fn,
	Zt,
	Kt,
	Se,
	un,
	an
], _n = [
	J,
	V,
	K,
	G,
	H,
	Pt,
	Nt,
	U
];
//#endregion
//#region node_modules/pixi.js/lib/rendering/renderers/gpu/renderTarget/calculateProjection.mjs
function vn(e, t, n, r, i, a) {
	let o = a ? 1 : -1;
	return e.identity(), e.a = 1 / r * 2, e.d = o * (1 / i * 2), e.tx = -1 - t * e.a, e.ty = -o - n * e.d, e;
}
//#endregion
//#region node_modules/pixi.js/lib/rendering/renderers/shared/renderTarget/isRenderingToScreen.mjs
function yn(e) {
	if (e.colorAttachments.length === 0) return !1;
	let t = e.colorTexture.resource;
	return globalThis.HTMLCanvasElement && t instanceof HTMLCanvasElement && document.body.contains(t);
}
//#endregion
//#region node_modules/pixi.js/lib/rendering/renderers/shared/renderTarget/RenderTargetSystem.mjs
var bn = class {
	constructor(e) {
		this.rootViewPort = new l(), this.viewport = new l(), this.onRenderTargetChange = new _e("onRenderTargetChange"), this.projectionMatrix = new b(), this.defaultClearColor = [
			0,
			0,
			0,
			0
		], this._renderSurfaceToRenderTargetHash = /* @__PURE__ */ new Map(), this._gpuRenderTargetHash = /* @__PURE__ */ Object.create(null), this._renderTargetStack = [], this._bindState = {
			target: null,
			frame: void 0,
			mipLevel: 0,
			layer: 0,
			flipY: !1
		}, this._bindFrame = new l(), this._renderer = e, e.gc.addCollection(this, "_gpuRenderTargetHash", "hash");
	}
	get renderSurface() {
		return this._bindState.target;
	}
	get mipLevel() {
		return this._bindState.mipLevel;
	}
	get layer() {
		return this._bindState.layer;
	}
	finishRenderPass() {
		this.adaptor.finishRenderPass(this.renderTarget);
	}
	renderStart(e) {
		this._renderTargetStack.length = 0, this.push(e), this.rootViewPort.copyFrom(this.viewport), this.rootRenderTarget = this.renderTarget, this.renderingToScreen = yn(this.rootRenderTarget), this.adaptor.prerender?.(this.rootRenderTarget);
	}
	postrender() {
		this.adaptor.postrender?.(this.rootRenderTarget);
	}
	bind(e, t = !0, n, r, i = 0, a = 0, s) {
		let c;
		"target" in e ? c = e : (o("8.20.0", "RenderTargetSystem.bind: positional arguments are deprecated, please use an options object instead: bind({ target, clear, clearColor, frame, mipLevel, layer, flipY })"), c = {
			target: e,
			clear: t,
			clearColor: n,
			frame: r,
			mipLevel: i,
			layer: a,
			flipY: s
		});
		let l = c.target;
		t = c.clear ?? !0, n = c.clearColor, i = (c.mipLevel ?? 0) | 0, a = (c.layer ?? 0) | 0, s = c.flipY, r = c.frame;
		let u = this.getRenderTarget(l), d = this.renderTarget !== u;
		this.renderTarget = u;
		let p = this.getGpuRenderTarget(u);
		(u.pixelWidth !== p.width || u.pixelHeight !== p.height) && (this.adaptor.resizeGpuRenderTarget(u), p.width = u.pixelWidth, p.height = u.pixelHeight);
		let m = u.colorAttachments[0]?.texture || u.depthStencilAttachment?.texture, h = this.viewport, g = m.arrayLayerCount || 1;
		if (a < 0 || a >= g) throw Error(`[RenderTargetSystem] layer ${a} is out of bounds (arrayLayerCount=${g}).`);
		let _ = this._bindState;
		_.target = l, _.frame = r ? this._bindFrame.copyFrom(r) : void 0, _.mipLevel = i, _.layer = a, _.flipY = s;
		let v = Math.max(m.pixelWidth >> i, 1), y = Math.max(m.pixelHeight >> i, 1);
		if (!r && l instanceof f && (r = l.frame), r) {
			let e = m._resolution, t = 1 << Math.max(i, 0), n = r.x * e + .5 | 0, a = r.y * e + .5 | 0, o = r.width * e + .5 | 0, s = r.height * e + .5 | 0, c = Math.floor(n / t), l = Math.floor(a / t), u = Math.ceil(o / t), d = Math.ceil(s / t);
			c < 0 && (u += c, c = 0), l < 0 && (d += l, l = 0), c = Math.min(c, v - 1), l = Math.min(l, y - 1), u = Math.min(u, v - c), d = Math.min(d, y - l), u = Math.max(u, 1), d = Math.max(d, 1), h.x = c, h.y = l, h.width = u, h.height = d;
		} else h.x = 0, h.y = 0, h.width = v, h.height = y;
		return u.flipY = s, vn(this.projectionMatrix, 0, 0, h.width / m.resolution, h.height / m.resolution, !u.isRoot != !!u.flipY), this.adaptor.startRenderPass(u, t, n, h, i, a), d && this.onRenderTargetChange.emit(u), u;
	}
	getBindState(e) {
		if (!this.renderTarget) throw Error("[RenderTargetSystem] getBindState is only valid while a render surface is bound");
		let t = this._bindState;
		return e ??= {}, e.target = t.target, e.clear = O.NONE, e.clearColor = void 0, t.frame ? e.frame ? e.frame.copyFrom(t.frame) : e.frame = t.frame.clone() : e.frame = void 0, e.mipLevel = t.mipLevel, e.layer = t.layer, e.flipY = !!t.flipY, e;
	}
	get frontFaceInverted() {
		let e = this.renderTarget;
		if (!e) return !1;
		let t = this._renderer.type === S.WEBGL && !e.isRoot;
		return !!e.flipY !== t;
	}
	clear(e, t = O.ALL, n, r = this.mipLevel, i = this.layer) {
		t && (e &&= this.getRenderTarget(e), this.adaptor.clear(e || this.renderTarget, t, n, this.viewport, r, i));
	}
	contextChange() {
		this._gpuRenderTargetHash = /* @__PURE__ */ Object.create(null);
	}
	push(e, t = O.ALL, n, r, i = 0, a = 0, s) {
		let c;
		"target" in e ? c = e : (o("8.20.0", "RenderTargetSystem.push: positional arguments are deprecated, please use an options object instead: push({ target, clear, clearColor, frame, mipLevel, layer, flipY })"), c = {
			target: e,
			clear: t,
			clearColor: n,
			frame: r,
			mipLevel: i,
			layer: a,
			flipY: s
		});
		let l = this.bind(c);
		return this._renderTargetStack.push({
			target: c.target,
			clear: !1,
			clearColor: void 0,
			frame: c.frame ? c.frame.clone() : void 0,
			mipLevel: c.mipLevel,
			layer: c.layer,
			flipY: c.flipY
		}), l;
	}
	pop() {
		this._renderTargetStack.pop();
		let e = this._renderTargetStack[this._renderTargetStack.length - 1];
		if (!e) throw Error("[RenderTargetSystem] pop: no previous binding to restore (unbalanced pop)");
		return this.bind(e);
	}
	getRenderTarget(e) {
		return e.isTexture && (e = e.source), this._renderSurfaceToRenderTargetHash.get(e) ?? this._initRenderTarget(e);
	}
	copyToTexture(e, t, n, r, i) {
		let a = this.getRenderTarget(e);
		n.x < 0 && (r.width += n.x, i.x -= n.x, n.x = 0), n.y < 0 && (r.height += n.y, i.y -= n.y, n.y = 0);
		let { pixelWidth: o, pixelHeight: s } = a;
		return r.width = Math.min(r.width, o - n.x), r.height = Math.min(r.height, s - n.y), this.adaptor.copyToTexture(a, t, n, r, i);
	}
	copyDepthTexture(e, t, n, r, i = {
		x: 0,
		y: 0
	}) {
		let a = this.getRenderTarget(e);
		if (!a.depthStencilAttachment) {
			u("[RenderTargetSystem] copyDepthTexture: the source render target has no depth attachment to copy from");
			return;
		}
		let o = t.source;
		if (!o.format.includes("depth") && !o.format.includes("stencil")) {
			u(`[RenderTargetSystem] copyDepthTexture: the destination texture must have a depth/stencil format (got '${o.format}')`);
			return;
		}
		let s = n.x, c = n.y, l = i.x, d = i.y, f = r.width, p = r.height;
		s < 0 && (f += s, l -= s, s = 0), c < 0 && (p += c, d -= c, c = 0), f = Math.min(f, a.pixelWidth - s), p = Math.min(p, a.pixelHeight - c), f = Math.min(f, o.pixelWidth - l), p = Math.min(p, o.pixelHeight - d), !(f <= 0 || p <= 0) && this.adaptor.copyDepthTexture(a, t, {
			x: s,
			y: c
		}, {
			width: f,
			height: p
		}, {
			x: l,
			y: d
		});
	}
	ensureDepthStencil() {
		if (!this.renderTarget.stencil) {
			if (this.renderTarget.depthStencilTexture) {
				u(`[RenderTargetSystem] a stencil mask is being used, but the render target's depthStencilTexture format '${this.renderTarget.depthStencilTexture.format}' has no stencil aspect, so masking cannot work here. Use a 'depth24plus-stencil8' texture instead.`);
				return;
			}
			this.renderTarget._depth = !0, this.renderTarget._stencil = !0, this.adaptor.startRenderPass(this.renderTarget, !1, null, this.viewport, 0, this.layer);
		}
	}
	destroy() {
		this._renderer = null, this._renderSurfaceToRenderTargetHash.forEach((e, t) => {
			e !== t && this._releaseRenderTarget(t, e);
		}), this._renderSurfaceToRenderTargetHash.clear(), this._gpuRenderTargetHash = /* @__PURE__ */ Object.create(null);
	}
	_initRenderTarget(e) {
		let t = null;
		if (w.test(e) && (e = mn(e).source), e instanceof Q) t = e;
		else if (e instanceof p) {
			let n = e.format;
			t = n.includes("depth") || n.includes("stencil") ? new Q({
				colorTextures: 0,
				depthStencilTexture: e
			}) : new Q({ colorTextures: [e] }), e.source instanceof w && (t.isRoot = !0), e.once("destroy", this._onRenderSurfaceDestroy, this);
		}
		return this._renderSurfaceToRenderTargetHash.set(e, t), t;
	}
	_onRenderSurfaceDestroy(e) {
		let t = this._renderSurfaceToRenderTargetHash.get(e);
		t && this._releaseRenderTarget(e, t);
	}
	_releaseRenderTarget(e, t) {
		t.destroy(), this._renderSurfaceToRenderTargetHash.delete(e), e.off("destroy", this._onRenderSurfaceDestroy, this);
		let n = this._gpuRenderTargetHash[t.uid];
		n && (this._gpuRenderTargetHash[t.uid] = null, this.adaptor.destroyGpuRenderTarget(n));
	}
	getGpuRenderTarget(e) {
		return this._gpuRenderTargetHash[e.uid] || (this._gpuRenderTargetHash[e.uid] = this.adaptor.initGpuRenderTarget(e));
	}
	resetState() {
		this.renderTarget = null, this._bindState.target = null;
	}
};
//#endregion
export { M as C, be as D, xe as E, O, De as S, A as T, _t as _, K as a, ct as b, H as c, wt as d, z as f, mt as g, yt as h, J as i, ge as k, V as l, vt as m, _n as n, G as o, xt as p, gn as r, U as s, bn as t, kt as u, lt as v, j as w, st as x, ut as y };

//# sourceMappingURL=RenderTargetSystem-Bs_X-W5p.js.map