import { $ as e, A as t, B as n, C as r, E as i, I as a, J as o, K as s, O as c, Q as l, R as u, S as d, U as f, V as p, W as m, X as h, Y as g, Z as _, _ as v, a as y, at as b, b as x, c as S, d as C, et as w, g as T, i as E, it as D, l as O, m as k, n as A, nt as j, o as M, ot as N, p as ee, r as P, rt as F, s as te, t as ne, tt as I, u as re, v as ie, x as ae, y as L, z as R } from "./Geometry-CYPxRocb.js";
import { t as oe } from "./init-Dz7_hNy6.js";
import { n as se, r as ce, t as le } from "./canvasUtils-B52VJkLn.js";
import { C as ue, D as de, E as fe, O as pe, S as me, T as he, _ as ge, a as _e, b as ve, c as ye, d as be, f as xe, g as Se, h as Ce, i as we, l as Te, m as Ee, n as De, o as Oe, p as ke, r as Ae, s as je, t as Me, u as Ne, v as Pe, w as Fe, x as Ie, y as Le } from "./RenderTargetSystem-Bs_X-W5p.js";
import { t as Re } from "./getTextureBatchBindGroup-9HBchnv9.js";
import { t as ze } from "./CanvasPool-4lFBuryO.js";
import { a as Be, c as Ve, d as He, f as Ue, i as We, l as Ge, n as Ke, o as qe, p as Je, r as Ye, s as Xe, t as Ze, u as Qe } from "./BufferResource-uMLrSSVl.js";
//#region node_modules/pixi.js/lib/environment-browser/browserExt.mjs
var $e = {
	extension: {
		type: D.Environment,
		name: "browser",
		priority: -1
	},
	test: () => !0,
	load: async () => {
		await import("./browserAll-D5DBqH_a.js");
	}
}, et = {
	extension: {
		type: D.Environment,
		name: "webworker",
		priority: 0
	},
	test: () => typeof self < "u" && self.WorkerGlobalScope !== void 0,
	load: async () => {
		await import("./webworkerAll-DXoAr3HC.js");
	}
}, tt = /* @__PURE__ */ new Set(), nt = !1;
function rt(e, t, n = 2) {
	let r = t && t.length, i = r ? t[0] * n : e.length;
	tt.size && tt.clear();
	let a = it(e, 0, i, n, !0), o = [];
	if (!a || a.next === a.prev) return o;
	let s = 0, c = 0, l = 0;
	if (r && (a = ft(e, t, a, n)), e.length > 80 * n) {
		s = e[0], c = e[1];
		let t = s, r = c;
		for (let a = n; a < i; a += n) {
			let n = e[a], i = e[a + 1];
			n < s && (s = n), i < c && (c = i), n > t && (t = n), i > r && (r = i);
		}
		l = Math.max(t - s, r - c), l = l === 0 ? 0 : 32767 / l;
	}
	return ot(a, o, s, c, l), o;
}
function it(e, t, n, r, i) {
	let a = null;
	if (i === Yt(e, t, n, r) > 0) for (let i = t; i < n; i += r) a = Kt(i / r | 0, e[i], e[i + 1], a);
	else for (let i = n - r; i >= t; i -= r) a = Kt(i / r | 0, e[i], e[i + 1], a);
	return a && zt(a, a.next) && (qt(a), a = a.next), a;
}
function at(e, t = e) {
	let n = t === e, r = e, i;
	do
		i = !1, r !== r.next && (tt.size === 0 || !tt.has(r)) && (zt(r, r.next) || Rt(r.prev, r, r.next) === 0) ? ((n || r === t) && (t = r.prev), nt = !0, qt(r), r = r.prev, i = !0) : (n || r !== t) && (r = r.next, i = !n);
	while (i || r !== t);
	return t;
}
function ot(e, t, n, r, i) {
	i && jt(e, n, r, i);
	let a = e, o = !1;
	for (; e.prev !== e.next;) {
		let s = e.prev, c = e.next;
		if (Rt(s, e, c) < 0 && (i ? ct(e, n, r, i) : st(e))) {
			t.push(s.i, e.i, c.i), qt(e), e = c, a = c;
			continue;
		}
		if (e = c, e === a) {
			if (nt = !1, e = at(e), nt) {
				a = e;
				continue;
			}
			if (!o) {
				e = lt(e, t), a = e, o = !0;
				continue;
			}
			ut(e, t, n, r, i);
			break;
		}
	}
}
function st(e) {
	let t = e.prev, n = e, r = e.next, i = t.x, a = n.x, o = r.x, s = t.y, c = n.y, l = r.y, u = Math.min(i, a, o), d = Math.min(s, c, l), f = Math.max(i, a, o), p = Math.max(s, c, l), m = r.next;
	for (; m !== t;) {
		if (m.x >= u && m.x <= f && m.y >= d && m.y <= p && (i !== m.x || s !== m.y) && It(i, s, a, c, o, l, m.x, m.y) && Rt(m.prev, m, m.next) >= 0) return !1;
		m = m.next;
	}
	return !0;
}
function ct(e, t, n, r) {
	let i = e.prev, a = e, o = e.next, s = i.x, c = a.x, l = o.x, u = i.y, d = a.y, f = o.y, p = Math.min(s, c, l), m = Math.min(u, d, f), h = Math.max(s, c, l), g = Math.max(u, d, f), _ = Pt(p, m, t, n, r), v = Pt(h, g, t, n, r), y = e.prevZ;
	for (; y && y.z >= _;) {
		if (y.x >= p && y.x <= h && y.y >= m && y.y <= g && y !== o && (s !== y.x || u !== y.y) && It(s, u, c, d, l, f, y.x, y.y) && Rt(y.prev, y, y.next) >= 0) return !1;
		y = y.prevZ;
	}
	let b = e.nextZ;
	for (; b && b.z <= v;) {
		if (b.x >= p && b.x <= h && b.y >= m && b.y <= g && b !== o && (s !== b.x || u !== b.y) && It(s, u, c, d, l, f, b.x, b.y) && Rt(b.prev, b, b.next) >= 0) return !1;
		b = b.nextZ;
	}
	return !0;
}
function lt(e, t) {
	let n = e, r = !1;
	do {
		let i = n.prev, a = n.next.next;
		Bt(i, n, n.next, a, !1) && Ut(i, a) && Ut(a, i) && (t.push(i.i, n.i, a.i), qt(n), qt(n.next), n = e = a, r = !0), n = n.next;
	} while (n !== e);
	return r ? at(n) : n;
}
function ut(e, t, n, r, i) {
	let a = e;
	do {
		let e = a.next.next;
		for (; e !== a.prev;) {
			if (a.i !== e.i && Lt(a, e)) {
				let o = Gt(a, e);
				a = at(a, a.next), o = at(o, o.next), ot(a, t, n, r, i), ot(o, t, n, r, i);
				return;
			}
			e = e.next;
		}
		a = a.next;
	} while (a !== e);
}
var dt = !1;
function ft(e, t, n, r) {
	let i = [];
	for (let n = 0, a = t.length; n < a; n++) {
		let o = it(e, t[n] * r, n < a - 1 ? t[n + 1] * r : e.length, r, !1);
		o === o.next && tt.add(o), i.push(Ft(o));
	}
	i.sort(pt), yt(e.length / r, t.length), bt(n, n), dt = !0;
	for (let e = 0; e < i.length; e++) n = mt(i[e], n);
	return dt = !1, at(n);
}
function pt(e, t) {
	return e.x - t.x || e.y - t.y || (e.next.y - e.y) / (e.next.x - e.x) - (t.next.y - t.y) / (t.next.x - t.x);
}
function mt(e, t) {
	let n = wt(e, t);
	if (!n) return t;
	let r = Gt(n, e), i = r.next;
	return bt(n, i.next), at(r, r.next), at(n, n.next);
}
var ht = 16, z = /* @__PURE__ */ new Float64Array(), gt = 0, _t = [], vt = [];
function yt(e, t) {
	let n = Math.ceil((e + 2 * t) / ht) + t + 2;
	z.length < n * 4 && (z = new Float64Array(n * 4)), gt = 0;
}
function bt(e, t) {
	let n = e;
	do {
		let e = gt++;
		_t[e] = n;
		let r = Infinity, i = Infinity, a = -Infinity, o = -Infinity, s = 0;
		do {
			let t = n.next;
			n.z = e, n.x < r && (r = n.x), n.x > a && (a = n.x), n.y < i && (i = n.y), n.y > o && (o = n.y), t.x < r && (r = t.x), t.x > a && (a = t.x), t.y < i && (i = t.y), t.y > o && (o = t.y), n = t;
		} while (++s < ht && n !== t);
		vt[e] = n;
		let c = e * 4;
		z[c] = r, z[c + 1] = i, z[c + 2] = a, z[c + 3] = o;
	} while (n !== t);
}
function xt(e, t) {
	let n = e.z * 4;
	t.x < z[n] && (z[n] = t.x), t.y < z[n + 1] && (z[n + 1] = t.y), t.x > z[n + 2] && (z[n + 2] = t.x), t.y > z[n + 3] && (z[n + 3] = t.y);
}
function St(e) {
	let t = vt[e];
	for (; t.prev.next !== t;) t = t.next;
	return vt[e] = t, t;
}
function Ct(e) {
	let t = _t[e];
	for (; t.prev.next !== t;) t = t.next;
	return _t[e] = t, t;
}
function wt(e, t) {
	let n = t, r = e.x, i = e.y, a = -Infinity, o;
	if (zt(e, n)) return n;
	for (let t = 0, s = 0; t < gt; t++, s += 4) {
		if (i < z[s + 1] || i > z[s + 3] || z[s] > r || z[s + 2] <= a) continue;
		let c = St(t);
		n = Ct(t);
		do {
			if (n.prev.next === n) {
				if (zt(e, n.next)) return n.next;
				if (i <= n.y && i >= n.next.y && n.next.y !== n.y) {
					let e = n.x + (i - n.y) * (n.next.x - n.x) / (n.next.y - n.y);
					if (e <= r && e > a && (a = e, o = n.x < n.next.x ? n : n.next, e === r)) return o;
				}
			}
			n = n.next;
		} while (n !== c);
	}
	if (!o) return null;
	let s = o.x, c = o.y, l = Math.min(i, c), u = Math.max(i, c), d = Infinity;
	for (let t = 0, f = 0; t < gt; t++, f += 4) {
		if (z[f + 2] < s || z[f] > r || z[f + 3] < l || z[f + 1] > u) continue;
		let p = St(t);
		n = Ct(t);
		do {
			if (n.prev.next === n && r >= n.x && n.x >= s && r !== n.x && It(i < c ? r : a, i, s, c, i < c ? a : r, i, n.x, n.y)) {
				let t = Math.abs(i - n.y) / (r - n.x);
				(Ut(n, e) || n.y === i && n.next.y === i && n.next.x > r) && (t < d || t === d && (n.x > o.x || n.x === o.x && Tt(o, n))) && (o = n, d = t);
			}
			n = n.next;
		} while (n !== p);
	}
	return o;
}
function Tt(e, t) {
	return Rt(e.prev, e, t.prev) < 0 && Rt(t.next, e, e.next) < 0;
}
var Et = [], Dt = [], Ot = /* @__PURE__ */ new Uint32Array(), kt = /* @__PURE__ */ new Uint32Array(), At = /* @__PURE__ */ new Uint32Array(256);
function jt(e, t, n, r) {
	let i = e, a = 0;
	do
		i.z = Pt(i.x, i.y, t, n, r), Et[a++] = i, i = i.next;
	while (i !== e);
	Mt(a);
	let o = null;
	for (let e = 0; e < a; e++) {
		let t = Et[e];
		t.prevZ = o, o && (o.nextZ = t), o = t;
	}
	o.nextZ = null;
}
function Mt(e) {
	if (e <= 32) {
		for (let t = 1; t < e; t++) {
			let e = Et[t], n = e.z, r = t - 1;
			for (; r >= 0 && Et[r].z > n;) Et[r + 1] = Et[r], r--;
			Et[r + 1] = e;
		}
		return;
	}
	Ot.length < e && (Ot = new Uint32Array(e), kt = new Uint32Array(e), Dt = Array(e));
	for (let t = 0; t < e; t++) Ot[t] = Et[t].z;
	Nt(e, Et, Ot, Dt, kt, 0), Nt(e, Dt, kt, Et, Ot, 8), Nt(e, Et, Ot, Dt, kt, 16), Nt(e, Dt, kt, Et, Ot, 24);
}
function Nt(e, t, n, r, i, a) {
	At.fill(0);
	for (let t = 0; t < e; t++) At[n[t] >>> a & 255]++;
	let o = 0;
	for (let e = 0; e < 256; e++) {
		let t = At[e];
		At[e] = o, o += t;
	}
	for (let o = 0; o < e; o++) {
		let e = n[o], s = At[e >>> a & 255]++;
		r[s] = t[o], i[s] = e;
	}
}
function Pt(e, t, n, r, i) {
	return e = (e - n) * i | 0, t = (t - r) * i | 0, e = (e | e << 8) & 16711935, e = (e | e << 4) & 252645135, e = (e | e << 2) & 858993459, e = (e | e << 1) & 1431655765, t = (t | t << 8) & 16711935, t = (t | t << 4) & 252645135, t = (t | t << 2) & 858993459, t = (t | t << 1) & 1431655765, e | t << 1;
}
function Ft(e) {
	let t = e, n = e;
	do
		(t.x < n.x || t.x === n.x && t.y < n.y) && (n = t), t = t.next;
	while (t !== e);
	return n;
}
function It(e, t, n, r, i, a, o, s) {
	return (i - o) * (t - s) >= (e - o) * (a - s) && (e - o) * (r - s) >= (n - o) * (t - s) && (n - o) * (a - s) >= (i - o) * (r - s);
}
function Lt(e, t) {
	let n = zt(e, t) && Rt(e.prev, e, e.next) > 0 && Rt(t.prev, t, t.next) > 0;
	return e.next.i !== t.i && (n || Ut(e, t) && Ut(t, e) && (Rt(e.prev, e, t.prev) !== 0 || Rt(e, t.prev, t) !== 0)) && !Ht(e, t) && (n || Wt(e, t));
}
function Rt(e, t, n) {
	return (t.y - e.y) * (n.x - t.x) - (t.x - e.x) * (n.y - t.y);
}
function zt(e, t) {
	return e.x === t.x && e.y === t.y;
}
function Bt(e, t, n, r, i = !0) {
	let a = Rt(e, t, n), o = Rt(e, t, r), s = Rt(n, r, e), c = Rt(n, r, t);
	return (a > 0 && o < 0 || a < 0 && o > 0) && (s > 0 && c < 0 || s < 0 && c > 0) ? !0 : i ? !!(a === 0 && Vt(e, n, t) || o === 0 && Vt(e, r, t) || s === 0 && Vt(n, e, r) || c === 0 && Vt(n, t, r)) : !1;
}
function Vt(e, t, n) {
	return t.x <= Math.max(e.x, n.x) && t.x >= Math.min(e.x, n.x) && t.y <= Math.max(e.y, n.y) && t.y >= Math.min(e.y, n.y);
}
function Ht(e, t) {
	let n = Math.min(e.x, t.x), r = Math.max(e.x, t.x), i = Math.min(e.y, t.y), a = Math.max(e.y, t.y), o = e;
	do {
		let s = o.next;
		if (o.x > r && s.x > r || o.x < n && s.x < n || o.y > a && s.y > a || o.y < i && s.y < i) {
			o = s;
			continue;
		}
		if (o.i !== e.i && s.i !== e.i && o.i !== t.i && s.i !== t.i && Bt(o, s, e, t)) return !0;
		o = s;
	} while (o !== e);
	return !1;
}
function Ut(e, t) {
	return Rt(e.prev, e, e.next) < 0 ? Rt(e, t, e.next) >= 0 && Rt(e, e.prev, t) >= 0 : Rt(e, t, e.prev) < 0 || Rt(e, e.next, t) < 0;
}
function Wt(e, t) {
	let n = e, r = !1, i = (e.x + t.x) / 2, a = (e.y + t.y) / 2;
	do {
		let e = n.next;
		n.y > a != e.y > a && i < (e.x - n.x) * (a - n.y) / (e.y - n.y) + n.x && (r = !r), n = e;
	} while (n !== e);
	return r;
}
function Gt(e, t) {
	let n = Jt(e.i, e.x, e.y), r = Jt(t.i, t.x, t.y), i = e.next, a = t.prev;
	return e.next = t, t.prev = e, n.next = i, i.prev = n, r.next = n, n.prev = r, a.next = r, r.prev = a, r;
}
function Kt(e, t, n, r) {
	let i = Jt(e, t, n);
	return r ? (i.next = r.next, i.prev = r, r.next.prev = i, r.next = i) : (i.prev = i, i.next = i), i;
}
function qt(e) {
	e.next.prev = e.prev, e.prev.next = e.next, e.prevZ && (e.prevZ.nextZ = e.nextZ), e.nextZ && (e.nextZ.prevZ = e.prevZ), dt && xt(e.prev, e.next);
}
function Jt(e, t, n) {
	return {
		i: e,
		x: t,
		y: n,
		prev: null,
		next: null,
		z: 0,
		prevZ: null,
		nextZ: null
	};
}
function Yt(e, t, n, r) {
	let i = 0;
	for (let a = t, o = n - r; a < n; a += r) i += (e[o] - e[a]) * (e[a + 1] + e[o + 1]), o = a;
	return i;
}
//#endregion
//#region node_modules/pixi.js/lib/utils/utils.mjs
var Xt = rt.default || rt, Zt;
function Qt(e) {
	return Zt === void 0 && (Zt = (() => {
		let t = {
			stencil: !0,
			failIfMajorPerformanceCaveat: e ?? de.defaultOptions.failIfMajorPerformanceCaveat
		};
		try {
			if (!x.get().getWebGLRenderingContext()) return !1;
			let e = x.get().createCanvas().getContext("webgl", t), n = !!e?.getContextAttributes()?.stencil;
			if (e) {
				let t = e.getExtension("WEBGL_lose_context");
				t && t.loseContext();
			}
			return e = null, n;
		} catch {
			return !1;
		}
	})()), Zt;
}
//#endregion
//#region node_modules/pixi.js/lib/utils/browser/isWebGPUSupported.mjs
var $t;
async function en(e = {}) {
	return $t === void 0 && ($t = await (async () => {
		let t = x.get().getNavigator().gpu;
		if (!t) return !1;
		try {
			return await (await t.requestAdapter(e)).requestDevice(), !0;
		} catch {
			return !1;
		}
	})()), $t;
}
//#endregion
//#region node_modules/pixi.js/lib/rendering/renderers/autoDetectRenderer.mjs
var tn = [
	"webgl",
	"webgpu",
	"canvas"
];
async function nn(e) {
	let t = [];
	e.preference ? Array.isArray(e.preference) ? t = e.preference.slice() : (t.push(e.preference), tn.forEach((n) => {
		n !== e.preference && t.push(n);
	})) : t = tn.slice();
	let n, r = {};
	for (let i = 0; i < t.length; i++) {
		let a = t[i];
		if (a === "webgpu" && await en()) {
			let { WebGPURenderer: t } = await Promise.resolve().then(() => mc);
			n = t, r = {
				...e,
				...e.webgpu
			};
			break;
		}
		if (a === "webgl" && Qt(e.failIfMajorPerformanceCaveat ?? de.defaultOptions.failIfMajorPerformanceCaveat)) {
			let { WebGLRenderer: t } = await Promise.resolve().then(() => us);
			n = t, r = {
				...e,
				...e.webgl
			};
			break;
		}
		if (a === "canvas") {
			let { CanvasRenderer: t } = await Promise.resolve().then(() => Ta);
			n = t, r = {
				...e,
				...e.canvasOptions
			};
			break;
		}
	}
	if (delete r.webgpu, delete r.webgl, delete r.canvasOptions, !n) throw Error("No available renderer for the current environment");
	let i = new n();
	return await i.init(r), i;
}
//#endregion
//#region node_modules/pixi.js/lib/app/ResizePlugin.mjs
var rn = class {
	static init(e) {
		Object.defineProperty(this, "resizeTo", {
			configurable: !0,
			set(e) {
				globalThis.removeEventListener("resize", this.queueResize), this._resizeTo = e, e && (globalThis.addEventListener("resize", this.queueResize), this.resize());
			},
			get() {
				return this._resizeTo;
			}
		}), this.queueResize = () => {
			this._resizeTo && (this._cancelResize(), this._resizeId = requestAnimationFrame(() => this.resize()));
		}, this._cancelResize = () => {
			this._resizeId &&= (cancelAnimationFrame(this._resizeId), null);
		}, this.resize = () => {
			if (!this._resizeTo) return;
			this._cancelResize();
			let e, t;
			if (this._resizeTo === globalThis.window) e = globalThis.innerWidth, t = globalThis.innerHeight;
			else {
				let { clientWidth: n, clientHeight: r } = this._resizeTo;
				e = n, t = r;
			}
			this.renderer.resize(e, t), this.render();
		}, this._resizeId = null, this._resizeTo = null, this.resizeTo = e.resizeTo || null;
	}
	static destroy() {
		globalThis.removeEventListener("resize", this.queueResize), this._cancelResize(), this._cancelResize = null, this.queueResize = null, this.resizeTo = null, this.resize = null;
	}
};
rn.extension = D.Application;
//#endregion
//#region node_modules/pixi.js/lib/app/TickerPlugin.mjs
var an = class {
	static init(e) {
		e = Object.assign({
			autoStart: !0,
			sharedTicker: !1
		}, e), Object.defineProperty(this, "ticker", {
			configurable: !0,
			set(e) {
				this._ticker && this._ticker.remove(this.render, this), this._ticker = e, e && e.add(this.render, this, ie.LOW);
			},
			get() {
				return this._ticker;
			}
		}), this.stop = () => {
			this._ticker.stop();
		}, this.start = () => {
			this._ticker.start();
		}, this._ticker = null, this.ticker = e.sharedTicker ? v.shared : new v(), e.autoStart && this.start();
	}
	static destroy() {
		if (this._ticker) {
			let e = this._ticker;
			this.ticker = null, e.destroy();
		}
	}
};
an.extension = D.Application, b.add(rn), b.add(an);
//#endregion
//#region node_modules/pixi.js/lib/app/Application.mjs
var on = class e {
	constructor(...e) {
		this.stage = new r(), e[0] !== void 0 && o(g, "Application constructor options are deprecated, please use Application.init() instead.");
	}
	async init(t) {
		t = { ...t }, this.stage ||= new r(), this.renderer = await nn(t), e._plugins.forEach((e) => {
			e.init.call(this, t);
		});
	}
	render() {
		this.renderer.render({ container: this.stage });
	}
	get canvas() {
		return this.renderer.canvas;
	}
	get view() {
		return o(g, "Application.view is deprecated, please use Application.canvas instead."), this.renderer.canvas;
	}
	get screen() {
		return this.renderer.screen;
	}
	get domContainerRoot() {
		return this.renderer.renderPipes.dom?._domElement;
	}
	destroy(t = !1, n = !1) {
		let r = e._plugins.slice(0);
		r.reverse(), r.forEach((e) => {
			e.destroy.call(this);
		}), this.stage.destroy(n), this.stage = null, this.renderer.destroy(t), this.renderer = null;
	}
};
on._plugins = [];
var sn = on;
b.handleByList(D.Application, sn._plugins), b.add(fe);
//#endregion
//#region node_modules/parse-svg-path/dist/index.mjs
var cn = {
	a: 7,
	c: 6,
	h: 1,
	l: 2,
	m: 2,
	q: 4,
	s: 4,
	t: 2,
	v: 1,
	z: 0
}, ln = /([astvzqmhlc])([^astvzqmhlc]*)/gi, un = /-?[0-9]*\.?[0-9]+(?:e[-+]?\d+)?/gi;
function dn(e) {
	let t = [];
	return e.replace(ln, (e, n, r) => {
		let i = n.toLowerCase(), a = n, o = fn(r);
		for (i === "m" && o.length > 2 && (t.push([a, ...o.splice(0, 2)]), i = "l", a = a === "m" ? "l" : "L");;) {
			if (o.length === cn[i]) return t.push([a, ...o]), "";
			if (o.length < cn[i]) throw Error("malformed path data");
			t.push([a, ...o.splice(0, cn[i])]);
		}
	}), t;
}
function fn(e) {
	let t = e.match(un);
	return t ? t.map(Number) : [];
}
//#endregion
//#region node_modules/pixi.js/lib/scene/graphics/shared/svg/parseSVGPath.mjs
function pn(e, t) {
	let n = dn(e), r = [], i = null, a = 0, o = 0;
	for (let e = 0; e < n.length; e++) {
		let s = n[e], c = s[0], l = s;
		switch (c) {
			case "M":
				a = l[1], o = l[2], t.moveTo(a, o);
				break;
			case "m":
				a += l[1], o += l[2], t.moveTo(a, o);
				break;
			case "H":
				a = l[1], t.lineTo(a, o);
				break;
			case "h":
				a += l[1], t.lineTo(a, o);
				break;
			case "V":
				o = l[1], t.lineTo(a, o);
				break;
			case "v":
				o += l[1], t.lineTo(a, o);
				break;
			case "L":
				a = l[1], o = l[2], t.lineTo(a, o);
				break;
			case "l":
				a += l[1], o += l[2], t.lineTo(a, o);
				break;
			case "C":
				a = l[5], o = l[6], t.bezierCurveTo(l[1], l[2], l[3], l[4], a, o);
				break;
			case "c":
				t.bezierCurveTo(a + l[1], o + l[2], a + l[3], o + l[4], a + l[5], o + l[6]), a += l[5], o += l[6];
				break;
			case "S":
				a = l[3], o = l[4], t.bezierCurveToShort(l[1], l[2], a, o);
				break;
			case "s":
				t.bezierCurveToShort(a + l[1], o + l[2], a + l[3], o + l[4]), a += l[3], o += l[4];
				break;
			case "Q":
				a = l[3], o = l[4], t.quadraticCurveTo(l[1], l[2], a, o);
				break;
			case "q":
				t.quadraticCurveTo(a + l[1], o + l[2], a + l[3], o + l[4]), a += l[3], o += l[4];
				break;
			case "T":
				a = l[1], o = l[2], t.quadraticCurveToShort(a, o);
				break;
			case "t":
				a += l[1], o += l[2], t.quadraticCurveToShort(a, o);
				break;
			case "A":
				a = l[6], o = l[7], t.arcToSvg(l[1], l[2], l[3], l[4], l[5], a, o);
				break;
			case "a":
				a += l[6], o += l[7], t.arcToSvg(l[1], l[2], l[3], l[4], l[5], a, o);
				break;
			case "Z":
			case "z":
				t.closePath(), r.length > 0 && (i = r.pop(), i ? (a = i.startX, o = i.startY) : (a = 0, o = 0)), i = null;
				break;
			default: u(`Unknown SVG path command: ${c}`);
		}
		c !== "Z" && c !== "z" && i === null && (i = {
			startX: a,
			startY: o
		}, r.push(i));
	}
	return t;
}
//#endregion
//#region node_modules/pixi.js/lib/maths/shapes/Circle.mjs
var mn = class e {
	constructor(e = 0, t = 0, n = 0) {
		this.type = "circle", this.x = e, this.y = t, this.radius = n;
	}
	clone() {
		return new e(this.x, this.y, this.radius);
	}
	contains(e, t) {
		if (this.radius <= 0) return !1;
		let n = this.radius * this.radius, r = this.x - e, i = this.y - t;
		return r *= r, i *= i, r + i <= n;
	}
	strokeContains(e, t, n, r = .5) {
		if (this.radius === 0) return !1;
		let i = this.x - e, a = this.y - t, o = this.radius, s = (1 - r) * n, c = Math.sqrt(i * i + a * a);
		return c <= o + s && c > o - (n - s);
	}
	getBounds(e) {
		return e ||= new l(), e.x = this.x - this.radius, e.y = this.y - this.radius, e.width = this.radius * 2, e.height = this.radius * 2, e;
	}
	copyFrom(e) {
		return this.x = e.x, this.y = e.y, this.radius = e.radius, this;
	}
	copyTo(e) {
		return e.copyFrom(this), e;
	}
	toString() {
		return `[pixi.js/math:Circle x=${this.x} y=${this.y} radius=${this.radius}]`;
	}
}, hn = class e {
	constructor(e = 0, t = 0, n = 0, r = 0) {
		this.type = "ellipse", this.x = e, this.y = t, this.halfWidth = n, this.halfHeight = r;
	}
	clone() {
		return new e(this.x, this.y, this.halfWidth, this.halfHeight);
	}
	contains(e, t) {
		if (this.halfWidth <= 0 || this.halfHeight <= 0) return !1;
		let n = (e - this.x) / this.halfWidth, r = (t - this.y) / this.halfHeight;
		return n *= n, r *= r, n + r <= 1;
	}
	strokeContains(e, t, n, r = .5) {
		let { halfWidth: i, halfHeight: a } = this;
		if (i <= 0 || a <= 0) return !1;
		let o = n * (1 - r), s = n - o, c = i - s, l = a - s, u = i + o, d = a + o, f = e - this.x, p = t - this.y, m = f * f / (c * c) + p * p / (l * l), h = f * f / (u * u) + p * p / (d * d);
		return m > 1 && h <= 1;
	}
	getBounds(e) {
		return e ||= new l(), e.x = this.x - this.halfWidth, e.y = this.y - this.halfHeight, e.width = this.halfWidth * 2, e.height = this.halfHeight * 2, e;
	}
	copyFrom(e) {
		return this.x = e.x, this.y = e.y, this.halfWidth = e.halfWidth, this.halfHeight = e.halfHeight, this;
	}
	copyTo(e) {
		return e.copyFrom(this), e;
	}
	toString() {
		return `[pixi.js/math:Ellipse x=${this.x} y=${this.y} halfWidth=${this.halfWidth} halfHeight=${this.halfHeight}]`;
	}
};
//#endregion
//#region node_modules/pixi.js/lib/maths/misc/getOrientationOfPoints.mjs
function gn(e) {
	let t = e.length;
	if (t < 6) return 1;
	let n = 0;
	for (let r = 0, i = e[t - 2], a = e[t - 1]; r < t; r += 2) {
		let t = e[r], o = e[r + 1];
		n += (t - i) * (o + a), i = t, a = o;
	}
	return n < 0 ? -1 : 1;
}
//#endregion
//#region node_modules/pixi.js/lib/maths/misc/squaredDistanceToLineSegment.mjs
function _n(e, t, n, r, i, a) {
	let o = e - n, s = t - r, c = i - n, l = a - r, u = o * c + s * l, d = c * c + l * l, f = -1;
	d !== 0 && (f = u / d);
	let p, m;
	f < 0 ? (p = n, m = r) : f > 1 ? (p = i, m = a) : (p = n + f * c, m = r + f * l);
	let h = e - p, g = t - m;
	return h * h + g * g;
}
//#endregion
//#region node_modules/pixi.js/lib/maths/shapes/Polygon.mjs
var vn, yn, bn = class e {
	constructor(...e) {
		this.type = "polygon";
		let t = Array.isArray(e[0]) ? e[0] : e;
		if (typeof t[0] != "number") {
			let e = [];
			for (let n = 0, r = t.length; n < r; n++) e.push(t[n].x, t[n].y);
			t = e;
		}
		this.points = t, this.closePath = !0;
	}
	isClockwise() {
		let e = 0, t = this.points, n = t.length;
		for (let r = 0; r < n; r += 2) {
			let i = t[r], a = t[r + 1], o = t[(r + 2) % n], s = t[(r + 3) % n];
			e += (o - i) * (s + a);
		}
		return e < 0;
	}
	containsPolygon(e) {
		let t = this.getBounds(vn), n = e.getBounds(yn);
		if (!t.containsRect(n)) return !1;
		let r = e.points;
		for (let e = 0; e < r.length; e += 2) {
			let t = r[e], n = r[e + 1];
			if (!this.contains(t, n)) return !1;
		}
		return !0;
	}
	clone() {
		let t = this.points.slice(), n = new e(t);
		return n.closePath = this.closePath, n;
	}
	contains(e, t) {
		let n = !1, r = this.points.length / 2;
		for (let i = 0, a = r - 1; i < r; a = i++) {
			let r = this.points[i * 2], o = this.points[i * 2 + 1], s = this.points[a * 2], c = this.points[a * 2 + 1];
			o > t != c > t && e < (s - r) * ((t - o) / (c - o)) + r && (n = !n);
		}
		return n;
	}
	strokeContains(e, t, n, r = .5) {
		let { points: i } = this, a = n * (r === .5 ? r : (r - .5) * gn(i) + .5), o = n - a, s = a * a, c = o * o, l = i.length - (this.closePath ? 0 : 2);
		for (let n = 0; n < l; n += 2) {
			let r = i[n], a = i[n + 1], o = i[(n + 2) % i.length], l = i[(n + 3) % i.length];
			if (_n(e, t, r, a, o, l) <= (Math.sign((o - r) * (t - a) - (l - a) * (e - r)) < 0 ? s : c)) return !0;
		}
		return !1;
	}
	getBounds(e) {
		e ||= new l();
		let t = this.points, n = Infinity, r = -Infinity, i = Infinity, a = -Infinity;
		for (let e = 0, o = t.length; e < o; e += 2) {
			let o = t[e], s = t[e + 1];
			n = o < n ? o : n, r = o > r ? o : r, i = s < i ? s : i, a = s > a ? s : a;
		}
		return e.x = n, e.width = r - n, e.y = i, e.height = a - i, e;
	}
	copyFrom(e) {
		return this.points = e.points.slice(), this.closePath = e.closePath, this;
	}
	copyTo(e) {
		return e.copyFrom(this), e;
	}
	toString() {
		return `[pixi.js/math:PolygoncloseStroke=${this.closePath}points=${this.points.reduce((e, t) => `${e}, ${t}`, "")}]`;
	}
	get lastX() {
		return this.points[this.points.length - 2];
	}
	get lastY() {
		return this.points[this.points.length - 1];
	}
	get x() {
		return o("8.11.0", "Polygon.lastX is deprecated, please use Polygon.lastX instead."), this.points[this.points.length - 2];
	}
	get y() {
		return o("8.11.0", "Polygon.y is deprecated, please use Polygon.lastY instead."), this.points[this.points.length - 1];
	}
	get startX() {
		return this.points[0];
	}
	get startY() {
		return this.points[1];
	}
}, xn = (e, t, n, r, i, a, o) => {
	let s = e - n, c = t - r, l = Math.sqrt(s * s + c * c);
	return l >= i - a && l <= i + o;
}, Sn = class e {
	constructor(e = 0, t = 0, n = 0, r = 0, i = 20) {
		this.type = "roundedRectangle", this.x = e, this.y = t, this.width = n, this.height = r, this.radius = i;
	}
	getBounds(e) {
		return e ||= new l(), e.x = this.x, e.y = this.y, e.width = this.width, e.height = this.height, e;
	}
	clone() {
		return new e(this.x, this.y, this.width, this.height, this.radius);
	}
	copyFrom(e) {
		return this.x = e.x, this.y = e.y, this.width = e.width, this.height = e.height, this.radius = e.radius, this;
	}
	copyTo(e) {
		return e.copyFrom(this), e;
	}
	contains(e, t) {
		if (this.width <= 0 || this.height <= 0) return !1;
		if (e >= this.x && e <= this.x + this.width && t >= this.y && t <= this.y + this.height) {
			let n = Math.max(0, Math.min(this.radius, Math.min(this.width, this.height) / 2));
			if (t >= this.y + n && t <= this.y + this.height - n || e >= this.x + n && e <= this.x + this.width - n) return !0;
			let r = e - (this.x + n), i = t - (this.y + n), a = n * n;
			if (r * r + i * i <= a || (r = e - (this.x + this.width - n), r * r + i * i <= a) || (i = t - (this.y + this.height - n), r * r + i * i <= a) || (r = e - (this.x + n), r * r + i * i <= a)) return !0;
		}
		return !1;
	}
	strokeContains(e, t, n, r = .5) {
		let { x: i, y: a, width: o, height: s, radius: c } = this, l = n * (1 - r), u = n - l, d = i + c, f = a + c, p = o - c * 2, m = s - c * 2, h = i + o, g = a + s;
		return (e >= i - l && e <= i + u || e >= h - u && e <= h + l) && t >= f && t <= f + m || (t >= a - l && t <= a + u || t >= g - u && t <= g + l) && e >= d && e <= d + p || e < d && t < f && xn(e, t, d, f, c, u, l) || e > h - c && t < f && xn(e, t, h - c, f, c, u, l) || e > h - c && t > g - c && xn(e, t, h - c, g - c, c, u, l) || e < d && t > g - c && xn(e, t, d, g - c, c, u, l);
	}
	toString() {
		return `[pixi.js/math:RoundedRectangle x=${this.x} y=${this.y}width=${this.width} height=${this.height} radius=${this.radius}]`;
	}
};
//#endregion
//#region node_modules/pixi.js/lib/rendering/renderers/shared/geometry/utils/buildUvs.mjs
function Cn(e, t, n, r, i, a, o, s = null) {
	let c = 0;
	n *= t, i *= a;
	let l = s.a, u = s.b, d = s.c, f = s.d, p = s.tx, m = s.ty;
	for (; c < o;) {
		let o = e[n], s = e[n + 1];
		r[i] = l * o + d * s + p, r[i + 1] = u * o + f * s + m, i += a, n += t, c++;
	}
}
function wn(e, t, n, r) {
	let i = 0;
	for (t *= n; i < r;) e[t] = 0, e[t + 1] = 0, t += n, i++;
}
//#endregion
//#region node_modules/pixi.js/lib/rendering/renderers/shared/geometry/utils/transformVertices.mjs
function Tn(e, t, n, r, i) {
	let a = t.a, o = t.b, s = t.c, c = t.d, l = t.tx, u = t.ty;
	n ||= 0, r ||= 2, i ||= e.length / r - n;
	let d = n * r;
	for (let t = 0; t < i; t++) {
		let t = e[d], n = e[d + 1];
		e[d] = a * t + s * n + l, e[d + 1] = o * t + c * n + u, d += r;
	}
}
//#endregion
//#region node_modules/pixi.js/lib/scene/graphics/shared/BatchableGraphics.mjs
var En = new w(), Dn = class {
	constructor() {
		this.packAsQuad = !1, this.batcherName = "default", this.topology = "triangle-list", this.applyTransform = !0, this.roundPixels = 0, this._batcher = null, this._batch = null;
	}
	get uvs() {
		return this.geometryData.uvs;
	}
	get positions() {
		return this.geometryData.vertices;
	}
	get indices() {
		return this.geometryData.indices;
	}
	get blendMode() {
		return this.renderable && this.applyTransform ? this.renderable.groupBlendMode : "normal";
	}
	get color() {
		let e = this.baseColor, n = e >> 16 | e & 65280 | (e & 255) << 16, r = this.renderable;
		return r ? t(n, r.groupColor) + (this.alpha * r.groupAlpha * 255 << 24) : n + (this.alpha * 255 << 24);
	}
	get transform() {
		return this.renderable?.groupTransform || En;
	}
	copyTo(e) {
		e.indexOffset = this.indexOffset, e.indexSize = this.indexSize, e.attributeOffset = this.attributeOffset, e.attributeSize = this.attributeSize, e.baseColor = this.baseColor, e.alpha = this.alpha, e.texture = this.texture, e.geometryData = this.geometryData, e.topology = this.topology;
	}
	reset() {
		this.applyTransform = !0, this.renderable = null, this.topology = "triangle-list";
	}
	destroy() {
		this.renderable = null, this.texture = null, this.geometryData = null, this._batcher = null, this._batch = null;
	}
}, On = {
	extension: {
		type: D.ShapeBuilder,
		name: "circle"
	},
	build(e, t) {
		let n, r, i, a, o, s;
		if (e.type === "circle") {
			let t = e;
			if (o = s = t.radius, o <= 0) return !1;
			n = t.x, r = t.y, i = a = 0;
		} else if (e.type === "ellipse") {
			let t = e;
			if (o = t.halfWidth, s = t.halfHeight, o <= 0 || s <= 0) return !1;
			n = t.x, r = t.y, i = a = 0;
		} else {
			let t = e, c = t.width / 2, l = t.height / 2;
			n = t.x + c, r = t.y + l, o = s = Math.max(0, Math.min(t.radius, Math.min(c, l))), i = c - o, a = l - s;
		}
		if (i < 0 || a < 0) return !1;
		let c = Math.ceil(2.3 * Math.sqrt(o + s)), l = c * 8 + (i ? 4 : 0) + (a ? 4 : 0);
		if (l === 0) return !1;
		if (c === 0) return t[0] = t[6] = n + i, t[1] = t[3] = r + a, t[2] = t[4] = n - i, t[5] = t[7] = r - a, !0;
		let u = 0, d = c * 4 + (i ? 2 : 0) + 2, f = d, p = l, m = i + o, h = a, g = n + m, _ = n - m, v = r + h;
		if (t[u++] = g, t[u++] = v, t[--d] = v, t[--d] = _, a) {
			let e = r - h;
			t[f++] = _, t[f++] = e, t[--p] = e, t[--p] = g;
		}
		for (let e = 1; e < c; e++) {
			let l = Math.PI / 2 * (e / c), m = i + Math.cos(l) * o, h = a + Math.sin(l) * s, g = n + m, _ = n - m, v = r + h, y = r - h;
			t[u++] = g, t[u++] = v, t[--d] = v, t[--d] = _, t[f++] = _, t[f++] = y, t[--p] = y, t[--p] = g;
		}
		m = i, h = a + s, g = n + m, _ = n - m, v = r + h;
		let y = r - h;
		return t[u++] = g, t[u++] = v, t[--p] = y, t[--p] = g, i && (t[u++] = _, t[u++] = v, t[--p] = y, t[--p] = _), !0;
	},
	triangulate(e, t, n, r, i, a) {
		if (e.length === 0) return;
		let o = 0, s = 0;
		for (let t = 0; t < e.length; t += 2) o += e[t], s += e[t + 1];
		o /= e.length / 2, s /= e.length / 2;
		let c = r;
		t[c * n] = o, t[c * n + 1] = s;
		let l = c++;
		for (let r = 0; r < e.length; r += 2) t[c * n] = e[r], t[c * n + 1] = e[r + 1], r > 0 && (i[a++] = c, i[a++] = l, i[a++] = c - 1), c++;
		i[a++] = l + 1, i[a++] = l, i[a++] = c - 1;
	}
}, kn = {
	...On,
	extension: {
		...On.extension,
		name: "ellipse"
	}
}, An = {
	...On,
	extension: {
		...On.extension,
		name: "roundedRectangle"
	}
}, jn = 1e-4, Mn = 1e-4;
//#endregion
//#region node_modules/pixi.js/lib/scene/graphics/shared/buildCommands/buildLine.mjs
function Nn(e, t, n, r, i, a, o, s) {
	let c = e - n * i, l = t - r * i, u = e + n * a, d = t + r * a, f, p;
	o ? (f = r, p = -n) : (f = -r, p = n);
	let m = c + f, h = l + p, g = u + f, _ = d + p;
	return s.push(m, h), s.push(g, _), 2;
}
function Pn(e, t, n, r, i, a, o, s) {
	let c = n - e, l = r - t, u = Math.atan2(c, l), d = Math.atan2(i - e, a - t);
	s && u < d ? u += Math.PI * 2 : !s && u > d && (d += Math.PI * 2);
	let f = u, p = d - u, m = Math.abs(p), h = Math.sqrt(c * c + l * l), g = (15 * m * Math.sqrt(h) / Math.PI >> 0) + 1, _ = p / g;
	if (f += _, s) {
		o.push(e, t), o.push(n, r);
		for (let n = 1, r = f; n < g; n++, r += _) o.push(e, t), o.push(e + Math.sin(r) * h, t + Math.cos(r) * h);
		o.push(e, t), o.push(i, a);
	} else {
		o.push(n, r), o.push(e, t);
		for (let n = 1, r = f; n < g; n++, r += _) o.push(e + Math.sin(r) * h, t + Math.cos(r) * h), o.push(e, t);
		o.push(i, a), o.push(e, t);
	}
	return g * 2;
}
function Fn(e, t, n, r, i, a) {
	let o = jn;
	if (e.length === 0) return;
	let s = t, c = s.alignment;
	if (t.alignment !== .5) {
		let t = gn(e);
		n && (t *= -1), c = (c - .5) * t + .5;
	}
	let l = new I(e[0], e[1]), u = new I(e[e.length - 2], e[e.length - 1]), d = r, f = Math.abs(l.x - u.x) < o && Math.abs(l.y - u.y) < o;
	if (d) {
		e = e.slice(), f && (e.pop(), e.pop(), u.set(e[e.length - 2], e[e.length - 1]));
		let t = (l.x + u.x) * .5, n = (u.y + l.y) * .5;
		e.unshift(t, n), e.push(t, n);
	}
	let p = i, m = e.length / 2, h = e.length, g = p.length / 2, _ = s.width / 2, v = _ * _, y = s.miterLimit * s.miterLimit, b = e[0], x = e[1], S = e[2], C = e[3], w = 0, T = 0, E = -(x - C), D = b - S, O = 0, k = 0, A = Math.sqrt(E * E + D * D);
	E /= A, D /= A, E *= _, D *= _;
	let j = c, M = (1 - j) * 2, N = j * 2;
	d || (s.cap === "round" ? h += Pn(b - E * (M - N) * .5, x - D * (M - N) * .5, b - E * M, x - D * M, b + E * N, x + D * N, p, !0) + 2 : s.cap === "square" && (h += Nn(b, x, E, D, M, N, !0, p))), p.push(b - E * M, x - D * M), p.push(b + E * N, x + D * N);
	for (let t = 1; t < m - 1; ++t) {
		b = e[(t - 1) * 2], x = e[(t - 1) * 2 + 1], S = e[t * 2], C = e[t * 2 + 1], w = e[(t + 1) * 2], T = e[(t + 1) * 2 + 1], E = -(x - C), D = b - S, A = Math.sqrt(E * E + D * D), E /= A, D /= A, E *= _, D *= _, O = -(C - T), k = S - w, A = Math.sqrt(O * O + k * k), O /= A, k /= A, O *= _, k *= _;
		let n = S - b, r = x - C, i = S - w, a = T - C, o = n * i + r * a, c = r * i - a * n, l = c < 0;
		if (Math.abs(c) < .001 * Math.abs(o)) {
			p.push(S - E * M, C - D * M), p.push(S + E * N, C + D * N), o >= 0 && (s.join === "round" ? h += Pn(S, C, S - E * M, C - D * M, S - O * M, C - k * M, p, !1) + 4 : h += 2, p.push(S - O * N, C - k * N), p.push(S + O * M, C + k * M));
			continue;
		}
		let u = (-E + b) * (-D + C) - (-E + S) * (-D + x), d = (-O + w) * (-k + C) - (-O + S) * (-k + T), f = (n * d - i * u) / c, m = (a * u - r * d) / c, g = (f - S) * (f - S) + (m - C) * (m - C), j = S + (f - S) * M, ee = C + (m - C) * M, P = S - (f - S) * N, F = C - (m - C) * N, te = Math.min(n * n + r * r, i * i + a * a), ne = l ? M : N;
		g <= te + ne * ne * v ? s.join === "bevel" || g / v > y ? (l ? (p.push(j, ee), p.push(S + E * N, C + D * N), p.push(j, ee), p.push(S + O * N, C + k * N)) : (p.push(S - E * M, C - D * M), p.push(P, F), p.push(S - O * M, C - k * M), p.push(P, F)), h += 2) : s.join === "round" ? l ? (p.push(j, ee), p.push(S + E * N, C + D * N), h += Pn(S, C, S + E * N, C + D * N, S + O * N, C + k * N, p, !0) + 4, p.push(j, ee), p.push(S + O * N, C + k * N)) : (p.push(S - E * M, C - D * M), p.push(P, F), h += Pn(S, C, S - E * M, C - D * M, S - O * M, C - k * M, p, !1) + 4, p.push(S - O * M, C - k * M), p.push(P, F)) : (p.push(j, ee), p.push(P, F)) : (p.push(S - E * M, C - D * M), p.push(S + E * N, C + D * N), s.join === "round" ? h += l ? Pn(S, C, S + E * N, C + D * N, S + O * N, C + k * N, p, !0) + 2 : Pn(S, C, S - E * M, C - D * M, S - O * M, C - k * M, p, !1) + 2 : s.join === "miter" && g / v <= y && (l ? (p.push(P, F), p.push(P, F)) : (p.push(j, ee), p.push(j, ee)), h += 2), p.push(S - O * M, C - k * M), p.push(S + O * N, C + k * N), h += 2);
	}
	b = e[(m - 2) * 2], x = e[(m - 2) * 2 + 1], S = e[(m - 1) * 2], C = e[(m - 1) * 2 + 1], E = -(x - C), D = b - S, A = Math.sqrt(E * E + D * D), E /= A, D /= A, E *= _, D *= _, p.push(S - E * M, C - D * M), p.push(S + E * N, C + D * N), d || (s.cap === "round" ? h += Pn(S - E * (M - N) * .5, C - D * (M - N) * .5, S - E * M, C - D * M, S + E * N, C + D * N, p, !1) + 2 : s.cap === "square" && (h += Nn(S, C, E, D, M, N, !1, p)));
	let ee = Mn * Mn;
	for (let e = g; e < h + g - 2; ++e) b = p[e * 2], x = p[e * 2 + 1], S = p[(e + 1) * 2], C = p[(e + 1) * 2 + 1], w = p[(e + 2) * 2], T = p[(e + 2) * 2 + 1], !(Math.abs(b * (C - T) + S * (T - x) + w * (x - C)) < ee) && a.push(e, e + 1, e + 2);
}
//#endregion
//#region node_modules/pixi.js/lib/scene/graphics/shared/buildCommands/buildPixelLine.mjs
function In(e, t, n, r) {
	let i = jn;
	if (e.length === 0) return;
	let a = e[0], o = e[1], s = e[e.length - 2], c = e[e.length - 1], l = t || Math.abs(a - s) < i && Math.abs(o - c) < i, u = n, d = e.length / 2, f = u.length / 2;
	for (let t = 0; t < d; t++) u.push(e[t * 2]), u.push(e[t * 2 + 1]);
	for (let e = 0; e < d - 1; e++) r.push(f + e, f + e + 1);
	l && r.push(f + d - 1, f);
}
//#endregion
//#region node_modules/pixi.js/lib/scene/graphics/shared/utils/triangulateWithHoles.mjs
function Ln(e, t, n, r, i, a, o) {
	let s = Xt(e, t, 2);
	if (!s) return;
	for (let e = 0; e < s.length; e += 3) a[o++] = s[e] + i, a[o++] = s[e + 1] + i, a[o++] = s[e + 2] + i;
	let c = i * r;
	for (let t = 0; t < e.length; t += 2) n[c] = e[t], n[c + 1] = e[t + 1], c += r;
}
//#endregion
//#region node_modules/pixi.js/lib/scene/graphics/shared/buildCommands/buildPolygon.mjs
var Rn = [], zn = {
	extension: {
		type: D.ShapeBuilder,
		name: "polygon"
	},
	build(e, t) {
		for (let n = 0; n < e.points.length; n++) t[n] = e.points[n];
		return !0;
	},
	triangulate(e, t, n, r, i, a) {
		Ln(e, Rn, t, n, r, i, a);
	}
}, Bn = {
	extension: {
		type: D.ShapeBuilder,
		name: "rectangle"
	},
	build(e, t) {
		let n = e, r = n.x, i = n.y, a = n.width, o = n.height;
		return a > 0 && o > 0 && (t[0] = r, t[1] = i, t[2] = r + a, t[3] = i, t[4] = r + a, t[5] = i + o, t[6] = r, t[7] = i + o, !0);
	},
	triangulate(e, t, n, r, i, a) {
		let o = 0;
		r *= n, t[r + o] = e[0], t[r + o + 1] = e[1], o += n, t[r + o] = e[2], t[r + o + 1] = e[3], o += n, t[r + o] = e[6], t[r + o + 1] = e[7], o += n, t[r + o] = e[4], t[r + o + 1] = e[5], o += n;
		let s = r / n;
		i[a++] = s, i[a++] = s + 1, i[a++] = s + 2, i[a++] = s + 1, i[a++] = s + 3, i[a++] = s + 2;
	}
}, Vn = {
	extension: {
		type: D.ShapeBuilder,
		name: "triangle"
	},
	build(e, t) {
		return t[0] = e.x, t[1] = e.y, t[2] = e.x2, t[3] = e.y2, t[4] = e.x3, t[5] = e.y3, !0;
	},
	triangulate(e, t, n, r, i, a) {
		let o = 0;
		r *= n, t[r + o] = e[0], t[r + o + 1] = e[1], o += n, t[r + o] = e[2], t[r + o + 1] = e[3], o += n, t[r + o] = e[4], t[r + o + 1] = e[5];
		let s = r / n;
		i[a++] = s, i[a++] = s + 1, i[a++] = s + 2;
	}
}, Hn = [{
	offset: 0,
	color: "white"
}, {
	offset: 1,
	color: "black"
}], Un = class e {
	constructor(...t) {
		this.uid = _("fillGradient"), this._tick = 0, this.type = "linear", this.colorStops = [];
		let n = qn(t);
		n = {
			...n.type === "radial" ? e.defaultRadialOptions : e.defaultLinearOptions,
			...s(n)
		}, this._textureSize = n.textureSize, this._wrapMode = n.wrapMode, n.type === "radial" ? (this.center = n.center, this.outerCenter = n.outerCenter ?? this.center, this.innerRadius = n.innerRadius, this.outerRadius = n.outerRadius, this.scale = n.scale, this.rotation = n.rotation) : (this.start = n.start, this.end = n.end), this.textureSpace = n.textureSpace, this.type = n.type, n.colorStops.forEach((e) => {
			this.addColorStop(e.offset, e.color);
		});
	}
	addColorStop(e, t) {
		return this.colorStops.push({
			offset: e,
			color: R.shared.setValue(t).toHexa()
		}), this;
	}
	buildLinearGradient() {
		if (this.texture) return;
		let { x: e, y: t } = this.start, { x: n, y: r } = this.end, i = n - e, a = r - t, o = i < 0 || a < 0;
		if (this._wrapMode === "clamp-to-edge") {
			if (i < 0) {
				let t = e;
				e = n, n = t, i *= -1;
			}
			if (a < 0) {
				let e = t;
				t = r, r = e, a *= -1;
			}
		}
		let s = this.colorStops.length ? this.colorStops : Hn, c = this._textureSize, { canvas: l, context: u } = Kn(c, 1), d = o ? u.createLinearGradient(this._textureSize, 0, 0, 0) : u.createLinearGradient(0, 0, this._textureSize, 0);
		Gn(d, s), u.fillStyle = d, u.fillRect(0, 0, c, 1), this.texture = new p({ source: new ce({
			resource: l,
			addressMode: this._wrapMode
		}) });
		let f = Math.sqrt(i * i + a * a), m = Math.atan2(a, i), h = new w();
		h.scale(f / c, 1), h.rotate(m), h.translate(e, t), this.textureSpace === "local" && h.scale(c, c), this.transform = h;
	}
	buildGradient() {
		this.texture || this._tick++, this.type === "linear" ? this.buildLinearGradient() : this.buildRadialGradient();
	}
	buildRadialGradient() {
		if (this.texture) return;
		let e = this.colorStops.length ? this.colorStops : Hn, t = this._textureSize, { canvas: n, context: r } = Kn(t, t), { x: i, y: a } = this.center, { x: o, y: s } = this.outerCenter, c = this.innerRadius, l = this.outerRadius, u = o - l, d = s - l, f = t / (l * 2), m = (i - u) * f, h = (a - d) * f, g = r.createRadialGradient(m, h, c * f, (o - u) * f, (s - d) * f, l * f);
		Gn(g, e), r.fillStyle = e[e.length - 1].color, r.fillRect(0, 0, t, t), r.fillStyle = g, r.translate(m, h), r.rotate(this.rotation), r.scale(1, this.scale), r.translate(-m, -h), r.fillRect(0, 0, t, t), this.texture = new p({ source: new ce({
			resource: n,
			addressMode: this._wrapMode
		}) });
		let _ = new w();
		this.textureSpace === "local" ? _.scale(2 * l, 2 * l) : _.scale(1 / f, 1 / f), _.translate(u, d), this.transform = _;
	}
	destroy() {
		this.texture?.destroy(!0), this.texture = null, this.transform = null, this.colorStops = [], this.start = null, this.end = null, this.center = null, this.outerCenter = null;
	}
	get styleKey() {
		return `fill-gradient-${this.uid}-${this._tick}`;
	}
};
Un.defaultLinearOptions = {
	start: {
		x: 0,
		y: 0
	},
	end: {
		x: 0,
		y: 1
	},
	colorStops: [],
	textureSpace: "local",
	type: "linear",
	textureSize: 256,
	wrapMode: "clamp-to-edge"
}, Un.defaultRadialOptions = {
	center: {
		x: .5,
		y: .5
	},
	innerRadius: 0,
	outerRadius: .5,
	colorStops: [],
	scale: 1,
	rotation: 0,
	textureSpace: "local",
	type: "radial",
	textureSize: 256,
	wrapMode: "clamp-to-edge"
};
var Wn = Un;
function Gn(e, t) {
	for (let n = 0; n < t.length; n++) {
		let r = t[n];
		e.addColorStop(r.offset, r.color);
	}
}
function Kn(e, t) {
	let n = x.get().createCanvas(e, t);
	return {
		canvas: n,
		context: n.getContext("2d")
	};
}
function qn(e) {
	let t = e[0] ?? {};
	return (typeof t == "number" || e[1]) && (o("8.5.2", "use options object instead"), t = {
		type: "linear",
		start: {
			x: e[0],
			y: e[1]
		},
		end: {
			x: e[2],
			y: e[3]
		},
		textureSpace: e[4],
		textureSize: e[5] ?? Wn.defaultLinearOptions.textureSize
	}), t;
}
//#endregion
//#region node_modules/pixi.js/lib/scene/graphics/shared/utils/generateTextureFillMatrix.mjs
var Jn = new w(), Yn = new l(), Xn = new w();
function Zn(e, t, n, r) {
	let i = t.matrix ? e.copyFrom(t.matrix).invert() : e.identity();
	if (t.textureSpace === "local") {
		let e = n.getBounds(Yn);
		t.width && e.pad(t.width);
		let { x: r, y: a } = e, o = 1 / e.width, s = 1 / e.height, c = -r * o, l = -a * s, u = i.a, d = i.b, f = i.c, p = i.d;
		i.a *= o, i.b *= o, i.c *= s, i.d *= s, i.tx = c * u + l * f + i.tx, i.ty = c * d + l * p + i.ty;
	} else if (t.texture.rotate) {
		let { uvs: e, orig: n } = t.texture;
		i.scale(1 / n.width, 1 / n.height), i.prepend(Xn.set(e.x1 - e.x0, e.y1 - e.y0, e.x3 - e.x0, e.y3 - e.y0, e.x0, e.y0));
	} else i.translate(t.texture.frame.x, t.texture.frame.y), i.scale(1 / t.texture.source.width, 1 / t.texture.source.height);
	let a = t.texture.source.style;
	return !(t.fill instanceof Wn) && a.addressMode === "clamp-to-edge" && (a.addressMode = "repeat", a.update()), r && i.append(Jn.copyFrom(r).invert()), i;
}
//#endregion
//#region node_modules/pixi.js/lib/scene/graphics/shared/utils/buildContextBatches.mjs
var Qn = {};
b.handleByMap(D.ShapeBuilder, Qn), b.add(Bn, zn, Vn, On, kn, An);
var $n = new l(), er = new w();
function tr(e, t) {
	let { geometryData: n, batches: r } = t;
	r.length = 0, n.indices.length = 0, n.vertices.length = 0, n.uvs.length = 0;
	for (let t = 0; t < e.instructions.length; t++) {
		let i = e.instructions[t];
		if (i.action === "texture") nr(i.data, r, n);
		else if (i.action === "fill" || i.action === "stroke") {
			let e = i.action === "stroke", t = i.data.path.shapePath, a = i.data.style, o = i.data.hole;
			e && o && rr(o.shapePath, a, !0, r, n), o && (t.shapePrimitives[t.shapePrimitives.length - 1].holes = o.shapePath.shapePrimitives), rr(t, a, e, r, n);
		}
	}
}
function nr(e, t, n) {
	let r = [], i = Qn.rectangle, o = $n;
	o.x = e.dx, o.y = e.dy, o.width = e.dw, o.height = e.dh;
	let s = e.transform;
	if (!i.build(o, r)) return;
	let { vertices: c, uvs: l, indices: u } = n, d = u.length, f = c.length / 2;
	s && Tn(r, s), i.triangulate(r, c, 2, f, u, d);
	let p = e.image, m = p.uvs;
	l.push(m.x0, m.y0, m.x1, m.y1, m.x3, m.y3, m.x2, m.y2);
	let h = a.get(Dn);
	h.indexOffset = d, h.indexSize = u.length - d, h.attributeOffset = f, h.attributeSize = c.length / 2 - f, h.baseColor = e.style, h.alpha = e.alpha, h.texture = p, h.geometryData = n, t.push(h);
}
function rr(e, t, n, r, i) {
	let { vertices: o, uvs: s, indices: c } = i;
	e.shapePrimitives.forEach(({ shape: e, transform: l, holes: u }) => {
		let d = [], f = Qn[e.type];
		if (!f.build(e, d)) return;
		let m = c.length, h = o.length / 2, g = "triangle-list";
		if (l && Tn(d, l), n) {
			let n = e.closePath ?? !0, r = t;
			r.pixelLine ? (In(d, n, o, c), g = "line-list") : Fn(d, r, !1, n, o, c);
		} else if (u) {
			let e = [], t = d.slice();
			ir(u).forEach((n) => {
				e.push(t.length / 2), t.push(...n);
			}), Ln(t, e, o, 2, h, c, m);
		} else f.triangulate(d, o, 2, h, c, m);
		let _ = s.length / 2, v = t.texture;
		if (v !== p.WHITE) {
			let n = Zn(er, t, e, l);
			Cn(o, 2, h, s, _, 2, o.length / 2 - h, n);
		} else wn(s, _, 2, o.length / 2 - h);
		let y = a.get(Dn);
		y.indexOffset = m, y.indexSize = c.length - m, y.attributeOffset = h, y.attributeSize = o.length / 2 - h, y.baseColor = t.color, y.alpha = t.alpha, y.texture = v, y.geometryData = i, y.topology = g, r.push(y);
	});
}
function ir(e) {
	let t = [];
	for (let n = 0; n < e.length; n++) {
		let r = e[n].shape, i = [];
		Qn[r.type].build(r, i) && t.push(i);
	}
	return t;
}
//#endregion
//#region node_modules/pixi.js/lib/scene/graphics/shared/GraphicsContextSystem.mjs
var ar = class {
	constructor() {
		this.batches = [], this.geometryData = {
			vertices: [],
			uvs: [],
			indices: []
		};
	}
	reset() {
		this.batches && this.batches.forEach((e) => {
			a.return(e);
		}), this.graphicsData && a.return(this.graphicsData), this.isBatchable = !1, this.context = null, this.batches.length = 0, this.geometryData.indices.length = 0, this.geometryData.vertices.length = 0, this.geometryData.uvs.length = 0, this.graphicsData = null;
	}
	destroy() {
		this.reset(), this.batches = null, this.geometryData = null;
	}
}, or = class {
	constructor() {
		this.instructions = new i();
	}
	init(e) {
		let t = e.maxTextures;
		this.batcher ? this.batcher._updateMaxTextures(t) : this.batcher = new xe({ maxTextures: t }), this.instructions.reset();
	}
	get geometry() {
		return o(h, "GraphicsContextRenderData#geometry is deprecated, please use batcher.geometry instead."), this.batcher.geometry;
	}
	destroy() {
		this.batcher.destroy(), this.instructions.destroy(), this.batcher = null, this.instructions = null;
	}
}, sr = class e {
	constructor(e) {
		this._renderer = e, this._managedContexts = new be({
			renderer: e,
			type: "resource",
			name: "graphicsContext"
		});
	}
	init(t) {
		e.defaultOptions.bezierSmoothness = t?.bezierSmoothness ?? e.defaultOptions.bezierSmoothness;
	}
	getContextRenderData(e) {
		return e._gpuData[this._renderer.uid].graphicsData || this._initContextRenderData(e);
	}
	updateGpuContext(e) {
		let t = !!e._gpuData[this._renderer.uid], n = e._gpuData[this._renderer.uid] || this._initContext(e);
		if (e.dirty || !t) {
			t && n.reset(), tr(e, n);
			let r = e.batchMode;
			n.isBatchable = e.customShader || r === "no-batch" ? !1 : r !== "auto" || n.geometryData.vertices.length < 400, e.dirty = !1;
		}
		return n;
	}
	getGpuContext(e) {
		return e._gpuData[this._renderer.uid] || this._initContext(e);
	}
	_initContextRenderData(e) {
		let t = a.get(or, { maxTextures: this._renderer.limits.maxBatchableTextures }), n = e._gpuData[this._renderer.uid], { batches: r, geometryData: i } = n;
		n.graphicsData = t;
		let o = i.vertices.length, s = i.indices.length;
		for (let e = 0; e < r.length; e++) r[e].applyTransform = !1;
		let c = t.batcher;
		c.ensureAttributeBuffer(o), c.ensureIndexBuffer(s), c.begin();
		for (let e = 0; e < r.length; e++) {
			let t = r[e];
			c.add(t);
		}
		c.finish(t.instructions);
		let l = c.geometry;
		l.indexBuffer.setDataWithSize(c.indexBuffer, c.indexSize, !0), l.buffers[0].setDataWithSize(c.attributeBuffer.float32View, c.attributeSize, !0);
		let u = c.batches;
		for (let e = 0; e < u.length; e++) {
			let t = u[e];
			t.bindGroup = Re(t.textures.textures, t.textures.count, this._renderer.limits.maxBatchableTextures);
		}
		return t;
	}
	_initContext(e) {
		let t = new ar();
		return t.context = e, e._gpuData[this._renderer.uid] = t, this._managedContexts.add(e), t;
	}
	destroy() {
		this._managedContexts.destroy(), this._renderer = null;
	}
};
sr.extension = {
	type: [D.WebGLSystem, D.WebGPUSystem],
	name: "graphicsContext"
}, sr.defaultOptions = { bezierSmoothness: .5 };
var cr = sr, lr = 8, ur = 1.1920929e-7, dr = 1;
function fr(e, t, n, r, i, a, o, s, c, l) {
	let u = (dr - Math.min(.99, Math.max(0, l ?? cr.defaultOptions.bezierSmoothness))) / 1;
	return u *= u, pr(t, n, r, i, a, o, s, c, e, u), e;
}
function pr(e, t, n, r, i, a, o, s, c, l) {
	mr(e, t, n, r, i, a, o, s, c, l, 0), c.push(o, s);
}
function mr(e, t, n, r, i, a, o, s, c, l, u) {
	if (u > lr) return;
	let d = (e + n) / 2, f = (t + r) / 2, p = (n + i) / 2, m = (r + a) / 2, h = (i + o) / 2, g = (a + s) / 2, _ = (d + p) / 2, v = (f + m) / 2, y = (p + h) / 2, b = (m + g) / 2, x = (_ + y) / 2, S = (v + b) / 2;
	if (u > 0) {
		let u = o - e, d = s - t, f = Math.abs((n - o) * d - (r - s) * u), p = Math.abs((i - o) * d - (a - s) * u);
		if (f > ur && p > ur) {
			if ((f + p) * (f + p) <= l * (u * u + d * d)) {
				c.push(x, S);
				return;
			}
		} else if (f > ur) {
			if (f * f <= l * (u * u + d * d)) {
				c.push(x, S);
				return;
			}
		} else if (p > ur) {
			if (p * p <= l * (u * u + d * d)) {
				c.push(x, S);
				return;
			}
		} else if (u = x - (e + o) / 2, d = S - (t + s) / 2, u * u + d * d <= l) {
			c.push(x, S);
			return;
		}
	}
	mr(e, t, d, f, _, v, x, S, c, l, u + 1), mr(x, S, y, b, h, g, o, s, c, l, u + 1);
}
//#endregion
//#region node_modules/pixi.js/lib/scene/graphics/shared/buildCommands/buildAdaptiveQuadratic.mjs
var hr = 8, gr = 1.1920929e-7, _r = 1;
function vr(e, t, n, r, i, a, o, s) {
	let c = (_r - Math.min(.99, Math.max(0, s ?? cr.defaultOptions.bezierSmoothness))) / 1;
	return c *= c, yr(t, n, r, i, a, o, e, c), e;
}
function yr(e, t, n, r, i, a, o, s) {
	br(o, e, t, n, r, i, a, s, 0), o.push(i, a);
}
function br(e, t, n, r, i, a, o, s, c) {
	if (c > hr) return;
	let l = (t + r) / 2, u = (n + i) / 2, d = (r + a) / 2, f = (i + o) / 2, p = (l + d) / 2, m = (u + f) / 2, h = a - t, g = o - n, _ = Math.abs((r - a) * g - (i - o) * h);
	if (_ > gr) {
		if (_ * _ <= s * (h * h + g * g)) {
			e.push(p, m);
			return;
		}
	} else if (h = p - (t + a) / 2, g = m - (n + o) / 2, h * h + g * g <= s) {
		e.push(p, m);
		return;
	}
	br(e, t, n, l, u, p, m, s, c + 1), br(e, p, m, d, f, a, o, s, c + 1);
}
//#endregion
//#region node_modules/pixi.js/lib/scene/graphics/shared/buildCommands/buildArc.mjs
function xr(e, t, n, r, i, a, o, s) {
	let c = Math.abs(i - a);
	(!o && i > a || o && a > i) && (c = 2 * Math.PI - c), s ||= Math.max(6, Math.floor(6 * r ** (1 / 3) * (c / Math.PI))), s = Math.max(s, 3);
	let l = c / s, u = i;
	l *= o ? -1 : 1;
	for (let i = 0; i < s + 1; i++) {
		let i = Math.cos(u), a = Math.sin(u), o = t + i * r, s = n + a * r;
		e.push(o, s), u += l;
	}
}
//#endregion
//#region node_modules/pixi.js/lib/scene/graphics/shared/buildCommands/buildArcTo.mjs
function Sr(e, t, n, r, i, a) {
	let o = e[e.length - 2], s = e[e.length - 1] - n, c = o - t, l = i - n, u = r - t, d = Math.abs(s * u - c * l);
	if (d < 1e-8 || a === 0) {
		(e[e.length - 2] !== t || e[e.length - 1] !== n) && e.push(t, n);
		return;
	}
	let f = s * s + c * c, p = l * l + u * u, m = s * l + c * u, h = a * Math.sqrt(f) / d, g = a * Math.sqrt(p) / d, _ = h * m / f, v = g * m / p, y = h * u + g * c, b = h * l + g * s, x = c * (g + _), S = s * (g + _), C = u * (h + v), w = l * (h + v), T = Math.atan2(S - b, x - y), E = Math.atan2(w - b, C - y);
	xr(e, y + t, b + n, a, T, E, c * l > u * s);
}
//#endregion
//#region node_modules/pixi.js/lib/scene/graphics/shared/buildCommands/buildArcToSvg.mjs
var Cr = Math.PI * 2, wr = {
	centerX: 0,
	centerY: 0,
	ang1: 0,
	ang2: 0
}, Tr = ({ x: e, y: t }, n, r, i, a, o, s, c) => {
	e *= n, t *= r;
	let l = i * e - a * t, u = a * e + i * t;
	return c.x = l + o, c.y = u + s, c;
};
function Er(e, t) {
	let n = t === -1.5707963267948966 ? -.551915024494 : 4 / 3 * Math.tan(t / 4), r = t === 1.5707963267948966 ? .551915024494 : n, i = Math.cos(e), a = Math.sin(e), o = Math.cos(e + t), s = Math.sin(e + t);
	return [
		{
			x: i - a * r,
			y: a + i * r
		},
		{
			x: o + s * r,
			y: s - o * r
		},
		{
			x: o,
			y: s
		}
	];
}
var Dr = (e, t, n, r) => {
	let i = e * r - t * n < 0 ? -1 : 1, a = e * n + t * r;
	return a > 1 && (a = 1), a < -1 && (a = -1), i * Math.acos(a);
}, Or = (e, t, n, r, i, a, o, s, c, l, u, d, f) => {
	let p = i ** 2, m = a ** 2, h = u ** 2, g = d ** 2, _ = p * m - p * g - m * h;
	_ < 0 && (_ = 0), _ /= p * g + m * h, _ = Math.sqrt(_) * (o === s ? -1 : 1);
	let v = _ * i / a * d, y = _ * -a / i * u, b = l * v - c * y + (e + n) / 2, x = c * v + l * y + (t + r) / 2, S = (u - v) / i, C = (d - y) / a, w = (-u - v) / i, T = (-d - y) / a, E = Dr(1, 0, S, C), D = Dr(S, C, w, T);
	s === 0 && D > 0 && (D -= Cr), s === 1 && D < 0 && (D += Cr), f.centerX = b, f.centerY = x, f.ang1 = E, f.ang2 = D;
};
function kr(e, t, n, r, i, a, o, s = 0, c = 0, l = 0) {
	if (a === 0 || o === 0) return;
	let u = Math.sin(s * Cr / 360), d = Math.cos(s * Cr / 360), f = d * (t - r) / 2 + u * (n - i) / 2, p = -u * (t - r) / 2 + d * (n - i) / 2;
	if (f === 0 && p === 0) return;
	a = Math.abs(a), o = Math.abs(o);
	let m = f ** 2 / a ** 2 + p ** 2 / o ** 2;
	m > 1 && (a *= Math.sqrt(m), o *= Math.sqrt(m)), Or(t, n, r, i, a, o, c, l, u, d, f, p, wr);
	let { ang1: h, ang2: g } = wr, { centerX: _, centerY: v } = wr, y = Math.abs(g) / (Cr / 4);
	Math.abs(1 - y) < 1e-7 && (y = 1);
	let b = Math.max(Math.ceil(y), 1);
	g /= b;
	let x = e[e.length - 2], S = e[e.length - 1], C = {
		x: 0,
		y: 0
	};
	for (let t = 0; t < b; t++) {
		let t = Er(h, g), { x: n, y: r } = Tr(t[0], a, o, d, u, _, v, C), { x: i, y: s } = Tr(t[1], a, o, d, u, _, v, C), { x: c, y: l } = Tr(t[2], a, o, d, u, _, v, C);
		fr(e, x, S, n, r, i, s, c, l), x = c, S = l, h += g;
	}
}
//#endregion
//#region node_modules/pixi.js/lib/scene/graphics/shared/path/roundShape.mjs
function Ar(e, t, n) {
	let r = (e, t) => {
		let n = t.x - e.x, r = t.y - e.y, i = Math.sqrt(n * n + r * r);
		return {
			len: i,
			nx: n / i,
			ny: r / i
		};
	}, i = (t, n) => {
		t === 0 ? e.moveTo(n.x, n.y) : e.lineTo(n.x, n.y);
	}, a = t[t.length - 1];
	for (let o = 0; o < t.length; o++) {
		let s = t[o % t.length], c = s.radius ?? n;
		if (c <= 0) {
			i(o, s), a = s;
			continue;
		}
		let l = t[(o + 1) % t.length], u = r(s, a), d = r(s, l);
		if (u.len < 1e-4 || d.len < 1e-4) {
			i(o, s), a = s;
			continue;
		}
		let f = Math.asin(u.nx * d.ny - u.ny * d.nx), p = 1, m = !1;
		u.nx * d.nx - u.ny * -d.ny < 0 ? f < 0 ? f = Math.PI + f : (f = Math.PI - f, p = -1, m = !0) : f > 0 && (p = -1, m = !0);
		let h = f / 2, g, _ = Math.abs(Math.cos(h) * c / Math.sin(h));
		_ > Math.min(u.len / 2, d.len / 2) ? (_ = Math.min(u.len / 2, d.len / 2), g = Math.abs(_ * Math.sin(h) / Math.cos(h))) : g = c;
		let v = s.x + d.nx * _ + -d.ny * g * p, y = s.y + d.ny * _ + d.nx * g * p, b = Math.atan2(u.ny, u.nx) + Math.PI / 2 * p, x = Math.atan2(d.ny, d.nx) - Math.PI / 2 * p;
		o === 0 && e.moveTo(v + Math.cos(b) * g, y + Math.sin(b) * g), e.arc(v, y, g, b, x, m), a = s;
	}
}
function jr(e, t, n, r) {
	let i = (e, t) => Math.sqrt((e.x - t.x) ** 2 + (e.y - t.y) ** 2), a = (e, t, n) => ({
		x: e.x + (t.x - e.x) * n,
		y: e.y + (t.y - e.y) * n
	}), o = t.length;
	for (let s = 0; s < o; s++) {
		let c = t[(s + 1) % o], l = c.radius ?? n;
		if (l <= 0) {
			s === 0 ? e.moveTo(c.x, c.y) : e.lineTo(c.x, c.y);
			continue;
		}
		let u = t[s], d = t[(s + 2) % o], f = i(u, c), p;
		p = f < 1e-4 ? c : a(c, u, Math.min(f / 2, l) / f);
		let m = i(d, c), h;
		h = m < 1e-4 ? c : a(c, d, Math.min(m / 2, l) / m), s === 0 ? e.moveTo(p.x, p.y) : e.lineTo(p.x, p.y), e.quadraticCurveTo(c.x, c.y, h.x, h.y, r);
	}
}
//#endregion
//#region node_modules/pixi.js/lib/scene/graphics/shared/path/ShapePath.mjs
var Mr = new l(), Nr = class {
	constructor(e) {
		this.shapePrimitives = [], this._currentPoly = null, this._bounds = new n(), this._graphicsPath2D = e, this.signed = e.checkForHoles;
	}
	moveTo(e, t) {
		return this.startPoly(e, t), this;
	}
	lineTo(e, t) {
		this._ensurePoly();
		let n = this._currentPoly.points, r = n[n.length - 2], i = n[n.length - 1];
		return (r !== e || i !== t) && n.push(e, t), this;
	}
	arc(e, t, n, r, i, a) {
		this._ensurePoly(!1);
		let o = this._currentPoly.points;
		return xr(o, e, t, n, r, i, a), this;
	}
	arcTo(e, t, n, r, i) {
		this._ensurePoly();
		let a = this._currentPoly.points;
		return Sr(a, e, t, n, r, i), this;
	}
	arcToSvg(e, t, n, r, i, a, o) {
		let s = this._currentPoly.points;
		return kr(s, this._currentPoly.lastX, this._currentPoly.lastY, a, o, e, t, n, r, i), this;
	}
	bezierCurveTo(e, t, n, r, i, a, o) {
		this._ensurePoly();
		let s = this._currentPoly;
		return fr(this._currentPoly.points, s.lastX, s.lastY, e, t, n, r, i, a, o), this;
	}
	quadraticCurveTo(e, t, n, r, i) {
		this._ensurePoly();
		let a = this._currentPoly;
		return vr(this._currentPoly.points, a.lastX, a.lastY, e, t, n, r, i), this;
	}
	closePath() {
		return this.endPoly(!0), this;
	}
	addPath(e, t) {
		this.endPoly(), t && !t.isIdentity() && (e = e.clone(!0), e.transform(t));
		let n = this.shapePrimitives, r = n.length;
		for (let t = 0; t < e.instructions.length; t++) {
			let n = e.instructions[t];
			this[n.action](...n.data);
		}
		if (e.checkForHoles && n.length - r > 1) {
			let e = null;
			for (let t = r; t < n.length; t++) {
				let r = n[t];
				if (r.shape.type === "polygon") {
					let i = r.shape, a = e?.shape;
					a && a.containsPolygon(i) ? (e.holes || (e.holes = []), e.holes.push(r), n.copyWithin(t, t + 1), n.length--, t--) : e = r;
				}
			}
		}
		return this;
	}
	finish(e = !1) {
		this.endPoly(e);
	}
	rect(e, t, n, r, i) {
		return this.drawShape(new l(e, t, n, r), i), this;
	}
	circle(e, t, n, r) {
		return this.drawShape(new mn(e, t, n), r), this;
	}
	poly(e, t, n) {
		let r = new bn(e);
		return r.closePath = t, this.drawShape(r, n), this;
	}
	regularPoly(e, t, n, r, i = 0, a) {
		r = Math.max(r | 0, 3);
		let o = -1 * Math.PI / 2 + i, s = Math.PI * 2 / r, c = [];
		for (let i = 0; i < r; i++) {
			let r = o - i * s;
			c.push(e + n * Math.cos(r), t + n * Math.sin(r));
		}
		return this.poly(c, !0, a), this;
	}
	roundPoly(e, t, n, r, i, a = 0, o) {
		if (r = Math.max(r | 0, 3), i <= 0) return this.regularPoly(e, t, n, r, a);
		let s = n * Math.sin(Math.PI / r) - .001;
		i = Math.min(i, s);
		let c = -1 * Math.PI / 2 + a, l = Math.PI * 2 / r, u = (r - 2) * Math.PI / r / 2;
		for (let a = 0; a < r; a++) {
			let r = a * l + c, s = e + n * Math.cos(r), d = t + n * Math.sin(r), f = r + Math.PI + u, p = r - Math.PI - u, m = s + i * Math.cos(f), h = d + i * Math.sin(f), g = s + i * Math.cos(p), _ = d + i * Math.sin(p);
			a === 0 ? this.moveTo(m, h) : this.lineTo(m, h), this.quadraticCurveTo(s, d, g, _, o);
		}
		return this.closePath();
	}
	roundShape(e, t, n = !1, r) {
		return e.length < 3 ? this : (n ? jr(this, e, t, r) : Ar(this, e, t), this.closePath());
	}
	filletRect(e, t, n, r, i) {
		if (i === 0) return this.rect(e, t, n, r);
		let a = Math.min(n, r) / 2, o = Math.min(a, Math.max(-a, i)), s = e + n, c = t + r, l = o < 0 ? -o : 0, u = Math.abs(o);
		return this.moveTo(e, t + u).arcTo(e + l, t + l, e + u, t, u).lineTo(s - u, t).arcTo(s - l, t + l, s, t + u, u).lineTo(s, c - u).arcTo(s - l, c - l, e + n - u, c, u).lineTo(e + u, c).arcTo(e + l, c - l, e, c - u, u).closePath();
	}
	chamferRect(e, t, n, r, i, a) {
		if (i <= 0) return this.rect(e, t, n, r);
		let o = Math.min(i, Math.min(n, r) / 2), s = e + n, c = t + r, l = [
			e + o,
			t,
			s - o,
			t,
			s,
			t + o,
			s,
			c - o,
			s - o,
			c,
			e + o,
			c,
			e,
			c - o,
			e,
			t + o
		];
		for (let e = l.length - 1; e >= 2; e -= 2) l[e] === l[e - 2] && l[e - 1] === l[e - 3] && l.splice(e - 1, 2);
		return this.poly(l, !0, a);
	}
	ellipse(e, t, n, r, i) {
		return this.drawShape(new hn(e, t, n, r), i), this;
	}
	roundRect(e, t, n, r, i, a) {
		return this.drawShape(new Sn(e, t, n, r, i), a), this;
	}
	drawShape(e, t) {
		return this.endPoly(), this.shapePrimitives.push({
			shape: e,
			transform: t
		}), this;
	}
	startPoly(e, t) {
		let n = this._currentPoly;
		return n && this.endPoly(), n = new bn(), n.points.push(e, t), this._currentPoly = n, this;
	}
	endPoly(e = !1) {
		let t = this._currentPoly;
		return t && t.points.length > 2 && (t.closePath = e, this.shapePrimitives.push({ shape: t })), this._currentPoly = null, this;
	}
	_ensurePoly(e = !0) {
		if (!this._currentPoly && (this._currentPoly = new bn(), e)) {
			let e = this.shapePrimitives[this.shapePrimitives.length - 1];
			if (e) {
				let t = e.shape.x, n = e.shape.y;
				if (e.transform && !e.transform.isIdentity()) {
					let r = e.transform, i = t;
					t = r.a * t + r.c * n + r.tx, n = r.b * i + r.d * n + r.ty;
				}
				this._currentPoly.points.push(t, n);
			} else this._currentPoly.points.push(0, 0);
		}
	}
	buildPath() {
		let e = this._graphicsPath2D;
		this.shapePrimitives.length = 0, this._currentPoly = null;
		for (let t = 0; t < e.instructions.length; t++) {
			let n = e.instructions[t];
			this[n.action](...n.data);
		}
		this.finish();
	}
	get bounds() {
		let e = this._bounds;
		e.clear();
		let t = this.shapePrimitives;
		for (let n = 0; n < t.length; n++) {
			let r = t[n], i = r.shape.getBounds(Mr);
			r.transform ? e.addRect(i, r.transform) : e.addRect(i);
		}
		return e;
	}
}, Pr = class e {
	constructor(e, t = !1) {
		this.instructions = [], this.uid = _("graphicsPath"), this._dirty = !0, this.checkForHoles = t, typeof e == "string" ? pn(e, this) : this.instructions = e?.slice() ?? [];
	}
	get shapePath() {
		return this._shapePath ||= new Nr(this), this._dirty && (this._dirty = !1, this._shapePath.buildPath()), this._shapePath;
	}
	addPath(e, t) {
		return e = e.clone(), this.instructions.push({
			action: "addPath",
			data: [e, t]
		}), this._dirty = !0, this;
	}
	arc(...e) {
		return this.instructions.push({
			action: "arc",
			data: e
		}), this._dirty = !0, this;
	}
	arcTo(...e) {
		return this.instructions.push({
			action: "arcTo",
			data: e
		}), this._dirty = !0, this;
	}
	arcToSvg(...e) {
		return this.instructions.push({
			action: "arcToSvg",
			data: e
		}), this._dirty = !0, this;
	}
	bezierCurveTo(...e) {
		return this.instructions.push({
			action: "bezierCurveTo",
			data: e
		}), this._dirty = !0, this;
	}
	bezierCurveToShort(e, t, n, r, i) {
		let a = this.instructions[this.instructions.length - 1], o = this.getLastPoint(I.shared), s = 0, c = 0;
		if (!a || a.action !== "bezierCurveTo") s = o.x, c = o.y;
		else {
			s = a.data[2], c = a.data[3];
			let e = o.x, t = o.y;
			s = e + (e - s), c = t + (t - c);
		}
		return this.instructions.push({
			action: "bezierCurveTo",
			data: [
				s,
				c,
				e,
				t,
				n,
				r,
				i
			]
		}), this._dirty = !0, this;
	}
	closePath() {
		return this.instructions.push({
			action: "closePath",
			data: []
		}), this._dirty = !0, this;
	}
	ellipse(...e) {
		return this.instructions.push({
			action: "ellipse",
			data: e
		}), this._dirty = !0, this;
	}
	lineTo(...e) {
		return this.instructions.push({
			action: "lineTo",
			data: e
		}), this._dirty = !0, this;
	}
	moveTo(...e) {
		return this.instructions.push({
			action: "moveTo",
			data: e
		}), this;
	}
	quadraticCurveTo(...e) {
		return this.instructions.push({
			action: "quadraticCurveTo",
			data: e
		}), this._dirty = !0, this;
	}
	quadraticCurveToShort(e, t, n) {
		let r = this.instructions[this.instructions.length - 1], i = this.getLastPoint(I.shared), a = 0, o = 0;
		if (!r || r.action !== "quadraticCurveTo") a = i.x, o = i.y;
		else {
			a = r.data[0], o = r.data[1];
			let e = i.x, t = i.y;
			a = e + (e - a), o = t + (t - o);
		}
		return this.instructions.push({
			action: "quadraticCurveTo",
			data: [
				a,
				o,
				e,
				t,
				n
			]
		}), this._dirty = !0, this;
	}
	rect(e, t, n, r, i) {
		return this.instructions.push({
			action: "rect",
			data: [
				e,
				t,
				n,
				r,
				i
			]
		}), this._dirty = !0, this;
	}
	circle(e, t, n, r) {
		return this.instructions.push({
			action: "circle",
			data: [
				e,
				t,
				n,
				r
			]
		}), this._dirty = !0, this;
	}
	roundRect(...e) {
		return this.instructions.push({
			action: "roundRect",
			data: e
		}), this._dirty = !0, this;
	}
	poly(...e) {
		return this.instructions.push({
			action: "poly",
			data: e
		}), this._dirty = !0, this;
	}
	regularPoly(...e) {
		return this.instructions.push({
			action: "regularPoly",
			data: e
		}), this._dirty = !0, this;
	}
	roundPoly(...e) {
		return this.instructions.push({
			action: "roundPoly",
			data: e
		}), this._dirty = !0, this;
	}
	roundShape(...e) {
		return this.instructions.push({
			action: "roundShape",
			data: e
		}), this._dirty = !0, this;
	}
	filletRect(...e) {
		return this.instructions.push({
			action: "filletRect",
			data: e
		}), this._dirty = !0, this;
	}
	chamferRect(...e) {
		return this.instructions.push({
			action: "chamferRect",
			data: e
		}), this._dirty = !0, this;
	}
	star(e, t, n, r, i, a, o) {
		i ||= r / 2;
		let s = -1 * Math.PI / 2 + a, c = n * 2, l = Math.PI * 2 / c, u = [];
		for (let n = 0; n < c; n++) {
			let a = n % 2 ? i : r, o = n * l + s;
			u.push(e + a * Math.cos(o), t + a * Math.sin(o));
		}
		return this.poly(u, !0, o), this;
	}
	clone(t = !1) {
		let n = new e();
		if (n.checkForHoles = this.checkForHoles, !t) n.instructions = this.instructions.slice();
		else for (let e = 0; e < this.instructions.length; e++) {
			let t = this.instructions[e];
			n.instructions.push({
				action: t.action,
				data: t.data.slice()
			});
		}
		return n;
	}
	clear() {
		return this.instructions.length = 0, this._dirty = !0, this;
	}
	transform(e) {
		if (e.isIdentity()) return this;
		let t = e.a, n = e.b, r = e.c, i = e.d, a = e.tx, o = e.ty, s = 0, c = 0, l = 0, d = 0, f = 0, p = 0, m = 0, h = 0;
		for (let g = 0; g < this.instructions.length; g++) {
			let _ = this.instructions[g], v = _.data;
			switch (_.action) {
				case "moveTo":
				case "lineTo":
					s = v[0], c = v[1], v[0] = t * s + r * c + a, v[1] = n * s + i * c + o;
					break;
				case "bezierCurveTo":
					l = v[0], d = v[1], f = v[2], p = v[3], s = v[4], c = v[5], v[0] = t * l + r * d + a, v[1] = n * l + i * d + o, v[2] = t * f + r * p + a, v[3] = n * f + i * p + o, v[4] = t * s + r * c + a, v[5] = n * s + i * c + o;
					break;
				case "quadraticCurveTo":
					l = v[0], d = v[1], s = v[2], c = v[3], v[0] = t * l + r * d + a, v[1] = n * l + i * d + o, v[2] = t * s + r * c + a, v[3] = n * s + i * c + o;
					break;
				case "arcToSvg":
					s = v[5], c = v[6], m = v[0], h = v[1], v[0] = t * m + r * h, v[1] = n * m + i * h, v[5] = t * s + r * c + a, v[6] = n * s + i * c + o;
					break;
				case "circle":
					v[4] = Fr(v[3], e);
					break;
				case "rect":
					v[4] = Fr(v[4], e);
					break;
				case "ellipse":
					v[8] = Fr(v[8], e);
					break;
				case "roundRect":
					v[5] = Fr(v[5], e);
					break;
				case "addPath":
					v[0].transform(e);
					break;
				case "poly":
					v[2] = Fr(v[2], e);
					break;
				case "regularPoly":
				case "chamferRect":
					v[5] = Fr(v[5], e);
					break;
				case "closePath": break;
				default: u("unknown transform action", _.action);
			}
		}
		return this._dirty = !0, this;
	}
	get bounds() {
		return this.shapePath.bounds;
	}
	getLastPoint(e) {
		let t = this.instructions.length - 1, n = this.instructions[t];
		if (!n) return e.x = 0, e.y = 0, e;
		for (; n.action === "closePath";) {
			if (t--, t < 0) return e.x = 0, e.y = 0, e;
			n = this.instructions[t];
		}
		switch (n.action) {
			case "moveTo":
			case "lineTo":
				e.x = n.data[0], e.y = n.data[1];
				break;
			case "quadraticCurveTo":
				e.x = n.data[2], e.y = n.data[3];
				break;
			case "bezierCurveTo":
				e.x = n.data[4], e.y = n.data[5];
				break;
			case "arc":
			case "arcToSvg":
				e.x = n.data[5], e.y = n.data[6];
				break;
			case "addPath": n.data[0].getLastPoint(e);
		}
		return e;
	}
};
function Fr(e, t) {
	return e ? e.prepend(t) : t.clone();
}
//#endregion
//#region node_modules/pixi.js/lib/scene/graphics/shared/svg/parseSVGFloatAttribute.mjs
function B(e, t, n) {
	let r = e.getAttribute(t);
	return r ? Number(r) : n;
}
//#endregion
//#region node_modules/pixi.js/lib/scene/graphics/shared/svg/parseSVGDefinitions.mjs
function Ir(e, t) {
	let n = e.querySelectorAll("defs");
	for (let e = 0; e < n.length; e++) {
		let r = n[e];
		for (let e = 0; e < r.children.length; e++) {
			let n = r.children[e];
			switch (n.nodeName.toLowerCase()) {
				case "lineargradient":
					t.defs[n.id] = Lr(n);
					break;
				case "radialgradient": t.defs[n.id] = Rr(n);
			}
		}
	}
}
function Lr(e) {
	let t = new Wn(B(e, "x1", 0), B(e, "y1", 0), B(e, "x2", 1), B(e, "y2", 0), (e.getAttribute("gradientUnits") || "objectBoundingBox") === "objectBoundingBox" ? "local" : "global");
	for (let n = 0; n < e.children.length; n++) {
		let r = e.children[n], i = B(r, "offset", 0), a = R.shared.setValue(r.getAttribute("stop-color")).toNumber();
		t.addColorStop(i, a);
	}
	return t;
}
function Rr(e) {
	return u("[SVG Parser] Radial gradients are not yet supported"), new Wn(0, 0, 1, 0);
}
//#endregion
//#region node_modules/pixi.js/lib/scene/graphics/shared/svg/utils/extractSvgUrlId.mjs
function zr(e) {
	let t = e.match(/url\s*\(\s*['"]?\s*#([^'"\s)]+)\s*['"]?\s*\)/i);
	return t ? t[1] : "";
}
//#endregion
//#region node_modules/pixi.js/lib/scene/graphics/shared/svg/parseSVGStyle.mjs
var Br = {
	fill: {
		type: "paint",
		default: 0
	},
	"fill-opacity": {
		type: "number",
		default: 1
	},
	stroke: {
		type: "paint",
		default: 0
	},
	"stroke-width": {
		type: "number",
		default: 1
	},
	"stroke-opacity": {
		type: "number",
		default: 1
	},
	"stroke-linecap": {
		type: "string",
		default: "butt"
	},
	"stroke-linejoin": {
		type: "string",
		default: "miter"
	},
	"stroke-miterlimit": {
		type: "number",
		default: 10
	},
	"stroke-dasharray": {
		type: "string",
		default: "none"
	},
	"stroke-dashoffset": {
		type: "number",
		default: 0
	},
	opacity: {
		type: "number",
		default: 1
	}
};
function Vr(e, t) {
	let n = e.getAttribute("style"), r = {}, i = {}, a = {
		strokeStyle: r,
		fillStyle: i,
		useFill: !1,
		useStroke: !1
	};
	for (let n in Br) {
		let r = e.getAttribute(n);
		r && Hr(t, a, n, r.trim());
	}
	if (n) {
		let e = n.split(";");
		for (let n = 0; n < e.length; n++) {
			let [r, i] = e[n].trim().split(":");
			Br[r] && Hr(t, a, r, i.trim());
		}
	}
	return {
		strokeStyle: a.useStroke ? r : null,
		fillStyle: a.useFill ? i : null,
		useFill: a.useFill,
		useStroke: a.useStroke
	};
}
function Hr(e, t, n, r) {
	switch (n) {
		case "stroke":
			if (r !== "none") {
				if (r.startsWith("url(")) {
					let n = zr(r);
					t.strokeStyle.fill = e.defs[n];
				} else t.strokeStyle.color = R.shared.setValue(r).toNumber();
				t.useStroke = !0;
			}
			break;
		case "stroke-width":
			t.strokeStyle.width = Number(r);
			break;
		case "fill":
			if (r !== "none") {
				if (r.startsWith("url(")) {
					let n = zr(r);
					t.fillStyle.fill = e.defs[n];
				} else t.fillStyle.color = R.shared.setValue(r).toNumber();
				t.useFill = !0;
			}
			break;
		case "fill-opacity":
			t.fillStyle.alpha = Number(r);
			break;
		case "stroke-opacity":
			t.strokeStyle.alpha = Number(r);
			break;
		case "opacity": t.fillStyle.alpha = Number(r), t.strokeStyle.alpha = Number(r);
	}
}
//#endregion
//#region node_modules/pixi.js/lib/scene/graphics/shared/svg/utils/fillOperations.mjs
function Ur(e) {
	if (e.length <= 2) return !0;
	let t = e.map((e) => e.area).sort((e, t) => t - e), [n, r] = t, i = t[t.length - 1], a = n / r, o = r / i;
	return !(a > 3 && o < 2);
}
//#endregion
//#region node_modules/pixi.js/lib/scene/graphics/shared/svg/utils/pathOperations.mjs
function Wr(e) {
	return e.split(/(?=[Mm])/).filter((e) => e.trim().length > 0);
}
function Gr(e) {
	let t = e.match(/[-+]?[0-9]*\.?[0-9]+/g);
	if (!t || t.length < 4) return 0;
	let n = t.map(Number), r = [], i = [];
	for (let e = 0; e < n.length; e += 2) e + 1 < n.length && (r.push(n[e]), i.push(n[e + 1]));
	if (r.length === 0 || i.length === 0) return 0;
	let a = Math.min(...r), o = Math.max(...r), s = Math.min(...i), c = Math.max(...i);
	return (o - a) * (c - s);
}
function Kr(e, t) {
	let n = new Pr(e, !1);
	for (let e of n.instructions) t.instructions.push(e);
}
//#endregion
//#region node_modules/pixi.js/lib/scene/graphics/shared/svg/SVGParser.mjs
function qr(e, t) {
	if (typeof e == "string") {
		let t = document.createElement("div");
		t.innerHTML = e.trim(), e = t.querySelector("svg");
	}
	let n = {
		context: t,
		defs: {},
		path: new Pr()
	};
	Ir(e, n);
	let r = e.children, { fillStyle: i, strokeStyle: a } = Vr(e, n);
	for (let e = 0; e < r.length; e++) {
		let t = r[e];
		t.nodeName.toLowerCase() !== "defs" && Jr(t, n, i, a);
	}
	return t;
}
function Jr(e, t, n, r) {
	let i = e.children, { fillStyle: a, strokeStyle: o } = Vr(e, t);
	a && n ? n = {
		...n,
		...a
	} : a && (n = a), o && r ? r = {
		...r,
		...o
	} : o && (r = o);
	let s = !n && !r;
	s && (n = { color: 0 });
	let c, l, d, f, p, m, h, g, _, v, y, b, x, S, C, w, T;
	switch (e.nodeName.toLowerCase()) {
		case "path": {
			S = e.getAttribute("d");
			let i = e.getAttribute("fill-rule"), a = Wr(S), o = i === "evenodd", s = a.length > 1;
			if (o && s) {
				let e = a.map((e) => ({
					path: e,
					area: Gr(e)
				}));
				if (e.sort((e, t) => t.area - e.area), a.length > 3 || !Ur(e)) for (let i = 0; i < e.length; i++) {
					let a = e[i], o = i === 0;
					t.context.beginPath();
					let s = new Pr(void 0, !0);
					Kr(a.path, s), t.context.path(s), o ? (n && t.context.fill(n), r && t.context.stroke(r)) : t.context.cut();
				}
				else for (let i = 0; i < e.length; i++) {
					let a = e[i], o = i % 2 == 1;
					t.context.beginPath();
					let s = new Pr(void 0, !0);
					Kr(a.path, s), t.context.path(s), o ? t.context.cut() : (n && t.context.fill(n), r && t.context.stroke(r));
				}
			} else C = new Pr(S, !i || i === "evenodd"), t.context.path(C), n && t.context.fill(n), r && t.context.stroke(r);
			break;
		}
		case "circle":
			h = B(e, "cx", 0), g = B(e, "cy", 0), _ = B(e, "r", 0), t.context.ellipse(h, g, _, _), n && t.context.fill(n), r && t.context.stroke(r);
			break;
		case "rect":
			c = B(e, "x", 0), l = B(e, "y", 0), w = B(e, "width", 0), T = B(e, "height", 0), v = B(e, "rx", 0), y = B(e, "ry", 0), v || y ? t.context.roundRect(c, l, w, T, v || y) : t.context.rect(c, l, w, T), n && t.context.fill(n), r && t.context.stroke(r);
			break;
		case "ellipse":
			h = B(e, "cx", 0), g = B(e, "cy", 0), v = B(e, "rx", 0), y = B(e, "ry", 0), t.context.beginPath(), t.context.ellipse(h, g, v, y), n && t.context.fill(n), r && t.context.stroke(r);
			break;
		case "line":
			d = B(e, "x1", 0), f = B(e, "y1", 0), p = B(e, "x2", 0), m = B(e, "y2", 0), t.context.beginPath(), t.context.moveTo(d, f), t.context.lineTo(p, m), r && t.context.stroke(r);
			break;
		case "polygon":
			x = e.getAttribute("points"), b = x.match(/-?\d+/g).map((e) => parseInt(e, 10)), t.context.poly(b, !0), n && t.context.fill(n), r && t.context.stroke(r);
			break;
		case "polyline":
			x = e.getAttribute("points"), b = x.match(/-?\d+/g).map((e) => parseInt(e, 10)), t.context.poly(b, !1), r && t.context.stroke(r);
			break;
		case "g":
		case "svg": break;
		default: u(`[SVG parser] <${e.nodeName}> elements unsupported`);
	}
	s && (n = null);
	for (let e = 0; e < i.length; e++) Jr(i[e], t, n, r);
}
//#endregion
//#region node_modules/pixi.js/lib/scene/graphics/shared/fill/FillPattern.mjs
function Yr(e) {
	return e.texture !== void 0;
}
var Xr = {
	repeat: {
		addressModeU: "repeat",
		addressModeV: "repeat"
	},
	"repeat-x": {
		addressModeU: "repeat",
		addressModeV: "clamp-to-edge"
	},
	"repeat-y": {
		addressModeU: "clamp-to-edge",
		addressModeV: "repeat"
	},
	"no-repeat": {
		addressModeU: "clamp-to-edge",
		addressModeV: "clamp-to-edge"
	}
}, Zr = class {
	constructor(e, t) {
		this.uid = _("fillPattern"), this._tick = 0, this.transform = new w();
		let n = Yr(e) ? e : {
			texture: e,
			repetition: t
		};
		this.texture = n.texture, this.textureSpace = n.textureSpace ?? "global";
		let r = n.repetition;
		r && (this.texture.source.style.addressModeU = Xr[r].addressModeU, this.texture.source.style.addressModeV = Xr[r].addressModeV);
	}
	setTransform(e) {
		if (e) {
			if (this.transform.equals(e)) return;
			this.transform.copyFrom(e);
		} else {
			if (this.transform.isIdentity()) return;
			this.transform.identity();
		}
		this._tick++;
	}
	get texture() {
		return this._texture;
	}
	set texture(e) {
		this._texture !== e && (this._texture = e, this._tick++);
	}
	get styleKey() {
		return `fill-pattern-${this.uid}-${this._tick}`;
	}
	destroy() {
		this.texture.destroy(!0), this.texture = null;
	}
};
//#endregion
//#region node_modules/pixi.js/lib/scene/graphics/shared/utils/convertFillInputToFillStyle.mjs
function Qr(e) {
	return R.isColorLike(e);
}
function $r(e) {
	return e instanceof Zr;
}
function ei(e) {
	return e instanceof Wn;
}
function ti(e) {
	return e instanceof p;
}
function ni(e, t, n) {
	let r = R.shared.setValue(t ?? 0);
	return e.color = r.toNumber(), e.alpha = r.alpha === 1 ? n.alpha : r.alpha, e.texture = p.WHITE, {
		...n,
		...e
	};
}
function ri(e, t, n) {
	return e.texture = t, {
		...n,
		...e
	};
}
function ii(e, t, n) {
	return e.fill = t, e.color = 16777215, e.texture = t.texture, e.matrix = t.transform, e.textureSpace = t.textureSpace, {
		...n,
		...e
	};
}
function ai(e, t, n) {
	return t.buildGradient(), e.fill = t, e.color = 16777215, e.texture = t.texture, e.matrix = t.transform, e.textureSpace = t.textureSpace, {
		...n,
		...e
	};
}
function oi(e, t) {
	let n = {
		...t,
		...e
	}, r = R.shared.setValue(n.color);
	return n.alpha *= r.alpha, n.color = r.toNumber(), n;
}
function si(e, t) {
	if (e == null) return null;
	let n = {}, r = e;
	return Qr(e) ? ni(n, e, t) : ti(e) ? ri(n, e, t) : $r(e) ? ii(n, e, t) : ei(e) ? ai(n, e, t) : r.fill && $r(r.fill) ? ii(r, r.fill, t) : r.fill && ei(r.fill) ? ai(r, r.fill, t) : oi(r, t);
}
function ci(e, t) {
	let { width: n, alignment: r, miterLimit: i, cap: a, join: o, pixelLine: s, ...c } = t, l = si(e, c);
	return l ? {
		width: n,
		alignment: r,
		miterLimit: i,
		cap: a,
		join: o,
		pixelLine: s,
		...l
	} : null;
}
//#endregion
//#region node_modules/pixi.js/lib/scene/graphics/shared/utils/getMaxMiterRatio.mjs
function li(e, t) {
	let n = 1, r = e.shapePath.shapePrimitives;
	for (let e = 0; e < r.length; e++) {
		let i = r[e].shape;
		if (i.type !== "polygon") continue;
		let a = i.points, o = a.length;
		if (o < 6) continue;
		let s = i.closePath;
		for (let e = 0; e < o; e += 2) {
			if (!s && (e === 0 || e === o - 2)) continue;
			let r = (e - 2 + o) % o, i = (e + 2) % o, c = a[r], l = a[r + 1], u = a[e], d = a[e + 1], f = a[i], p = a[i + 1], m = c - u, h = l - d, g = f - u, _ = p - d, v = m * m + h * h, y = g * g + _ * _;
			if (v < 1e-12 || y < 1e-12) continue;
			let b = (m * g + h * _) / Math.sqrt(v * y);
			b < -1 ? b = -1 : b > 1 && (b = 1);
			let x = Math.sqrt((1 - b) * .5);
			if (x < 1e-6) continue;
			let S = Math.min(1 / x, t);
			S > n && (n = S);
		}
	}
	return n;
}
//#endregion
//#region node_modules/pixi.js/lib/scene/graphics/shared/GraphicsContext.mjs
var ui = new I(), di = new w(), fi = class e extends j {
	constructor() {
		super(...arguments), this._gpuData = /* @__PURE__ */ Object.create(null), this.autoGarbageCollect = !0, this._gcLastUsed = -1, this.uid = _("graphicsContext"), this.dirty = !0, this.batchMode = "auto", this.instructions = [], this.destroyed = !1, this._activePath = new Pr(), this._transform = new w(), this._fillStyle = { ...e.defaultFillStyle }, this._strokeStyle = { ...e.defaultStrokeStyle }, this._stateStack = [], this._tick = 0, this._bounds = new n(), this._boundsDirty = !0;
	}
	clone() {
		let t = new e();
		return t.batchMode = this.batchMode, t.instructions = this.instructions.slice(), t._activePath = this._activePath.clone(), t._transform = this._transform.clone(), t._fillStyle = { ...this._fillStyle }, t._strokeStyle = { ...this._strokeStyle }, t._stateStack = this._stateStack.slice(), t._bounds = this._bounds.clone(), t._boundsDirty = !0, t;
	}
	get fillStyle() {
		return this._fillStyle;
	}
	set fillStyle(t) {
		this._fillStyle = si(t, e.defaultFillStyle);
	}
	get strokeStyle() {
		return this._strokeStyle;
	}
	set strokeStyle(t) {
		this._strokeStyle = ci(t, e.defaultStrokeStyle);
	}
	setFillStyle(t) {
		return this._fillStyle = si(t, e.defaultFillStyle), this;
	}
	setStrokeStyle(t) {
		return this._strokeStyle = si(t, e.defaultStrokeStyle), this;
	}
	texture(e, t, n, r, i, a) {
		return this.instructions.push({
			action: "texture",
			data: {
				image: e,
				dx: n || 0,
				dy: r || 0,
				dw: i || e.frame.width,
				dh: a || e.frame.height,
				transform: this._transform.clone(),
				alpha: this._fillStyle.alpha,
				style: t || t === 0 ? R.shared.setValue(t).toNumber() : 16777215
			}
		}), this.onUpdate(), this;
	}
	beginPath() {
		return this._activePath = new Pr(), this;
	}
	fill(t, n) {
		let r, i = this.instructions[this.instructions.length - 1];
		return r = this._tick === 0 && i?.action === "stroke" ? i.data.path : this._activePath.clone(), r ? (t != null && (n !== void 0 && typeof t == "number" && (o(g, "GraphicsContext.fill(color, alpha) is deprecated, use GraphicsContext.fill({ color, alpha }) instead"), t = {
			color: t,
			alpha: n
		}), this._fillStyle = si(t, e.defaultFillStyle)), this.instructions.push({
			action: "fill",
			data: {
				style: this.fillStyle,
				path: r
			}
		}), this.onUpdate(), this._initNextPathLocation(), this._tick = 0, this) : this;
	}
	_initNextPathLocation() {
		let { x: e, y: t } = this._activePath.getLastPoint(I.shared);
		this._activePath.clear(), this._activePath.moveTo(e, t);
	}
	stroke(t) {
		let n, r = this.instructions[this.instructions.length - 1];
		return n = this._tick === 0 && r?.action === "fill" ? r.data.path : this._activePath.clone(), n ? (t != null && (this._strokeStyle = ci(t, e.defaultStrokeStyle)), this.instructions.push({
			action: "stroke",
			data: {
				style: this.strokeStyle,
				path: n
			}
		}), this.onUpdate(), this._initNextPathLocation(), this._tick = 0, this) : this;
	}
	cut() {
		for (let e = 0; e < 2; e++) {
			let t = this.instructions[this.instructions.length - 1 - e], n = this._activePath.clone();
			if (t && (t.action === "stroke" || t.action === "fill")) {
				if (t.data.hole) t.data.hole.addPath(n);
				else {
					t.data.hole = n;
					break;
				}
			}
		}
		return this._initNextPathLocation(), this;
	}
	arc(e, t, n, r, i, a) {
		this._tick++;
		let o = this._transform;
		return this._activePath.arc(o.a * e + o.c * t + o.tx, o.b * e + o.d * t + o.ty, n, r, i, a), this;
	}
	arcTo(e, t, n, r, i) {
		this._tick++;
		let a = this._transform;
		return this._activePath.arcTo(a.a * e + a.c * t + a.tx, a.b * e + a.d * t + a.ty, a.a * n + a.c * r + a.tx, a.b * n + a.d * r + a.ty, i), this;
	}
	arcToSvg(e, t, n, r, i, a, o) {
		this._tick++;
		let s = this._transform;
		return this._activePath.arcToSvg(e, t, n, r, i, s.a * a + s.c * o + s.tx, s.b * a + s.d * o + s.ty), this;
	}
	bezierCurveTo(e, t, n, r, i, a, o) {
		this._tick++;
		let s = this._transform;
		return this._activePath.bezierCurveTo(s.a * e + s.c * t + s.tx, s.b * e + s.d * t + s.ty, s.a * n + s.c * r + s.tx, s.b * n + s.d * r + s.ty, s.a * i + s.c * a + s.tx, s.b * i + s.d * a + s.ty, o), this;
	}
	closePath() {
		return this._tick++, this._activePath?.closePath(), this;
	}
	ellipse(e, t, n, r) {
		return this._tick++, this._activePath.ellipse(e, t, n, r, this._transform.clone()), this;
	}
	circle(e, t, n) {
		return this._tick++, this._activePath.circle(e, t, n, this._transform.clone()), this;
	}
	path(e) {
		return this._tick++, this._activePath.addPath(e, this._transform.clone()), this;
	}
	lineTo(e, t) {
		this._tick++;
		let n = this._transform;
		return this._activePath.lineTo(n.a * e + n.c * t + n.tx, n.b * e + n.d * t + n.ty), this;
	}
	moveTo(e, t) {
		this._tick++;
		let n = this._transform, r = this._activePath.instructions, i = n.a * e + n.c * t + n.tx, a = n.b * e + n.d * t + n.ty;
		return r.length === 1 && r[0].action === "moveTo" ? (r[0].data[0] = i, r[0].data[1] = a, this) : (this._activePath.moveTo(i, a), this);
	}
	quadraticCurveTo(e, t, n, r, i) {
		this._tick++;
		let a = this._transform;
		return this._activePath.quadraticCurveTo(a.a * e + a.c * t + a.tx, a.b * e + a.d * t + a.ty, a.a * n + a.c * r + a.tx, a.b * n + a.d * r + a.ty, i), this;
	}
	rect(e, t, n, r) {
		return this._tick++, this._activePath.rect(e, t, n, r, this._transform.clone()), this;
	}
	roundRect(e, t, n, r, i) {
		return this._tick++, this._activePath.roundRect(e, t, n, r, i, this._transform.clone()), this;
	}
	poly(e, t) {
		return this._tick++, this._activePath.poly(e, t, this._transform.clone()), this;
	}
	regularPoly(e, t, n, r, i = 0, a) {
		return this._tick++, this._activePath.regularPoly(e, t, n, r, i, a), this;
	}
	roundPoly(e, t, n, r, i, a) {
		return this._tick++, this._activePath.roundPoly(e, t, n, r, i, a), this;
	}
	roundShape(e, t, n, r) {
		return this._tick++, this._activePath.roundShape(e, t, n, r), this;
	}
	filletRect(e, t, n, r, i) {
		return this._tick++, this._activePath.filletRect(e, t, n, r, i), this;
	}
	chamferRect(e, t, n, r, i, a) {
		return this._tick++, this._activePath.chamferRect(e, t, n, r, i, a), this;
	}
	star(e, t, n, r, i = 0, a = 0) {
		return this._tick++, this._activePath.star(e, t, n, r, i, a, this._transform.clone()), this;
	}
	svg(e) {
		return this._tick++, qr(e, this), this;
	}
	restore() {
		let e = this._stateStack.pop();
		return e && (this._transform = e.transform, this._fillStyle = e.fillStyle, this._strokeStyle = e.strokeStyle), this;
	}
	save() {
		return this._stateStack.push({
			transform: this._transform.clone(),
			fillStyle: { ...this._fillStyle },
			strokeStyle: { ...this._strokeStyle }
		}), this;
	}
	getTransform() {
		return this._transform;
	}
	resetTransform() {
		return this._transform.identity(), this;
	}
	rotate(e) {
		return this._transform.rotate(e), this;
	}
	scale(e, t = e) {
		return this._transform.scale(e, t), this;
	}
	setTransform(e, t, n, r, i, a) {
		return e instanceof w ? (this._transform.set(e.a, e.b, e.c, e.d, e.tx, e.ty), this) : (this._transform.set(e, t, n, r, i, a), this);
	}
	transform(e, t, n, r, i, a) {
		return e instanceof w ? (this._transform.append(e), this) : (di.set(e, t, n, r, i, a), this._transform.append(di), this);
	}
	translate(e, t = e) {
		return this._transform.translate(e, t), this;
	}
	clear() {
		return this._activePath.clear(), this.instructions.length = 0, this.resetTransform(), this.onUpdate(), this;
	}
	onUpdate() {
		this._boundsDirty = !0, this.dirty = !0, this.emit("update", this, 16);
	}
	get bounds() {
		if (!this._boundsDirty) return this._bounds;
		this._boundsDirty = !1;
		let e = this._bounds;
		e.clear();
		for (let t = 0; t < this.instructions.length; t++) {
			let n = this.instructions[t], r = n.action;
			if (r === "fill") {
				let t = n.data;
				e.addBounds(t.path.bounds);
			} else if (r === "texture") {
				let t = n.data;
				e.addFrame(t.dx, t.dy, t.dx + t.dw, t.dy + t.dh, t.transform);
			}
			if (r === "stroke") {
				let t = n.data, r = t.style.alignment, i = t.style.width * (1 - r);
				t.style.join === "miter" && (i *= li(t.path, t.style.miterLimit));
				let a = t.path.bounds;
				e.addFrame(a.minX - i, a.minY - i, a.maxX + i, a.maxY + i);
			}
		}
		return e.isValid || e.set(0, 0, 0, 0), e;
	}
	containsPoint(e) {
		if (!this.bounds.containsPoint(e.x, e.y)) return !1;
		let t = this.instructions, n = !1;
		for (let r = 0; r < t.length; r++) {
			let i = t[r], a = i.data, o = a.path;
			if (!i.action || !o) continue;
			let s = a.style, c = o.shapePath.shapePrimitives;
			for (let t = 0; t < c.length; t++) {
				let r = c[t].shape;
				if (!s || !r) continue;
				let o = c[t].transform, l = o ? o.applyInverse(e, ui) : e;
				if (i.action === "fill") n = r.contains(l.x, l.y);
				else {
					let e = s;
					n = r.strokeContains(l.x, l.y, e.width, e.alignment);
				}
				let u = a.hole;
				if (u) {
					let e = u.shapePath?.shapePrimitives;
					if (e) for (let t = 0; t < e.length; t++) e[t].shape.contains(l.x, l.y) && (n = !1);
				}
				if (n) return !0;
			}
		}
		return n;
	}
	unload() {
		this.emit("unload", this);
		for (let e in this._gpuData) this._gpuData[e]?.destroy();
		this._gpuData = /* @__PURE__ */ Object.create(null);
	}
	destroy(e = !1) {
		if (!this.destroyed) {
			if (this.destroyed = !0, this._stateStack.length = 0, this._transform = null, this.unload(), this.emit("destroy", this), this.removeAllListeners(), typeof e == "boolean" ? e : e?.texture) {
				let t = typeof e == "boolean" ? e : e?.textureSource;
				this._fillStyle.texture && (this._fillStyle.fill && "uid" in this._fillStyle.fill ? this._fillStyle.fill.destroy() : this._fillStyle.texture.destroy(t)), this._strokeStyle.texture && (this._strokeStyle.fill && "uid" in this._strokeStyle.fill ? this._strokeStyle.fill.destroy() : this._strokeStyle.texture.destroy(t));
			}
			this._fillStyle = null, this._strokeStyle = null, this.instructions = null, this._activePath = null, this._bounds = null, this._stateStack = null, this.customShader = null, this._transform = null;
		}
	}
};
fi.defaultFillStyle = {
	color: 16777215,
	alpha: 1,
	texture: p.WHITE,
	matrix: null,
	fill: null,
	textureSpace: "local"
}, fi.defaultStrokeStyle = {
	width: 1,
	color: 16777215,
	alpha: 1,
	alignment: .5,
	miterLimit: 10,
	cap: "butt",
	join: "miter",
	texture: p.WHITE,
	matrix: null,
	fill: null,
	textureSpace: "local",
	pixelLine: !1
};
var pi = fi;
//#endregion
//#region node_modules/pixi.js/lib/maths/point/pointInTriangle.mjs
function mi(e, t, n, r, i, a, o, s) {
	let c = o - n, l = s - r, u = i - n, d = a - r, f = e - n, p = t - r, m = c * c + l * l, h = c * u + l * d, g = c * f + l * p, _ = u * u + d * d, v = u * f + d * p, y = 1 / (m * _ - h * h), b = (_ * g - h * v) * y, x = (m * v - h * g) * y;
	return b >= 0 && x >= 0 && b + x < 1;
}
//#endregion
//#region node_modules/pixi.js/lib/scene/graphics/canvas/CanvasGraphicsContextSystem.mjs
var hi = class {
	constructor() {
		this.isBatchable = !1;
	}
	reset() {
		this.isBatchable = !1, this.context = null, this.graphicsData &&= (this.graphicsData.destroy(), null);
	}
	destroy() {
		this.reset();
	}
}, gi = class {
	constructor() {
		this.instructions = new i();
	}
	init() {
		this.instructions.reset();
	}
	destroy() {
		this.instructions.destroy(), this.instructions = null;
	}
}, _i = class e {
	constructor(e) {
		this._renderer = e, this._managedContexts = new be({
			renderer: e,
			type: "resource",
			name: "graphicsContext"
		});
	}
	init(t) {
		e.defaultOptions.bezierSmoothness = t?.bezierSmoothness ?? e.defaultOptions.bezierSmoothness;
	}
	getContextRenderData(e) {
		return this.getGpuContext(e).graphicsData || this._initContextRenderData(e);
	}
	updateGpuContext(e) {
		let t = e._gpuData, n = !!t[this._renderer.uid], r = t[this._renderer.uid] || this._initContext(e);
		return (e.dirty || !n) && (n && r.reset(), r.isBatchable = !1, e.dirty = !1), r;
	}
	getGpuContext(e) {
		return e._gpuData[this._renderer.uid] || this._initContext(e);
	}
	_initContextRenderData(e) {
		let t = new gi(), n = this.getGpuContext(e);
		return n.graphicsData = t, t.init(), t;
	}
	_initContext(e) {
		let t = new hi();
		return t.context = e, e._gpuData[this._renderer.uid] = t, this._managedContexts.add(e), t;
	}
	destroy() {
		this._managedContexts.destroy(), this._renderer = null;
	}
};
_i.extension = {
	type: [D.CanvasSystem],
	name: "graphicsContext"
}, _i.defaultOptions = { bezierSmoothness: .5 };
var vi = _i, yi = class {
	constructor(e, t) {
		this.state = M.for2d(), this.renderer = e, this._adaptor = t, this.renderer.runners.contextChange.add(this), this._managedGraphics = new be({
			renderer: e,
			type: "renderable",
			priority: -1,
			name: "graphics"
		});
	}
	contextChange() {
		this._adaptor.contextChange(this.renderer);
	}
	validateRenderable(e) {
		return !1;
	}
	addRenderable(e, t) {
		this._managedGraphics.add(e), this.renderer.renderPipes.batch.break(t), t.add(e);
	}
	updateRenderable(e) {}
	execute(e) {
		e.isRenderable && this._adaptor.execute(this, e);
	}
	destroy() {
		this._managedGraphics.destroy(), this.renderer = null, this._adaptor.destroy(), this._adaptor = null;
	}
};
yi.extension = {
	type: [D.CanvasPipes],
	name: "graphics"
};
//#endregion
//#region node_modules/pixi.js/lib/scene/graphics/shared/GraphicsPipe.mjs
var bi = class {
	constructor() {
		this.batches = [], this.batched = !1;
	}
	destroy() {
		this.batches.forEach((e) => {
			a.return(e);
		}), this.batches.length = 0;
	}
}, xi = class {
	constructor(e, t) {
		this.state = M.for2d(), this.renderer = e, this._adaptor = t, this.renderer.runners.contextChange.add(this), this._managedGraphics = new be({
			renderer: e,
			type: "renderable",
			priority: -1,
			name: "graphics"
		});
	}
	contextChange() {
		this._adaptor.contextChange(this.renderer);
	}
	validateRenderable(e) {
		let t = e.context, n = !!e._gpuData, r = this.renderer.graphicsContext.updateGpuContext(t);
		return !!(r.isBatchable || n !== r.isBatchable);
	}
	addRenderable(e, t) {
		let n = this.renderer.graphicsContext.updateGpuContext(e.context);
		e.didViewUpdate && this._rebuild(e), n.isBatchable ? this._addToBatcher(e, t) : (this.renderer.renderPipes.batch.break(t), t.add(e));
	}
	updateRenderable(e) {
		let t = this._getGpuDataForRenderable(e).batches;
		for (let e = 0; e < t.length; e++) {
			let n = t[e];
			n._batcher.updateElement(n);
		}
	}
	execute(e) {
		if (!e.isRenderable) return;
		let t = this.renderer, n = e.context;
		if (!t.graphicsContext.getGpuContext(n).batches.length) return;
		let r = n.customShader || this._adaptor.shader;
		this.state.blendMode = e.groupBlendMode;
		let i = r.resources.localUniforms.uniforms;
		i.uTransformMatrix = e.groupTransform, i.uRound = t._roundPixels | e._roundPixels, Ne(e.groupColorAlpha, i.uColor, 0), this._adaptor.execute(this, e);
	}
	_rebuild(e) {
		let t = this._getGpuDataForRenderable(e), n = this.renderer.graphicsContext.updateGpuContext(e.context);
		t.destroy(), n.isBatchable && this._updateBatchesForRenderable(e, t);
	}
	_addToBatcher(e, t) {
		let n = this.renderer.renderPipes.batch, r = this._getGpuDataForRenderable(e).batches;
		for (let e = 0; e < r.length; e++) {
			let i = r[e];
			n.addToBatch(i, t);
		}
	}
	_getGpuDataForRenderable(e) {
		return e._gpuData[this.renderer.uid] || this._initGpuDataForRenderable(e);
	}
	_initGpuDataForRenderable(e) {
		let t = new bi();
		return e._gpuData[this.renderer.uid] = t, this._managedGraphics.add(e), t;
	}
	_updateBatchesForRenderable(e, t) {
		let n = e.context, r = this.renderer.graphicsContext.getGpuContext(n), i = this.renderer._roundPixels | e._roundPixels;
		t.batches = r.batches.map((t) => {
			let n = a.get(Dn);
			return t.copyTo(n), n.renderable = e, n.roundPixels = i, n;
		});
	}
	destroy() {
		this._managedGraphics.destroy(), this.renderer = null, this._adaptor.destroy(), this._adaptor = null, this.state = null;
	}
};
xi.extension = {
	type: [D.WebGLPipes, D.WebGPUPipes],
	name: "graphics"
}, b.add(yi), b.add(xi), b.add(vi), b.add(cr);
//#endregion
//#region node_modules/pixi.js/lib/scene/graphics/shared/Graphics.mjs
var V = class e extends d {
	constructor(e) {
		e instanceof pi && (e = { context: e });
		let { context: t, roundPixels: n, ...r } = e || {};
		super({
			label: "Graphics",
			...r
		}), this.renderPipeId = "graphics", t ? this.context = t : (this.context = this._ownedContext = new pi(), this.context.autoGarbageCollect = this.autoGarbageCollect), this.didViewUpdate = !0, this.allowChildren = !1, this.roundPixels = n ?? !1;
	}
	set context(e) {
		e !== this._context && (this._context && (this._context.off("update", this.onViewUpdate, this), this._context.off("unload", this.unload, this)), this._context = e, this._context.on("update", this.onViewUpdate, this), this._context.on("unload", this.unload, this), this.onViewUpdate());
	}
	get context() {
		return this._context;
	}
	get bounds() {
		return this._context.bounds;
	}
	updateBounds() {}
	containsPoint(e) {
		return this._context.containsPoint(e);
	}
	destroy(e) {
		this._ownedContext && !e ? this._ownedContext.destroy(e) : (e === !0 || e?.context === !0) && this._context.destroy(e), this._context?.off("update", this.onViewUpdate, this), this._context?.off("unload", this.unload, this), this._ownedContext = null, this._context = null, super.destroy(e);
	}
	_onTouch(e) {
		this._gcLastUsed = e, this._context._gcLastUsed = e;
	}
	_callContextMethod(e, t) {
		return this.context[e](...t), this;
	}
	setFillStyle(...e) {
		return this._callContextMethod("setFillStyle", e);
	}
	setStrokeStyle(...e) {
		return this._callContextMethod("setStrokeStyle", e);
	}
	fill(...e) {
		return this._callContextMethod("fill", e);
	}
	stroke(...e) {
		return this._callContextMethod("stroke", e);
	}
	texture(...e) {
		return this._callContextMethod("texture", e);
	}
	beginPath() {
		return this._callContextMethod("beginPath", []);
	}
	cut() {
		return this._callContextMethod("cut", []);
	}
	arc(...e) {
		return this._callContextMethod("arc", e);
	}
	arcTo(...e) {
		return this._callContextMethod("arcTo", e);
	}
	arcToSvg(...e) {
		return this._callContextMethod("arcToSvg", e);
	}
	bezierCurveTo(...e) {
		return this._callContextMethod("bezierCurveTo", e);
	}
	closePath() {
		return this._callContextMethod("closePath", []);
	}
	ellipse(...e) {
		return this._callContextMethod("ellipse", e);
	}
	circle(...e) {
		return this._callContextMethod("circle", e);
	}
	path(...e) {
		return this._callContextMethod("path", e);
	}
	lineTo(...e) {
		return this._callContextMethod("lineTo", e);
	}
	moveTo(...e) {
		return this._callContextMethod("moveTo", e);
	}
	quadraticCurveTo(...e) {
		return this._callContextMethod("quadraticCurveTo", e);
	}
	rect(...e) {
		return this._callContextMethod("rect", e);
	}
	roundRect(...e) {
		return this._callContextMethod("roundRect", e);
	}
	poly(...e) {
		return this._callContextMethod("poly", e);
	}
	regularPoly(...e) {
		return this._callContextMethod("regularPoly", e);
	}
	roundPoly(...e) {
		return this._callContextMethod("roundPoly", e);
	}
	roundShape(...e) {
		return this._callContextMethod("roundShape", e);
	}
	filletRect(...e) {
		return this._callContextMethod("filletRect", e);
	}
	chamferRect(...e) {
		return this._callContextMethod("chamferRect", e);
	}
	star(...e) {
		return this._callContextMethod("star", e);
	}
	svg(...e) {
		return this._callContextMethod("svg", e);
	}
	restore(...e) {
		return this._callContextMethod("restore", e);
	}
	save() {
		return this._callContextMethod("save", []);
	}
	getTransform() {
		return this.context.getTransform();
	}
	resetTransform() {
		return this._callContextMethod("resetTransform", []);
	}
	rotateTransform(...e) {
		return this._callContextMethod("rotate", e);
	}
	scaleTransform(...e) {
		return this._callContextMethod("scale", e);
	}
	setTransform(...e) {
		return this._callContextMethod("setTransform", e);
	}
	transform(...e) {
		return this._callContextMethod("transform", e);
	}
	translateTransform(...e) {
		return this._callContextMethod("translate", e);
	}
	clear() {
		return this._callContextMethod("clear", []);
	}
	get fillStyle() {
		return this._context.fillStyle;
	}
	set fillStyle(e) {
		this._context.fillStyle = e;
	}
	get strokeStyle() {
		return this._context.strokeStyle;
	}
	set strokeStyle(e) {
		this._context.strokeStyle = e;
	}
	clone(t = !1) {
		return t ? new e(this._context.clone()) : (this._ownedContext = null, new e(this._context));
	}
	lineStyle(e, t, n) {
		o(g, "Graphics#lineStyle is no longer needed. Use Graphics#setStrokeStyle to set the stroke style.");
		let r = {};
		return e && (r.width = e), t && (r.color = t), n && (r.alpha = n), this.context.strokeStyle = r, this;
	}
	beginFill(e, t) {
		o(g, "Graphics#beginFill is no longer needed. Use Graphics#fill to fill the shape with the desired style.");
		let n = {};
		return e !== void 0 && (n.color = e), t !== void 0 && (n.alpha = t), this.context.fillStyle = n, this;
	}
	endFill() {
		o(g, "Graphics#endFill is no longer needed. Use Graphics#fill to fill the shape with the desired style."), this.context.fill();
		let e = this.context.strokeStyle;
		return (e.width !== pi.defaultStrokeStyle.width || e.color !== pi.defaultStrokeStyle.color || e.alpha !== pi.defaultStrokeStyle.alpha) && this.context.stroke(), this;
	}
	drawCircle(...e) {
		return o(g, "Graphics#drawCircle has been renamed to Graphics#circle"), this._callContextMethod("circle", e);
	}
	drawEllipse(...e) {
		return o(g, "Graphics#drawEllipse has been renamed to Graphics#ellipse"), this._callContextMethod("ellipse", e);
	}
	drawPolygon(...e) {
		return o(g, "Graphics#drawPolygon has been renamed to Graphics#poly"), this._callContextMethod("poly", e);
	}
	drawRect(...e) {
		return o(g, "Graphics#drawRect has been renamed to Graphics#rect"), this._callContextMethod("rect", e);
	}
	drawRoundedRect(...e) {
		return o(g, "Graphics#drawRoundedRect has been renamed to Graphics#roundRect"), this._callContextMethod("roundRect", e);
	}
	drawStar(...e) {
		return o(g, "Graphics#drawStar has been renamed to Graphics#star"), this._callContextMethod("star", e);
	}
}, Si = class e extends ne {
	constructor(...t) {
		let n = t[0] ?? {};
		n instanceof Float32Array && (o(g, "use new MeshGeometry({ positions, uvs, indices }) instead"), n = {
			positions: n,
			uvs: t[1],
			indices: t[2]
		}), n = {
			...e.defaultOptions,
			...n
		};
		let r = n.positions || new Float32Array([
			0,
			0,
			1,
			0,
			1,
			1,
			0,
			1
		]), i = n.uvs;
		i ||= n.positions ? new Float32Array(r.length) : new Float32Array([
			0,
			0,
			1,
			0,
			1,
			1,
			0,
			1
		]);
		let a = n.indices || new Uint32Array([
			0,
			1,
			2,
			0,
			2,
			3
		]), s = n.shrinkBuffersToFit, c = new A({
			data: r,
			label: "attribute-mesh-positions",
			shrinkToFit: s,
			usage: P.VERTEX | P.COPY_DST
		}), l = new A({
			data: i,
			label: "attribute-mesh-uvs",
			shrinkToFit: s,
			usage: P.VERTEX | P.COPY_DST
		}), u = new A({
			data: a,
			label: "index-mesh-buffer",
			shrinkToFit: s,
			usage: P.INDEX | P.COPY_DST
		});
		super({
			attributes: {
				aPosition: {
					buffer: c,
					format: "float32x2",
					stride: 8,
					offset: 0
				},
				aUV: {
					buffer: l,
					format: "float32x2",
					stride: 8,
					offset: 0
				}
			},
			indexBuffer: u,
			topology: n.topology
		}), this.batchMode = "auto";
	}
	get positions() {
		return this.attributes.aPosition.buffer.data;
	}
	set positions(e) {
		this.attributes.aPosition.buffer.data = e;
	}
	get uvs() {
		return this.attributes.aUV.buffer.data;
	}
	set uvs(e) {
		this.attributes.aUV.buffer.data = e;
	}
	get indices() {
		return this.indexBuffer.data;
	}
	set indices(e) {
		this.indexBuffer.data = e;
	}
};
Si.defaultOptions = {
	topology: "triangle-list",
	shrinkBuffersToFit: !1
};
var Ci = Si, wi = class {
	constructor() {
		this.batcherName = "default", this.packAsQuad = !1, this.indexOffset = 0, this.attributeOffset = 0, this.roundPixels = 0, this._batcher = null, this._batch = null, this._textureMatrixUpdateId = -1, this._uvUpdateId = -1;
	}
	get blendMode() {
		return this.renderable.groupBlendMode;
	}
	get topology() {
		return this._topology || this.geometry.topology;
	}
	set topology(e) {
		this._topology = e;
	}
	reset() {
		this.renderable = null, this.texture = null, this._batcher = null, this._batch = null, this.geometry = null, this._uvUpdateId = -1, this._textureMatrixUpdateId = -1;
	}
	setTexture(e) {
		this.texture !== e && (this.texture = e, this._textureMatrixUpdateId = -1);
	}
	get uvs() {
		let e = this.geometry.getBuffer("aUV"), t = e.data, n = t, r = this.texture.textureMatrix;
		return r.isSimple || (n = this._transformedUvs, (this._textureMatrixUpdateId !== r._updateID || this._uvUpdateId !== e._updateID) && ((!n || n.length < t.length) && (n = this._transformedUvs = new Float32Array(t.length)), this._textureMatrixUpdateId = r._updateID, this._uvUpdateId = e._updateID, r.multiplyUvs(t, n))), n;
	}
	get positions() {
		return this.geometry.positions;
	}
	get indices() {
		return this.geometry.indices;
	}
	get color() {
		return this.renderable.groupColorAlpha;
	}
	get groupTransform() {
		return this.renderable.groupTransform;
	}
	get attributeSize() {
		return this.geometry.positions.length / 2;
	}
	get indexSize() {
		return this.geometry.indices.length;
	}
}, Ti = class {
	destroy() {}
}, Ei = class {
	constructor(e, t) {
		this.localUniforms = new C({
			uTransformMatrix: {
				value: new w(),
				type: "mat3x3<f32>"
			},
			uColor: {
				value: new Float32Array([
					1,
					1,
					1,
					1
				]),
				type: "vec4<f32>"
			},
			uRound: {
				value: 0,
				type: "f32"
			}
		}), this.localUniformsBindGroup = new re({ 0: this.localUniforms }), this.renderer = e, this._adaptor = t, this._adaptor.init();
	}
	validateRenderable(e) {
		let t = this._getMeshData(e), n = t.batched, r = e.batched;
		if (t.batched = r, n !== r) return !0;
		if (r) {
			let n = e._geometry;
			if (n.indices.length !== t.indexSize || n.positions.length !== t.vertexSize) return t.indexSize = n.indices.length, t.vertexSize = n.positions.length, !0;
			let r = this._getBatchableMesh(e);
			return r.texture.uid !== e._texture.uid && (r._textureMatrixUpdateId = -1), !r._batcher.checkAndUpdateTexture(r, e._texture);
		}
		return !1;
	}
	addRenderable(e, t) {
		let n = this.renderer.renderPipes.batch, r = this._getMeshData(e);
		if (e.didViewUpdate && (r.indexSize = e._geometry.indices?.length, r.vertexSize = e._geometry.positions?.length), r.batched) {
			let r = this._getBatchableMesh(e);
			r.setTexture(e._texture), r.geometry = e._geometry, n.addToBatch(r, t);
		} else n.break(t), t.add(e);
	}
	updateRenderable(e) {
		if (e.batched) {
			let t = this._getBatchableMesh(e);
			t.setTexture(e._texture), t.geometry = e._geometry, t._batcher.updateElement(t);
		}
	}
	execute(e) {
		if (!e.isRenderable) return;
		e.state.blend && (e.state.blendMode = ue(e.groupBlendMode, e.texture._source));
		let t = this.localUniforms;
		t.uniforms.uTransformMatrix = e.groupTransform, t.uniforms.uRound = this.renderer._roundPixels | e._roundPixels, t.update(), Ne(e.groupColorAlpha, t.uniforms.uColor, 0), this._adaptor.execute(this, e);
	}
	_getMeshData(e) {
		var t, n;
		return (t = e._gpuData)[n = this.renderer.uid] || (t[n] = new Ti()), e._gpuData[this.renderer.uid].meshData || this._initMeshData(e);
	}
	_initMeshData(e) {
		return e._gpuData[this.renderer.uid].meshData = {
			batched: e.batched,
			indexSize: 0,
			vertexSize: 0
		}, e._gpuData[this.renderer.uid].meshData;
	}
	_getBatchableMesh(e) {
		var t, n;
		return (t = e._gpuData)[n = this.renderer.uid] || (t[n] = new Ti()), e._gpuData[this.renderer.uid].batchableMesh || this._initBatchableMesh(e);
	}
	_initBatchableMesh(e) {
		let t = new wi();
		return t.renderable = e, t.setTexture(e._texture), t.transform = e.groupTransform, t.roundPixels = this.renderer._roundPixels | e._roundPixels, e._gpuData[this.renderer.uid].batchableMesh = t, t;
	}
	destroy() {
		this.localUniforms = null, this.localUniformsBindGroup = null, this._adaptor.destroy(), this._adaptor = null, this.renderer = null;
	}
};
//#endregion
//#region node_modules/pixi.js/lib/scene/mesh/init.mjs
Ei.extension = {
	type: [D.WebGLPipes, D.WebGPUPipes],
	name: "mesh"
}, b.add(Ei);
//#endregion
//#region node_modules/pixi.js/lib/scene/mesh/shared/Mesh.mjs
var Di = class extends d {
	constructor(...e) {
		let t = e[0];
		t instanceof ne && (o(g, "Mesh: use new Mesh({ geometry, shader }) instead"), t = {
			geometry: t,
			shader: e[1]
		}, e[3] && (o(g, "Mesh: drawMode argument has been removed, use geometry.topology instead"), t.geometry.topology = e[3]));
		let { geometry: n, shader: r, texture: i, roundPixels: a, state: s, ...c } = t;
		super({
			label: "Mesh",
			...c
		}), this.renderPipeId = "mesh", this._shader = null, this.allowChildren = !1, this.shader = r ?? null, this.texture = i ?? r?.texture ?? p.WHITE, this.state = s ?? M.for2d(), this._geometry = n, this._geometry.on("update", this.onViewUpdate, this), this.roundPixels = a ?? !1;
	}
	get material() {
		return o(g, "mesh.material property has been removed, use mesh.shader instead"), this._shader;
	}
	set shader(e) {
		this._shader !== e && (this._shader = e, this.onViewUpdate());
	}
	get shader() {
		return this._shader;
	}
	set geometry(e) {
		this._geometry !== e && (this._geometry?.off("update", this.onViewUpdate, this), e.on("update", this.onViewUpdate, this), this._geometry = e, this.onViewUpdate());
	}
	get geometry() {
		return this._geometry;
	}
	set texture(e) {
		e ||= p.EMPTY;
		let t = this._texture;
		t !== e && (t && t.dynamic && t.off("update", this.onViewUpdate, this), e.dynamic && e.on("update", this.onViewUpdate, this), this.shader && (this.shader.texture = e), this._texture = e, this.onViewUpdate());
	}
	get texture() {
		return this._texture;
	}
	get batched() {
		return this._shader || this.state.data & 12 ? !1 : this._geometry instanceof Ci ? this._geometry.batchMode === "auto" ? this._geometry.positions.length / 2 <= 100 : this._geometry.batchMode === "batch" : !1;
	}
	get bounds() {
		return this._geometry.bounds;
	}
	updateBounds() {
		this._bounds = this._geometry.bounds;
	}
	containsPoint(e) {
		let { x: t, y: n } = e;
		if (!this.bounds.containsPoint(t, n)) return !1;
		let r = this.geometry.getBuffer("aPosition").data, i = this.geometry.topology === "triangle-strip" ? 3 : 1;
		if (this.geometry.getIndex()) {
			let e = this.geometry.getIndex().data, a = e.length;
			for (let o = 0; o + 2 < a; o += i) {
				let i = e[o] * 2, a = e[o + 1] * 2, s = e[o + 2] * 2;
				if (mi(t, n, r[i], r[i + 1], r[a], r[a + 1], r[s], r[s + 1])) return !0;
			}
		} else {
			let e = r.length / 2;
			for (let a = 0; a + 2 < e; a += i) {
				let e = a * 2, i = (a + 1) * 2, o = (a + 2) * 2;
				if (mi(t, n, r[e], r[e + 1], r[i], r[i + 1], r[o], r[o + 1])) return !0;
			}
		}
		return !1;
	}
	destroy(e) {
		if (super.destroy(e), typeof e == "boolean" ? e : e?.texture) {
			let t = typeof e == "boolean" ? e : e?.textureSource;
			this._texture.destroy(t);
		}
		this._geometry?.off("update", this.onViewUpdate, this), this._texture = null, this._geometry = null, this._shader = null;
	}
}, Oi = class {
	constructor({ matrix: e, observer: t } = {}) {
		this.dirty = !0, this._matrix = e ?? new w(), this.observer = t, this.position = new F(this, 0, 0), this.scale = new F(this, 1, 1), this.pivot = new F(this, 0, 0), this.skew = new F(this, 0, 0), this._rotation = 0, this._cx = 1, this._sx = 0, this._cy = 0, this._sy = 1;
	}
	get matrix() {
		let e = this._matrix;
		return this.dirty ? (e.a = this._cx * this.scale.x, e.b = this._sx * this.scale.x, e.c = this._cy * this.scale.y, e.d = this._sy * this.scale.y, e.tx = this.position.x - (this.pivot.x * e.a + this.pivot.y * e.c), e.ty = this.position.y - (this.pivot.x * e.b + this.pivot.y * e.d), this.dirty = !1, e) : e;
	}
	_onUpdate(e) {
		this.dirty = !0, e === this.skew && this.updateSkew(), this.observer?._onUpdate(this);
	}
	updateSkew() {
		this._cx = Math.cos(this._rotation + this.skew.y), this._sx = Math.sin(this._rotation + this.skew.y), this._cy = -Math.sin(this._rotation - this.skew.x), this._sy = Math.cos(this._rotation - this.skew.x), this.dirty = !0;
	}
	toString() {
		return `[pixi.js/math:Transform position=(${this.position.x}, ${this.position.y}) rotation=${this.rotation} scale=(${this.scale.x}, ${this.scale.y}) skew=(${this.skew.x}, ${this.skew.y}) ]`;
	}
	setFromMatrix(e) {
		e.decompose(this), this.dirty = !0;
	}
	get rotation() {
		return this._rotation;
	}
	set rotation(e) {
		this._rotation !== e && (this._rotation = e, this._onUpdate(this.skew));
	}
}, ki = new w(), Ai = new w(), ji = [
	new I(),
	new I(),
	new I(),
	new I()
], Mi = class {
	constructor(e) {
		this._renderer = e;
	}
	validateRenderable(e) {
		return !1;
	}
	addRenderable(e, t) {
		this._renderer.renderPipes.batch.break(t), t.add(e);
	}
	updateRenderable(e) {}
	execute(e) {
		let n = this._renderer, r = n.canvasContext, i = r.activeContext;
		i.save(), r.setBlendMode(e.groupBlendMode);
		let a = n.globalUniforms.globalUniformData?.worldColor ?? 4294967295, o = e.groupColorAlpha, s = (a >>> 24 & 255) / 255, l = (o >>> 24 & 255) / 255, u = n.filter?.alphaMultiplier ?? 1, d = s * l * u;
		if (d <= 0) {
			i.restore();
			return;
		}
		i.globalAlpha = d;
		let f = a & 16777215, p = o & 16777215, m = c(t(p, f)), h = e.texture, g = le.getTintedPattern(h, m), _ = e.width, v = e.height, y = e.groupTransform, b = h.source._resolution ?? h.source.resolution ?? 1;
		Ai.copyFrom(e._tileTransform.matrix), e.applyAnchorToTexture || Ai.translate(-e.anchor.x * _, -e.anchor.y * v);
		let x = Ai.tx, S = Ai.ty;
		Ai.scale(1 / b, 1 / b), Ai.tx = x, Ai.ty = S, ki.identity(), ki.prepend(Ai), ki.prepend(y);
		let C = n._roundPixels | e._roundPixels;
		r.setContextTransform(ki, C === 1), i.fillStyle = g;
		let w = e.anchor.x * -_, T = e.anchor.y * -v;
		ji[0].set(w, T), ji[1].set(w + _, T), ji[2].set(w + _, T + v), ji[3].set(w, T + v);
		for (let e = 0; e < 4; e++) Ai.applyInverse(ji[e], ji[e]);
		i.beginPath(), i.moveTo(ji[0].x, ji[0].y);
		for (let e = 1; e < 4; e++) i.lineTo(ji[e].x, ji[e].y);
		i.closePath(), i.fill(), i.restore();
	}
	destroy() {
		this._renderer = null;
	}
};
Mi.extension = {
	type: [D.CanvasPipes],
	name: "tilingSprite"
};
//#endregion
//#region node_modules/pixi.js/lib/scene/sprite-tiling/shader/tilingBit.mjs
var Ni = {
	name: "tiling-bit",
	vertex: {
		header: "\n            struct TilingUniforms {\n                uMapCoord:mat3x3<f32>,\n                uClampFrame:vec4<f32>,\n                uClampOffset:vec2<f32>,\n                uTextureTransform:mat3x3<f32>,\n                uSizeAnchor:vec4<f32>\n            };\n\n            @group(2) @binding(0) var<uniform> tilingUniforms: TilingUniforms;\n            @group(2) @binding(1) var uTexture: texture_2d<f32>;\n            @group(2) @binding(2) var uSampler: sampler;\n        ",
		main: "\n            uv = (tilingUniforms.uTextureTransform * vec3(uv, 1.0)).xy;\n\n            position = (position - tilingUniforms.uSizeAnchor.zw) * tilingUniforms.uSizeAnchor.xy;\n        "
	},
	fragment: {
		header: "\n            struct TilingUniforms {\n                uMapCoord:mat3x3<f32>,\n                uClampFrame:vec4<f32>,\n                uClampOffset:vec2<f32>,\n                uTextureTransform:mat3x3<f32>,\n                uSizeAnchor:vec4<f32>\n            };\n\n            @group(2) @binding(0) var<uniform> tilingUniforms: TilingUniforms;\n            @group(2) @binding(1) var uTexture: texture_2d<f32>;\n            @group(2) @binding(2) var uSampler: sampler;\n        ",
		main: "\n\n            var coord = vUV + ceil(tilingUniforms.uClampOffset - vUV);\n            coord = (tilingUniforms.uMapCoord * vec3(coord, 1.0)).xy;\n            var unclamped = coord;\n            coord = clamp(coord, tilingUniforms.uClampFrame.xy, tilingUniforms.uClampFrame.zw);\n\n            var bias = 0.;\n\n            if(unclamped.x == coord.x && unclamped.y == coord.y)\n            {\n                bias = -32.;\n            }\n\n            outColor = textureSampleBias(uTexture, uSampler, coord, bias);\n        "
	}
}, Pi = {
	name: "tiling-bit",
	vertex: {
		header: "\n            uniform mat3 uTextureTransform;\n            uniform vec4 uSizeAnchor;\n\n        ",
		main: "\n            uv = (uTextureTransform * vec3(aUV, 1.0)).xy;\n\n            position = (position - uSizeAnchor.zw) * uSizeAnchor.xy;\n        "
	},
	fragment: {
		header: "\n            uniform sampler2D uTexture;\n            uniform mat3 uMapCoord;\n            uniform vec4 uClampFrame;\n            uniform vec2 uClampOffset;\n        ",
		main: "\n\n        vec2 coord = vUV + ceil(uClampOffset - vUV);\n        coord = (uMapCoord * vec3(coord, 1.0)).xy;\n        vec2 unclamped = coord;\n        coord = clamp(coord, uClampFrame.xy, uClampFrame.zw);\n\n        outColor = texture(uTexture, coord, unclamped == coord ? 0.0 : -32.0);// lod-bias very negative to force lod 0\n\n        "
	}
}, Fi, Ii, Li = class extends te {
	constructor() {
		Fi ??= Ie({
			name: "tiling-sprite-shader",
			bits: [
				He,
				Ni,
				Ee
			]
		}), Ii ??= ve({
			name: "tiling-sprite-shader",
			bits: [
				Ue,
				Pi,
				Ce
			]
		});
		let e = new C({
			uMapCoord: {
				value: new w(),
				type: "mat3x3<f32>"
			},
			uClampFrame: {
				value: new Float32Array([
					0,
					0,
					1,
					1
				]),
				type: "vec4<f32>"
			},
			uClampOffset: {
				value: new Float32Array([0, 0]),
				type: "vec2<f32>"
			},
			uTextureTransform: {
				value: new w(),
				type: "mat3x3<f32>"
			},
			uSizeAnchor: {
				value: new Float32Array([
					100,
					100,
					.5,
					.5
				]),
				type: "vec4<f32>"
			}
		});
		super({
			glProgram: Ii,
			gpuProgram: Fi,
			resources: {
				localUniforms: new C({
					uTransformMatrix: {
						value: new w(),
						type: "mat3x3<f32>"
					},
					uColor: {
						value: new Float32Array([
							1,
							1,
							1,
							1
						]),
						type: "vec4<f32>"
					},
					uRound: {
						value: 0,
						type: "f32"
					}
				}),
				tilingUniforms: e,
				uTexture: p.EMPTY.source,
				uSampler: p.EMPTY.source.style
			}
		});
	}
	updateUniforms(e, t, n, r, i, a) {
		let o = this.resources.tilingUniforms, s = a.width, c = a.height, l = a.textureMatrix, u = o.uniforms.uTextureTransform;
		u.set(n.a * s / e, n.b * s / t, n.c * c / e, n.d * c / t, n.tx / e, n.ty / t), u.invert(), o.uniforms.uMapCoord = l.mapCoord, o.uniforms.uClampFrame = l.uClampFrame, o.uniforms.uClampOffset = l.uClampOffset, o.uniforms.uTextureTransform = u, o.uniforms.uSizeAnchor[0] = e, o.uniforms.uSizeAnchor[1] = t, o.uniforms.uSizeAnchor[2] = r, o.uniforms.uSizeAnchor[3] = i, a && (this.resources.uTexture = a.source, this.resources.uSampler = a.source.style);
	}
}, Ri = class extends Ci {
	constructor() {
		super({
			positions: new Float32Array([
				0,
				0,
				1,
				0,
				1,
				1,
				0,
				1
			]),
			uvs: new Float32Array([
				0,
				0,
				1,
				0,
				1,
				1,
				0,
				1
			]),
			indices: new Uint32Array([
				0,
				1,
				2,
				0,
				2,
				3
			])
		});
	}
};
//#endregion
//#region node_modules/pixi.js/lib/scene/sprite-tiling/utils/setPositions.mjs
function zi(e, t) {
	let n = e.anchor.x, r = e.anchor.y;
	t[0] = -n * e.width, t[1] = -r * e.height, t[2] = (1 - n) * e.width, t[3] = -r * e.height, t[4] = (1 - n) * e.width, t[5] = (1 - r) * e.height, t[6] = -n * e.width, t[7] = (1 - r) * e.height;
}
//#endregion
//#region node_modules/pixi.js/lib/scene/sprite-tiling/utils/applyMatrix.mjs
function Bi(e, t, n, r) {
	let i = 0, a = e.length / (t || 2), o = r.a, s = r.b, c = r.c, l = r.d, u = r.tx, d = r.ty;
	for (n *= t; i < a;) {
		let r = e[n], a = e[n + 1];
		e[n] = o * r + c * a + u, e[n + 1] = s * r + l * a + d, n += t, i++;
	}
}
//#endregion
//#region node_modules/pixi.js/lib/scene/sprite-tiling/utils/setUvs.mjs
function Vi(e, t) {
	let n = e.texture, r = n.frame.width, i = n.frame.height, a = 0, o = 0;
	e.applyAnchorToTexture && (a = e.anchor.x, o = e.anchor.y), t[0] = t[6] = -a, t[2] = t[4] = 1 - a, t[1] = t[3] = -o, t[5] = t[7] = 1 - o;
	let s = e._tileTransform.matrix, c = w.shared;
	c.set(s.a * r / e.width, s.b * r / e.height, s.c * i / e.width, s.d * i / e.height, s.tx / e.width, s.ty / e.height), c.invert(), Bi(t, 2, 0, c);
}
//#endregion
//#region node_modules/pixi.js/lib/scene/sprite-tiling/TilingSpritePipe.mjs
var Hi = new Ri(), Ui = class {
	constructor() {
		this.canBatch = !0, this.geometry = new Ci({
			indices: Hi.indices.slice(),
			positions: Hi.positions.slice(),
			uvs: Hi.uvs.slice()
		});
	}
	destroy() {
		this.geometry.destroy(), this.shader?.destroy();
	}
}, Wi = class {
	constructor(e) {
		this._state = M.default2d, this._renderer = e, this._managedTilingSprites = new be({
			renderer: e,
			type: "renderable",
			name: "tilingSprite"
		});
	}
	validateRenderable(e) {
		let t = this._getTilingSpriteData(e), n = t.canBatch;
		this._updateCanBatch(e);
		let r = t.canBatch;
		if (r && r === n) {
			let { batchableMesh: n } = t;
			return !n._batcher.checkAndUpdateTexture(n, e.texture);
		}
		return n !== r;
	}
	addRenderable(e, t) {
		let n = this._renderer.renderPipes.batch;
		this._updateCanBatch(e);
		let r = this._getTilingSpriteData(e), { geometry: i, canBatch: a } = r;
		if (a) {
			r.batchableMesh ||= new wi();
			let a = r.batchableMesh;
			e.didViewUpdate && (this._updateBatchableMesh(e), a.geometry = i, a.renderable = e, a.transform = e.groupTransform, a.setTexture(e._texture)), a.roundPixels = this._renderer._roundPixels | e._roundPixels, n.addToBatch(a, t);
		} else n.break(t), r.shader ||= new Li(), this.updateRenderable(e), t.add(e);
	}
	execute(e) {
		let t = this._renderer, { shader: n } = this._getTilingSpriteData(e);
		n.groups[0] = t.globalUniforms.bindGroup;
		let r = n.resources.localUniforms.uniforms;
		r.uTransformMatrix = e.groupTransform, r.uRound = t._roundPixels | e._roundPixels, Ne(e.groupColorAlpha, r.uColor, 0), this._state.blendMode = ue(e.groupBlendMode, e.texture._source), t.encoder.draw({
			geometry: Hi,
			shader: n,
			state: this._state
		});
	}
	updateRenderable(e) {
		let t = this._getTilingSpriteData(e), { canBatch: n } = t;
		if (n) {
			let { batchableMesh: n } = t;
			e.didViewUpdate && this._updateBatchableMesh(e), n._batcher.updateElement(n);
		} else if (e.didViewUpdate) {
			let { shader: n } = t;
			n.updateUniforms(e.width, e.height, e._tileTransform.matrix, e.anchor.x, e.anchor.y, e.texture);
		}
	}
	_getTilingSpriteData(e) {
		return e._gpuData[this._renderer.uid] || this._initTilingSpriteData(e);
	}
	_initTilingSpriteData(e) {
		let t = new Ui();
		return t.renderable = e, e._gpuData[this._renderer.uid] = t, this._managedTilingSprites.add(e), t;
	}
	_updateBatchableMesh(e) {
		let { geometry: t } = this._getTilingSpriteData(e), n = e.texture.source.style;
		n.addressMode !== "repeat" && (n.addressMode = "repeat", n.update()), Vi(e, t.uvs), zi(e, t.positions);
	}
	destroy() {
		this._managedTilingSprites.destroy(), this._renderer = null;
	}
	_updateCanBatch(e) {
		let t = this._getTilingSpriteData(e), n = e.texture, r = !0;
		return this._renderer.type === O.WEBGL && (r = this._renderer.context.supports.nonPowOf2wrapping), t.canBatch = n.textureMatrix.isSimple && (r || n.source.isPowerOfTwo), t.canBatch;
	}
};
Wi.extension = {
	type: [D.WebGLPipes, D.WebGPUPipes],
	name: "tilingSprite"
}, b.add(Mi), b.add(Wi);
//#endregion
//#region node_modules/pixi.js/lib/scene/sprite-tiling/TilingSprite.mjs
var Gi = class e extends d {
	constructor(...t) {
		let n = t[0] || {};
		n instanceof p && (n = { texture: n }), t.length > 1 && (o(g, "use new TilingSprite({ texture, width:100, height:100 }) instead"), n.width = t[1], n.height = t[2]), n = {
			...e.defaultOptions,
			...n
		};
		let { texture: r, anchor: i, tilePosition: a, tileScale: s, tileRotation: c, width: l, height: u, applyAnchorToTexture: d, roundPixels: f, ...m } = n ?? {};
		super({
			label: "TilingSprite",
			...m
		}), this.renderPipeId = "tilingSprite", this.batched = !0, this.allowChildren = !1, this._anchor = new F({ _onUpdate: () => {
			this.onViewUpdate();
		} }), this.applyAnchorToTexture = d, this.texture = r, this._width = l ?? r.width, this._height = u ?? r.height, this._tileTransform = new Oi({ observer: { _onUpdate: () => this.onViewUpdate() } }), i && (this.anchor = i), this.tilePosition = a, this.tileScale = s, this.tileRotation = c, this.roundPixels = f ?? !1;
	}
	static from(t, n = {}) {
		return typeof t == "string" ? new e({
			texture: oe.get(t),
			...n
		}) : new e({
			texture: t,
			...n
		});
	}
	get uvRespectAnchor() {
		return o(g, "uvRespectAnchor is deprecated, please use applyAnchorToTexture instead"), this.applyAnchorToTexture;
	}
	set uvRespectAnchor(e) {
		o(g, "uvRespectAnchor is deprecated, please use applyAnchorToTexture instead"), this.applyAnchorToTexture = e;
	}
	get clampMargin() {
		return this._texture.textureMatrix.clampMargin;
	}
	set clampMargin(e) {
		this._texture.textureMatrix.clampMargin = e;
	}
	get anchor() {
		return this._anchor;
	}
	set anchor(e) {
		typeof e == "number" ? this._anchor.set(e) : this._anchor.copyFrom(e);
	}
	get tilePosition() {
		return this._tileTransform.position;
	}
	set tilePosition(e) {
		this._tileTransform.position.copyFrom(e);
	}
	get tileScale() {
		return this._tileTransform.scale;
	}
	set tileScale(e) {
		typeof e == "number" ? this._tileTransform.scale.set(e) : this._tileTransform.scale.copyFrom(e);
	}
	set tileRotation(e) {
		this._tileTransform.rotation = e;
	}
	get tileRotation() {
		return this._tileTransform.rotation;
	}
	get tileTransform() {
		return this._tileTransform;
	}
	set texture(e) {
		e ||= p.EMPTY;
		let t = this._texture;
		t !== e && (t && t.dynamic && t.off("update", this.onViewUpdate, this), e.dynamic && e.on("update", this.onViewUpdate, this), this._texture = e, this.onViewUpdate());
	}
	get texture() {
		return this._texture;
	}
	set width(e) {
		this._width = e, this.onViewUpdate();
	}
	get width() {
		return this._width;
	}
	set height(e) {
		this._height = e, this.onViewUpdate();
	}
	get height() {
		return this._height;
	}
	setSize(e, t) {
		typeof e == "object" && (t = e.height ?? e.width, e = e.width), this._width = e, this._height = t ?? e, this.onViewUpdate();
	}
	getSize(e) {
		return e ||= {}, e.width = this._width, e.height = this._height, e;
	}
	updateBounds() {
		let e = this._bounds, t = this._anchor, n = this._width, r = this._height;
		e.minX = -t._x * n, e.maxX = e.minX + n, e.minY = -t._y * r, e.maxY = e.minY + r;
	}
	containsPoint(e) {
		let t = this._width, n = this._height, r = -t * this._anchor._x, i = 0;
		return e.x >= r && e.x <= r + t && (i = -n * this._anchor._y, e.y >= i && e.y <= i + n);
	}
	destroy(e = !1) {
		if (super.destroy(e), this._anchor = null, this._tileTransform = null, this._bounds = null, typeof e == "boolean" ? e : e?.texture) {
			let t = typeof e == "boolean" ? e : e?.textureSource;
			this._texture.destroy(t);
		}
		this._texture = null;
	}
};
Gi.defaultOptions = {
	texture: p.EMPTY,
	anchor: {
		x: 0,
		y: 0
	},
	tilePosition: {
		x: 0,
		y: 0
	},
	tileScale: {
		x: 1,
		y: 1
	},
	tileRotation: 0,
	applyAnchorToTexture: !1
};
var Ki = Gi;
//#endregion
//#region node_modules/pixi.js/lib/utils/browser/isSafari.mjs
function qi() {
	let { userAgent: e } = x.get().getNavigator();
	return /^((?!chrome|android).)*safari/i.test(e);
}
//#endregion
//#region node_modules/pixi.js/lib/rendering/batcher/canvas/CanvasBatchAdaptor.mjs
var Ji = class n {
	static _getPatternRepeat(e, t) {
		let n = e && e !== "clamp-to-edge", r = t && t !== "clamp-to-edge";
		return n && r ? "repeat" : n ? "repeat-x" : r ? "repeat-y" : "no-repeat";
	}
	start(e, t, n) {}
	execute(r, i) {
		let a = i.elements;
		if (!a || !a.length) return;
		let o = r.renderer, s = o.canvasContext, l = s.activeContext;
		for (let r = 0; r < a.length; r++) {
			let u = a[r];
			if (!u.packAsQuad) continue;
			let d = u, f = d.texture, p = f ? le.getCanvasSource(f) : null;
			if (!p) continue;
			let m = f.source.style, h = s.smoothProperty, g = m.scaleMode !== "nearest";
			l[h] !== g && (l[h] = g), s.setBlendMode(i.blendMode);
			let _ = o.globalUniforms.globalUniformData?.worldColor ?? 4294967295, v = d.color, y = (_ >>> 24 & 255) / 255, b = (v >>> 24 & 255) / 255, x = o.filter?.alphaMultiplier ?? 1, S = y * b * x;
			if (S <= 0) continue;
			l.globalAlpha = S;
			let C = _ & 16777215, w = v & 16777215, T = c(t(w, C)), E = f.frame, D = m.addressModeU ?? m.addressMode, O = m.addressModeV ?? m.addressMode, k = n._getPatternRepeat(D, O), A = f.source._resolution ?? f.source.resolution ?? 1, j = d.renderable?.renderGroup?.isCachedAsTexture, M = E.x * A, N = E.y * A, ee = E.width * A, P = E.height * A, F = d.bounds, te = o.renderTarget.renderTarget.isRoot, ne = F.minX, I = F.minY, re = F.maxX - F.minX, ie = F.maxY - F.minY, ae = f.rotate, L = f.uvs, R = Math.min(L.x0, L.x1, L.x2, L.x3, L.y0, L.y1, L.y2, L.y3), oe = Math.max(L.x0, L.x1, L.x2, L.x3, L.y0, L.y1, L.y2, L.y3), se = k !== "no-repeat" && (R < 0 || oe > 1), ce = ae && !(!se && (T !== 16777215 || ae));
			ce ? (n._tempPatternMatrix.copyFrom(d.transform), e.matrixAppendRotationInv(n._tempPatternMatrix, ae, ne, I, re, ie), s.setContextTransform(n._tempPatternMatrix, d.roundPixels === 1, void 0, j && te)) : s.setContextTransform(d.transform, d.roundPixels === 1, void 0, j && te);
			let ue = re, de = ie, fe = ce ? 0 : ne, pe = ce ? 0 : I;
			if (!ce && d.roundPixels === 1 && (fe |= 0, pe |= 0), se) {
				let e = p, t = T !== 16777215 && !ae, r = E.width <= f.source.width && E.height <= f.source.height;
				t && r && (e = le.getTintedCanvas({ texture: f }, T));
				let i = l.createPattern(e, k);
				if (!i) continue;
				let a = ue, o = de;
				if (a === 0 || o === 0) continue;
				let s = 1 / a, c = 1 / o, u = (L.x1 - L.x0) * s, d = (L.y1 - L.y0) * s, m = (L.x3 - L.x0) * c, h = (L.y3 - L.y0) * c, g = L.x0 - u * fe - m * pe, _ = L.y0 - d * fe - h * pe, v = f.source.pixelWidth, y = f.source.pixelHeight;
				n._tempPatternMatrix.set(u * v, d * y, m * v, h * y, g * v, _ * y), le.applyPatternTransform(i, n._tempPatternMatrix), l.fillStyle = i, l.fillRect(fe, pe, ue, de);
			} else {
				let e = T !== 16777215 || ae ? le.getTintedCanvas({ texture: f }, T) : p, t = e !== p;
				l.drawImage(e, t ? 0 : M, t ? 0 : N, t ? e.width : ee, t ? e.height : P, fe, pe, ue, de);
			}
		}
	}
};
Ji._tempPatternMatrix = new w(), Ji.extension = {
	type: [D.CanvasPipesAdaptor],
	name: "batch"
};
var Yi = Ji, Xi = class {
	constructor() {
		this._tempState = M.for2d(), this._didUploadHash = {};
	}
	init(e) {
		e.renderer.runners.contextChange.add(this);
	}
	contextChange() {
		this._didUploadHash = {};
	}
	start(e, t, n) {
		let r = e.renderer, i = this._didUploadHash[n.uid];
		r.shader.bind(n, i), i || (this._didUploadHash[n.uid] = !0), r.shader.updateUniformGroup(r.globalUniforms.uniformGroup), r.geometry.bind(t, n.glProgram);
	}
	execute(e, t) {
		let n = e.renderer;
		this._tempState.blendMode = t.blendMode, n.state.set(this._tempState);
		let r = t.textures.textures;
		for (let e = 0; e < t.textures.count; e++) n.texture.bind(r[e], e);
		n.geometry.draw(t.topology, t.size, t.start);
	}
};
Xi.extension = {
	type: [D.WebGLPipesAdaptor],
	name: "batch"
};
//#endregion
//#region node_modules/pixi.js/lib/rendering/batcher/gpu/GpuBatchAdaptor.mjs
var Zi = M.for2d(), Qi = class {
	start(e, t, n) {
		let r = e.renderer, i = r.encoder, a = n.gpuProgram;
		this._shader = n, this._geometry = t, i.setGeometry(t, a), Zi.blendMode = "normal", r.pipeline.getPipeline(t, a, Zi, void 0, n._overrides);
		let o = r.globalUniforms.bindGroup;
		i.resetBindGroup(1), i.setBindGroup(0, o, a);
	}
	execute(e, t) {
		let n = this._shader.gpuProgram, r = e.renderer, i = r.encoder;
		if (!t.bindGroup) {
			let e = t.textures;
			t.bindGroup = Re(e.textures, e.count, r.limits.maxBatchableTextures);
		}
		Zi.blendMode = t.blendMode;
		let a = r.bindGroup.getBindGroup(t.bindGroup, n, 1), o = r.pipeline.getPipeline(this._geometry, n, Zi, t.topology, this._shader._overrides);
		t.bindGroup._touch(r.gc.now, r.tick), i.setPipeline(o), i.renderPassEncoder.setBindGroup(1, a), i.renderPassEncoder.drawIndexed(t.size, 1, t.start);
	}
};
Qi.extension = {
	type: [D.WebGPUPipesAdaptor],
	name: "batch"
};
//#endregion
//#region node_modules/pixi.js/lib/rendering/mask/color/CanvasColorMaskPipe.mjs
var $i = class {
	constructor(e) {
		this._colorStack = [], this._colorStackIndex = 0, this._currentColor = 0, this._renderer = e;
	}
	buildStart() {
		this._colorStack[0] = 15, this._colorStackIndex = 1, this._currentColor = 15;
	}
	push(e, t, n) {
		this._renderer.renderPipes.batch.break(n);
		let r = this._colorStack;
		r[this._colorStackIndex] = r[this._colorStackIndex - 1] & e.mask;
		let i = this._colorStack[this._colorStackIndex];
		i !== this._currentColor && (this._currentColor = i, n.add({
			renderPipeId: "colorMask",
			colorMask: i,
			canBundle: !1
		})), this._colorStackIndex++;
	}
	pop(e, t, n) {
		this._renderer.renderPipes.batch.break(n);
		let r = this._colorStack;
		this._colorStackIndex--;
		let i = r[this._colorStackIndex - 1];
		i !== this._currentColor && (this._currentColor = i, n.add({
			renderPipeId: "colorMask",
			colorMask: i,
			canBundle: !1
		}));
	}
	execute(e) {}
	destroy() {
		this._renderer = null, this._colorStack = null;
	}
};
$i.extension = {
	type: [D.CanvasPipes],
	name: "colorMask"
};
//#endregion
//#region node_modules/pixi.js/lib/rendering/mask/stencil/CanvasStencilMaskPipe.mjs
function ea(e, t, n, r, i, a) {
	a = Math.max(0, Math.min(a, Math.min(r, i) / 2)), e.moveTo(t + a, n), e.lineTo(t + r - a, n), e.quadraticCurveTo(t + r, n, t + r, n + a), e.lineTo(t + r, n + i - a), e.quadraticCurveTo(t + r, n + i, t + r - a, n + i), e.lineTo(t + a, n + i), e.quadraticCurveTo(t, n + i, t, n + i - a), e.lineTo(t, n + a), e.quadraticCurveTo(t, n, t + a, n);
}
function ta(e, t) {
	switch (t.type) {
		case "rectangle": {
			let n = t;
			e.rect(n.x, n.y, n.width, n.height);
			break;
		}
		case "roundedRectangle": {
			let n = t;
			ea(e, n.x, n.y, n.width, n.height, n.radius);
			break;
		}
		case "circle": {
			let n = t;
			e.moveTo(n.x + n.radius, n.y), e.arc(n.x, n.y, n.radius, 0, Math.PI * 2);
			break;
		}
		case "ellipse": {
			let n = t;
			e.ellipse ? (e.moveTo(n.x + n.halfWidth, n.y), e.ellipse(n.x, n.y, n.halfWidth, n.halfHeight, 0, 0, Math.PI * 2)) : (e.save(), e.translate(n.x, n.y), e.scale(n.halfWidth, n.halfHeight), e.moveTo(1, 0), e.arc(0, 0, 1, 0, Math.PI * 2), e.restore());
			break;
		}
		case "triangle": {
			let n = t;
			e.moveTo(n.x, n.y), e.lineTo(n.x2, n.y2), e.lineTo(n.x3, n.y3), e.closePath();
			break;
		}
		default: {
			let n = t, r = n.points;
			if (!r?.length) break;
			e.moveTo(r[0], r[1]);
			for (let t = 2; t < r.length; t += 2) e.lineTo(r[t], r[t + 1]);
			n.closePath && e.closePath();
			break;
		}
	}
}
function na(e, t, n) {
	let r = [], i = [], a = [];
	if (!Qn[t.type]?.build(t, r)) return !1;
	Fn(r, n, !1, t.closePath ?? !0, i, a);
	for (let t = 0; t < a.length; t += 3) {
		let n = a[t] * 2, r = a[t + 1] * 2, o = a[t + 2] * 2;
		e.moveTo(i[n], i[n + 1]), e.lineTo(i[r], i[r + 1]), e.lineTo(i[o], i[o + 1]), e.closePath();
	}
	return !0;
}
function ra(e, t) {
	if (!t?.length) return !1;
	for (let n = 0; n < t.length; n++) {
		let r = t[n];
		if (!r?.shape) continue;
		let i = r.transform, a = i && !i.isIdentity();
		a && (e.save(), e.transform(i.a, i.b, i.c, i.d, i.tx, i.ty)), ta(e, r.shape), a && e.restore();
	}
	return !0;
}
var ia = class {
	constructor(e) {
		this._warnedMaskTypes = /* @__PURE__ */ new Set(), this._canvasMaskStack = [], this._renderer = e;
	}
	push(e, t, n) {
		this._renderer.renderPipes.batch.break(n), n.add({
			renderPipeId: "stencilMask",
			action: "pushMaskBegin",
			mask: e,
			inverse: t._maskOptions.inverse,
			canBundle: !1
		});
	}
	pop(e, t, n) {
		this._renderer.renderPipes.batch.break(n), n.add({
			renderPipeId: "stencilMask",
			action: "popMaskEnd",
			mask: e,
			inverse: t._maskOptions.inverse,
			canBundle: !1
		});
	}
	execute(e) {
		if (e.action !== "pushMaskBegin" && e.action !== "popMaskEnd") return;
		let t = this._renderer, n = t.canvasContext, r = n?.activeContext;
		if (!r) return;
		if (e.action === "popMaskEnd") {
			this._canvasMaskStack.pop() && r.restore();
			return;
		}
		e.inverse && this._warnOnce("inverse", "CanvasRenderer: inverse masks are not supported on Canvas2D; ignoring inverse flag.");
		let i = e.mask.mask;
		if (!(i instanceof V)) {
			this._warnOnce("nonGraphics", "CanvasRenderer: only Graphics masks are supported in Canvas2D; skipping mask."), this._canvasMaskStack.push(!1);
			return;
		}
		let a = i, o = a.context?.instructions;
		if (!o?.length) {
			this._canvasMaskStack.push(!1);
			return;
		}
		r.save(), n.setContextTransform(a.groupTransform, (t._roundPixels | a._roundPixels) === 1), r.beginPath();
		let s = !1, c = !1;
		for (let e = 0; e < o.length; e++) {
			let t = o[e], n = t.action;
			if (n !== "fill" && n !== "stroke") continue;
			let i = t.data, a = i?.path?.shapePath;
			if (!a?.shapePrimitives?.length) continue;
			let l = n === "stroke", u = a.shapePrimitives;
			for (let e = 0; e < u.length; e++) {
				let t = u[e];
				if (!t?.shape) continue;
				let n = t.transform, a = n && !n.isIdentity();
				a && (r.save(), r.transform(n.a, n.b, n.c, n.d, n.tx, n.ty)), l && i.style ? s = na(r, t.shape, i.style) || s : (ta(r, t.shape), c = ra(r, t.holes) || c, s = !0), a && r.restore();
			}
		}
		if (!s) {
			r.restore(), this._canvasMaskStack.push(!1);
			return;
		}
		c ? r.clip("evenodd") : r.clip(), this._canvasMaskStack.push(!0);
	}
	destroy() {
		this._renderer = null, this._warnedMaskTypes = null, this._canvasMaskStack = null;
	}
	_warnOnce(e, t) {
		this._warnedMaskTypes.has(e) || (this._warnedMaskTypes.add(e), u(t));
	}
};
ia.extension = {
	type: [D.CanvasPipes],
	name: "stencilMask"
};
//#endregion
//#region node_modules/pixi.js/lib/rendering/renderers/canvas/utils/mapCanvasBlendModesToPixi.mjs
var H = "source-over";
function aa() {
	let e = se(), t = /* @__PURE__ */ Object.create(null);
	return t.inherit = H, t.none = H, t.normal = "source-over", t.add = "lighter", t.multiply = e ? "multiply" : H, t.screen = e ? "screen" : H, t.overlay = e ? "overlay" : H, t.darken = e ? "darken" : H, t.lighten = e ? "lighten" : H, t["color-dodge"] = e ? "color-dodge" : H, t["color-burn"] = e ? "color-burn" : H, t["hard-light"] = e ? "hard-light" : H, t["soft-light"] = e ? "soft-light" : H, t.difference = e ? "difference" : H, t.exclusion = e ? "exclusion" : H, t.saturation = e ? "saturation" : H, t.color = e ? "color" : H, t.luminosity = e ? "luminosity" : H, t["linear-burn"] = e ? "color-burn" : H, t["linear-dodge"] = e ? "color-dodge" : H, t["linear-light"] = e ? "hard-light" : H, t["pin-light"] = e ? "hard-light" : H, t["vivid-light"] = e ? "hard-light" : H, t["hard-mix"] = H, t.negation = e ? "difference" : H, t["normal-npm"] = t.normal, t["add-npm"] = t.add, t["screen-npm"] = t.screen, t.erase = "destination-out", t.subtract = H, t.divide = H, t.min = H, t.max = H, t;
}
//#endregion
//#region node_modules/pixi.js/lib/rendering/renderers/canvas/CanvasContextSystem.mjs
var oa = new w(), sa = class {
	constructor(e) {
		this.activeResolution = 1, this.smoothProperty = "imageSmoothingEnabled", this.blendModes = aa(), this._activeBlendMode = "normal", this._projTransform = null, this._outerBlend = !1, this._warnedBlendModes = /* @__PURE__ */ new Set(), this._renderer = e;
	}
	resolutionChange(e) {
		this.activeResolution = e;
	}
	init() {
		let e = this._renderer.background.alpha < 1;
		if (this.rootContext = this._renderer.canvas.getContext("2d", { alpha: e }), this.activeContext = this.rootContext, this.activeResolution = this._renderer.resolution, !this.rootContext.imageSmoothingEnabled) {
			let e = this.rootContext;
			e.webkitImageSmoothingEnabled ? this.smoothProperty = "webkitImageSmoothingEnabled" : e.mozImageSmoothingEnabled ? this.smoothProperty = "mozImageSmoothingEnabled" : e.oImageSmoothingEnabled ? this.smoothProperty = "oImageSmoothingEnabled" : e.msImageSmoothingEnabled && (this.smoothProperty = "msImageSmoothingEnabled");
		}
	}
	setContextTransform(e, t, n, r) {
		let i = r ? w.IDENTITY : this._renderer.globalUniforms.globalUniformData?.worldTransformMatrix || w.IDENTITY, a = oa;
		a.copyFrom(i), a.append(e);
		let o = this._projTransform, s = this.activeResolution;
		if (n ||= s, o) {
			let e = w.shared;
			e.copyFrom(a), e.prepend(o), a = e;
		}
		t ? this.activeContext.setTransform(a.a * n, a.b * n, a.c * n, a.d * n, a.tx * s | 0, a.ty * s | 0) : this.activeContext.setTransform(a.a * n, a.b * n, a.c * n, a.d * n, a.tx * s, a.ty * s);
	}
	clear(e, t) {
		let n = this.activeContext, r = this._renderer;
		if (n.clearRect(0, 0, r.width, r.height), e) {
			let i = R.shared.setValue(e);
			n.globalAlpha = t ?? i.alpha, n.fillStyle = i.toHex(), n.fillRect(0, 0, r.width, r.height), n.globalAlpha = 1;
		}
	}
	setBlendMode(e) {
		if (this._activeBlendMode === e) return;
		this._activeBlendMode = e, this._outerBlend = !1;
		let t = this.blendModes[e];
		if (!t) {
			this._warnedBlendModes.has(e) || (console.warn(`CanvasRenderer: blend mode "${e}" is not supported in Canvas2D; falling back to "source-over".`), this._warnedBlendModes.add(e)), this.activeContext.globalCompositeOperation = "source-over";
			return;
		}
		this.activeContext.globalCompositeOperation = t;
	}
	destroy() {
		this.rootContext = null, this.activeContext = null, this._warnedBlendModes.clear();
	}
};
sa.extension = {
	type: [D.CanvasSystem],
	name: "canvasContext"
};
//#endregion
//#region node_modules/pixi.js/lib/rendering/renderers/canvas/CanvasLimitsSystem.mjs
var ca = class {
	constructor() {
		this.maxTextures = 16, this.maxBatchableTextures = 16, this.maxUniformBindings = 0;
	}
	init() {}
};
ca.extension = {
	type: [D.CanvasSystem],
	name: "limits"
};
//#endregion
//#region node_modules/pixi.js/lib/scene/graphics/canvas/CanvasGraphicsAdaptor.mjs
var la = "#808080", ua = new w(), da = new w(), fa = new w(), pa = new w(), ma = new w();
function ha(e, t, n) {
	e.beginPath();
	for (let r = 0; r < n.length; r += 3) {
		let i = n[r] * 2, a = n[r + 1] * 2, o = n[r + 2] * 2;
		e.moveTo(t[i], t[i + 1]), e.lineTo(t[a], t[a + 1]), e.lineTo(t[o], t[o + 1]), e.closePath();
	}
	e.fill();
}
function ga(e) {
	return `#${(e & 16777215).toString(16).padStart(6, "0")}`;
}
function _a(e, t, n, r, i, a) {
	a = Math.max(0, Math.min(a, Math.min(r, i) / 2)), e.moveTo(t + a, n), e.lineTo(t + r - a, n), e.quadraticCurveTo(t + r, n, t + r, n + a), e.lineTo(t + r, n + i - a), e.quadraticCurveTo(t + r, n + i, t + r - a, n + i), e.lineTo(t + a, n + i), e.quadraticCurveTo(t, n + i, t, n + i - a), e.lineTo(t, n + a), e.quadraticCurveTo(t, n, t + a, n);
}
function va(e, t) {
	switch (t.type) {
		case "rectangle": {
			let n = t;
			e.rect(n.x, n.y, n.width, n.height);
			break;
		}
		case "roundedRectangle": {
			let n = t;
			_a(e, n.x, n.y, n.width, n.height, n.radius);
			break;
		}
		case "circle": {
			let n = t;
			e.arc(n.x, n.y, n.radius, 0, Math.PI * 2);
			break;
		}
		case "ellipse": {
			let n = t;
			e.ellipse ? e.ellipse(n.x, n.y, n.halfWidth, n.halfHeight, 0, 0, Math.PI * 2) : (e.save(), e.translate(n.x, n.y), e.scale(n.halfWidth, n.halfHeight), e.arc(0, 0, 1, 0, Math.PI * 2), e.restore());
			break;
		}
		case "triangle": {
			let n = t;
			e.moveTo(n.x, n.y), e.lineTo(n.x2, n.y2), e.lineTo(n.x3, n.y3), e.closePath();
			break;
		}
		default: {
			let n = t, r = n.points;
			if (!r?.length) break;
			e.moveTo(r[0], r[1]);
			for (let t = 2; t < r.length; t += 2) e.lineTo(r[t], r[t + 1]);
			n.closePath && e.closePath();
			break;
		}
	}
}
function ya(e, t) {
	if (!t?.length) return !1;
	for (let n = 0; n < t.length; n++) {
		let r = t[n];
		if (!r?.shape) continue;
		let i = r.transform, a = i && !i.isIdentity();
		a && (e.save(), e.transform(i.a, i.b, i.c, i.d, i.tx, i.ty)), va(e, r.shape), a && e.restore();
	}
	return !0;
}
function ba(e, t, n, r) {
	let i = e.fill;
	if (i instanceof Wn) {
		i.buildGradient();
		let a = i.texture;
		if (a) {
			let o = le.getTintedPattern(a, t), s = n ? pa.copyFrom(n).scale(a.source.pixelWidth, a.source.pixelHeight) : pa.copyFrom(i.transform);
			return r && !e.textureSpace && s.append(r), le.applyPatternTransform(o, s), o;
		}
	}
	if (i instanceof Zr) {
		let e = le.getTintedPattern(i.texture, t);
		return le.applyPatternTransform(e, i.transform, !1), e;
	}
	let a = e.texture;
	if (a && a !== p.WHITE) {
		if (!a.source.resource) return la;
		let r = le.getTintedPattern(a, t), i = e.matrix;
		if (n) {
			let { resolution: e } = a.source;
			if (i = pa.copyFrom(n), a.rotate) {
				let { uvs: t, orig: n } = a;
				i.prepend(ma.set(t.x1 - t.x0, t.y1 - t.y0, t.x3 - t.x0, t.y3 - t.y0, t.x0, t.y0).invert()).scale(n.width * e, n.height * e);
			} else i.scale(a.source.pixelWidth, a.source.pixelHeight).translate(-a.frame.x * e, -a.frame.y * e);
		}
		return le.applyPatternTransform(r, i), r;
	}
	return ga(t);
}
var xa = class {
	constructor() {
		this.shader = null;
	}
	contextChange(e) {}
	execute(n, r) {
		let i = n.renderer, a = i.canvasContext, o = a.activeContext, s = r.groupTransform, l = i.globalUniforms.globalUniformData?.worldColor ?? 4294967295, u = r.groupColorAlpha, d = (l >>> 24 & 255) / 255, f = (u >>> 24 & 255) / 255, m = i.filter?.alphaMultiplier ?? 1, h = d * f * m;
		if (h <= 0) return;
		let g = l & 16777215, _ = u & 16777215, v = c(t(_, g)), y = i._roundPixels | r._roundPixels;
		o.save(), a.setContextTransform(s, y === 1), a.setBlendMode(r.groupBlendMode);
		let b = r.context.instructions;
		for (let n = 0; n < b.length; n++) {
			let r = b[n];
			if (r.action === "texture") {
				let n = r.data, i = n.image, c = i ? le.getCanvasSource(i) : null;
				if (!c) continue;
				let l = n.alpha * h;
				if (l <= 0) continue;
				let u = t(n.style, v);
				o.globalAlpha = l;
				let d = c;
				u !== 16777215 && (d = le.getTintedCanvas({ texture: i }, u));
				let f = i.frame, p = i.source._resolution ?? i.source.resolution ?? 1, m = f.x * p, g = f.y * p, _ = f.width * p, b = f.height * p;
				d !== c && (m = 0, g = 0);
				let x = n.transform, S = x && !x.isIdentity(), C = i.rotate;
				S || C ? (ua.copyFrom(s), S && ua.append(x), C && e.matrixAppendRotationInv(ua, C, n.dx, n.dy, n.dw, n.dh), a.setContextTransform(ua, y === 1)) : a.setContextTransform(s, y === 1), o.drawImage(d, m, g, d === c ? _ : d.width, d === c ? b : d.height, C ? 0 : n.dx, C ? 0 : n.dy, n.dw, n.dh), (S || C) && a.setContextTransform(s, y === 1);
				continue;
			}
			let i = r.data, c = i?.path?.shapePath;
			if (!c?.shapePrimitives?.length) continue;
			let l = i.style, u = t(l.color, v), d = l.alpha * h;
			if (d <= 0) continue;
			let f = r.action === "stroke";
			if (o.globalAlpha = d, f) {
				let e = l;
				o.lineWidth = e.width, o.lineCap = e.cap, o.lineJoin = e.join, o.miterLimit = e.miterLimit;
			}
			let m = c.shapePrimitives;
			if (!f && i.hole?.shapePath?.shapePrimitives?.length) {
				let e = m[m.length - 1];
				e.holes = i.hole.shapePath.shapePrimitives;
			}
			for (let e = 0; e < m.length; e++) {
				let t = m[e];
				if (!t?.shape) continue;
				let n = t.transform, r = n && !n.isIdentity(), i = l.texture && l.texture !== p.WHITE, a = l.textureSpace === "global" ? n : null, c = ba(l, u, i ? Zn(da, l, t.shape, a) : null, r ? fa.copyFrom(s).append(n) : s);
				if (r && (o.save(), o.transform(n.a, n.b, n.c, n.d, n.tx, n.ty)), f) {
					let e = l;
					if (e.alignment !== .5 && !e.pixelLine) {
						let n = [], r = [], i = [];
						Qn[t.shape.type]?.build(t.shape, n) ? (Fn(n, e, !1, t.shape.closePath ?? !0, r, i), o.fillStyle = c, ha(o, r, i)) : (o.strokeStyle = c, o.beginPath(), va(o, t.shape), o.stroke());
					} else o.strokeStyle = c, o.beginPath(), va(o, t.shape), o.stroke();
				} else o.fillStyle = c, o.beginPath(), va(o, t.shape), ya(o, t.holes) ? o.fill("evenodd") : o.fill();
				r && o.restore();
			}
		}
		o.restore();
	}
	destroy() {
		this.shader = null;
	}
};
xa.extension = {
	type: [D.CanvasPipesAdaptor],
	name: "graphics"
};
//#endregion
//#region node_modules/pixi.js/lib/rendering/renderers/canvas/renderTarget/CanvasRenderTargetAdaptor.mjs
var Sa = class {
	init(e, t) {
		this._renderer = e, this._renderTargetSystem = t;
	}
	initGpuRenderTarget(e) {
		let t = e.colorTexture, { canvas: n, context: r } = this._ensureCanvas(t);
		return {
			canvas: n,
			context: r,
			width: n.width,
			height: n.height
		};
	}
	resizeGpuRenderTarget(e) {
		let t = e.colorTexture, { canvas: n } = this._ensureCanvas(t);
		n.width = e.pixelWidth, n.height = e.pixelHeight;
	}
	startRenderPass(e, t, n, r) {
		let i = this._renderTargetSystem.getGpuRenderTarget(e);
		this._renderer.canvasContext.activeContext = i.context, this._renderer.canvasContext.activeResolution = e.resolution, t && this.clear(e, t, n, r);
	}
	clear(e, t, n, r) {
		let i = this._renderTargetSystem.getGpuRenderTarget(e).context, a = r || {
			x: 0,
			y: 0,
			width: e.pixelWidth,
			height: e.pixelHeight
		};
		if (i.setTransform(1, 0, 0, 1, 0, 0), i.clearRect(a.x, a.y, a.width, a.height), n) {
			let e = R.shared.setValue(n);
			e.alpha > 0 && (i.globalAlpha = e.alpha, i.fillStyle = e.toHex(), i.fillRect(a.x, a.y, a.width, a.height), i.globalAlpha = 1);
		}
	}
	finishRenderPass() {}
	copyToTexture(e, t, n, r, i) {
		let a = this._renderTargetSystem.getGpuRenderTarget(e).canvas, o = t.source, { context: s } = this._ensureCanvas(o), c = i?.x ?? 0, l = i?.y ?? 0;
		return s.drawImage(a, n.x, n.y, r.width, r.height, c, l, r.width, r.height), o.update(), t;
	}
	copyDepthTexture(e, t, n, r, i) {
		u("[CanvasRenderTargetAdaptor] copyDepthTexture is not supported in the canvas renderer");
	}
	destroyGpuRenderTarget(e) {}
	_ensureCanvas(e) {
		let t = e.resource;
		(!t || !L.test(t)) && (t = x.get().createCanvas(e.pixelWidth, e.pixelHeight), e.resource = t), (t.width !== e.pixelWidth || t.height !== e.pixelHeight) && (t.width = e.pixelWidth, t.height = e.pixelHeight);
		let n = t.getContext("2d");
		return {
			canvas: t,
			context: n
		};
	}
}, Ca = class extends Me {
	constructor(e) {
		super(e), this.adaptor = new Sa(), this.adaptor.init(e, this);
	}
};
Ca.extension = {
	type: [D.CanvasSystem],
	name: "renderTarget"
};
//#endregion
//#region node_modules/pixi.js/lib/rendering/renderers/canvas/texture/CanvasTextureSystem.mjs
var wa = class {
	constructor(e) {}
	init() {}
	initSource(e) {}
	generateCanvas(e) {
		let t = x.get().createCanvas(), n = t.getContext("2d"), r = le.getCanvasSource(e);
		if (!r) return t;
		let i = e.frame, a = e.source._resolution ?? e.source.resolution ?? 1, o = i.x * a, s = i.y * a, c = i.width * a, l = i.height * a;
		return t.width = Math.ceil(c), t.height = Math.ceil(l), n.drawImage(r, o, s, c, l, 0, 0, c, l), t;
	}
	getPixels(e) {
		let t = this.generateCanvas(e);
		return {
			pixels: t.getContext("2d", { willReadFrequently: !0 }).getImageData(0, 0, t.width, t.height).data,
			width: t.width,
			height: t.height
		};
	}
	destroy() {}
};
wa.extension = {
	type: [D.CanvasSystem],
	name: "texture"
};
//#endregion
//#region node_modules/pixi.js/lib/rendering/renderers/canvas/CanvasRenderer.mjs
var Ta = /* @__PURE__ */ N({ CanvasRenderer: () => Ma }), Ea = [
	...Ae,
	sa,
	ca,
	wa,
	Ca
], Da = [
	we,
	Te,
	_e,
	Oe,
	ye,
	ia,
	$i,
	je
], Oa = [Yi, xa], ka = [], Aa = [], ja = [];
b.handleByNamedList(D.CanvasSystem, ka), b.handleByNamedList(D.CanvasPipes, Aa), b.handleByNamedList(D.CanvasPipesAdaptor, ja), b.add(...Ea, ...Da, ...Oa);
var Ma = class extends de {
	constructor() {
		let e = {
			name: "canvas",
			type: O.CANVAS,
			systems: ka,
			renderPipes: Aa,
			renderPipeAdaptors: ja
		};
		super(e);
	}
}, Na = /* @__PURE__ */ ((e) => (e[e.ELEMENT_ARRAY_BUFFER = 34963] = "ELEMENT_ARRAY_BUFFER", e[e.ARRAY_BUFFER = 34962] = "ARRAY_BUFFER", e[e.UNIFORM_BUFFER = 35345] = "UNIFORM_BUFFER", e))(Na || {}), Pa = class {
	constructor(e, t) {
		this._lastBindBaseLocation = -1, this._lastBindCallId = -1, this.buffer = e || null, this.updateID = -1, this.byteLength = -1, this.type = t;
	}
	destroy() {
		this.buffer = null, this.updateID = -1, this.byteLength = -1, this.type = -1, this._lastBindBaseLocation = -1, this._lastBindCallId = -1;
	}
}, Fa = class {
	constructor(e) {
		this._boundBufferBases = /* @__PURE__ */ Object.create(null), this._minBaseLocation = 0, this._nextBindBaseIndex = this._minBaseLocation, this._bindCallId = 0, this._renderer = e, this._managedBuffers = new be({
			renderer: e,
			type: "resource",
			onUnload: this.onBufferUnload.bind(this),
			name: "glBuffer"
		});
	}
	destroy() {
		this._managedBuffers.destroy(), this._renderer = null, this._gl = null, this._boundBufferBases = {};
	}
	contextChange() {
		this._gl = this._renderer.gl, this.destroyAll(!0), this._maxBindings = this._renderer.limits.maxUniformBindings;
	}
	getGlBuffer(e) {
		return e._gcLastUsed = this._renderer.gc.now, e._gpuData[this._renderer.uid] || this.createGLBuffer(e);
	}
	bind(e) {
		let { _gl: t } = this, n = this.getGlBuffer(e);
		t.bindBuffer(n.type, n.buffer);
	}
	bindBufferBase(e, t) {
		let { _gl: n } = this;
		this._boundBufferBases[t] !== e && (this._boundBufferBases[t] = e, e._lastBindBaseLocation = t, n.bindBufferBase(n.UNIFORM_BUFFER, t, e.buffer));
	}
	nextBindBase(e) {
		this._bindCallId++, this._minBaseLocation = 0, e && (this._boundBufferBases[0] = null, this._minBaseLocation = 1, this._nextBindBaseIndex < 1 && (this._nextBindBaseIndex = 1));
	}
	freeLocationForBufferBase(e) {
		let t = this.getLastBindBaseLocation(e);
		if (t >= this._minBaseLocation) return e._lastBindCallId = this._bindCallId, t;
		let n = 0, r = this._nextBindBaseIndex;
		for (; n < 2;) {
			r >= this._maxBindings && (r = this._minBaseLocation, n++);
			let e = this._boundBufferBases[r];
			if (e && e._lastBindCallId === this._bindCallId) {
				r++;
				continue;
			}
			break;
		}
		return t = r, this._nextBindBaseIndex = r + 1, n >= 2 ? -1 : (e._lastBindCallId = this._bindCallId, this._boundBufferBases[t] = null, t);
	}
	getLastBindBaseLocation(e) {
		let t = e._lastBindBaseLocation;
		return this._boundBufferBases[t] === e ? t : -1;
	}
	bindBufferRange(e, t, n, r) {
		let { _gl: i } = this;
		n ||= 0, t ||= 0, this._boundBufferBases[t] = null, i.bindBufferRange(i.UNIFORM_BUFFER, t || 0, e.buffer, n * 256, r || 256);
	}
	updateBuffer(e) {
		let { _gl: t } = this, n = this.getGlBuffer(e);
		if (e._updateID === n.updateID) return n;
		n.updateID = e._updateID, t.bindBuffer(n.type, n.buffer);
		let r = e.data, i = e.descriptor.usage & P.STATIC ? t.STATIC_DRAW : t.DYNAMIC_DRAW;
		return r ? n.byteLength >= r.byteLength ? t.bufferSubData(n.type, e._updateOffset, r, e._updateOffset / r.BYTES_PER_ELEMENT, (e._updateSize || r.byteLength) / r.BYTES_PER_ELEMENT) : (n.byteLength = r.byteLength, t.bufferData(n.type, r, i)) : (n.byteLength = e.descriptor.size, t.bufferData(n.type, n.byteLength, i)), n;
	}
	destroyAll(e = !1) {
		this._managedBuffers.removeAll(e);
	}
	onBufferUnload(e, t = !1) {
		let n = e._gpuData[this._renderer.uid];
		n && (t || this._gl.deleteBuffer(n.buffer));
	}
	createGLBuffer(e) {
		let { _gl: t } = this, n = Na.ARRAY_BUFFER;
		e.descriptor.usage & P.INDEX ? n = Na.ELEMENT_ARRAY_BUFFER : e.descriptor.usage & P.UNIFORM && (n = Na.UNIFORM_BUFFER);
		let r = new Pa(t.createBuffer(), n);
		return e._gpuData[this._renderer.uid] = r, this._managedBuffers.add(e), r;
	}
	resetState() {
		this._boundBufferBases = /* @__PURE__ */ Object.create(null);
	}
};
Fa.extension = {
	type: [D.WebGLSystem],
	name: "buffer"
};
//#endregion
//#region node_modules/pixi.js/lib/rendering/renderers/gl/context/GlContextSystem.mjs
var Ia = class e {
	constructor(e) {
		this.supports = {
			uint32Indices: !0,
			uniformBufferObject: !0,
			vertexArrayObject: !0,
			srgbTextures: !0,
			nonPowOf2wrapping: !0,
			msaa: !0,
			nonPowOf2mipmaps: !0
		}, this._renderer = e, this.extensions = /* @__PURE__ */ Object.create(null), this.handleContextLost = this.handleContextLost.bind(this), this.handleContextRestored = this.handleContextRestored.bind(this);
	}
	get isLost() {
		return !this.gl || this.gl.isContextLost();
	}
	contextChange(e) {
		this.gl = e, this._renderer.gl = e;
	}
	init(t) {
		t = {
			...e.defaultOptions,
			...t
		};
		let n = this.multiView = t.multiView;
		if (t.context && n && (u("Renderer created with both a context and multiview enabled. Disabling multiView as both cannot work together."), n = !1), this.canvas = n ? x.get().createCanvas(this._renderer.canvas.width, this._renderer.canvas.height) : this._renderer.view.canvas, t.context) this.initFromContext(t.context);
		else {
			let e = this._renderer.background.alpha < 1, n = t.premultipliedAlpha ?? !0, r = t.antialias && !this._renderer.backBuffer.useBackBuffer;
			this.createContext(t.preferWebGLVersion, {
				alpha: e,
				premultipliedAlpha: n,
				antialias: r,
				stencil: !0,
				preserveDrawingBuffer: t.preserveDrawingBuffer,
				powerPreference: t.powerPreference ?? "default"
			});
		}
	}
	ensureCanvasSize(e) {
		if (!this.multiView) {
			e !== this.canvas && u("multiView is disabled, but targetCanvas is not the main canvas");
			return;
		}
		let { canvas: t } = this;
		(t.width < e.width || t.height < e.height) && (t.width = Math.max(e.width, e.width), t.height = Math.max(e.height, e.height));
	}
	initFromContext(e) {
		this.gl = e, this.webGLVersion = e instanceof x.get().getWebGLRenderingContext() ? 1 : 2, this.getExtensions(), this.validateContext(e), this._renderer.runners.contextChange.emit(e);
		let t = this._renderer.view.canvas;
		t.addEventListener("webglcontextlost", this.handleContextLost, !1), t.addEventListener("webglcontextrestored", this.handleContextRestored, !1);
	}
	createContext(e, t) {
		let n, r = this.canvas;
		if (e === 2 && (n = r.getContext("webgl2", t)), !n && (n = r.getContext("webgl", t), !n)) throw Error("This browser does not support WebGL. Try using the canvas renderer");
		this.gl = n, this.initFromContext(this.gl);
	}
	getExtensions() {
		let { gl: e } = this, t = {
			anisotropicFiltering: e.getExtension("EXT_texture_filter_anisotropic"),
			floatTextureLinear: e.getExtension("OES_texture_float_linear"),
			s3tc: e.getExtension("WEBGL_compressed_texture_s3tc"),
			s3tc_sRGB: e.getExtension("WEBGL_compressed_texture_s3tc_srgb"),
			etc: e.getExtension("WEBGL_compressed_texture_etc"),
			etc1: e.getExtension("WEBGL_compressed_texture_etc1"),
			pvrtc: e.getExtension("WEBGL_compressed_texture_pvrtc") || e.getExtension("WEBKIT_WEBGL_compressed_texture_pvrtc"),
			atc: e.getExtension("WEBGL_compressed_texture_atc"),
			astc: e.getExtension("WEBGL_compressed_texture_astc"),
			bptc: e.getExtension("EXT_texture_compression_bptc"),
			rgtc: e.getExtension("EXT_texture_compression_rgtc"),
			loseContext: e.getExtension("WEBGL_lose_context")
		};
		if (this.webGLVersion === 1) this.extensions = {
			...t,
			drawBuffers: e.getExtension("WEBGL_draw_buffers"),
			depthTexture: e.getExtension("WEBGL_depth_texture"),
			vertexArrayObject: e.getExtension("OES_vertex_array_object") || e.getExtension("MOZ_OES_vertex_array_object") || e.getExtension("WEBKIT_OES_vertex_array_object"),
			uint32ElementIndex: e.getExtension("OES_element_index_uint"),
			floatTexture: e.getExtension("OES_texture_float"),
			floatTextureLinear: e.getExtension("OES_texture_float_linear"),
			textureHalfFloat: e.getExtension("OES_texture_half_float"),
			textureHalfFloatLinear: e.getExtension("OES_texture_half_float_linear"),
			vertexAttribDivisorANGLE: e.getExtension("ANGLE_instanced_arrays"),
			srgb: e.getExtension("EXT_sRGB")
		};
		else {
			this.extensions = {
				...t,
				colorBufferFloat: e.getExtension("EXT_color_buffer_float")
			};
			let n = e.getExtension("WEBGL_provoking_vertex");
			n && n.provokingVertexWEBGL(n.FIRST_VERTEX_CONVENTION_WEBGL);
		}
	}
	handleContextLost(e) {
		e.preventDefault(), this._contextLossForced && (this._contextLossForced = !1, setTimeout(() => {
			this.gl.isContextLost() && this.extensions.loseContext?.restoreContext();
		}, 0));
	}
	handleContextRestored() {
		this.getExtensions(), this._renderer.runners.contextChange.emit(this.gl);
	}
	destroy() {
		let e = this._renderer.view.canvas;
		this._renderer = null, e.removeEventListener("webglcontextlost", this.handleContextLost), e.removeEventListener("webglcontextrestored", this.handleContextRestored), this.gl.useProgram(null), this.extensions.loseContext?.loseContext();
	}
	forceContextLoss() {
		this.extensions.loseContext?.loseContext(), this._contextLossForced = !0;
	}
	validateContext(e) {
		let t = e.getContextAttributes();
		t && !t.stencil && u("Provided WebGL context does not have a stencil buffer, masks may not render correctly");
		let n = this.supports, r = this.webGLVersion === 2, i = this.extensions;
		n.uint32Indices = r || !!i.uint32ElementIndex, n.uniformBufferObject = r, n.vertexArrayObject = r || !!i.vertexArrayObject, n.srgbTextures = r || !!i.srgb, n.nonPowOf2wrapping = r, n.nonPowOf2mipmaps = r, n.msaa = r, n.uint32Indices || u("Provided WebGL context does not support 32 index buffer, large scenes may not render correctly");
	}
};
Ia.extension = {
	type: [D.WebGLSystem],
	name: "context"
}, Ia.defaultOptions = {
	context: null,
	premultipliedAlpha: !0,
	preserveDrawingBuffer: !1,
	powerPreference: void 0,
	preferWebGLVersion: 2,
	multiView: !1
};
var La = Ia, Ra = /* @__PURE__ */ ((e) => (e[e.RGBA = 6408] = "RGBA", e[e.RGB = 6407] = "RGB", e[e.RG = 33319] = "RG", e[e.RED = 6403] = "RED", e[e.RGBA_INTEGER = 36249] = "RGBA_INTEGER", e[e.RGB_INTEGER = 36248] = "RGB_INTEGER", e[e.RG_INTEGER = 33320] = "RG_INTEGER", e[e.RED_INTEGER = 36244] = "RED_INTEGER", e[e.ALPHA = 6406] = "ALPHA", e[e.LUMINANCE = 6409] = "LUMINANCE", e[e.LUMINANCE_ALPHA = 6410] = "LUMINANCE_ALPHA", e[e.DEPTH_COMPONENT = 6402] = "DEPTH_COMPONENT", e[e.DEPTH_STENCIL = 34041] = "DEPTH_STENCIL", e))(Ra || {}), za = /* @__PURE__ */ ((e) => (e[e.TEXTURE_2D = 3553] = "TEXTURE_2D", e[e.TEXTURE_CUBE_MAP = 34067] = "TEXTURE_CUBE_MAP", e[e.TEXTURE_2D_ARRAY = 35866] = "TEXTURE_2D_ARRAY", e[e.TEXTURE_CUBE_MAP_POSITIVE_X = 34069] = "TEXTURE_CUBE_MAP_POSITIVE_X", e[e.TEXTURE_CUBE_MAP_NEGATIVE_X = 34070] = "TEXTURE_CUBE_MAP_NEGATIVE_X", e[e.TEXTURE_CUBE_MAP_POSITIVE_Y = 34071] = "TEXTURE_CUBE_MAP_POSITIVE_Y", e[e.TEXTURE_CUBE_MAP_NEGATIVE_Y = 34072] = "TEXTURE_CUBE_MAP_NEGATIVE_Y", e[e.TEXTURE_CUBE_MAP_POSITIVE_Z = 34073] = "TEXTURE_CUBE_MAP_POSITIVE_Z", e[e.TEXTURE_CUBE_MAP_NEGATIVE_Z = 34074] = "TEXTURE_CUBE_MAP_NEGATIVE_Z", e))(za || {}), U = /* @__PURE__ */ ((e) => (e[e.UNSIGNED_BYTE = 5121] = "UNSIGNED_BYTE", e[e.UNSIGNED_SHORT = 5123] = "UNSIGNED_SHORT", e[e.UNSIGNED_SHORT_5_6_5 = 33635] = "UNSIGNED_SHORT_5_6_5", e[e.UNSIGNED_SHORT_4_4_4_4 = 32819] = "UNSIGNED_SHORT_4_4_4_4", e[e.UNSIGNED_SHORT_5_5_5_1 = 32820] = "UNSIGNED_SHORT_5_5_5_1", e[e.UNSIGNED_INT = 5125] = "UNSIGNED_INT", e[e.UNSIGNED_INT_10F_11F_11F_REV = 35899] = "UNSIGNED_INT_10F_11F_11F_REV", e[e.UNSIGNED_INT_2_10_10_10_REV = 33640] = "UNSIGNED_INT_2_10_10_10_REV", e[e.UNSIGNED_INT_24_8 = 34042] = "UNSIGNED_INT_24_8", e[e.UNSIGNED_INT_5_9_9_9_REV = 35902] = "UNSIGNED_INT_5_9_9_9_REV", e[e.BYTE = 5120] = "BYTE", e[e.SHORT = 5122] = "SHORT", e[e.INT = 5124] = "INT", e[e.FLOAT = 5126] = "FLOAT", e[e.FLOAT_32_UNSIGNED_INT_24_8_REV = 36269] = "FLOAT_32_UNSIGNED_INT_24_8_REV", e[e.HALF_FLOAT = 36193] = "HALF_FLOAT", e))(U || {}), Ba = {
	uint8x2: U.UNSIGNED_BYTE,
	uint8x4: U.UNSIGNED_BYTE,
	sint8x2: U.BYTE,
	sint8x4: U.BYTE,
	unorm8x2: U.UNSIGNED_BYTE,
	unorm8x4: U.UNSIGNED_BYTE,
	snorm8x2: U.BYTE,
	snorm8x4: U.BYTE,
	uint16x2: U.UNSIGNED_SHORT,
	uint16x4: U.UNSIGNED_SHORT,
	sint16x2: U.SHORT,
	sint16x4: U.SHORT,
	unorm16x2: U.UNSIGNED_SHORT,
	unorm16x4: U.UNSIGNED_SHORT,
	snorm16x2: U.SHORT,
	snorm16x4: U.SHORT,
	float16x2: U.HALF_FLOAT,
	float16x4: U.HALF_FLOAT,
	float32: U.FLOAT,
	float32x2: U.FLOAT,
	float32x3: U.FLOAT,
	float32x4: U.FLOAT,
	uint32: U.UNSIGNED_INT,
	uint32x2: U.UNSIGNED_INT,
	uint32x3: U.UNSIGNED_INT,
	uint32x4: U.UNSIGNED_INT,
	sint32: U.INT,
	sint32x2: U.INT,
	sint32x3: U.INT,
	sint32x4: U.INT
};
function Va(e) {
	return Ba[e] ?? Ba.float32;
}
//#endregion
//#region node_modules/pixi.js/lib/rendering/renderers/gl/geometry/GlGeometrySystem.mjs
var Ha = {
	"point-list": 0,
	"line-list": 1,
	"line-strip": 3,
	"triangle-list": 4,
	"triangle-strip": 5
}, Ua = class {
	constructor() {
		this.vaoCache = /* @__PURE__ */ Object.create(null);
	}
	destroy() {
		this.vaoCache = /* @__PURE__ */ Object.create(null);
	}
}, Wa = class {
	constructor(e) {
		this._renderer = e, this._activeGeometry = null, this._activeVao = null, this.hasVao = !0, this.hasInstance = !0, this._managedGeometries = new be({
			renderer: e,
			type: "resource",
			onUnload: this.onGeometryUnload.bind(this),
			name: "glGeometry"
		});
	}
	contextChange() {
		let e = this.gl = this._renderer.gl;
		if (!this._renderer.context.supports.vertexArrayObject) throw Error("[PixiJS] Vertex Array Objects are not supported on this device");
		this.destroyAll(!0);
		let t = this._renderer.context.extensions.vertexArrayObject;
		t && (e.createVertexArray = () => t.createVertexArrayOES(), e.bindVertexArray = (e) => t.bindVertexArrayOES(e), e.deleteVertexArray = (e) => t.deleteVertexArrayOES(e));
		let n = this._renderer.context.extensions.vertexAttribDivisorANGLE;
		n && (e.drawArraysInstanced = (e, t, r, i) => {
			n.drawArraysInstancedANGLE(e, t, r, i);
		}, e.drawElementsInstanced = (e, t, r, i, a) => {
			n.drawElementsInstancedANGLE(e, t, r, i, a);
		}, e.vertexAttribDivisor = (e, t) => n.vertexAttribDivisorANGLE(e, t)), this._activeGeometry = null, this._activeVao = null;
	}
	bind(e, t) {
		let n = this.gl;
		this._activeGeometry = e;
		let r = this.getVao(e, t);
		this._activeVao !== r && (this._activeVao = r, n.bindVertexArray(r)), this.updateBuffers();
	}
	resetState() {
		this.unbind();
	}
	updateBuffers() {
		let e = this._activeGeometry, t = this._renderer.buffer;
		for (let n = 0; n < e.buffers.length; n++) {
			let r = e.buffers[n];
			t.updateBuffer(r);
		}
		e._gcLastUsed = this._renderer.gc.now;
	}
	checkCompatibility(e, t) {
		let n = e.attributes, r = t._attributeData;
		for (let e in r) if (!n[e]) throw Error(`shader and geometry incompatible, geometry missing the "${e}" attribute`);
	}
	getSignature(e, t) {
		let n = e.attributes, r = t._attributeData, i = ["g", e.uid];
		for (let e in n) r[e] && i.push(e, r[e].location);
		return i.join("-");
	}
	getVao(e, t) {
		return e._gpuData[this._renderer.uid]?.vaoCache[t._key] || this.initGeometryVao(e, t);
	}
	initGeometryVao(e, t, n = !0) {
		let r = this._renderer.gl, i = this._renderer.buffer;
		this._renderer.shader._getProgramData(t), this.checkCompatibility(e, t);
		let a = this.getSignature(e, t), o = e._gpuData[this._renderer.uid];
		o || (o = new Ua(), e._gpuData[this._renderer.uid] = o, this._managedGeometries.add(e));
		let s = o.vaoCache, c = s[a];
		if (c) return s[t._key] = c, c;
		Ve(e, t._attributeData);
		let l = e.buffers;
		c = r.createVertexArray(), r.bindVertexArray(c);
		for (let e = 0; e < l.length; e++) {
			let t = l[e];
			i.bind(t);
		}
		return this.activateVao(e, t), s[t._key] = c, s[a] = c, r.bindVertexArray(null), c;
	}
	onGeometryUnload(e, t = !1) {
		let n = e._gpuData[this._renderer.uid];
		if (!n) return;
		let r = n.vaoCache;
		if (!t) for (let e in r) this._activeVao !== r[e] && this.resetState(), this.gl.deleteVertexArray(r[e]);
	}
	destroyAll(e = !1) {
		this._managedGeometries.removeAll(e);
	}
	activateVao(e, t) {
		let n = this._renderer.gl, r = this._renderer.buffer, i = e.attributes;
		e.indexBuffer && r.bind(e.indexBuffer);
		let a = null;
		for (let e in i) {
			let o = i[e], s = o.buffer, c = r.getGlBuffer(s), l = t._attributeData[e];
			if (l) {
				a !== c && (r.bind(s), a = c);
				let e = l.location;
				n.enableVertexAttribArray(e);
				let t = ee(o.format), i = Va(o.format);
				if (l.format?.substring(1, 4) === "int" ? n.vertexAttribIPointer(e, t.size, i, o.stride, o.offset) : n.vertexAttribPointer(e, t.size, i, t.normalised, o.stride, o.offset), o.instance) {
					if (this.hasInstance) {
						let t = o.divisor ?? 1;
						n.vertexAttribDivisor(e, t);
					} else throw Error("geometry error, GPU Instancing is not supported on this device");
				}
			}
		}
	}
	draw(e, t, n, r) {
		let { gl: i } = this._renderer, a = this._activeGeometry, o = Ha[e || a.topology];
		if (r ??= a.instanceCount, a.indexBuffer) {
			let e = a.indexBuffer.data.BYTES_PER_ELEMENT, s = e === 2 ? i.UNSIGNED_SHORT : i.UNSIGNED_INT;
			r === 1 ? i.drawElements(o, t || a.indexBuffer.data.length, s, (n || 0) * e) : i.drawElementsInstanced(o, t || a.indexBuffer.data.length, s, (n || 0) * e, r);
		} else r === 1 ? i.drawArrays(o, n || 0, t || a.vertexCount) : i.drawArraysInstanced(o, n || 0, t || a.vertexCount, r);
		return this;
	}
	unbind() {
		this.gl.bindVertexArray(null), this._activeVao = null, this._activeGeometry = null;
	}
	destroy() {
		this._managedGeometries.destroy(), this._renderer = null, this.gl = null, this._activeVao = null, this._activeGeometry = null;
	}
};
Wa.extension = {
	type: [D.WebGLSystem],
	name: "geometry"
};
//#endregion
//#region node_modules/pixi.js/lib/rendering/renderers/gl/GlBackBufferSystem.mjs
var Ga = new ne({ attributes: { aPosition: [
	-1,
	-1,
	3,
	-1,
	-1,
	3
] } }), Ka = class e {
	constructor(e) {
		this.useBackBuffer = !1, this._useBackBufferThisRender = !1, this._renderer = e;
	}
	init(t = {}) {
		let { useBackBuffer: n, antialias: r } = {
			...e.defaultOptions,
			...t
		};
		this.useBackBuffer = n, this._antialias = r, this._renderer.context.supports.msaa || (u("antialiasing, is not supported on when using the back buffer"), this._antialias = !1), this._state = M.for2d();
		let i = new k({
			vertex: "\n                attribute vec2 aPosition;\n                out vec2 vUv;\n\n                void main() {\n                    gl_Position = vec4(aPosition, 0.0, 1.0);\n\n                    vUv = (aPosition + 1.0) / 2.0;\n\n                    // flip dem UVs\n                    vUv.y = 1.0 - vUv.y;\n                }",
			fragment: "\n                in vec2 vUv;\n                out vec4 finalColor;\n\n                uniform sampler2D uTexture;\n\n                void main() {\n                    finalColor = texture(uTexture, vUv);\n                }",
			name: "big-triangle"
		});
		this._bigTriangleShader = new te({
			glProgram: i,
			resources: { uTexture: p.WHITE.source }
		});
	}
	renderStart(e) {
		let t = this._renderer.renderTarget.getRenderTarget(e.target);
		if (this._useBackBufferThisRender = this.useBackBuffer && !!t.isRoot, this._useBackBufferThisRender) {
			let t = this._renderer.renderTarget.getRenderTarget(e.target);
			this._targetTexture = t.colorTexture, e.target = this._getBackBufferTexture(t.colorTexture);
		}
	}
	renderEnd() {
		this._presentBackBuffer();
	}
	_presentBackBuffer() {
		let e = this._renderer;
		e.renderTarget.finishRenderPass(), this._useBackBufferThisRender && (e.renderTarget.bind({
			target: this._targetTexture,
			clear: !1
		}), this._bigTriangleShader.resources.uTexture = this._backBufferTexture.source, e.encoder.draw({
			geometry: Ga,
			shader: this._bigTriangleShader,
			state: this._state
		}));
	}
	_getBackBufferTexture(e) {
		return this._backBufferTexture = this._backBufferTexture || new p({ source: new m({
			width: e.width,
			height: e.height,
			resolution: e._resolution,
			antialias: this._antialias
		}) }), this._backBufferTexture.source.resize(e.width, e.height, e._resolution), this._backBufferTexture;
	}
	destroy() {
		this._backBufferTexture &&= (this._backBufferTexture.destroy(), null);
	}
};
Ka.extension = {
	type: [D.WebGLSystem],
	name: "backBuffer",
	priority: 1
}, Ka.defaultOptions = { useBackBuffer: !1 };
var qa = Ka, Ja = class {
	constructor(e) {
		this._colorMaskCache = 15, this._renderer = e;
	}
	setMask(e) {
		this._colorMaskCache !== e && (this._colorMaskCache = e, this._renderer.gl.colorMask(!!(e & 8), !!(e & 4), !!(e & 2), !!(e & 1)));
	}
};
Ja.extension = {
	type: [D.WebGLSystem],
	name: "colorMask"
};
//#endregion
//#region node_modules/pixi.js/lib/rendering/renderers/gl/GlEncoderSystem.mjs
var Ya = class {
	constructor(e) {
		this.commandFinished = Promise.resolve(), this._renderer = e;
	}
	setGeometry(e, t) {
		this._renderer.geometry.bind(e, t.glProgram);
	}
	finishRenderPass() {}
	draw(e) {
		let t = this._renderer, { geometry: n, shader: r, state: i, skipSync: a, topology: o, size: s, start: c, instanceCount: l } = e;
		t.shader.bind(r, a), t.geometry.bind(n, t.shader._activeProgram), i && t.state.set(i), t.geometry.draw(o, s, c, l ?? n.instanceCount);
	}
	destroy() {
		this._renderer = null;
	}
};
Ya.extension = {
	type: [D.WebGLSystem],
	name: "encoder"
};
//#endregion
//#region node_modules/pixi.js/lib/rendering/renderers/gl/GlLimitsSystem.mjs
var Xa = class {
	constructor(e) {
		this._renderer = e;
	}
	contextChange() {
		let e = this._renderer.gl;
		this.maxTextures = e.getParameter(e.MAX_TEXTURE_IMAGE_UNITS), this.maxBatchableTextures = me(this.maxTextures, e);
		let t = this._renderer.context.webGLVersion === 2;
		this.maxUniformBindings = t ? e.getParameter(e.MAX_UNIFORM_BUFFER_BINDINGS) : 0;
	}
	destroy() {}
};
Xa.extension = {
	type: [D.WebGLSystem],
	name: "limits"
};
//#endregion
//#region node_modules/pixi.js/lib/rendering/renderers/gl/GlRenderTarget.mjs
var Za = class {
	constructor() {
		this.width = -1, this.height = -1, this.msaa = !1, this._attachedMipLevel = 0, this._attachedLayer = 0, this.msaaRenderBuffer = [];
	}
}, Qa = class {
	constructor(e) {
		this._stencilCache = {
			enabled: !1,
			stencilReference: 0,
			stencilMode: Fe.NONE
		}, this._renderTargetStencilState = /* @__PURE__ */ Object.create(null), e.renderTarget.onRenderTargetChange.add(this);
	}
	contextChange(e) {
		this._gl = e, this._comparisonFuncMapping = {
			always: e.ALWAYS,
			never: e.NEVER,
			equal: e.EQUAL,
			"not-equal": e.NOTEQUAL,
			less: e.LESS,
			"less-equal": e.LEQUAL,
			greater: e.GREATER,
			"greater-equal": e.GEQUAL
		}, this._stencilOpsMapping = {
			keep: e.KEEP,
			zero: e.ZERO,
			replace: e.REPLACE,
			invert: e.INVERT,
			"increment-clamp": e.INCR,
			"decrement-clamp": e.DECR,
			"increment-wrap": e.INCR_WRAP,
			"decrement-wrap": e.DECR_WRAP
		}, this.resetState();
	}
	onRenderTargetChange(e) {
		if (this._activeRenderTarget === e) return;
		this._activeRenderTarget = e;
		let t = this._renderTargetStencilState[e.uid];
		t ||= this._renderTargetStencilState[e.uid] = {
			stencilMode: Fe.DISABLED,
			stencilReference: 0
		}, this.setStencilMode(t.stencilMode, t.stencilReference);
	}
	resetState() {
		this._stencilCache.enabled = !1, this._stencilCache.stencilMode = Fe.NONE, this._stencilCache.stencilReference = 0;
	}
	setStencilMode(e, t) {
		let n = this._renderTargetStencilState[this._activeRenderTarget.uid], r = this._gl, i = Xe[e], a = this._stencilCache;
		if (n.stencilMode = e, n.stencilReference = t, e === Fe.DISABLED) {
			this._stencilCache.enabled && (this._stencilCache.enabled = !1, r.disable(r.STENCIL_TEST));
			return;
		}
		this._stencilCache.enabled || (this._stencilCache.enabled = !0, r.enable(r.STENCIL_TEST)), (e !== a.stencilMode || a.stencilReference !== t) && (a.stencilMode = e, a.stencilReference = t, r.stencilFunc(this._comparisonFuncMapping[i.stencilBack.compare], t, 255), r.stencilOp(r.KEEP, r.KEEP, this._stencilOpsMapping[i.stencilBack.passOp]));
	}
};
Qa.extension = {
	type: [D.WebGLSystem],
	name: "stencil"
};
//#endregion
//#region node_modules/pixi.js/lib/rendering/renderers/gl/shader/utils/createUboElementsSTD40.mjs
var $a = {
	f32: 4,
	i32: 4,
	"vec2<f32>": 8,
	"vec3<f32>": 12,
	"vec4<f32>": 16,
	"vec2<i32>": 8,
	"vec3<i32>": 12,
	"vec4<i32>": 16,
	u32: 4,
	"vec2<u32>": 8,
	"vec3<u32>": 12,
	"vec4<u32>": 16,
	"mat2x2<f32>": 32,
	"mat3x3<f32>": 48,
	"mat4x4<f32>": 64
};
function eo(e) {
	let t = e.map((e) => ({
		data: e,
		offset: 0,
		size: 0
	})), n = 0, r = 0;
	for (let e = 0; e < t.length; e++) {
		let i = t[e];
		if (n = $a[i.data.type], !n) throw Error(`Unknown type ${i.data.type}`);
		i.data.size > 1 && (n = Math.max(n, 16) * i.data.size);
		let a = n === 12 ? 16 : n;
		i.size = n;
		let o = r % 16;
		o > 0 && 16 - o < a ? r += (16 - o) % 16 : r += (n - o % n) % n, i.offset = r, r += n;
	}
	return r = Math.ceil(r / 16) * 16, {
		uboElements: t,
		size: r
	};
}
//#endregion
//#region node_modules/pixi.js/lib/rendering/renderers/gl/shader/utils/generateArraySyncSTD40.mjs
function to(e, t) {
	let n = Math.max($a[e.data.type] / 16, 1), r = e.data.value.length / e.data.size, i = (4 - r % 4) % 4, a = e.data.type.indexOf("i32") >= 0 ? "dataInt32" : "data";
	return `
        v = uv.${e.data.name};
        offset += ${t};

        arrayOffset = offset;

        t = 0;

        for(var i=0; i < ${e.data.size * n}; i++)
        {
            for(var j = 0; j < ${r}; j++)
            {
                ${a}[arrayOffset++] = v[t++];
            }
            ${i === 0 ? "" : `arrayOffset += ${i};`}
        }
    `;
}
//#endregion
//#region node_modules/pixi.js/lib/rendering/renderers/gl/shader/utils/createUboSyncSTD40.mjs
function no(e) {
	return We(e, Ke, to);
}
//#endregion
//#region node_modules/pixi.js/lib/rendering/renderers/gl/GlUboSystem.mjs
var ro = class extends qe {
	constructor() {
		super({
			createUboElements: eo,
			generateUboSync: no
		});
	}
};
ro.extension = {
	type: [D.WebGLSystem],
	name: "ubo"
};
//#endregion
//#region node_modules/pixi.js/lib/rendering/renderers/gl/renderTarget/GlRenderTargetAdaptor.mjs
var io = class {
	constructor() {
		this._clearColorCache = [
			0,
			0,
			0,
			0
		], this._viewPortCache = new l(), this._boundFramebuffer = void 0;
	}
	init(e, t) {
		this._renderer = e, this._renderTargetSystem = t, e.runners.contextChange.add(this);
	}
	contextChange() {
		this._clearColorCache = [
			0,
			0,
			0,
			0
		], this._viewPortCache = new l(), this._boundFramebuffer = void 0;
		let e = this._renderer.gl;
		this._drawBuffersCache = [];
		for (let t = 1; t <= 16; t++) this._drawBuffersCache[t] = Array.from({ length: t }, (t, n) => e.COLOR_ATTACHMENT0 + n);
	}
	copyToTexture(e, t, n, r, i) {
		let a = this._renderTargetSystem, o = this._renderer, s = a.getGpuRenderTarget(e), c = o.gl;
		return this.finishRenderPass(e), c.bindFramebuffer(c.FRAMEBUFFER, s.resolveTargetFramebuffer), this._boundFramebuffer = s.resolveTargetFramebuffer, o.texture.bind(t, 0), c.copyTexSubImage2D(c.TEXTURE_2D, 0, i.x, i.y, n.x, n.y, r.width, r.height), t;
	}
	copyDepthTexture(e, t, n, r, i) {
		let a = this._renderTargetSystem, o = this._renderer.gl;
		this.finishRenderPass(e);
		let s = a.getRenderTarget(t), c = a.getGpuRenderTarget(e), l = a.getGpuRenderTarget(s);
		o.bindFramebuffer(o.READ_FRAMEBUFFER, c.framebuffer), o.bindFramebuffer(o.DRAW_FRAMEBUFFER, l.framebuffer), this._boundFramebuffer = void 0, o.blitFramebuffer(n.x, n.y, n.x + r.width, n.y + r.height, i.x, i.y, i.x + r.width, i.y + r.height, o.DEPTH_BUFFER_BIT, o.NEAREST);
	}
	startRenderPass(e, t = !0, n, r, i = 0, a = 0) {
		let o = this._renderTargetSystem.getGpuRenderTarget(e);
		if (a !== 0 && this._renderer.context.webGLVersion < 2) throw Error("[RenderTargetSystem] Rendering to array layers requires WebGL2.");
		if (i > 0) {
			if (o.msaa) throw Error("[RenderTargetSystem] Rendering to mip levels is not supported with MSAA render targets.");
			if (this._renderer.context.webGLVersion < 2) throw Error("[RenderTargetSystem] Rendering to mip levels requires WebGL2.");
		}
		e.colorAttachments.forEach((e) => {
			this._renderer.texture.unbind(e.texture);
		});
		let s = this._renderer.gl;
		this.bindFramebuffer(o.framebuffer), !e.isRoot && e.colorAttachments.length > 0 && (o._attachedMipLevel !== i || o._attachedLayer !== a) && (e.colorAttachments.forEach((e, t) => {
			let n = e.texture, r = this._renderer.texture.getGlSource(n);
			if (r.target === s.TEXTURE_2D) {
				if (a !== 0) throw Error("[RenderTargetSystem] layer must be 0 when rendering to 2D textures in WebGL.");
				s.framebufferTexture2D(s.FRAMEBUFFER, s.COLOR_ATTACHMENT0 + t, s.TEXTURE_2D, r.texture, i);
			} else if (r.target === s.TEXTURE_2D_ARRAY) {
				if (this._renderer.context.webGLVersion < 2) throw Error("[RenderTargetSystem] Rendering to 2D array textures requires WebGL2.");
				s.framebufferTextureLayer(s.FRAMEBUFFER, s.COLOR_ATTACHMENT0 + t, r.texture, i, a);
			} else if (r.target === s.TEXTURE_CUBE_MAP) {
				if (a < 0 || a > 5) throw Error("[RenderTargetSystem] Cube map layer must be between 0 and 5.");
				s.framebufferTexture2D(s.FRAMEBUFFER, s.COLOR_ATTACHMENT0 + t, s.TEXTURE_CUBE_MAP_POSITIVE_X + a, r.texture, i);
			} else throw Error("[RenderTargetSystem] Unsupported texture target for render-to-layer in WebGL.");
		}), o._attachedMipLevel = i, o._attachedLayer = a), o.framebuffer && (e.depthStencilAttachment ? this._attachDepthStencilTexture(e, i, a) : !o.depthStencilRenderBuffer && (e.stencil || e.depth) && this._initStencil(o)), e.colorAttachments.length > 1 && this._setDrawBuffers(e, s);
		let c = r.y;
		e.isRoot && (c = e.pixelHeight - r.height - r.y);
		let l = this._viewPortCache;
		(l.x !== r.x || l.y !== c || l.width !== r.width || l.height !== r.height) && (l.x = r.x, l.y = c, l.width = r.width, l.height = r.height, s.viewport(r.x, c, r.width, r.height)), this.clear(e, t, n);
	}
	finishRenderPass(e) {
		let t = this._renderTargetSystem.getGpuRenderTarget(e);
		if (!t.msaa || e.colorAttachments.length === 0) return;
		let n = this._renderer.gl;
		n.bindFramebuffer(n.FRAMEBUFFER, t.resolveTargetFramebuffer), n.bindFramebuffer(n.READ_FRAMEBUFFER, t.framebuffer), n.blitFramebuffer(0, 0, t.width, t.height, 0, 0, t.width, t.height, n.COLOR_BUFFER_BIT, n.NEAREST), n.bindFramebuffer(n.FRAMEBUFFER, t.framebuffer), this._boundFramebuffer = t.framebuffer;
	}
	initGpuRenderTarget(e) {
		let t = this._renderer.gl, n = new Za();
		n._attachedMipLevel = 0, n._attachedLayer = 0;
		let r = e.colorTexture;
		return r instanceof L ? (this._renderer.context.ensureCanvasSize(r.resource), n.framebuffer = null, n) : (n.width = e.pixelWidth, n.height = e.pixelHeight, e.colorAttachments.length === 0 ? this._initDepth(e, n) : this._initColor(e, n), e.depthStencilAttachment && this._attachDepthStencilTexture(e, 0, 0), t.bindFramebuffer(t.FRAMEBUFFER, null), this._boundFramebuffer = null, n);
	}
	destroyGpuRenderTarget(e) {
		let t = this._renderer.gl;
		e.framebuffer &&= (t.deleteFramebuffer(e.framebuffer), null), e.resolveTargetFramebuffer &&= (t.deleteFramebuffer(e.resolveTargetFramebuffer), null), e.depthStencilRenderBuffer &&= (t.deleteRenderbuffer(e.depthStencilRenderBuffer), null), e.msaaRenderBuffer.forEach((e) => {
			t.deleteRenderbuffer(e);
		}), e.msaaRenderBuffer = null;
	}
	clear(e, t, n, r, i = 0, a = 0) {
		if (!t) return;
		if (a !== 0) throw Error("[RenderTargetSystem] Clearing array layers is not supported in WebGL renderer.");
		let o = this._renderTargetSystem;
		if (typeof t == "boolean" && (t = t ? pe.ALL : pe.NONE), e.colorAttachments.length === 0 && (t &= ~pe.COLOR, !t)) return;
		let s = this._renderer.gl, c = !!(t & pe.DEPTH) && !this._renderer.state.depthMaskEnabled;
		if (t & pe.COLOR) {
			n ??= o.defaultClearColor;
			let e = this._clearColorCache, t = n;
			(e[0] !== t[0] || e[1] !== t[1] || e[2] !== t[2] || e[3] !== t[3]) && (e[0] = t[0], e[1] = t[1], e[2] = t[2], e[3] = t[3], s.clearColor(t[0], t[1], t[2], t[3]));
		}
		c && s.depthMask(!0), s.clear(t), c && s.depthMask(!1);
	}
	resizeGpuRenderTarget(e) {
		if (e.isRoot) return;
		let t = this._renderTargetSystem.getGpuRenderTarget(e);
		t.width = e.pixelWidth, t.height = e.pixelHeight, e.colorAttachments.length > 0 && this._resizeColor(e, t), t.depthStencilRenderBuffer && this._resizeStencil(t), this._boundFramebuffer = void 0;
	}
	_initColor(e, t) {
		let n = this._renderer, r = n.gl, i = r.createFramebuffer();
		if (t.resolveTargetFramebuffer = i, r.bindFramebuffer(r.FRAMEBUFFER, i), e.colorAttachments.forEach((e, i) => {
			let a = e.texture;
			a.antialias && (n.context.supports.msaa ? t.msaa = !0 : u("[RenderTexture] Antialiasing on textures is not supported in WebGL1")), n.texture.bindSource(a, 0);
			let o = n.texture.getGlSource(a), s = o.texture;
			if (o.target === r.TEXTURE_2D) r.framebufferTexture2D(r.FRAMEBUFFER, r.COLOR_ATTACHMENT0 + i, r.TEXTURE_2D, s, 0);
			else if (o.target === r.TEXTURE_2D_ARRAY) {
				if (n.context.webGLVersion < 2) throw Error("[RenderTargetSystem] TEXTURE_2D_ARRAY requires WebGL2.");
				r.framebufferTextureLayer(r.FRAMEBUFFER, r.COLOR_ATTACHMENT0 + i, s, 0, 0);
			} else if (o.target === r.TEXTURE_CUBE_MAP) r.framebufferTexture2D(r.FRAMEBUFFER, r.COLOR_ATTACHMENT0 + i, r.TEXTURE_CUBE_MAP_POSITIVE_X, s, 0);
			else throw Error("[RenderTargetSystem] Unsupported texture target for framebuffer attachment.");
		}), t.msaa) {
			let n = r.createFramebuffer();
			t.framebuffer = n, r.bindFramebuffer(r.FRAMEBUFFER, n), e.colorAttachments.forEach((e, n) => {
				let i = r.createRenderbuffer();
				t.msaaRenderBuffer[n] = i;
			});
		} else t.framebuffer = i;
		this._resizeColor(e, t);
	}
	_initDepth(e, t) {
		let n = this._renderer;
		if (n.context.webGLVersion < 2) throw Error("[RenderTargetSystem] Depth-only render targets require WebGL2.");
		let r = n.gl, i = r.createFramebuffer();
		t.resolveTargetFramebuffer = i, t.framebuffer = i, r.bindFramebuffer(r.FRAMEBUFFER, i), r.drawBuffers([r.NONE]), r.readBuffer(r.NONE);
	}
	_resizeColor(e, t) {
		let n = e.colorAttachments[0].texture;
		if (t._attachedMipLevel = 0, t._attachedLayer = 0, e.colorAttachments.forEach((e, t) => {
			t !== 0 && e.texture.resize(n.width, n.height, n._resolution);
		}), t.msaa) {
			let n = this._renderer, r = n.gl, i = t.framebuffer;
			r.bindFramebuffer(r.FRAMEBUFFER, i), e.colorAttachments.forEach((e, i) => {
				let a = e.texture;
				n.texture.bindSource(a, 0);
				let o = n.texture.getGlSource(a).internalFormat, s = t.msaaRenderBuffer[i];
				r.bindRenderbuffer(r.RENDERBUFFER, s), r.renderbufferStorageMultisample(r.RENDERBUFFER, 4, o, a.pixelWidth, a.pixelHeight), r.framebufferRenderbuffer(r.FRAMEBUFFER, r.COLOR_ATTACHMENT0 + i, r.RENDERBUFFER, s);
			});
		}
	}
	_attachDepthStencilTexture(e, t, n) {
		let r = this._renderer, i = r.gl, a = e.depthStencilAttachment.texture, o = r.texture.getGlSource(a), s = o.texture, c = a.format, l;
		l = c === "depth24plus-stencil8" || c === "depth32float-stencil8" ? i.DEPTH_STENCIL_ATTACHMENT : c === "stencil8" ? i.STENCIL_ATTACHMENT : i.DEPTH_ATTACHMENT, o.target === i.TEXTURE_2D ? i.framebufferTexture2D(i.FRAMEBUFFER, l, i.TEXTURE_2D, s, t) : o.target === i.TEXTURE_2D_ARRAY ? i.framebufferTextureLayer(i.FRAMEBUFFER, l, s, t, n) : o.target === i.TEXTURE_CUBE_MAP && i.framebufferTexture2D(i.FRAMEBUFFER, l, i.TEXTURE_CUBE_MAP_POSITIVE_X + n, s, t);
	}
	_initStencil(e) {
		if (e.framebuffer === null) return;
		let t = this._renderer.gl, n = t.createRenderbuffer();
		e.depthStencilRenderBuffer = n, t.bindRenderbuffer(t.RENDERBUFFER, n), t.framebufferRenderbuffer(t.FRAMEBUFFER, t.DEPTH_STENCIL_ATTACHMENT, t.RENDERBUFFER, n), this._resizeStencil(e);
	}
	_resizeStencil(e) {
		let t = this._renderer.gl;
		t.bindRenderbuffer(t.RENDERBUFFER, e.depthStencilRenderBuffer), e.msaa ? t.renderbufferStorageMultisample(t.RENDERBUFFER, 4, t.DEPTH24_STENCIL8, e.width, e.height) : t.renderbufferStorage(t.RENDERBUFFER, this._renderer.context.webGLVersion === 2 ? t.DEPTH24_STENCIL8 : t.DEPTH_STENCIL, e.width, e.height);
	}
	prerender(e) {
		if (e.colorAttachments.length === 0) return;
		let t = e.colorAttachments[0].texture.resource;
		this._renderer.context.multiView && L.test(t) && this._renderer.context.ensureCanvasSize(t);
	}
	postrender(e) {
		if (!this._renderer.context.multiView || e.colorAttachments.length === 0) return;
		let t = e.colorAttachments[0].texture;
		if (L.test(t.resource)) {
			let e = this._renderer.context.canvas, n = t;
			n.context2D.drawImage(e, 0, n.pixelHeight - e.height);
		}
	}
	_setDrawBuffers(e, t) {
		let n = e.colorAttachments.length, r = this._drawBuffersCache[n];
		if (this._renderer.context.webGLVersion === 1) {
			let e = this._renderer.context.extensions.drawBuffers;
			e ? e.drawBuffersWEBGL(r) : u("[RenderTexture] This WebGL1 context does not support rendering to multiple targets");
		} else t.drawBuffers(r);
	}
	resetState() {
		this._boundFramebuffer = void 0, this._viewPortCache = new l(), this._clearColorCache = [
			0,
			0,
			0,
			0
		];
	}
	bindFramebuffer(e) {
		this._boundFramebuffer !== e && (this._boundFramebuffer = e, this._renderer.gl.bindFramebuffer(this._renderer.gl.FRAMEBUFFER, e));
	}
}, ao = class extends Me {
	constructor(e) {
		super(e), this.adaptor = new io(), this.adaptor.init(e, this);
	}
	resetState() {
		this.adaptor.resetState();
	}
};
ao.extension = {
	type: [D.WebGLSystem],
	name: "renderTarget"
};
//#endregion
//#region node_modules/pixi.js/lib/rendering/renderers/shared/texture/TextureView.mjs
var oo = class extends j {
	constructor(e, t) {
		super(), this._resourceType = "textureView", this._resourceId = _("resource"), this._touched = 0, this.source = e, this.viewDescriptor = t, this._onChange = this._onChange.bind(this), this._onDestroy = this._onDestroy.bind(this), this.source.on("change", this._onChange), this.source.on("destroy", this._onDestroy);
	}
	_onChange() {
		this.emit("change", this);
	}
	_onDestroy() {
		this.destroy();
	}
	get destroyed() {
		return this.source.destroyed;
	}
	destroy() {
		this.source && (this.source.off("change", this._onChange), this.source.off("destroy", this._onDestroy)), this.emit("destroy", this), this.removeAllListeners();
	}
};
//#endregion
//#region node_modules/pixi.js/lib/rendering/renderers/gl/shader/GenerateShaderSyncCode.mjs
function so(e, t) {
	let n = [], r = ["\n        var g = s.groups;\n        var sS = r.shader;\n        var p = s.glProgram;\n        var ugS = r.uniformGroup;\n        var resources;\n    "], i = !1, a = 0, o = t._getProgramData(e.glProgram);
	for (let s in e.groups) {
		let c = e.groups[s];
		n.push(`
            resources = g[${s}].resources;
        `);
		for (let l in c.resources) {
			let u = c.resources[l];
			if (u instanceof C) {
				if (u.ubo) {
					let t = e._uniformBindMap[s][Number(l)];
					n.push(`
                        sS.bindUniformBlock(
                            resources[${l}],
                            '${t}',
                            ${e.glProgram._uniformBlockData[t].index}
                        );
                    `);
				} else n.push(`
                        ugS.updateUniformGroup(resources[${l}], p, sD);
                    `);
			} else if (u instanceof Ze) {
				let t = e._uniformBindMap[s][Number(l)];
				n.push(`
                    sS.bindUniformBlock(
                        resources[${l}],
                        '${t}',
                        ${e.glProgram._uniformBlockData[t].index}
                    );
                `);
			} else if (u instanceof m || u instanceof oo) {
				let c = e._uniformBindMap[s][l], u = o.uniformData[c];
				u && (i || (i = !0, r.push("\n                        var tS = r.texture;\n                        ")), t._gl.uniform1i(u.location, a), n.push(`
                        tS.bind(resources[${l}], ${a});
                    `), a++);
			}
		}
	}
	let s = [...r, ...n].join("\n");
	return Function("r", "s", "sD", s);
}
//#endregion
//#region node_modules/pixi.js/lib/rendering/renderers/gl/shader/GlProgramData.mjs
var co = class {
	constructor(e, t) {
		this.program = e, this.uniformData = t, this.uniformGroups = {}, this.uniformDirtyGroups = {}, this.uniformBlockBindings = {};
	}
	destroy() {
		this.uniformData = null, this.uniformGroups = null, this.uniformDirtyGroups = null, this.uniformBlockBindings = null, this.program = null;
	}
};
//#endregion
//#region node_modules/pixi.js/lib/rendering/renderers/gl/shader/program/compileShader.mjs
function lo(e, t, n) {
	let r = e.createShader(t);
	return e.shaderSource(r, n), e.compileShader(r), r;
}
//#endregion
//#region node_modules/pixi.js/lib/rendering/renderers/gl/shader/program/defaultValue.mjs
function uo(e) {
	let t = Array(e);
	for (let e = 0; e < t.length; e++) t[e] = !1;
	return t;
}
function fo(e, t) {
	switch (e) {
		case "float": return 0;
		case "vec2": return new Float32Array(2 * t);
		case "vec3": return new Float32Array(3 * t);
		case "vec4": return new Float32Array(4 * t);
		case "int":
		case "uint":
		case "sampler2D":
		case "sampler2DArray": return 0;
		case "ivec2": return new Int32Array(2 * t);
		case "ivec3": return new Int32Array(3 * t);
		case "ivec4": return new Int32Array(4 * t);
		case "uvec2": return new Uint32Array(2 * t);
		case "uvec3": return new Uint32Array(3 * t);
		case "uvec4": return new Uint32Array(4 * t);
		case "bool": return !1;
		case "bvec2": return uo(2 * t);
		case "bvec3": return uo(3 * t);
		case "bvec4": return uo(4 * t);
		case "mat2": return new Float32Array([
			1,
			0,
			0,
			1
		]);
		case "mat3": return new Float32Array([
			1,
			0,
			0,
			0,
			1,
			0,
			0,
			0,
			1
		]);
		case "mat4": return new Float32Array([
			1,
			0,
			0,
			0,
			0,
			1,
			0,
			0,
			0,
			0,
			1,
			0,
			0,
			0,
			0,
			1
		]);
	}
	return null;
}
//#endregion
//#region node_modules/pixi.js/lib/rendering/renderers/gl/shader/program/mapType.mjs
var po = null, mo = {
	FLOAT: "float",
	FLOAT_VEC2: "vec2",
	FLOAT_VEC3: "vec3",
	FLOAT_VEC4: "vec4",
	INT: "int",
	INT_VEC2: "ivec2",
	INT_VEC3: "ivec3",
	INT_VEC4: "ivec4",
	UNSIGNED_INT: "uint",
	UNSIGNED_INT_VEC2: "uvec2",
	UNSIGNED_INT_VEC3: "uvec3",
	UNSIGNED_INT_VEC4: "uvec4",
	BOOL: "bool",
	BOOL_VEC2: "bvec2",
	BOOL_VEC3: "bvec3",
	BOOL_VEC4: "bvec4",
	FLOAT_MAT2: "mat2",
	FLOAT_MAT3: "mat3",
	FLOAT_MAT4: "mat4",
	SAMPLER_2D: "sampler2D",
	INT_SAMPLER_2D: "sampler2D",
	UNSIGNED_INT_SAMPLER_2D: "sampler2D",
	SAMPLER_2D_SHADOW: "sampler2DShadow",
	SAMPLER_CUBE: "samplerCube",
	INT_SAMPLER_CUBE: "samplerCube",
	UNSIGNED_INT_SAMPLER_CUBE: "samplerCube",
	SAMPLER_CUBE_SHADOW: "samplerCubeShadow",
	SAMPLER_2D_ARRAY: "sampler2DArray",
	INT_SAMPLER_2D_ARRAY: "sampler2DArray",
	UNSIGNED_INT_SAMPLER_2D_ARRAY: "sampler2DArray",
	SAMPLER_2D_ARRAY_SHADOW: "sampler2DArrayShadow"
}, ho = {
	float: "float32",
	vec2: "float32x2",
	vec3: "float32x3",
	vec4: "float32x4",
	int: "sint32",
	ivec2: "sint32x2",
	ivec3: "sint32x3",
	ivec4: "sint32x4",
	uint: "uint32",
	uvec2: "uint32x2",
	uvec3: "uint32x3",
	uvec4: "uint32x4",
	bool: "uint32",
	bvec2: "uint32x2",
	bvec3: "uint32x3",
	bvec4: "uint32x4"
};
function go(e, t) {
	if (!po) {
		let t = Object.keys(mo);
		po = {};
		for (let n = 0; n < t.length; ++n) {
			let r = t[n];
			po[e[r]] = mo[r];
		}
	}
	return po[t];
}
function _o(e, t) {
	return ho[go(e, t)] || "float32";
}
//#endregion
//#region node_modules/pixi.js/lib/rendering/renderers/gl/shader/program/extractAttributesFromGlProgram.mjs
function vo(e, t, n = !1) {
	let r = {}, i = t.getProgramParameter(e, t.ACTIVE_ATTRIBUTES);
	for (let n = 0; n < i; n++) {
		let i = t.getActiveAttrib(e, n);
		if (i.name.startsWith("gl_")) continue;
		let a = _o(t, i.type);
		r[i.name] = {
			location: 0,
			format: a,
			stride: ee(a).stride,
			offset: 0,
			instance: !1,
			start: 0
		};
	}
	let a = Object.keys(r);
	if (n) {
		a.sort((e, t) => e > t ? 1 : -1);
		for (let n = 0; n < a.length; n++) r[a[n]].location = n, t.bindAttribLocation(e, n, a[n]);
		t.linkProgram(e);
	} else for (let n = 0; n < a.length; n++) r[a[n]].location = t.getAttribLocation(e, a[n]);
	return r;
}
//#endregion
//#region node_modules/pixi.js/lib/rendering/renderers/gl/shader/program/getUboData.mjs
function yo(e, t) {
	if (!t.ACTIVE_UNIFORM_BLOCKS) return {};
	let n = {}, r = t.getProgramParameter(e, t.ACTIVE_UNIFORM_BLOCKS);
	for (let i = 0; i < r; i++) {
		let r = t.getActiveUniformBlockName(e, i);
		n[r] = {
			name: r,
			index: t.getUniformBlockIndex(e, r),
			size: t.getActiveUniformBlockParameter(e, i, t.UNIFORM_BLOCK_DATA_SIZE)
		};
	}
	return n;
}
//#endregion
//#region node_modules/pixi.js/lib/rendering/renderers/gl/shader/program/getUniformData.mjs
function bo(e, t) {
	let n = {}, r = t.getProgramParameter(e, t.ACTIVE_UNIFORMS);
	for (let i = 0; i < r; i++) {
		let r = t.getActiveUniform(e, i), a = r.name.replace(/\[.*?\]$/, ""), o = !!r.name.match(/\[.*?\]$/), s = go(t, r.type);
		n[a] = {
			name: a,
			index: i,
			type: s,
			size: r.size,
			isArray: o,
			value: fo(s, r.size)
		};
	}
	return n;
}
//#endregion
//#region node_modules/pixi.js/lib/rendering/renderers/gl/shader/program/logProgramError.mjs
function xo(e, t) {
	let n = e.getShaderSource(t);
	if (n === null) {
		console.error("PixiJS Error: Could not retrieve shader source (WebGL context may be lost).");
		return;
	}
	let r = n.split("\n").map((e, t) => `${t}: ${e}`), i = e.getShaderInfoLog(t) ?? "", a = i.split("\n"), o = {}, s = a.map((e) => parseFloat(e.replace(/^ERROR\: 0\:([\d]+)\:.*$/, "$1"))).filter((e) => e && !o[e] ? (o[e] = !0, !0) : !1), c = [""];
	s.forEach((e) => {
		r[e - 1] = `%c${r[e - 1]}%c`, c.push("background: #FF0000; color:#FFFFFF; font-size: 10px", "font-size: 10px");
	}), c[0] = r.join("\n"), console.error(i), console.groupCollapsed("click to view full shader code"), console.warn(...c), console.groupEnd();
}
function So(e, t, n, r) {
	e.getProgramParameter(t, e.LINK_STATUS) || (e.getShaderParameter(n, e.COMPILE_STATUS) || xo(e, n), e.getShaderParameter(r, e.COMPILE_STATUS) || xo(e, r), console.error("PixiJS Error: Could not initialize shader."), e.getProgramInfoLog(t) !== "" && console.warn("PixiJS Warning: gl.getProgramInfoLog()", e.getProgramInfoLog(t)));
}
//#endregion
//#region node_modules/pixi.js/lib/rendering/renderers/gl/shader/program/generateProgram.mjs
function Co(e, t) {
	let n = lo(e, e.VERTEX_SHADER, t.vertex), r = lo(e, e.FRAGMENT_SHADER, t.fragment), i = e.createProgram();
	e.attachShader(i, n), e.attachShader(i, r);
	let a = t.transformFeedbackVaryings;
	a && (typeof e.transformFeedbackVaryings == "function" ? e.transformFeedbackVaryings(i, a.names, a.bufferMode === "separate" ? e.SEPARATE_ATTRIBS : e.INTERLEAVED_ATTRIBS) : u("TransformFeedback is not supported but TransformFeedbackVaryings are given.")), e.linkProgram(i), e.getProgramParameter(i, e.LINK_STATUS) || So(e, i, n, r), t._attributeData = vo(i, e, !/^[ \t]*#[ \t]*version[ \t]+300[ \t]+es[ \t]*$/m.test(t.vertex)), t._uniformData = bo(i, e), t._uniformBlockData = yo(i, e), e.deleteShader(n), e.deleteShader(r);
	let o = {};
	for (let n in t._uniformData) {
		let r = t._uniformData[n];
		o[n] = {
			location: e.getUniformLocation(i, n),
			value: fo(r.type, r.size)
		};
	}
	return new co(i, o);
}
//#endregion
//#region node_modules/pixi.js/lib/rendering/renderers/gl/shader/GlShaderSystem.mjs
var wo = {
	textureCount: 0,
	blockIndex: 0
}, To = class {
	constructor(e) {
		this._activeProgram = null, this._programDataHash = /* @__PURE__ */ Object.create(null), this._shaderSyncFunctions = /* @__PURE__ */ Object.create(null), this._renderer = e;
	}
	contextChange(e) {
		this._gl = e, this._programDataHash = /* @__PURE__ */ Object.create(null), this._shaderSyncFunctions = /* @__PURE__ */ Object.create(null), this._activeProgram = null;
	}
	bind(e, t) {
		if (this._setProgram(e.glProgram), t) return;
		wo.textureCount = 0, wo.blockIndex = 0;
		let n = this._shaderSyncFunctions[e.glProgram._key];
		n ||= this._shaderSyncFunctions[e.glProgram._key] = this._generateShaderSync(e, this), this._renderer.buffer.nextBindBase(!!e.glProgram.transformFeedbackVaryings), n(this._renderer, e, wo);
	}
	updateUniformGroup(e) {
		this._renderer.uniformGroup.updateUniformGroup(e, this._activeProgram, wo);
	}
	bindUniformBlock(e, t, n = 0) {
		let r = this._renderer.buffer, i = this._getProgramData(this._activeProgram), a = e._bufferResource;
		a || this._renderer.ubo.updateUniformGroup(e);
		let o = e.buffer, s = r.updateBuffer(o), c = r.freeLocationForBufferBase(s);
		if (a) {
			let { offset: t, size: n } = e;
			t === 0 && n === o.data.byteLength ? r.bindBufferBase(s, c) : r.bindBufferRange(s, c, t);
		} else r.getLastBindBaseLocation(s) !== c && r.bindBufferBase(s, c);
		let l = this._activeProgram._uniformBlockData[t].index;
		i.uniformBlockBindings[n] !== c && (i.uniformBlockBindings[n] = c, this._renderer.gl.uniformBlockBinding(i.program, l, c));
	}
	_setProgram(e) {
		if (this._activeProgram === e) return;
		this._activeProgram = e;
		let t = this._getProgramData(e);
		this._gl.useProgram(t.program);
	}
	_getProgramData(e) {
		return this._programDataHash[e._key] || this._createProgramData(e);
	}
	_createProgramData(e) {
		let t = e._key;
		return this._programDataHash[t] = Co(this._gl, e), this._programDataHash[t];
	}
	destroy() {
		for (let e of Object.keys(this._programDataHash)) this._programDataHash[e].destroy();
		this._programDataHash = null, this._shaderSyncFunctions = null, this._activeProgram = null, this._renderer = null, this._gl = null;
	}
	_generateShaderSync(e, t) {
		return so(e, t);
	}
	resetState() {
		this._activeProgram = null;
	}
};
To.extension = {
	type: [D.WebGLSystem],
	name: "shader"
};
//#endregion
//#region node_modules/pixi.js/lib/rendering/renderers/gl/shader/utils/generateUniformsSyncTypes.mjs
var Eo = {
	f32: "if (cv !== v) {\n            cu.value = v;\n            gl.uniform1f(location, v);\n        }",
	"vec2<f32>": "if (cv[0] !== v[0] || cv[1] !== v[1]) {\n            cv[0] = v[0];\n            cv[1] = v[1];\n            gl.uniform2f(location, v[0], v[1]);\n        }",
	"vec3<f32>": "if (cv[0] !== v[0] || cv[1] !== v[1] || cv[2] !== v[2]) {\n            cv[0] = v[0];\n            cv[1] = v[1];\n            cv[2] = v[2];\n            gl.uniform3f(location, v[0], v[1], v[2]);\n        }",
	"vec4<f32>": "if (cv[0] !== v[0] || cv[1] !== v[1] || cv[2] !== v[2] || cv[3] !== v[3]) {\n            cv[0] = v[0];\n            cv[1] = v[1];\n            cv[2] = v[2];\n            cv[3] = v[3];\n            gl.uniform4f(location, v[0], v[1], v[2], v[3]);\n        }",
	i32: "if (cv !== v) {\n            cu.value = v;\n            gl.uniform1i(location, v);\n        }",
	"vec2<i32>": "if (cv[0] !== v[0] || cv[1] !== v[1]) {\n            cv[0] = v[0];\n            cv[1] = v[1];\n            gl.uniform2i(location, v[0], v[1]);\n        }",
	"vec3<i32>": "if (cv[0] !== v[0] || cv[1] !== v[1] || cv[2] !== v[2]) {\n            cv[0] = v[0];\n            cv[1] = v[1];\n            cv[2] = v[2];\n            gl.uniform3i(location, v[0], v[1], v[2]);\n        }",
	"vec4<i32>": "if (cv[0] !== v[0] || cv[1] !== v[1] || cv[2] !== v[2] || cv[3] !== v[3]) {\n            cv[0] = v[0];\n            cv[1] = v[1];\n            cv[2] = v[2];\n            cv[3] = v[3];\n            gl.uniform4i(location, v[0], v[1], v[2], v[3]);\n        }",
	u32: "if (cv !== v) {\n            cu.value = v;\n            gl.uniform1ui(location, v);\n        }",
	"vec2<u32>": "if (cv[0] !== v[0] || cv[1] !== v[1]) {\n            cv[0] = v[0];\n            cv[1] = v[1];\n            gl.uniform2ui(location, v[0], v[1]);\n        }",
	"vec3<u32>": "if (cv[0] !== v[0] || cv[1] !== v[1] || cv[2] !== v[2]) {\n            cv[0] = v[0];\n            cv[1] = v[1];\n            cv[2] = v[2];\n            gl.uniform3ui(location, v[0], v[1], v[2]);\n        }",
	"vec4<u32>": "if (cv[0] !== v[0] || cv[1] !== v[1] || cv[2] !== v[2] || cv[3] !== v[3]) {\n            cv[0] = v[0];\n            cv[1] = v[1];\n            cv[2] = v[2];\n            cv[3] = v[3];\n            gl.uniform4ui(location, v[0], v[1], v[2], v[3]);\n        }",
	bool: "if (cv !== v) {\n            cu.value = v;\n            gl.uniform1i(location, v);\n        }",
	"vec2<bool>": "if (cv[0] !== v[0] || cv[1] !== v[1]) {\n            cv[0] = v[0];\n            cv[1] = v[1];\n            gl.uniform2i(location, v[0], v[1]);\n        }",
	"vec3<bool>": "if (cv[0] !== v[0] || cv[1] !== v[1] || cv[2] !== v[2]) {\n            cv[0] = v[0];\n            cv[1] = v[1];\n            cv[2] = v[2];\n            gl.uniform3i(location, v[0], v[1], v[2]);\n        }",
	"vec4<bool>": "if (cv[0] !== v[0] || cv[1] !== v[1] || cv[2] !== v[2] || cv[3] !== v[3]) {\n            cv[0] = v[0];\n            cv[1] = v[1];\n            cv[2] = v[2];\n            cv[3] = v[3];\n            gl.uniform4i(location, v[0], v[1], v[2], v[3]);\n        }",
	"mat2x2<f32>": "gl.uniformMatrix2fv(location, false, v);",
	"mat3x3<f32>": "gl.uniformMatrix3fv(location, false, v);",
	"mat4x4<f32>": "gl.uniformMatrix4fv(location, false, v);"
}, Do = {
	f32: "gl.uniform1fv(location, v);",
	"vec2<f32>": "gl.uniform2fv(location, v);",
	"vec3<f32>": "gl.uniform3fv(location, v);",
	"vec4<f32>": "gl.uniform4fv(location, v);",
	"mat2x2<f32>": "gl.uniformMatrix2fv(location, false, v);",
	"mat3x3<f32>": "gl.uniformMatrix3fv(location, false, v);",
	"mat4x4<f32>": "gl.uniformMatrix4fv(location, false, v);",
	i32: "gl.uniform1iv(location, v);",
	"vec2<i32>": "gl.uniform2iv(location, v);",
	"vec3<i32>": "gl.uniform3iv(location, v);",
	"vec4<i32>": "gl.uniform4iv(location, v);",
	u32: "gl.uniform1iv(location, v);",
	"vec2<u32>": "gl.uniform2iv(location, v);",
	"vec3<u32>": "gl.uniform3iv(location, v);",
	"vec4<u32>": "gl.uniform4iv(location, v);",
	bool: "gl.uniform1iv(location, v);",
	"vec2<bool>": "gl.uniform2iv(location, v);",
	"vec3<bool>": "gl.uniform3iv(location, v);",
	"vec4<bool>": "gl.uniform4iv(location, v);"
};
//#endregion
//#region node_modules/pixi.js/lib/rendering/renderers/gl/shader/utils/generateUniformsSync.mjs
function Oo(e, t) {
	let n = ["\n        var v = null;\n        var cv = null;\n        var cu = null;\n        var t = 0;\n        var gl = renderer.gl;\n        var name = null;\n    "];
	for (let r in e.uniforms) {
		if (!t[r]) {
			e.uniforms[r] instanceof C ? e.uniforms[r].ubo ? n.push(`
                        renderer.shader.bindUniformBlock(uv.${r}, "${r}");
                    `) : n.push(`
                        renderer.shader.updateUniformGroup(uv.${r});
                    `) : e.uniforms[r] instanceof Ze && n.push(`
                        renderer.shader.bindBufferResource(uv.${r}, "${r}");
                    `);
			continue;
		}
		let i = e.uniformStructures[r], a = !1;
		for (let e = 0; e < Be.length; e++) {
			let t = Be[e];
			if (i.type === t.type && t.test(i)) {
				n.push(`name = "${r}";`, Be[e].uniform), a = !0;
				break;
			}
		}
		if (!a) {
			let e = (i.size === 1 ? Eo : Do)[i.type].replace("location", `ud["${r}"].location`);
			n.push(`
            cu = ud["${r}"];
            cv = cu.value;
            v = uv["${r}"];
            ${e};`);
		}
	}
	return Function("ud", "uv", "renderer", "syncData", n.join("\n"));
}
//#endregion
//#region node_modules/pixi.js/lib/rendering/renderers/gl/shader/GlUniformGroupSystem.mjs
var ko = class {
	constructor(e) {
		this._cache = {}, this._uniformGroupSyncHash = {}, this._renderer = e, this.gl = null, this._cache = {};
	}
	contextChange(e) {
		this.gl = e;
	}
	updateUniformGroup(e, t, n) {
		let r = this._renderer.shader._getProgramData(t);
		(!e.isStatic || e._dirtyId !== r.uniformDirtyGroups[e.uid]) && (r.uniformDirtyGroups[e.uid] = e._dirtyId, this._getUniformSyncFunction(e, t)(r.uniformData, e.uniforms, this._renderer, n));
	}
	_getUniformSyncFunction(e, t) {
		return this._uniformGroupSyncHash[e._signature]?.[t._key] || this._createUniformSyncFunction(e, t);
	}
	_createUniformSyncFunction(e, t) {
		let n = this._uniformGroupSyncHash[e._signature] || (this._uniformGroupSyncHash[e._signature] = {}), r = this._getSignature(e, t._uniformData, "u");
		return this._cache[r] || (this._cache[r] = this._generateUniformsSync(e, t._uniformData)), n[t._key] = this._cache[r], n[t._key];
	}
	_generateUniformsSync(e, t) {
		return Oo(e, t);
	}
	_getSignature(e, t, n) {
		let r = e.uniforms, i = [`${n}-`];
		for (let e in r) i.push(e), t[e] && i.push(t[e].type);
		return i.join("-");
	}
	destroy() {
		this._renderer = null, this._cache = null;
	}
};
ko.extension = {
	type: [D.WebGLSystem],
	name: "uniformGroup"
};
//#endregion
//#region node_modules/pixi.js/lib/rendering/renderers/gl/state/mapWebGLBlendModesToPixi.mjs
function Ao(e) {
	let t = {};
	if (t.normal = [e.ONE, e.ONE_MINUS_SRC_ALPHA], t.add = [e.ONE, e.ONE], t.multiply = [
		e.DST_COLOR,
		e.ONE_MINUS_SRC_ALPHA,
		e.ONE,
		e.ONE_MINUS_SRC_ALPHA
	], t.screen = [
		e.ONE,
		e.ONE_MINUS_SRC_COLOR,
		e.ONE,
		e.ONE_MINUS_SRC_ALPHA
	], t.none = [0, 0], t["normal-npm"] = [
		e.SRC_ALPHA,
		e.ONE_MINUS_SRC_ALPHA,
		e.ONE,
		e.ONE_MINUS_SRC_ALPHA
	], t["add-npm"] = [
		e.SRC_ALPHA,
		e.ONE,
		e.ONE,
		e.ONE
	], t["screen-npm"] = [
		e.SRC_ALPHA,
		e.ONE_MINUS_SRC_COLOR,
		e.ONE,
		e.ONE_MINUS_SRC_ALPHA
	], t.erase = [e.ZERO, e.ONE_MINUS_SRC_ALPHA], !(e instanceof x.get().getWebGLRenderingContext())) t.min = [
		e.ONE,
		e.ONE,
		e.ONE,
		e.ONE,
		e.MIN,
		e.MIN
	], t.max = [
		e.ONE,
		e.ONE,
		e.ONE,
		e.ONE,
		e.MAX,
		e.MAX
	];
	else {
		let n = e.getExtension("EXT_blend_minmax");
		n && (t.min = [
			e.ONE,
			e.ONE,
			e.ONE,
			e.ONE,
			n.MIN_EXT,
			n.MIN_EXT
		], t.max = [
			e.ONE,
			e.ONE,
			e.ONE,
			e.ONE,
			n.MAX_EXT,
			n.MAX_EXT
		]);
	}
	return t;
}
//#endregion
//#region node_modules/pixi.js/lib/rendering/renderers/gl/state/GlStateSystem.mjs
var { BLEND: jo, OFFSET: Mo, CULLING: No, DEPTH_TEST: Po, WINDING: Fo, DEPTH_MASK: Io } = y, Lo = class e {
	constructor(e) {
		this._invertFrontFace = !1, this.gl = null, this.stateId = 0, this.polygonOffset = 0, this.blendMode = "none", this._blendEq = !1, this.map = [], this.map[jo] = this.setBlend, this.map[Mo] = this.setOffset, this.map[No] = this.setCullFace, this.map[Po] = this.setDepthTest, this.map[Fo] = this.setFrontFace, this.map[Io] = this.setDepthMask, this.checks = [], this.defaultState = M.for2d(), e.renderTarget.onRenderTargetChange.add(this);
	}
	onRenderTargetChange(e) {
		this._invertFrontFace = !e.isRoot != !!e.flipY, this._cullFace ? this.setFrontFace(this._frontFace) : this._frontFaceDirty = !0;
	}
	contextChange(e) {
		this.gl = e, this.blendModesMap = Ao(e), this.resetState();
	}
	set(e) {
		if (e ||= this.defaultState, this.stateId !== e.data) {
			let t = this.stateId ^ e.data, n = 0;
			for (; t;) t & 1 && this.map[n].call(this, !!(e.data & 1 << n)), t >>= 1, n++;
			this.stateId = e.data;
		}
		for (let t = 0; t < this.checks.length; t++) this.checks[t](this, e);
	}
	forceState(e) {
		e ||= this.defaultState;
		for (let t = 0; t < this.map.length; t++) this.map[t].call(this, !!(e.data & 1 << t));
		for (let t = 0; t < this.checks.length; t++) this.checks[t](this, e);
		this.stateId = e.data;
	}
	setBlend(t) {
		this._updateCheck(e._checkBlendMode, t), this.gl[t ? "enable" : "disable"](this.gl.BLEND);
	}
	setOffset(t) {
		this._updateCheck(e._checkPolygonOffset, t), this.gl[t ? "enable" : "disable"](this.gl.POLYGON_OFFSET_FILL);
	}
	setDepthTest(e) {
		this.gl[e ? "enable" : "disable"](this.gl.DEPTH_TEST);
	}
	setDepthMask(e) {
		this.gl.depthMask(e);
	}
	get depthMaskEnabled() {
		return !!(this.stateId & 1 << Io);
	}
	setCullFace(e) {
		this._cullFace = e, this.gl[e ? "enable" : "disable"](this.gl.CULL_FACE), this._cullFace && this._frontFaceDirty && this.setFrontFace(this._frontFace);
	}
	setFrontFace(e) {
		this._frontFace = e, this._frontFaceDirty = !1;
		let t = this._invertFrontFace ? !e : e;
		this._glFrontFace !== t && (this._glFrontFace = t, this.gl.frontFace(this.gl[t ? "CW" : "CCW"]));
	}
	setBlendMode(e) {
		if (this.blendModesMap[e] || (e = "normal"), e === this.blendMode) return;
		this.blendMode = e;
		let t = this.blendModesMap[e], n = this.gl;
		t.length === 2 ? n.blendFunc(t[0], t[1]) : n.blendFuncSeparate(t[0], t[1], t[2], t[3]), t.length === 6 ? (this._blendEq = !0, n.blendEquationSeparate(t[4], t[5])) : this._blendEq && (this._blendEq = !1, n.blendEquationSeparate(n.FUNC_ADD, n.FUNC_ADD));
	}
	setPolygonOffset(e, t) {
		this.gl.polygonOffset(e, t);
	}
	resetState() {
		this._glFrontFace = !1, this._frontFace = !1, this._cullFace = !1, this._frontFaceDirty = !1, this._invertFrontFace = !1, this.gl.frontFace(this.gl.CCW), this.gl.pixelStorei(this.gl.UNPACK_FLIP_Y_WEBGL, !1), this.forceState(this.defaultState), this._blendEq = !0, this.blendMode = "", this.setBlendMode("normal");
	}
	_updateCheck(e, t) {
		let n = this.checks.indexOf(e);
		t && n === -1 ? this.checks.push(e) : !t && n !== -1 && this.checks.splice(n, 1);
	}
	static _checkBlendMode(e, t) {
		e.setBlendMode(t.blendMode);
	}
	static _checkPolygonOffset(e, t) {
		e.setPolygonOffset(1, t.polygonOffset);
	}
	destroy() {
		this.gl = null, this.checks.length = 0;
	}
};
Lo.extension = {
	type: [D.WebGLSystem],
	name: "state"
};
var Ro = Lo, zo = class {
	constructor(e) {
		this.target = za.TEXTURE_2D, this._layerInitMask = 0, this.texture = e, this.width = -1, this.height = -1, this.type = U.UNSIGNED_BYTE, this.internalFormat = Ra.RGBA, this.format = Ra.RGBA, this.samplerType = 0;
	}
	destroy() {}
}, Bo = {
	id: "buffer",
	upload(e, t, n, r, i, a = !1) {
		let o = i || t.target;
		!a && t.width === e.width && t.height === e.height ? n.texSubImage2D(o, 0, 0, 0, e.width, e.height, t.format, t.type, e.resource) : n.texImage2D(o, 0, t.internalFormat, e.width, e.height, 0, t.format, t.type, e.resource), t.width = e.width, t.height = e.height;
	}
}, Vo = {
	"bc1-rgba-unorm": !0,
	"bc1-rgba-unorm-srgb": !0,
	"bc2-rgba-unorm": !0,
	"bc2-rgba-unorm-srgb": !0,
	"bc3-rgba-unorm": !0,
	"bc3-rgba-unorm-srgb": !0,
	"bc4-r-unorm": !0,
	"bc4-r-snorm": !0,
	"bc5-rg-unorm": !0,
	"bc5-rg-snorm": !0,
	"bc6h-rgb-ufloat": !0,
	"bc6h-rgb-float": !0,
	"bc7-rgba-unorm": !0,
	"bc7-rgba-unorm-srgb": !0,
	"etc2-rgb8unorm": !0,
	"etc2-rgb8unorm-srgb": !0,
	"etc2-rgb8a1unorm": !0,
	"etc2-rgb8a1unorm-srgb": !0,
	"etc2-rgba8unorm": !0,
	"etc2-rgba8unorm-srgb": !0,
	"eac-r11unorm": !0,
	"eac-r11snorm": !0,
	"eac-rg11unorm": !0,
	"eac-rg11snorm": !0,
	"astc-4x4-unorm": !0,
	"astc-4x4-unorm-srgb": !0,
	"astc-5x4-unorm": !0,
	"astc-5x4-unorm-srgb": !0,
	"astc-5x5-unorm": !0,
	"astc-5x5-unorm-srgb": !0,
	"astc-6x5-unorm": !0,
	"astc-6x5-unorm-srgb": !0,
	"astc-6x6-unorm": !0,
	"astc-6x6-unorm-srgb": !0,
	"astc-8x5-unorm": !0,
	"astc-8x5-unorm-srgb": !0,
	"astc-8x6-unorm": !0,
	"astc-8x6-unorm-srgb": !0,
	"astc-8x8-unorm": !0,
	"astc-8x8-unorm-srgb": !0,
	"astc-10x5-unorm": !0,
	"astc-10x5-unorm-srgb": !0,
	"astc-10x6-unorm": !0,
	"astc-10x6-unorm-srgb": !0,
	"astc-10x8-unorm": !0,
	"astc-10x8-unorm-srgb": !0,
	"astc-10x10-unorm": !0,
	"astc-10x10-unorm-srgb": !0,
	"astc-12x10-unorm": !0,
	"astc-12x10-unorm-srgb": !0,
	"astc-12x12-unorm": !0,
	"astc-12x12-unorm-srgb": !0
}, Ho = {
	id: "compressed",
	upload(e, t, n, r, i, a) {
		let o = i ?? t.target;
		n.pixelStorei(n.UNPACK_ALIGNMENT, 4);
		let s = e.pixelWidth, c = e.pixelHeight, l = !!Vo[e.format];
		for (let r = 0; r < e.resource.length; r++) {
			let i = e.resource[r];
			l ? n.compressedTexImage2D(o, r, t.internalFormat, s, c, 0, i) : n.texImage2D(o, r, t.internalFormat, s, c, 0, t.format, t.type, i), s = Math.max(s >> 1, 1), c = Math.max(c >> 1, 1);
		}
	}
}, Uo = [
	"right",
	"left",
	"top",
	"bottom",
	"front",
	"back"
];
function Wo(e) {
	return {
		id: "cube",
		upload(t, n, r, i) {
			let a = t.faces;
			for (let t = 0; t < Uo.length; t++) {
				let o = a[Uo[t]];
				o.resource && ((e[o.uploadMethodId] || e.image).upload(o, n, r, i, za.TEXTURE_CUBE_MAP_POSITIVE_X + t, !(n._layerInitMask & 1 << t)), n._layerInitMask |= 1 << t);
			}
			n.width = t.pixelWidth, n.height = t.pixelHeight;
		}
	};
}
//#endregion
//#region node_modules/pixi.js/lib/rendering/renderers/gl/texture/uploaders/glUploadImageResource.mjs
var Go = {
	id: "image",
	upload(e, t, n, r, i, a = !1) {
		let o = i || t.target, s = e.pixelWidth, c = e.pixelHeight, l = e.resourceWidth, u = e.resourceHeight, d = r === 2, f = a || t.width !== s || t.height !== c, p = l >= s && u >= c, m = e.resource;
		(d ? Ko : qo)(n, o, t, s, c, l, u, m, f, p), t.width = s, t.height = c;
	}
};
function Ko(e, t, n, r, i, a, o, s, c, l) {
	if (!l) {
		c && e.texImage2D(t, 0, n.internalFormat, r, i, 0, n.format, n.type, null), e.texSubImage2D(t, 0, 0, 0, a, o, n.format, n.type, s);
		return;
	}
	if (!c) {
		e.texSubImage2D(t, 0, 0, 0, n.format, n.type, s);
		return;
	}
	e.texImage2D(t, 0, n.internalFormat, r, i, 0, n.format, n.type, s);
}
function qo(e, t, n, r, i, a, o, s, c, l) {
	if (!l) {
		c && e.texImage2D(t, 0, n.internalFormat, r, i, 0, n.format, n.type, null), e.texSubImage2D(t, 0, 0, 0, n.format, n.type, s);
		return;
	}
	if (!c) {
		e.texSubImage2D(t, 0, 0, 0, n.format, n.type, s);
		return;
	}
	e.texImage2D(t, 0, n.internalFormat, n.format, n.type, s);
}
//#endregion
//#region node_modules/pixi.js/lib/rendering/renderers/gl/texture/uploaders/glUploadVideoResource.mjs
var Jo = qi(), Yo = {
	id: "video",
	upload(e, t, n, r, i, a = Jo) {
		if (!e.isValid) {
			let e = i ?? t.target;
			n.texImage2D(e, 0, t.internalFormat, 1, 1, 0, t.format, t.type, null);
			return;
		}
		Go.upload(e, t, n, r, i, a);
	}
}, Xo = {
	linear: 9729,
	nearest: 9728
}, Zo = {
	linear: {
		linear: 9987,
		nearest: 9985
	},
	nearest: {
		linear: 9986,
		nearest: 9984
	}
}, Qo = {
	"clamp-to-edge": 33071,
	repeat: 10497,
	"mirror-repeat": 33648
}, $o = {
	never: 512,
	less: 513,
	equal: 514,
	"less-equal": 515,
	greater: 516,
	"not-equal": 517,
	"greater-equal": 518,
	always: 519
};
//#endregion
//#region node_modules/pixi.js/lib/rendering/renderers/gl/texture/utils/applyStyleParams.mjs
function es(e, t, n, r, i, a, o, s) {
	let c = a;
	if (!s || e.addressModeU !== "repeat" || e.addressModeV !== "repeat" || e.addressModeW !== "repeat") {
		let n = Qo[o ? "clamp-to-edge" : e.addressModeU], r = Qo[o ? "clamp-to-edge" : e.addressModeV], a = Qo[o ? "clamp-to-edge" : e.addressModeW];
		t[i](c, t.TEXTURE_WRAP_S, n), t[i](c, t.TEXTURE_WRAP_T, r), t.TEXTURE_WRAP_R && t[i](c, t.TEXTURE_WRAP_R, a);
	}
	if ((!s || e.magFilter !== "linear") && t[i](c, t.TEXTURE_MAG_FILTER, Xo[e.magFilter]), n) {
		if (!s || e.mipmapFilter !== "linear") {
			let n = Zo[e.minFilter][e.mipmapFilter];
			t[i](c, t.TEXTURE_MIN_FILTER, n);
		}
	} else t[i](c, t.TEXTURE_MIN_FILTER, Xo[e.minFilter]);
	if (r && e.maxAnisotropy > 1) {
		let n = Math.min(e.maxAnisotropy, t.getParameter(r.MAX_TEXTURE_MAX_ANISOTROPY_EXT));
		t[i](c, r.TEXTURE_MAX_ANISOTROPY_EXT, n);
	}
	e.compare ? (t[i](c, t.TEXTURE_COMPARE_FUNC, $o[e.compare]), t[i](c, t.TEXTURE_COMPARE_MODE, t.COMPARE_REF_TO_TEXTURE)) : s || t[i](c, t.TEXTURE_COMPARE_MODE, t.NONE);
}
//#endregion
//#region node_modules/pixi.js/lib/rendering/renderers/gl/texture/utils/mapFormatToGlFormat.mjs
function ts(e) {
	return {
		r8unorm: e.RED,
		r8snorm: e.RED,
		r8uint: e.RED,
		r8sint: e.RED,
		r16uint: e.RED,
		r16sint: e.RED,
		r16float: e.RED,
		rg8unorm: e.RG,
		rg8snorm: e.RG,
		rg8uint: e.RG,
		rg8sint: e.RG,
		r32uint: e.RED,
		r32sint: e.RED,
		r32float: e.RED,
		rg16uint: e.RG,
		rg16sint: e.RG,
		rg16float: e.RG,
		rgba8unorm: e.RGBA,
		"rgba8unorm-srgb": e.RGBA,
		rgba8snorm: e.RGBA,
		rgba8uint: e.RGBA,
		rgba8sint: e.RGBA,
		bgra8unorm: e.RGBA,
		"bgra8unorm-srgb": e.RGBA,
		rgb9e5ufloat: e.RGB,
		rgb10a2unorm: e.RGBA,
		rg11b10ufloat: e.RGB,
		rg32uint: e.RG,
		rg32sint: e.RG,
		rg32float: e.RG,
		rgba16uint: e.RGBA,
		rgba16sint: e.RGBA,
		rgba16float: e.RGBA,
		rgba32uint: e.RGBA,
		rgba32sint: e.RGBA,
		rgba32float: e.RGBA,
		stencil8: e.STENCIL_INDEX8,
		depth16unorm: e.DEPTH_COMPONENT,
		depth24plus: e.DEPTH_COMPONENT,
		"depth24plus-stencil8": e.DEPTH_STENCIL,
		depth32float: e.DEPTH_COMPONENT,
		"depth32float-stencil8": e.DEPTH_STENCIL
	};
}
//#endregion
//#region node_modules/pixi.js/lib/rendering/renderers/gl/texture/utils/mapFormatToGlInternalFormat.mjs
function ns(e, t) {
	let n = {}, r = e.RGBA;
	return e instanceof x.get().getWebGLRenderingContext() ? t.srgb && (n = {
		"rgba8unorm-srgb": t.srgb.SRGB8_ALPHA8_EXT,
		"bgra8unorm-srgb": t.srgb.SRGB8_ALPHA8_EXT
	}) : (n = {
		"rgba8unorm-srgb": e.SRGB8_ALPHA8,
		"bgra8unorm-srgb": e.SRGB8_ALPHA8
	}, r = e.RGBA8), {
		r8unorm: e.R8,
		r8snorm: e.R8_SNORM,
		r8uint: e.R8UI,
		r8sint: e.R8I,
		r16uint: e.R16UI,
		r16sint: e.R16I,
		r16float: e.R16F,
		rg8unorm: e.RG8,
		rg8snorm: e.RG8_SNORM,
		rg8uint: e.RG8UI,
		rg8sint: e.RG8I,
		r32uint: e.R32UI,
		r32sint: e.R32I,
		r32float: e.R32F,
		rg16uint: e.RG16UI,
		rg16sint: e.RG16I,
		rg16float: e.RG16F,
		rgba8unorm: e.RGBA,
		...n,
		rgba8snorm: e.RGBA8_SNORM,
		rgba8uint: e.RGBA8UI,
		rgba8sint: e.RGBA8I,
		bgra8unorm: r,
		rgb9e5ufloat: e.RGB9_E5,
		rgb10a2unorm: e.RGB10_A2,
		rg11b10ufloat: e.R11F_G11F_B10F,
		rg32uint: e.RG32UI,
		rg32sint: e.RG32I,
		rg32float: e.RG32F,
		rgba16uint: e.RGBA16UI,
		rgba16sint: e.RGBA16I,
		rgba16float: e.RGBA16F,
		rgba32uint: e.RGBA32UI,
		rgba32sint: e.RGBA32I,
		rgba32float: e.RGBA32F,
		stencil8: e.STENCIL_INDEX8,
		depth16unorm: e.DEPTH_COMPONENT16,
		depth24plus: e.DEPTH_COMPONENT24,
		"depth24plus-stencil8": e.DEPTH24_STENCIL8,
		depth32float: e.DEPTH_COMPONENT32F,
		"depth32float-stencil8": e.DEPTH32F_STENCIL8,
		...t.s3tc ? {
			"bc1-rgba-unorm": t.s3tc.COMPRESSED_RGBA_S3TC_DXT1_EXT,
			"bc2-rgba-unorm": t.s3tc.COMPRESSED_RGBA_S3TC_DXT3_EXT,
			"bc3-rgba-unorm": t.s3tc.COMPRESSED_RGBA_S3TC_DXT5_EXT
		} : {},
		...t.s3tc_sRGB ? {
			"bc1-rgba-unorm-srgb": t.s3tc_sRGB.COMPRESSED_SRGB_ALPHA_S3TC_DXT1_EXT,
			"bc2-rgba-unorm-srgb": t.s3tc_sRGB.COMPRESSED_SRGB_ALPHA_S3TC_DXT3_EXT,
			"bc3-rgba-unorm-srgb": t.s3tc_sRGB.COMPRESSED_SRGB_ALPHA_S3TC_DXT5_EXT
		} : {},
		...t.rgtc ? {
			"bc4-r-unorm": t.rgtc.COMPRESSED_RED_RGTC1_EXT,
			"bc4-r-snorm": t.rgtc.COMPRESSED_SIGNED_RED_RGTC1_EXT,
			"bc5-rg-unorm": t.rgtc.COMPRESSED_RED_GREEN_RGTC2_EXT,
			"bc5-rg-snorm": t.rgtc.COMPRESSED_SIGNED_RED_GREEN_RGTC2_EXT
		} : {},
		...t.bptc ? {
			"bc6h-rgb-float": t.bptc.COMPRESSED_RGB_BPTC_SIGNED_FLOAT_EXT,
			"bc6h-rgb-ufloat": t.bptc.COMPRESSED_RGB_BPTC_UNSIGNED_FLOAT_EXT,
			"bc7-rgba-unorm": t.bptc.COMPRESSED_RGBA_BPTC_UNORM_EXT,
			"bc7-rgba-unorm-srgb": t.bptc.COMPRESSED_SRGB_ALPHA_BPTC_UNORM_EXT
		} : {},
		...t.etc ? {
			"etc2-rgb8unorm": t.etc.COMPRESSED_RGB8_ETC2,
			"etc2-rgb8unorm-srgb": t.etc.COMPRESSED_SRGB8_ETC2,
			"etc2-rgb8a1unorm": t.etc.COMPRESSED_RGB8_PUNCHTHROUGH_ALPHA1_ETC2,
			"etc2-rgb8a1unorm-srgb": t.etc.COMPRESSED_SRGB8_PUNCHTHROUGH_ALPHA1_ETC2,
			"etc2-rgba8unorm": t.etc.COMPRESSED_RGBA8_ETC2_EAC,
			"etc2-rgba8unorm-srgb": t.etc.COMPRESSED_SRGB8_ALPHA8_ETC2_EAC,
			"eac-r11unorm": t.etc.COMPRESSED_R11_EAC,
			"eac-rg11unorm": t.etc.COMPRESSED_SIGNED_RG11_EAC
		} : {},
		...t.astc ? {
			"astc-4x4-unorm": t.astc.COMPRESSED_RGBA_ASTC_4x4_KHR,
			"astc-4x4-unorm-srgb": t.astc.COMPRESSED_SRGB8_ALPHA8_ASTC_4x4_KHR,
			"astc-5x4-unorm": t.astc.COMPRESSED_RGBA_ASTC_5x4_KHR,
			"astc-5x4-unorm-srgb": t.astc.COMPRESSED_SRGB8_ALPHA8_ASTC_5x4_KHR,
			"astc-5x5-unorm": t.astc.COMPRESSED_RGBA_ASTC_5x5_KHR,
			"astc-5x5-unorm-srgb": t.astc.COMPRESSED_SRGB8_ALPHA8_ASTC_5x5_KHR,
			"astc-6x5-unorm": t.astc.COMPRESSED_RGBA_ASTC_6x5_KHR,
			"astc-6x5-unorm-srgb": t.astc.COMPRESSED_SRGB8_ALPHA8_ASTC_6x5_KHR,
			"astc-6x6-unorm": t.astc.COMPRESSED_RGBA_ASTC_6x6_KHR,
			"astc-6x6-unorm-srgb": t.astc.COMPRESSED_SRGB8_ALPHA8_ASTC_6x6_KHR,
			"astc-8x5-unorm": t.astc.COMPRESSED_RGBA_ASTC_8x5_KHR,
			"astc-8x5-unorm-srgb": t.astc.COMPRESSED_SRGB8_ALPHA8_ASTC_8x5_KHR,
			"astc-8x6-unorm": t.astc.COMPRESSED_RGBA_ASTC_8x6_KHR,
			"astc-8x6-unorm-srgb": t.astc.COMPRESSED_SRGB8_ALPHA8_ASTC_8x6_KHR,
			"astc-8x8-unorm": t.astc.COMPRESSED_RGBA_ASTC_8x8_KHR,
			"astc-8x8-unorm-srgb": t.astc.COMPRESSED_SRGB8_ALPHA8_ASTC_8x8_KHR,
			"astc-10x5-unorm": t.astc.COMPRESSED_RGBA_ASTC_10x5_KHR,
			"astc-10x5-unorm-srgb": t.astc.COMPRESSED_SRGB8_ALPHA8_ASTC_10x5_KHR,
			"astc-10x6-unorm": t.astc.COMPRESSED_RGBA_ASTC_10x6_KHR,
			"astc-10x6-unorm-srgb": t.astc.COMPRESSED_SRGB8_ALPHA8_ASTC_10x6_KHR,
			"astc-10x8-unorm": t.astc.COMPRESSED_RGBA_ASTC_10x8_KHR,
			"astc-10x8-unorm-srgb": t.astc.COMPRESSED_SRGB8_ALPHA8_ASTC_10x8_KHR,
			"astc-10x10-unorm": t.astc.COMPRESSED_RGBA_ASTC_10x10_KHR,
			"astc-10x10-unorm-srgb": t.astc.COMPRESSED_SRGB8_ALPHA8_ASTC_10x10_KHR,
			"astc-12x10-unorm": t.astc.COMPRESSED_RGBA_ASTC_12x10_KHR,
			"astc-12x10-unorm-srgb": t.astc.COMPRESSED_SRGB8_ALPHA8_ASTC_12x10_KHR,
			"astc-12x12-unorm": t.astc.COMPRESSED_RGBA_ASTC_12x12_KHR,
			"astc-12x12-unorm-srgb": t.astc.COMPRESSED_SRGB8_ALPHA8_ASTC_12x12_KHR
		} : {}
	};
}
//#endregion
//#region node_modules/pixi.js/lib/rendering/renderers/gl/texture/utils/mapFormatToGlType.mjs
function rs(e) {
	return {
		r8unorm: e.UNSIGNED_BYTE,
		r8snorm: e.BYTE,
		r8uint: e.UNSIGNED_BYTE,
		r8sint: e.BYTE,
		r16uint: e.UNSIGNED_SHORT,
		r16sint: e.SHORT,
		r16float: e.HALF_FLOAT,
		rg8unorm: e.UNSIGNED_BYTE,
		rg8snorm: e.BYTE,
		rg8uint: e.UNSIGNED_BYTE,
		rg8sint: e.BYTE,
		r32uint: e.UNSIGNED_INT,
		r32sint: e.INT,
		r32float: e.FLOAT,
		rg16uint: e.UNSIGNED_SHORT,
		rg16sint: e.SHORT,
		rg16float: e.HALF_FLOAT,
		rgba8unorm: e.UNSIGNED_BYTE,
		"rgba8unorm-srgb": e.UNSIGNED_BYTE,
		rgba8snorm: e.BYTE,
		rgba8uint: e.UNSIGNED_BYTE,
		rgba8sint: e.BYTE,
		bgra8unorm: e.UNSIGNED_BYTE,
		"bgra8unorm-srgb": e.UNSIGNED_BYTE,
		rgb9e5ufloat: e.UNSIGNED_INT_5_9_9_9_REV,
		rgb10a2unorm: e.UNSIGNED_INT_2_10_10_10_REV,
		rg11b10ufloat: e.UNSIGNED_INT_10F_11F_11F_REV,
		rg32uint: e.UNSIGNED_INT,
		rg32sint: e.INT,
		rg32float: e.FLOAT,
		rgba16uint: e.UNSIGNED_SHORT,
		rgba16sint: e.SHORT,
		rgba16float: e.HALF_FLOAT,
		rgba32uint: e.UNSIGNED_INT,
		rgba32sint: e.INT,
		rgba32float: e.FLOAT,
		stencil8: e.UNSIGNED_BYTE,
		depth16unorm: e.UNSIGNED_SHORT,
		depth24plus: e.UNSIGNED_INT,
		"depth24plus-stencil8": e.UNSIGNED_INT_24_8,
		depth32float: e.FLOAT,
		"depth32float-stencil8": e.FLOAT_32_UNSIGNED_INT_24_8_REV
	};
}
//#endregion
//#region node_modules/pixi.js/lib/rendering/renderers/gl/texture/utils/mapViewDimensionToGlTarget.mjs
function is(e) {
	return {
		"2d": e.TEXTURE_2D,
		cube: e.TEXTURE_CUBE_MAP,
		"1d": null,
		"3d": e?.TEXTURE_3D || null,
		"2d-array": e?.TEXTURE_2D_ARRAY || null,
		"cube-array": e?.TEXTURE_CUBE_MAP_ARRAY || null
	};
}
//#endregion
//#region node_modules/pixi.js/lib/rendering/renderers/gl/texture/GlTextureSystem.mjs
var as = 4, os = class e {
	constructor(t) {
		this._glSamplers = /* @__PURE__ */ Object.create(null), this._boundTextures = [], this._activeTextureLocation = -1, this._boundSamplers = /* @__PURE__ */ Object.create(null), this._premultiplyAlpha = !1, this._useSeparateSamplers = !1, this._renderer = t, this._managedTextures = new be({
			renderer: t,
			type: "resource",
			onUnload: this.onSourceUnload.bind(this),
			name: "glTexture"
		});
		let n = {
			image: Go,
			buffer: Bo,
			video: Yo,
			compressed: Ho,
			...e.uploadExtensions
		};
		this._uploads = {
			...n,
			cube: Wo(n)
		};
	}
	get managedTextures() {
		return Object.values(this._managedTextures.items);
	}
	contextChange(e) {
		this._gl = e, this._mapFormatToInternalFormat || (this._mapFormatToInternalFormat = ns(e, this._renderer.context.extensions), this._mapFormatToType = rs(e), this._mapFormatToFormat = ts(e), this._mapViewDimensionToGlTarget = is(e)), this._managedTextures.removeAll(!0), this._glSamplers = /* @__PURE__ */ Object.create(null), this._boundSamplers = /* @__PURE__ */ Object.create(null), this._premultiplyAlpha = !1;
		for (let e = 0; e < 16; e++) this.bind(p.EMPTY, e);
	}
	initSource(e) {
		this.bind(e);
	}
	bind(e, t = 0) {
		let n = e.source;
		e ? (this.bindSource(n, t), this._useSeparateSamplers && this._bindSampler(n.style, t)) : (this.bindSource(null, t), this._useSeparateSamplers && this._bindSampler(null, t));
	}
	bindSource(e, t = 0) {
		let n = this._gl;
		if (e._gcLastUsed = this._renderer.gc.now, this._boundTextures[t] !== e) {
			this._boundTextures[t] = e, this._activateLocation(t), e ||= p.EMPTY.source;
			let r = this.getGlSource(e);
			n.bindTexture(r.target, r.texture);
		}
	}
	_bindSampler(e, t = 0) {
		let n = this._gl;
		if (!e) {
			this._boundSamplers[t] = null, n.bindSampler(t, null);
			return;
		}
		let r = this._getGlSampler(e);
		this._boundSamplers[t] !== r && (this._boundSamplers[t] = r, n.bindSampler(t, r));
	}
	unbind(e) {
		let t = e.source, n = this._boundTextures, r = this._gl;
		for (let e = 0; e < n.length; e++) if (n[e] === t) {
			this._activateLocation(e);
			let i = this.getGlSource(t);
			r.bindTexture(i.target, null), n[e] = null;
		}
	}
	_activateLocation(e) {
		this._activeTextureLocation !== e && (this._activeTextureLocation = e, this._gl.activeTexture(this._gl.TEXTURE0 + e));
	}
	_initSource(e) {
		let t = this._gl, n = new zo(t.createTexture());
		if (n.type = this._mapFormatToType[e.format], n.internalFormat = this._mapFormatToInternalFormat[e.format], n.format = this._mapFormatToFormat[e.format], n.target = this._mapViewDimensionToGlTarget[e.viewDimension], n.target === null) throw Error(`Unsupported view dimension: ${e.viewDimension} with this webgl version: ${this._renderer.context.webGLVersion}`);
		if (e.autoGenerateMipmaps && (this._renderer.context.supports.nonPowOf2mipmaps || e.isPowerOfTwo)) {
			let t = Math.max(e.width, e.height);
			e.mipLevelCount = Math.floor(Math.log2(t)) + 1;
		}
		return e._gpuData[this._renderer.uid] = n, this._managedTextures.add(e) && (e.on("update", this.onSourceUpdate, this), e.on("resize", this.onSourceUpdate, this), e.on("styleChange", this.onStyleChange, this), e.on("updateMipmaps", this.onUpdateMipmaps, this)), this.onSourceUpdate(e), this.updateStyle(e, !1), n;
	}
	onStyleChange(e) {
		this.updateStyle(e, !1);
	}
	updateStyle(e, t) {
		let n = this._gl, r = this.getGlSource(e);
		n.bindTexture(r.target, r.texture), this._boundTextures[this._activeTextureLocation] = e, es(e.style, n, e.mipLevelCount > 1, this._renderer.context.extensions.anisotropicFiltering, "texParameteri", r.target, !this._renderer.context.supports.nonPowOf2wrapping && !e.isPowerOfTwo, t);
	}
	onSourceUnload(e, t = !1) {
		let n = e._gpuData[this._renderer.uid];
		n && (t || (this.unbind(e), this._gl.deleteTexture(n.texture)), e.off("update", this.onSourceUpdate, this), e.off("resize", this.onSourceUpdate, this), e.off("styleChange", this.onStyleChange, this), e.off("updateMipmaps", this.onUpdateMipmaps, this));
	}
	onSourceUpdate(e) {
		let t = this._gl, n = this.getGlSource(e);
		t.bindTexture(n.target, n.texture), this._boundTextures[this._activeTextureLocation] = e;
		let r = e.alphaMode === "premultiply-alpha-on-upload";
		if (this._premultiplyAlpha !== r && (this._premultiplyAlpha = r, t.pixelStorei(t.UNPACK_PREMULTIPLY_ALPHA_WEBGL, r)), this._uploads[e.uploadMethodId]) this._uploads[e.uploadMethodId].upload(e, n, t, this._renderer.context.webGLVersion);
		else if (n.target === t.TEXTURE_2D) this._initEmptyTexture2D(n, e);
		else if (n.target === t.TEXTURE_2D_ARRAY) this._initEmptyTexture2DArray(n, e);
		else if (n.target === t.TEXTURE_CUBE_MAP) this._initEmptyTextureCube(n, e);
		else throw Error("[GlTextureSystem] Unsupported texture target for empty allocation.");
		this._applyMipRange(n, e), e.autoGenerateMipmaps && e.mipLevelCount > 1 && this.onUpdateMipmaps(e, !1);
	}
	onUpdateMipmaps(e, t = !0) {
		t && this.bindSource(e, 0);
		let n = this.getGlSource(e);
		this._gl.generateMipmap(n.target);
	}
	_initEmptyTexture2D(e, t) {
		let n = this._gl;
		n.texImage2D(n.TEXTURE_2D, 0, e.internalFormat, t.pixelWidth, t.pixelHeight, 0, e.format, e.type, null);
		let r = Math.max(t.pixelWidth >> 1, 1), i = Math.max(t.pixelHeight >> 1, 1);
		for (let a = 1; a < t.mipLevelCount; a++) n.texImage2D(n.TEXTURE_2D, a, e.internalFormat, r, i, 0, e.format, e.type, null), r = Math.max(r >> 1, 1), i = Math.max(i >> 1, 1);
	}
	_initEmptyTexture2DArray(e, t) {
		if (this._renderer.context.webGLVersion !== 2) throw Error("[GlTextureSystem] TEXTURE_2D_ARRAY requires WebGL2.");
		let n = this._gl, r = Math.max(t.arrayLayerCount | 0, 1);
		n.texImage3D(n.TEXTURE_2D_ARRAY, 0, e.internalFormat, t.pixelWidth, t.pixelHeight, r, 0, e.format, e.type, null);
		let i = Math.max(t.pixelWidth >> 1, 1), a = Math.max(t.pixelHeight >> 1, 1);
		for (let o = 1; o < t.mipLevelCount; o++) n.texImage3D(n.TEXTURE_2D_ARRAY, o, e.internalFormat, i, a, r, 0, e.format, e.type, null), i = Math.max(i >> 1, 1), a = Math.max(a >> 1, 1);
	}
	_initEmptyTextureCube(e, t) {
		let n = this._gl;
		for (let r = 0; r < 6; r++) n.texImage2D(n.TEXTURE_CUBE_MAP_POSITIVE_X + r, 0, e.internalFormat, t.pixelWidth, t.pixelHeight, 0, e.format, e.type, null);
		let r = Math.max(t.pixelWidth >> 1, 1), i = Math.max(t.pixelHeight >> 1, 1);
		for (let a = 1; a < t.mipLevelCount; a++) {
			for (let t = 0; t < 6; t++) n.texImage2D(n.TEXTURE_CUBE_MAP_POSITIVE_X + t, a, e.internalFormat, r, i, 0, e.format, e.type, null);
			r = Math.max(r >> 1, 1), i = Math.max(i >> 1, 1);
		}
	}
	_applyMipRange(e, t) {
		if (this._renderer.context.webGLVersion !== 2 || t.mipLevelCount <= 1) return;
		let n = this._gl, r = Math.max((t.mipLevelCount | 0) - 1, 0);
		n.texParameteri(e.target, n.TEXTURE_BASE_LEVEL, 0), n.texParameteri(e.target, n.TEXTURE_MAX_LEVEL, r);
	}
	_initSampler(e) {
		let t = this._gl, n = this._gl.createSampler();
		return this._glSamplers[e._resourceId] = n, es(e, t, this._boundTextures[this._activeTextureLocation].mipLevelCount > 1, this._renderer.context.extensions.anisotropicFiltering, "samplerParameteri", n, !1, !0), this._glSamplers[e._resourceId];
	}
	_getGlSampler(e) {
		return this._glSamplers[e._resourceId] || this._initSampler(e);
	}
	getGlSource(e) {
		return e._gcLastUsed = this._renderer.gc.now, e._gpuData[this._renderer.uid] || this._initSource(e);
	}
	generateCanvas(e) {
		let { pixels: t, width: n, height: r } = this.getPixels(e), i = x.get().createCanvas();
		i.width = n, i.height = r;
		let a = i.getContext("2d");
		if (a) {
			let e = a.createImageData(n, r);
			e.data.set(t), a.putImageData(e, 0, 0);
		}
		return i;
	}
	getPixels(e) {
		let t = e.source.resolution, n = e.frame, r = Math.max(Math.round(n.width * t), 1), i = Math.max(Math.round(n.height * t), 1), a = new Uint8Array(as * r * i), o = this._renderer, s = o.renderTarget.getRenderTarget(e), c = o.renderTarget.getGpuRenderTarget(s), l = o.gl;
		return o.renderTarget.adaptor.bindFramebuffer(c.resolveTargetFramebuffer), l.readPixels(Math.round(n.x * t), Math.round(n.y * t), r, i, l.RGBA, l.UNSIGNED_BYTE, a), {
			pixels: new Uint8ClampedArray(a.buffer),
			width: r,
			height: i
		};
	}
	destroy() {
		this._managedTextures.destroy(), this._glSamplers = null, this._boundTextures = null, this._boundSamplers = null, this._mapFormatToInternalFormat = null, this._mapFormatToType = null, this._mapFormatToFormat = null, this._uploads = null, this._renderer = null;
	}
	resetState() {
		this._activeTextureLocation = -1, this._boundTextures.fill(p.EMPTY.source), this._boundSamplers = /* @__PURE__ */ Object.create(null);
		let e = this._gl;
		this._premultiplyAlpha = !1, e.pixelStorei(e.UNPACK_PREMULTIPLY_ALPHA_WEBGL, this._premultiplyAlpha);
	}
};
os.extension = {
	type: [D.WebGLSystem],
	name: "texture"
}, os.uploadExtensions = /* @__PURE__ */ Object.create(null);
var ss = os;
b.handleByMap(D.TextureUploaderWebGL, ss.uploadExtensions);
//#endregion
//#region node_modules/pixi.js/lib/scene/graphics/gl/GlGraphicsAdaptor.mjs
var cs = class {
	contextChange(e) {
		let t = new C({
			uColor: {
				value: new Float32Array([
					1,
					1,
					1,
					1
				]),
				type: "vec4<f32>"
			},
			uTransformMatrix: {
				value: new w(),
				type: "mat3x3<f32>"
			},
			uRound: {
				value: 0,
				type: "f32"
			}
		}), n = e.limits.maxBatchableTextures, r = ve({
			name: "graphics",
			bits: [
				Le,
				ge(n),
				Ue,
				Ce
			]
		});
		this.shader = new te({
			glProgram: r,
			resources: {
				localUniforms: t,
				batchSamplers: ke(n)
			}
		});
	}
	execute(e, t) {
		let n = t.context, r = n.customShader || this.shader, i = e.renderer, { batcher: a, instructions: o } = i.graphicsContext.getContextRenderData(n);
		r.groups[0] = i.globalUniforms.bindGroup, i.state.set(e.state), i.shader.bind(r), i.geometry.bind(a.geometry, r.glProgram);
		let s = o.instructions;
		for (let e = 0; e < o.instructionSize; e++) {
			let t = s[e];
			if (t.size) {
				for (let e = 0; e < t.textures.count; e++) i.texture.bind(t.textures.textures[e], e);
				i.geometry.draw(t.topology, t.size, t.start);
			}
		}
	}
	destroy() {
		this.shader.destroy(!0), this.shader = null;
	}
};
cs.extension = {
	type: [D.WebGLPipesAdaptor],
	name: "graphics"
};
//#endregion
//#region node_modules/pixi.js/lib/scene/mesh/gl/GlMeshAdaptor.mjs
var ls = class {
	init() {
		let e = ve({
			name: "mesh",
			bits: [
				Ue,
				Qe,
				Ce
			]
		});
		this._shader = new te({
			glProgram: e,
			resources: {
				uTexture: p.EMPTY.source,
				textureUniforms: { uTextureMatrix: {
					type: "mat3x3<f32>",
					value: new w()
				} }
			}
		});
	}
	execute(e, t) {
		let n = e.renderer, r = t._shader;
		if (!r) {
			r = this._shader;
			let e = t.texture, n = e.source;
			r.resources.uTexture = n, r.resources.uSampler = n.style, r.resources.textureUniforms.uniforms.uTextureMatrix = e.textureMatrix.mapCoord;
		} else if (!r.glProgram) {
			u("Mesh shader has no glProgram", t.shader);
			return;
		}
		r.groups[100] = n.globalUniforms.bindGroup, r.groups[101] = e.localUniformsBindGroup, n.encoder.draw({
			geometry: t._geometry,
			shader: r,
			state: t.state
		});
	}
	destroy() {
		this._shader.destroy(!0), this._shader = null;
	}
};
ls.extension = {
	type: [D.WebGLPipesAdaptor],
	name: "mesh"
};
//#endregion
//#region node_modules/pixi.js/lib/rendering/renderers/gl/WebGLRenderer.mjs
var us = /* @__PURE__ */ N({ WebGLRenderer: () => _s }), ds = [
	...Ae,
	ro,
	qa,
	La,
	Xa,
	Fa,
	ss,
	ao,
	Wa,
	ko,
	To,
	Ya,
	Ro,
	Qa,
	Ja
], fs = [...De], ps = [
	Xi,
	ls,
	cs
], ms = [], hs = [], gs = [];
b.handleByNamedList(D.WebGLSystem, ms), b.handleByNamedList(D.WebGLPipes, hs), b.handleByNamedList(D.WebGLPipesAdaptor, gs), b.add(...ds, ...fs, ...ps);
var _s = class extends de {
	constructor() {
		let e = {
			name: "webgl",
			type: O.WEBGL,
			systems: ms,
			renderPipes: hs,
			renderPipeAdaptors: gs
		};
		super(e);
	}
}, vs = class {
	constructor(e) {
		this._hash = /* @__PURE__ */ Object.create(null), this._renderer = e;
	}
	contextChange(e) {
		this._gpu = e;
	}
	getBindGroup(e, t, n) {
		let r = `${e._key}:${t._layoutKey << 4 | n}`;
		return this._hash[r] || this._createBindGroup(r, e, t, n);
	}
	_createBindGroup(e, t, n, r) {
		let i = this._gpu.device, a = n.layout[r], o = [], s = this._renderer;
		for (let e in a) {
			let n = t.resources[e] ?? t.resources[a[e]];
			if (!n || n.destroyed) throw Error(`[BindGroup] the resource bound as '${e}' was destroyed while a shader still uses it. Remove it from the shader before destroying it.`);
			let r;
			if (n._resourceType === "uniformGroup") {
				let e = n;
				s.ubo.updateUniformGroup(e);
				let t = e.buffer;
				r = {
					buffer: s.buffer.getGPUBuffer(t),
					offset: 0,
					size: t.descriptor.size
				};
			} else if (n._resourceType === "buffer") {
				let e = n;
				r = {
					buffer: s.buffer.getGPUBuffer(e),
					offset: 0,
					size: e.descriptor.size
				};
			} else if (n._resourceType === "bufferResource") {
				let e = n;
				r = {
					buffer: s.buffer.getGPUBuffer(e.buffer),
					offset: e.offset,
					size: e.size ?? e.buffer.descriptor.size
				};
			} else if (n._resourceType === "textureSampler") {
				let e = n;
				r = s.texture.getGpuSampler(e);
			} else if (n._resourceType === "textureSource") {
				let e = n;
				r = s.texture.getTextureView(e);
			} else if (n._resourceType === "textureView") {
				let e = n;
				r = s.texture.getTextureView(e.source, e.viewDescriptor);
			}
			o.push({
				binding: a[e],
				resource: r
			});
		}
		let c = s.shader.getProgramData(n).bindGroups[r], l = i.createBindGroup({
			layout: c,
			entries: o
		});
		return this._hash[e] = l, l;
	}
	destroy() {
		this._hash = null, this._renderer = null;
	}
};
vs.extension = {
	type: [D.WebGPUSystem],
	name: "bindGroup"
};
//#endregion
//#region node_modules/pixi.js/lib/rendering/renderers/gpu/buffer/GpuBufferSystem.mjs
var ys = class {
	constructor(e) {
		this.gpuBuffer = e;
	}
	destroy() {
		this.gpuBuffer.destroy(), this.gpuBuffer = null;
	}
}, bs = class {
	constructor(e) {
		this._renderer = e, this._managedBuffers = new be({
			renderer: e,
			type: "resource",
			onUnload: this.onBufferUnload.bind(this),
			name: "gpuBuffer"
		});
	}
	contextChange(e) {
		this._gpu = e;
	}
	getGPUBuffer(e) {
		return e._gcLastUsed = this._renderer.gc.now, e._gpuData[this._renderer.uid]?.gpuBuffer || this.createGPUBuffer(e);
	}
	updateBuffer(e) {
		let t = this.getGPUBuffer(e), n = e.data;
		return e._updateID && n && (e._updateID = 0, this._gpu.device.queue.writeBuffer(t, e._updateOffset, n.buffer, n.byteOffset + e._updateOffset, (e._updateSize || n.byteLength) + 3 & -4)), t;
	}
	destroyAll() {
		this._managedBuffers.removeAll();
	}
	onBufferUnload(e) {
		e.off("update", this.updateBuffer, this), e.off("change", this.onBufferChange, this);
	}
	createGPUBuffer(e) {
		let t = this._gpu.device.createBuffer(e.descriptor);
		return e._updateID = 0, e.data && (he(e.data.buffer, t.getMappedRange(), e.data.byteOffset, e.data.byteLength), t.unmap()), e._gpuData[this._renderer.uid] = new ys(t), this._managedBuffers.add(e) && (e.on("update", this.updateBuffer, this), e.on("change", this.onBufferChange, this)), t;
	}
	onBufferChange(e) {
		this._managedBuffers.remove(e), e._updateID = 0, this.createGPUBuffer(e);
	}
	destroy() {
		this._managedBuffers.destroy(), this._renderer = null, this._gpu = null;
	}
};
bs.extension = {
	type: [D.WebGPUSystem],
	name: "buffer"
};
//#endregion
//#region node_modules/pixi.js/lib/rendering/renderers/gpu/buffer/UboBatch.mjs
var xs = class {
	constructor({ minUniformOffsetAlignment: e }) {
		this._minUniformOffsetAlignment = 256, this.byteIndex = 0, this._minUniformOffsetAlignment = e, this.data = /* @__PURE__ */ new Float32Array(65535);
	}
	clear() {
		this.byteIndex = 0;
	}
	addEmptyGroup(e) {
		if (e > this._minUniformOffsetAlignment / 4) throw Error(`UniformBufferBatch: array is too large: ${e * 4}`);
		let t = this.byteIndex, n = t + e * 4;
		if (n = Math.ceil(n / this._minUniformOffsetAlignment) * this._minUniformOffsetAlignment, n > this.data.length * 4) throw Error("UniformBufferBatch: ubo batch got too big");
		return this.byteIndex = n, t;
	}
	addGroup(e) {
		let t = this.addEmptyGroup(e.length);
		for (let n = 0; n < e.length; n++) this.data[t / 4 + n] = e[n];
		return t;
	}
	destroy() {
		this.data = null;
	}
}, Ss = class {
	constructor(e) {
		this._colorMaskCache = 15, this._renderer = e;
	}
	setMask(e) {
		this._colorMaskCache !== e && (this._colorMaskCache = e, this._renderer.pipeline.setColorMask(e));
	}
	destroy() {
		this._renderer = null, this._colorMaskCache = null;
	}
};
Ss.extension = {
	type: [D.WebGPUSystem],
	name: "colorMask"
};
//#endregion
//#region node_modules/pixi.js/lib/rendering/renderers/gpu/GpuDeviceSystem.mjs
var Cs = class {
	constructor(e) {
		this._renderer = e;
	}
	async init(e) {
		return this._initPromise ||= (e.gpu ? Promise.resolve(e.gpu) : this._createDeviceAndAdaptor(e)).then((e) => {
			this.gpu = e, this.extensions = { transientAttachment: typeof GPUTextureUsage.TRANSIENT_ATTACHMENT == "number" }, this._renderer.runners.contextChange.emit(this.gpu);
		}), this._initPromise;
	}
	contextChange(e) {
		this._renderer.gpu = e;
	}
	async _createDeviceAndAdaptor(e) {
		let t = await x.get().getNavigator().gpu.requestAdapter({
			powerPreference: e.powerPreference,
			forceFallbackAdapter: e.forceFallbackAdapter
		});
		if (!t) throw Error("WebGPU not supported. No GPU adapter was returned by navigator.gpu.requestAdapter().");
		let n = [
			"texture-compression-bc",
			"texture-compression-astc",
			"texture-compression-etc2",
			"indirect-first-instance"
		].filter((e) => t.features.has(e));
		return {
			adapter: t,
			device: await t.requestDevice({
				requiredFeatures: n,
				requiredLimits: {
					maxSampledTexturesPerShaderStage: t.limits.maxSampledTexturesPerShaderStage,
					maxSamplersPerShaderStage: t.limits.maxSamplersPerShaderStage
				}
			})
		};
	}
	destroy() {
		this.gpu = null, this.extensions = null, this._renderer = null;
	}
};
Cs.extension = {
	type: [D.WebGPUSystem],
	name: "device"
}, Cs.defaultOptions = {
	powerPreference: void 0,
	forceFallbackAdapter: !1
};
//#endregion
//#region node_modules/pixi.js/lib/rendering/renderers/gpu/GpuEncoderSystem.mjs
var ws = class {
	constructor(e) {
		this._boundBindGroup = /* @__PURE__ */ Object.create(null), this._boundVertexBuffer = /* @__PURE__ */ Object.create(null), this._renderer = e;
		for (let e = 0; e < 16; e++) this._boundBindGroup[e] = {
			bindGroup: null,
			program: null,
			key: null
		};
	}
	renderStart() {
		this.commandFinished = new Promise((e) => {
			this._resolveCommandFinished = e;
		}), this.commandEncoder = this._renderer.gpu.device.createCommandEncoder();
	}
	beginRenderPass(e) {
		this.endRenderPass(), this._clearCache(), this._passEncoder = this.commandEncoder.beginRenderPass(e.descriptor), this.renderPassEncoder = this._passEncoder;
	}
	endRenderPass() {
		this._passEncoder && this._passEncoder.end(), this.renderPassEncoder = null, this._passEncoder = null;
	}
	beginBundle() {
		if (this._passEncoder !== this.renderPassEncoder) throw Error("Cannot begin a new render bundle while one is already being recorded.");
		this._clearCache();
		let e = this._renderer.pipeline.getBundleDescriptor();
		this.renderPassEncoder = this._gpu.device.createRenderBundleEncoder(e);
	}
	endBundle() {
		let e = this.renderPassEncoder;
		if (!e || !("finish" in e)) throw Error("endBundle called without an active render bundle.");
		let t = e.finish();
		return this.renderPassEncoder = this._passEncoder, this._clearCache(), t;
	}
	executeBundle(e) {
		this._clearCache(), this._passEncoder.executeBundles([e]);
	}
	setViewport(e) {
		this._passEncoder.setViewport(e.x, e.y, e.width, e.height, 0, 1);
	}
	setStencilReference(e) {
		this._passEncoder.setStencilReference(e);
	}
	setPipelineFromGeometryProgramAndState(e, t, n, r, i) {
		let a = this._renderer.pipeline.getPipeline(e, t, n, r, i);
		this.setPipeline(a);
	}
	setPipeline(e) {
		this._boundPipeline !== e && (this._boundPipeline = e, this.renderPassEncoder.setPipeline(e));
	}
	_setVertexBuffer(e, t) {
		this._boundVertexBuffer[e] !== t && (this._boundVertexBuffer[e] = t, this.renderPassEncoder.setVertexBuffer(e, this._renderer.buffer.updateBuffer(t)));
	}
	_setIndexBuffer(e) {
		if (this._boundIndexBuffer === e) return;
		this._boundIndexBuffer = e;
		let t = e.data.BYTES_PER_ELEMENT === 2 ? "uint16" : "uint32";
		this.renderPassEncoder.setIndexBuffer(this._renderer.buffer.updateBuffer(e), t);
	}
	resetBindGroup(e) {
		let t = this._boundBindGroup[e];
		t.bindGroup = null, t.program = null, t.key = null;
	}
	setBindGroup(e, t, n) {
		let r = this._boundBindGroup[e];
		if (r.bindGroup === t && r.program === n && r.key === t._key) return;
		r.bindGroup = t, r.program = n, r.key = t._key, t._touch(this._renderer.gc.now, this._renderer.tick);
		let i = this._renderer.bindGroup.getBindGroup(t, n, e);
		this.renderPassEncoder.setBindGroup(e, i);
	}
	setGeometry(e, t) {
		let n = this._renderer.pipeline.getBufferNamesToBind(e, t);
		for (let t in n) this._setVertexBuffer(parseInt(t, 10), e.attributes[n[t]].buffer);
		e.indexBuffer && this._setIndexBuffer(e.indexBuffer);
	}
	_setShaderBindGroups(e, t) {
		let n = e.gpuProgram;
		for (let r in e.groups) {
			if (!n.layout[r]) continue;
			let i = e.groups[r];
			t || this._syncBindGroup(i), this.setBindGroup(r, i, n);
		}
	}
	_syncBindGroup(e) {
		for (let t in e.resources) {
			let n = e.resources[t];
			n && n.isUniformGroup && this._renderer.ubo.updateUniformGroup(n);
		}
	}
	draw(e) {
		let { geometry: t, shader: n, state: r, topology: i, size: a, start: o, baseVertex: s, instanceCount: c, skipSync: l, firstInstance: u } = e;
		this.setPipelineFromGeometryProgramAndState(t, n.gpuProgram, r, i, n._overrides), this.setGeometry(t, n.gpuProgram), this._setShaderBindGroups(n, l), t.indexBuffer ? this.renderPassEncoder.drawIndexed(a || t.indexBuffer.data.length, c ?? t.instanceCount, o || 0, s || 0, u || 0) : this.renderPassEncoder.draw(a || t.vertexCount, c ?? t.instanceCount, o || 0, u || 0);
	}
	drawIndirect(e) {
		let { geometry: t, shader: n, state: r, topology: i, skipSync: a, indirectBuffer: o, indirectOffset: s } = e;
		this.setPipelineFromGeometryProgramAndState(t, n.gpuProgram, r, i, n._overrides), this.setGeometry(t, n.gpuProgram), this._setShaderBindGroups(n, a), t.indexBuffer ? this.renderPassEncoder.drawIndexedIndirect(o, s) : this.renderPassEncoder.drawIndirect(o, s);
	}
	finishRenderPass() {
		this._passEncoder &&= (this._passEncoder.end(), this.renderPassEncoder = null, null);
	}
	postrender() {
		this.finishRenderPass(), this._gpu.device.queue.submit([this.commandEncoder.finish()]), this._resolveCommandFinished(), this.commandEncoder = null;
	}
	_clearCache() {
		for (let e = 0; e < 16; e++) {
			let t = this._boundBindGroup[e];
			t.bindGroup = null, t.program = null, t.key = null, this._boundVertexBuffer[e] = null;
		}
		this._boundIndexBuffer = null, this._boundPipeline = null;
	}
	destroy() {
		this._renderer = null, this._gpu = null, this._boundBindGroup = null, this._boundVertexBuffer = null, this._boundIndexBuffer = null, this._boundPipeline = null, this.renderPassEncoder = null, this._passEncoder = null;
	}
	contextChange(e) {
		this._gpu = e;
	}
};
ws.extension = {
	type: [D.WebGPUSystem],
	name: "encoder",
	priority: 1
};
//#endregion
//#region node_modules/pixi.js/lib/rendering/renderers/gpu/GpuLimitsSystem.mjs
var Ts = class {
	constructor(e) {
		this.supportsOverrideConstants = !1, this._renderer = e;
	}
	contextChange() {
		let e = this._renderer.device.gpu.device;
		this.maxTextures = Math.min(e.limits.maxSampledTexturesPerShaderStage, e.limits.maxSamplersPerShaderStage), this.maxBatchableTextures = this.maxTextures, this._detectOverrideConstantsSupport(e);
	}
	_detectOverrideConstantsSupport(e) {
		e.pushErrorScope("validation");
		let t = e.createShaderModule({ code: "override TEST_VALUE: f32 = 0.0;\n@compute @workgroup_size(1) fn main() {}" });
		e.createComputePipeline({
			layout: "auto",
			compute: {
				module: t,
				entryPoint: "main",
				constants: { TEST_VALUE: 1 }
			}
		}), e.popErrorScope().then((e) => {
			this.supportsOverrideConstants = !e;
		});
	}
	destroy() {}
};
Ts.extension = {
	type: [D.WebGPUSystem],
	name: "limits"
};
//#endregion
//#region node_modules/pixi.js/lib/rendering/renderers/gpu/GpuStencilSystem.mjs
var Es = class {
	constructor(e) {
		this._renderTargetStencilState = /* @__PURE__ */ Object.create(null), this._renderer = e, e.renderTarget.onRenderTargetChange.add(this);
	}
	onRenderTargetChange(e) {
		let t = this._renderTargetStencilState[e.uid];
		t ||= this._renderTargetStencilState[e.uid] = {
			stencilMode: Fe.DISABLED,
			stencilReference: 0
		}, this._activeRenderTarget = e, this.setStencilMode(t.stencilMode, t.stencilReference);
	}
	setStencilMode(e, t) {
		let n = this._renderTargetStencilState[this._activeRenderTarget.uid];
		n.stencilMode = e, n.stencilReference = t;
		let r = this._renderer;
		r.pipeline.setStencilMode(e), r.encoder.setStencilReference(t);
	}
	destroy() {
		this._renderer.renderTarget.onRenderTargetChange.remove(this), this._renderer = null, this._activeRenderTarget = null, this._renderTargetStencilState = null;
	}
};
Es.extension = {
	type: [D.WebGPUSystem],
	name: "stencil"
};
//#endregion
//#region node_modules/pixi.js/lib/rendering/renderers/gpu/shader/utils/createUboElementsWGSL.mjs
var Ds = {
	i32: {
		align: 4,
		size: 4
	},
	u32: {
		align: 4,
		size: 4
	},
	f32: {
		align: 4,
		size: 4
	},
	f16: {
		align: 2,
		size: 2
	},
	"vec2<i32>": {
		align: 8,
		size: 8
	},
	"vec2<u32>": {
		align: 8,
		size: 8
	},
	"vec2<f32>": {
		align: 8,
		size: 8
	},
	"vec2<f16>": {
		align: 4,
		size: 4
	},
	"vec3<i32>": {
		align: 16,
		size: 12
	},
	"vec3<u32>": {
		align: 16,
		size: 12
	},
	"vec3<f32>": {
		align: 16,
		size: 12
	},
	"vec3<f16>": {
		align: 8,
		size: 6
	},
	"vec4<i32>": {
		align: 16,
		size: 16
	},
	"vec4<u32>": {
		align: 16,
		size: 16
	},
	"vec4<f32>": {
		align: 16,
		size: 16
	},
	"vec4<f16>": {
		align: 8,
		size: 8
	},
	"mat2x2<f32>": {
		align: 8,
		size: 16
	},
	"mat2x2<f16>": {
		align: 4,
		size: 8
	},
	"mat3x2<f32>": {
		align: 8,
		size: 24
	},
	"mat3x2<f16>": {
		align: 4,
		size: 12
	},
	"mat4x2<f32>": {
		align: 8,
		size: 32
	},
	"mat4x2<f16>": {
		align: 4,
		size: 16
	},
	"mat2x3<f32>": {
		align: 16,
		size: 32
	},
	"mat2x3<f16>": {
		align: 8,
		size: 16
	},
	"mat3x3<f32>": {
		align: 16,
		size: 48
	},
	"mat3x3<f16>": {
		align: 8,
		size: 24
	},
	"mat4x3<f32>": {
		align: 16,
		size: 64
	},
	"mat4x3<f16>": {
		align: 8,
		size: 32
	},
	"mat2x4<f32>": {
		align: 16,
		size: 32
	},
	"mat2x4<f16>": {
		align: 8,
		size: 16
	},
	"mat3x4<f32>": {
		align: 16,
		size: 48
	},
	"mat3x4<f16>": {
		align: 8,
		size: 24
	},
	"mat4x4<f32>": {
		align: 16,
		size: 64
	},
	"mat4x4<f16>": {
		align: 8,
		size: 32
	}
};
function Os(e) {
	let t = e.map((e) => ({
		data: e,
		offset: 0,
		size: 0
	})), n = 0;
	for (let e = 0; e < t.length; e++) {
		let r = t[e], i = Ds[r.data.type].size, a = Ds[r.data.type].align;
		if (!Ds[r.data.type]) throw Error(`[Pixi.js] WebGPU UniformBuffer: Unknown type ${r.data.type}`);
		r.data.size > 1 && (i = Math.max(i, a) * r.data.size), n = Math.ceil(n / a) * a, r.size = i, r.offset = n, n += i;
	}
	return n = Math.ceil(n / 16) * 16, {
		uboElements: t,
		size: n
	};
}
//#endregion
//#region node_modules/pixi.js/lib/rendering/renderers/gpu/shader/utils/generateArraySyncWGSL.mjs
function ks(e, t) {
	let { size: n, align: r } = Ds[e.data.type], i = (r - n) / 4, a = e.data.type.indexOf("i32") >= 0 ? "dataInt32" : "data";
	return `
         v = uv.${e.data.name};
         ${t === 0 ? "" : `offset += ${t};`}

         arrayOffset = offset;

         t = 0;

         for(var i=0; i < ${e.data.size * (n / 4)}; i++)
         {
             for(var j = 0; j < ${n / 4}; j++)
             {
                 ${a}[arrayOffset++] = v[t++];
             }
             ${i === 0 ? "" : `arrayOffset += ${i};`}
         }
     `;
}
//#endregion
//#region node_modules/pixi.js/lib/rendering/renderers/gpu/shader/utils/createUboSyncFunctionWGSL.mjs
function As(e) {
	return We(e, Ye, ks);
}
//#endregion
//#region node_modules/pixi.js/lib/rendering/renderers/gpu/GpuUboSystem.mjs
var js = class extends qe {
	constructor() {
		super({
			createUboElements: Os,
			generateUboSync: As
		});
	}
};
js.extension = {
	type: [D.WebGPUSystem],
	name: "ubo"
};
//#endregion
//#region node_modules/pixi.js/lib/rendering/renderers/gpu/GpuUniformBatchPipe.mjs
var Ms = 128, Ns = class {
	constructor(e) {
		this._bindGroupHash = /* @__PURE__ */ Object.create(null), this._buffers = [], this._bindGroups = [], this._bufferResources = [], this._renderer = e, this._batchBuffer = new xs({ minUniformOffsetAlignment: Ms });
		let t = 256 / Ms;
		for (let e = 0; e < t; e++) {
			let t = P.UNIFORM | P.COPY_DST;
			e === 0 && (t |= P.COPY_SRC), this._buffers.push(new A({
				data: this._batchBuffer.data,
				usage: t
			}));
		}
	}
	renderEnd() {
		this._uploadBindGroups(), this._resetBindGroups();
	}
	_resetBindGroups() {
		this._bindGroupHash = /* @__PURE__ */ Object.create(null), this._batchBuffer.clear();
	}
	getUniformBindGroup(e, t) {
		if (!t && this._bindGroupHash[e.uid]) return this._bindGroupHash[e.uid];
		this._renderer.ubo.ensureUniformGroup(e);
		let n = e.buffer.data, r = this._batchBuffer.addEmptyGroup(n.length);
		return this._renderer.ubo.syncUniformGroup(e, this._batchBuffer.data, r / 4), this._bindGroupHash[e.uid] = this._getBindGroup(r / Ms), this._bindGroupHash[e.uid];
	}
	getUboResource(e) {
		this._renderer.ubo.updateUniformGroup(e);
		let t = e.buffer.data, n = this._batchBuffer.addGroup(t);
		return this._getBufferResource(n / Ms);
	}
	getArrayBindGroup(e) {
		let t = this._batchBuffer.addGroup(e);
		return this._getBindGroup(t / Ms);
	}
	getArrayBufferResource(e) {
		let t = this._batchBuffer.addGroup(e) / Ms;
		return this._getBufferResource(t);
	}
	_getBufferResource(e) {
		if (!this._bufferResources[e]) {
			let t = this._buffers[e % 2];
			this._bufferResources[e] = new Ze({
				buffer: t,
				offset: (e / 2 | 0) * 256,
				size: Ms
			});
		}
		return this._bufferResources[e];
	}
	_getBindGroup(e) {
		if (!this._bindGroups[e]) {
			let t = new re({ 0: this._getBufferResource(e) });
			this._bindGroups[e] = t;
		}
		return this._bindGroups[e];
	}
	_uploadBindGroups() {
		let e = this._renderer.buffer, t = this._buffers[0];
		t.update(this._batchBuffer.byteIndex), e.updateBuffer(t);
		let n = this._renderer.gpu.device.createCommandEncoder();
		for (let r = 1; r < this._buffers.length; r++) {
			let i = this._buffers[r];
			n.copyBufferToBuffer(e.getGPUBuffer(t), Ms, e.getGPUBuffer(i), 0, this._batchBuffer.byteIndex);
		}
		this._renderer.gpu.device.queue.submit([n.finish()]);
	}
	destroy() {
		for (let e = 0; e < this._bindGroups.length; e++) this._bindGroups[e]?.destroy();
		this._bindGroups = null, this._bindGroupHash = null;
		for (let e = 0; e < this._buffers.length; e++) this._buffers[e].destroy();
		this._buffers = null;
		for (let e = 0; e < this._bufferResources.length; e++) this._bufferResources[e].destroy();
		this._bufferResources = null, this._batchBuffer.destroy(), this._renderer = null;
	}
};
Ns.extension = {
	type: [D.WebGPUPipes],
	name: "uniformBatch"
};
//#endregion
//#region node_modules/pixi.js/lib/rendering/renderers/gpu/pipeline/PipelineSystem.mjs
var Ps = {
	"point-list": 0,
	"line-list": 1,
	"line-strip": 2,
	"triangle-list": 3,
	"triangle-strip": 4
}, Fs = new S({}), Is = {
	"depth24plus-stencil8": {
		depth: !0,
		stencil: !0,
		index: 1
	},
	depth24plus: {
		depth: !0,
		stencil: !1,
		index: 2
	},
	depth32float: {
		depth: !0,
		stencil: !1,
		index: 3
	},
	"depth32float-stencil8": {
		depth: !0,
		stencil: !0,
		index: 4
	},
	depth16unorm: {
		depth: !0,
		stencil: !1,
		index: 5
	},
	stencil8: {
		depth: !1,
		stencil: !0,
		index: 6
	}
}, Ls = {
	depth: !1,
	stencil: !1,
	index: 0
};
function Rs(e, t) {
	for (let [n, r] of Object.entries(t)) {
		let t = RegExp(`override\\s+${n}\\s*:\\s*(\\w+)\\s*(?:=[^;]*)?;`);
		e = e.replace(t, (e, t) => {
			let i;
			return i = t === "u32" ? `${Math.trunc(r)}u` : t === "i32" ? `${Math.trunc(r)}` : Number.isInteger(r) ? `${r}.0` : `${r}`, `const ${n}: ${t} = ${i};`;
		});
	}
	return e;
}
function zs(e, t, n, r, i, a) {
	return e * 35184372088832 + t * 536870912 + a * 16384 + (n << 8) + (r << 3) + i;
}
var Bs = /* @__PURE__ */ Object.create(null), Vs = 0;
function Hs(e) {
	let t = Bs[e];
	return t === void 0 && (t = Bs[e] = Vs++), t;
}
function Us(e, t, n, r, i, a, o, s) {
	return s << 20 | a << 16 | i << 13 | n << 9 | e << 6 | o << 5 | r << 1 | t;
}
var Ws = class {
	constructor(e) {
		this._moduleCache = /* @__PURE__ */ Object.create(null), this._bufferLayoutsCache = /* @__PURE__ */ Object.create(null), this._bindingNamesCache = /* @__PURE__ */ Object.create(null), this._pipeCache = /* @__PURE__ */ new Map(), this._pipeStateCaches = /* @__PURE__ */ Object.create(null), this._colorMask = 15, this._multisampleCount = 1, this._colorTargetCount = 1, this._colorFormat = "bgra8unorm", this._colorFormatId = Hs("bgra8unorm"), this._depthStencilFormat = "depth24plus-stencil8", this._depthStencilFormatData = Ls, this._depthReadOnly = !1, this._invertFrontFace = !1, this._renderer = e;
	}
	contextChange(e) {
		this._gpu = e, this.setStencilMode(Fe.DISABLED), this._updatePipeHash();
	}
	setMultisampleCount(e) {
		this._multisampleCount !== e && (this._multisampleCount = e, this._updatePipeHash());
	}
	setRenderTarget(e) {
		let t = e.colorAttachments[0]?.texture;
		this._multisampleCount = t?.source.antialias ? 4 : 1, this._colorTargetCount = e.colorAttachments.length, this._colorFormat = t?.format ?? "bgra8unorm", this._colorFormatId = Hs(this._colorFormat), this._depthStencilFormat = e.depthStencilAttachment?.texture.format, this._depthStencilFormatData = Is[this._depthStencilFormat] || Ls, this._depthReadOnly = e.depthStencilAttachment?.depthReadOnly ?? !1, this._invertFrontFace = !!e.flipY, this._updatePipeHash();
	}
	setColorMask(e) {
		this._colorMask !== e && (this._colorMask = e, this._updatePipeHash());
	}
	setStencilMode(e) {
		this._stencilMode !== e && (this._stencilMode = e, this._stencilState = Xe[e], this._updatePipeHash());
	}
	getBundleDescriptor() {
		let e = [];
		for (let t = 0; t < this._colorTargetCount; t++) e.push(this._colorFormat);
		let t = {
			colorFormats: e,
			sampleCount: this._multisampleCount
		};
		return (this._depthStencilFormatData.depth || this._depthStencilFormatData.stencil) && (t.depthStencilFormat = this._depthStencilFormat), t;
	}
	setPipeline(e, t, n, r) {
		let i = this.getPipeline(e, t, n);
		r.setPipeline(i);
	}
	getPipelineKey(e, t, n, r, i) {
		return e._layoutKey || (Ve(e, t.attributeData), this._generateBufferKey(e)), zs(e._layoutKey, t._layoutKey, n.data, n._blendModeId, Ps[r], i.id);
	}
	getPipeline(e, t, n, r, i) {
		e._layoutKey || (Ve(e, t.attributeData), this._generateBufferKey(e)), r ||= e.topology, i ||= Fs;
		let a = zs(e._layoutKey, t._layoutKey, n.data, n._blendModeId, Ps[r], i.id), o = this._pipeCache.get(a);
		return o || (o = this._createPipeline(e, t, n, r, i), this._pipeCache.set(a, o)), o;
	}
	_createPipeline(e, t, n, r, i) {
		let a = this._gpu.device, o = this._createVertexBufferLayouts(e, t), s = this._renderer.state.getColorTargets(n, this._colorTargetCount, this._colorFormat), c = this._stencilMode === Fe.RENDERING_MASK_ADD ? 0 : this._colorMask;
		for (let e = 0; e < s.length; e++) s[e].writeMask = c;
		let l = this._renderer.shader.getProgramData(t).pipeline, u = Object.keys(i.data).length > 0, d = t.vertex.source, f = t.fragment.source, p;
		u && (this._renderer.limits.supportsOverrideConstants ? p = i.data : (d = Rs(d, i.data), f = Rs(f, i.data)));
		let m = {
			vertex: {
				module: this._getModule(d),
				entryPoint: t.vertex.entryPoint,
				constants: p,
				buffers: o
			},
			fragment: {
				module: this._getModule(f),
				entryPoint: t.fragment.entryPoint,
				targets: s,
				constants: p
			},
			primitive: {
				topology: r,
				cullMode: n.culling ? "back" : "none",
				frontFace: n.clockwiseFrontFace === this._invertFrontFace ? "ccw" : "cw"
			},
			layout: l,
			multisample: { count: this._multisampleCount },
			label: t.name ? `PIXI Pipeline (${t.name})` : "PIXI Pipeline"
		};
		if (this._depthStencilFormatData.depth || this._depthStencilFormatData.stencil) {
			let e = this._depthStencilFormatData;
			m.depthStencil = {
				...this._stencilState,
				format: this._depthStencilFormat,
				depthWriteEnabled: e.depth ? n.depthMask && !this._depthReadOnly : !1,
				depthCompare: e.depth && n.depthTest ? "less" : "always"
			};
		}
		return a.createRenderPipeline(m);
	}
	_getModule(e) {
		return this._moduleCache[e] || this._createModule(e);
	}
	_createModule(e) {
		let t = this._gpu.device;
		return this._moduleCache[e] = t.createShaderModule({ code: e }), this._moduleCache[e];
	}
	_generateBufferKey(e) {
		let t = [], n = 0, r = Object.keys(e.attributes).sort();
		for (let i = 0; i < r.length; i++) {
			let a = e.attributes[r[i]];
			t[n++] = a.offset, t[n++] = a.format, t[n++] = a.stride, t[n++] = a.instance;
		}
		let i = t.join("|");
		return e._layoutKey = T(i, "geometry"), e._layoutKey;
	}
	_generateAttributeLocationsKey(e) {
		let t = [], n = 0, r = Object.keys(e.attributeData).sort();
		for (let i = 0; i < r.length; i++) {
			let a = e.attributeData[r[i]];
			t[n++] = a.location;
		}
		let i = t.join("|");
		return e._attributeLocationsKey = T(i, "programAttributes"), e._attributeLocationsKey;
	}
	getBufferNamesToBind(e, t) {
		let n = e._layoutKey << 16 | t._attributeLocationsKey;
		if (this._bindingNamesCache[n]) return this._bindingNamesCache[n];
		let r = this._createVertexBufferLayouts(e, t), i = /* @__PURE__ */ Object.create(null), a = t.attributeData;
		for (let e = 0; e < r.length; e++) {
			let t = Object.values(r[e].attributes)[0].shaderLocation;
			for (let n in a) if (a[n].location === t) {
				i[e] = n;
				break;
			}
		}
		return this._bindingNamesCache[n] = i, i;
	}
	_createVertexBufferLayouts(e, t) {
		t._attributeLocationsKey || this._generateAttributeLocationsKey(t);
		let n = e._layoutKey << 16 | t._attributeLocationsKey;
		if (this._bufferLayoutsCache[n]) return this._bufferLayoutsCache[n];
		let r = [];
		return e.buffers.forEach((n) => {
			let i = {
				arrayStride: 0,
				stepMode: "vertex",
				attributes: []
			}, a = i.attributes;
			for (let r in t.attributeData) {
				let o = e.attributes[r];
				(o.divisor ?? 1) !== 1 && u(`Attribute ${r} has an invalid divisor value of '${o.divisor}'. WebGPU only supports a divisor value of 1`), o.buffer === n && (i.arrayStride = o.stride, i.stepMode = o.instance ? "instance" : "vertex", a.push({
					shaderLocation: t.attributeData[r].location,
					offset: o.offset,
					format: o.format
				}));
			}
			a.length && r.push(i);
		}), this._bufferLayoutsCache[n] = r, r;
	}
	_updatePipeHash() {
		var e;
		let t = Us(this._stencilMode, this._multisampleCount === 1 ? 0 : 1, this._colorMask, this._colorTargetCount, this._depthStencilFormatData.index, this._colorFormatId, +!!this._depthReadOnly, +!!this._invertFrontFace);
		this._pipeCache = (e = this._pipeStateCaches)[t] ?? (e[t] = /* @__PURE__ */ new Map());
	}
	destroy() {
		this._bufferLayoutsCache = null, this._pipeCache = null, this._gpu = null, this._renderer = null, this._bindingNamesCache = null, this._pipeStateCaches = null, this._moduleCache = null;
	}
};
Ws.extension = {
	type: [D.WebGPUSystem],
	name: "pipeline"
};
//#endregion
//#region node_modules/pixi.js/lib/rendering/renderers/gpu/renderTarget/GpuRenderTarget.mjs
var Gs = class {
	constructor() {
		this.contexts = [], this.msaaTextures = [], this.msaaSamples = 1;
	}
}, Ks = {
	bgra8unorm: !0,
	rgba8unorm: !0,
	rgba16float: !0
};
function qs(e) {
	if (Ks[e]) return e;
	let t = navigator.gpu.getPreferredCanvasFormat();
	return u(`[WebGPU] CanvasSource format '${e}' is not a valid GPUCanvasContext format. Falling back to '${t}'. Allowed formats are: bgra8unorm, rgba8unorm, rgba16float.`), t;
}
var Js = class {
	constructor() {
		this._activePass = null;
	}
	init(e, t) {
		this._renderer = e, this._renderTargetSystem = t;
	}
	copyToTexture(e, t, n, r, i) {
		let a = this._renderer;
		this.finishRenderPass();
		let o = this._getGpuColorTexture(e), s = a.texture.getGpuSource(t.source);
		return a.encoder.commandEncoder.copyTextureToTexture({
			texture: o,
			origin: n
		}, {
			texture: s,
			origin: i
		}, r), t;
	}
	copyDepthTexture(e, t, n, r, i) {
		let a = this._renderer;
		this.finishRenderPass();
		let o = e.depthStencilAttachment.texture, s = a.texture.getGpuSource(o), c = a.texture.getGpuSource(t.source), l = a.encoder.commandEncoder === null, u = l ? a.gpu.device.createCommandEncoder() : a.encoder.commandEncoder;
		u.copyTextureToTexture({
			texture: s,
			origin: n
		}, {
			texture: c,
			origin: i
		}, {
			width: r.width,
			height: r.height
		}), l && a.gpu.device.queue.submit([u.finish()]);
	}
	startRenderPass(e, t = !0, n, r, i = 0, a = 0) {
		let o = this._renderTargetSystem.getGpuRenderTarget(e);
		if (a !== 0 && o.msaaTextures?.length) throw Error("[RenderTargetSystem] Rendering to array layers is not supported with MSAA render targets.");
		if (i > 0 && o.msaaTextures?.length) throw Error("[RenderTargetSystem] Rendering to mip levels is not supported with MSAA render targets.");
		let s = t;
		typeof s == "boolean" && (s = s ? pe.ALL : pe.NONE), (e.stencil || e.depth) && !e.depthStencilAttachment && e.ensureDepthStencilTexture();
		let c = !!e.depthStencilAttachment, l = this._activePass;
		if (l !== null && l.renderTarget === e && l.mipLevel === i && l.layer === a && l.depthStencil === c && this._renderer.encoder.renderPassEncoder !== null && s === pe.NONE) {
			this._renderer.encoder.setViewport(r);
			return;
		}
		o.descriptor = this.getDescriptor(e, t, n, i, a), this._renderer.pipeline.setRenderTarget(e), this._renderer.encoder.beginRenderPass(o), this._renderer.encoder.setViewport(r), this._activePass = {
			renderTarget: e,
			mipLevel: i,
			layer: a,
			depthStencil: c
		};
	}
	finishRenderPass() {
		this._renderer.encoder.endRenderPass(), this._activePass = null;
	}
	_getGpuColorTexture(e) {
		if (e.colorAttachments.length === 0) throw Error("[GpuRenderTargetAdaptor] cannot get gpu color texture from a depth-only render target");
		let t = e.colorAttachments[0].texture;
		return t instanceof L && t._gpuContext ? t._gpuContext.getCurrentTexture() : this._renderer.texture.getGpuSource(t);
	}
	getDescriptor(e, t, n, r = 0, i = 0) {
		typeof t == "boolean" && (t = t ? pe.ALL : pe.NONE);
		let a = this._renderTargetSystem, o = a.getGpuRenderTarget(e), s = e.colorAttachments.map((e, s) => {
			let c = e.texture, l = c instanceof L ? c._gpuContext : null, u, d;
			if (l) {
				if (i !== 0) throw Error("[RenderTargetSystem] Rendering to array layers is not supported for canvas targets.");
				u = l.getCurrentTexture().createView(e.viewDescriptor);
			} else u = this._renderer.texture.getTextureRenderTargetView(e.texture, r, i, e.viewDescriptor);
			let f = !1;
			o.msaaTextures[s] && (d = u, u = this._renderer.texture.getTextureView(o.msaaTextures[s]), f = o.msaaTextures[s].transient);
			let p = e.loadOp;
			t !== void 0 && (p = t & pe.COLOR ? "clear" : "load"), n ??= a.defaultClearColor;
			let m = e.storeOp ?? "store", h = {
				view: u,
				resolveTarget: d,
				storeOp: f ? "discard" : m,
				loadOp: p
			};
			p === "clear" && (n ??= e.clearValue ?? a.defaultClearColor, h.clearValue = n);
			for (let t in e) t !== "texture" && t !== "viewDescriptor" && t !== "clearValue" && t !== "loadOp" && t !== "storeOp" && (h[t] = e[t]);
			return h;
		}), c;
		if (e.depthStencilAttachment) {
			o.msaa && (e.depthStencilAttachment.texture.sampleCount = 4), e.depthStencilAttachment.texture.transient = !!o.msaaTextures[0]?.transient;
			let n = e.depthStencilAttachment, a = n.texture.format.includes("stencil"), s = n.texture.format.includes("depth"), l = n.texture.transient ? "discard" : "store";
			c = { view: this._renderer.texture.getTextureRenderTargetView(n.texture, r, i, n.viewDescriptor) };
			let u = n.depthReadOnly ?? !1, d = n.stencilReadOnly ?? u;
			a && !d ? (c.stencilLoadOp = t & pe.STENCIL ? "clear" : n.stencilLoadOp ?? "load", c.stencilStoreOp = n.stencilStoreOp ?? l, c.stencilLoadOp === "clear" && (c.stencilClearValue = n.stencilClearValue ?? 0)) : a && d && (c.stencilReadOnly = !0), s && !u ? (c.depthLoadOp = t & pe.DEPTH ? "clear" : n.depthLoadOp ?? "load", c.depthStoreOp = n.depthStoreOp ?? l, c.depthLoadOp === "clear" && (c.depthClearValue = n.depthClearValue ?? 1)) : s && u && (c.depthReadOnly = !0);
			for (let e in n) e !== "texture" && e !== "viewDescriptor" && e !== "stencilLoadOp" && e !== "stencilStoreOp" && e !== "stencilClearValue" && e !== "stencilReadOnly" && e !== "depthLoadOp" && e !== "depthStoreOp" && e !== "depthClearValue" && e !== "depthReadOnly" && (c[e] = n[e]);
		}
		return {
			colorAttachments: s,
			depthStencilAttachment: c,
			label: e.label
		};
	}
	clear(e, t = !0, n, r, i = 0, a = 0) {
		if (!t) return;
		let { gpu: o, encoder: s } = this._renderer, c = o.device;
		if (s.commandEncoder === null) {
			let o = c.createCommandEncoder(), s = this.getDescriptor(e, t, n, i, a), l = o.beginRenderPass(s);
			l.setViewport(r.x, r.y, r.width, r.height, 0, 1), l.end();
			let u = o.finish();
			c.queue.submit([u]);
		} else this.startRenderPass(e, t, n, r, i, a);
	}
	initGpuRenderTarget(e) {
		e.isRoot = !0;
		let t = new Gs();
		return e.colorAttachments.forEach((e, n) => {
			let r = e.texture;
			if (r instanceof L) {
				if (!r._gpuContext) {
					let e = r.resource.getContext("webgpu"), t = r.transparent ? "premultiplied" : "opaque", n = qs(r.format);
					try {
						e.configure({
							device: this._renderer.gpu.device,
							usage: GPUTextureUsage.TEXTURE_BINDING | GPUTextureUsage.COPY_DST | GPUTextureUsage.RENDER_ATTACHMENT | GPUTextureUsage.COPY_SRC,
							format: n,
							alphaMode: t,
							...n === "rgba16float" ? { toneMapping: { mode: "extended" } } : {}
						});
					} catch (e) {
						console.error(e);
					}
					r._gpuContext = e;
				}
				t.contexts[n] = r._gpuContext;
			}
			if (t.msaa = r.source.antialias, r.antialias) {
				let e = new m({
					width: 0,
					height: 0,
					sampleCount: 4,
					transient: r.transient,
					arrayLayerCount: r.arrayLayerCount,
					format: r.format
				});
				t.msaaTextures[n] = e;
			}
		}), t.msaa && (t.msaaSamples = 4, e.depthStencilAttachment && (e.depthStencilAttachment.texture.sampleCount = 4, e.depthStencilAttachment.texture.transient = !!t.msaaTextures[0]?.transient)), t;
	}
	destroyGpuRenderTarget(e) {
		e.contexts.forEach((e) => {
			e.unconfigure();
		}), e.msaaTextures.forEach((e) => {
			e.destroy();
		}), e.msaaTextures.length = 0, e.contexts.length = 0;
	}
	ensureDepthStencilTexture(e) {
		let t = this._renderTargetSystem.getGpuRenderTarget(e);
		e.depthStencilAttachment && t.msaa && (e.depthStencilAttachment.texture.sampleCount = 4);
	}
	resizeGpuRenderTarget(e) {
		let t = this._renderTargetSystem.getGpuRenderTarget(e);
		t.width = e.width, t.height = e.height, t.msaa && e.colorAttachments.forEach((e, n) => {
			let r = e.texture;
			t.msaaTextures[n]?.resize(r.width, r.height, r._resolution);
		});
	}
}, Ys = class extends Me {
	constructor(e) {
		super(e), this.adaptor = new Js(), this.adaptor.init(e, this);
	}
};
Ys.extension = {
	type: [D.WebGPUSystem],
	name: "renderTarget"
};
//#endregion
//#region node_modules/pixi.js/lib/rendering/renderers/gpu/shader/GpuShaderSystem.mjs
var Xs = class {
	constructor() {
		this._gpuProgramData = /* @__PURE__ */ Object.create(null);
	}
	contextChange(e) {
		this._gpu = e;
	}
	getProgramData(e) {
		return this._gpuProgramData[e._layoutKey] || this._createGPUProgramData(e);
	}
	_createGPUProgramData(e) {
		let t = this._gpu.device, n = e.gpuLayout.map((e) => t.createBindGroupLayout({ entries: e })), r = { bindGroupLayouts: n };
		return this._gpuProgramData[e._layoutKey] = {
			bindGroups: n,
			pipeline: t.createPipelineLayout(r)
		}, this._gpuProgramData[e._layoutKey];
	}
	destroy() {
		this._gpu = null, this._gpuProgramData = null;
	}
};
Xs.extension = {
	type: [D.WebGPUSystem],
	name: "shader"
};
//#endregion
//#region node_modules/pixi.js/lib/rendering/renderers/gpu/state/GpuBlendModesToPixi.mjs
var Zs = {};
Zs.normal = {
	alpha: {
		srcFactor: "one",
		dstFactor: "one-minus-src-alpha",
		operation: "add"
	},
	color: {
		srcFactor: "one",
		dstFactor: "one-minus-src-alpha",
		operation: "add"
	}
}, Zs.add = {
	alpha: {
		srcFactor: "src-alpha",
		dstFactor: "one-minus-src-alpha",
		operation: "add"
	},
	color: {
		srcFactor: "one",
		dstFactor: "one",
		operation: "add"
	}
}, Zs.multiply = {
	alpha: {
		srcFactor: "one",
		dstFactor: "one-minus-src-alpha",
		operation: "add"
	},
	color: {
		srcFactor: "dst",
		dstFactor: "one-minus-src-alpha",
		operation: "add"
	}
}, Zs.screen = {
	alpha: {
		srcFactor: "one",
		dstFactor: "one-minus-src-alpha",
		operation: "add"
	},
	color: {
		srcFactor: "one",
		dstFactor: "one-minus-src",
		operation: "add"
	}
}, Zs.overlay = {
	alpha: {
		srcFactor: "one",
		dstFactor: "one-minus-src-alpha",
		operation: "add"
	},
	color: {
		srcFactor: "one",
		dstFactor: "one-minus-src",
		operation: "add"
	}
}, Zs.none = {
	alpha: {
		srcFactor: "one",
		dstFactor: "one-minus-src-alpha",
		operation: "add"
	},
	color: {
		srcFactor: "zero",
		dstFactor: "zero",
		operation: "add"
	}
}, Zs["normal-npm"] = {
	alpha: {
		srcFactor: "one",
		dstFactor: "one-minus-src-alpha",
		operation: "add"
	},
	color: {
		srcFactor: "src-alpha",
		dstFactor: "one-minus-src-alpha",
		operation: "add"
	}
}, Zs["add-npm"] = {
	alpha: {
		srcFactor: "one",
		dstFactor: "one",
		operation: "add"
	},
	color: {
		srcFactor: "src-alpha",
		dstFactor: "one",
		operation: "add"
	}
}, Zs["screen-npm"] = {
	alpha: {
		srcFactor: "one",
		dstFactor: "one-minus-src-alpha",
		operation: "add"
	},
	color: {
		srcFactor: "src-alpha",
		dstFactor: "one-minus-src",
		operation: "add"
	}
}, Zs.erase = {
	alpha: {
		srcFactor: "zero",
		dstFactor: "one-minus-src-alpha",
		operation: "add"
	},
	color: {
		srcFactor: "zero",
		dstFactor: "one-minus-src",
		operation: "add"
	}
}, Zs.min = {
	alpha: {
		srcFactor: "one",
		dstFactor: "one",
		operation: "min"
	},
	color: {
		srcFactor: "one",
		dstFactor: "one",
		operation: "min"
	}
}, Zs.max = {
	alpha: {
		srcFactor: "one",
		dstFactor: "one",
		operation: "max"
	},
	color: {
		srcFactor: "one",
		dstFactor: "one",
		operation: "max"
	}
};
//#endregion
//#region node_modules/pixi.js/lib/rendering/renderers/gpu/state/GpuStateSystem.mjs
var Qs = class {
	constructor() {
		this.defaultState = new M(), this.defaultState.blend = !0;
	}
	contextChange(e) {
		this.gpu = e;
	}
	getColorTargets(e, t, n) {
		let r = e.blend ? Zs[e.blendMode] || Zs.normal : void 0, i = [];
		for (let e = 0; e < t; e++) i[e] = {
			format: n,
			writeMask: 0,
			blend: r
		};
		return i;
	}
	destroy() {
		this.gpu = null;
	}
};
Qs.extension = {
	type: [D.WebGPUSystem],
	name: "state"
};
//#endregion
//#region node_modules/pixi.js/lib/rendering/renderers/gpu/texture/uploaders/gpuUploadBufferImageResource.mjs
var $s = {
	type: "image",
	upload(e, t, n, r = 0) {
		let i = e.resource, a = (e.pixelWidth | 0) * (e.pixelHeight | 0), o = i.byteLength / a;
		n.device.queue.writeTexture({
			texture: t,
			origin: {
				x: 0,
				y: 0,
				z: r
			}
		}, i, {
			offset: 0,
			rowsPerImage: e.pixelHeight,
			bytesPerRow: e.pixelWidth * o
		}, {
			width: e.pixelWidth,
			height: e.pixelHeight,
			depthOrArrayLayers: 1
		});
	}
}, ec = {
	"bc1-rgba-unorm": {
		blockBytes: 8,
		blockWidth: 4,
		blockHeight: 4
	},
	"bc2-rgba-unorm": {
		blockBytes: 16,
		blockWidth: 4,
		blockHeight: 4
	},
	"bc3-rgba-unorm": {
		blockBytes: 16,
		blockWidth: 4,
		blockHeight: 4
	},
	"bc7-rgba-unorm": {
		blockBytes: 16,
		blockWidth: 4,
		blockHeight: 4
	},
	"etc1-rgb-unorm": {
		blockBytes: 8,
		blockWidth: 4,
		blockHeight: 4
	},
	"etc2-rgba8unorm": {
		blockBytes: 16,
		blockWidth: 4,
		blockHeight: 4
	},
	"astc-4x4-unorm": {
		blockBytes: 16,
		blockWidth: 4,
		blockHeight: 4
	}
}, tc = {
	blockBytes: 4,
	blockWidth: 1,
	blockHeight: 1
}, nc = {
	type: "compressed",
	upload(e, t, n, r = 0) {
		let i = e.pixelWidth, a = e.pixelHeight, o = ec[e.format] || tc;
		for (let s = 0; s < e.resource.length; s++) {
			let c = e.resource[s], l = Math.ceil(i / o.blockWidth) * o.blockBytes;
			n.device.queue.writeTexture({
				texture: t,
				mipLevel: s,
				origin: {
					x: 0,
					y: 0,
					z: r
				}
			}, c, {
				offset: 0,
				bytesPerRow: l
			}, {
				width: Math.ceil(i / o.blockWidth) * o.blockWidth,
				height: Math.ceil(a / o.blockHeight) * o.blockHeight,
				depthOrArrayLayers: 1
			}), i = Math.max(i >> 1, 1), a = Math.max(a >> 1, 1);
		}
	}
}, rc = [
	"right",
	"left",
	"top",
	"bottom",
	"front",
	"back"
];
function ic(e) {
	return {
		type: "cube",
		upload(t, n, r) {
			let i = t.faces;
			for (let t = 0; t < rc.length; t++) {
				let a = i[rc[t]];
				(e[a.uploadMethodId] || e.image).upload(a, n, r, t);
			}
		}
	};
}
//#endregion
//#region node_modules/pixi.js/lib/rendering/renderers/gpu/texture/uploaders/gpuUploadImageSource.mjs
var ac = {
	type: "image",
	upload(e, t, n, r = 0) {
		let i = e.resource;
		if (!i) return;
		if (globalThis.HTMLImageElement && i instanceof HTMLImageElement) {
			let t = x.get().createCanvas(i.width, i.height);
			t.getContext("2d").drawImage(i, 0, 0, i.width, i.height), e.resource = t, u("ImageSource: Image element passed, converting to canvas and replacing resource.");
		}
		let a = Math.min(t.width, e.resourceWidth || e.pixelWidth), o = Math.min(t.height, e.resourceHeight || e.pixelHeight), s = e.alphaMode === "premultiply-alpha-on-upload";
		n.device.queue.copyExternalImageToTexture({ source: i }, {
			texture: t,
			origin: {
				x: 0,
				y: 0,
				z: r
			},
			premultipliedAlpha: s
		}, {
			width: a,
			height: o
		});
	}
}, oc = {
	type: "video",
	upload(e, t, n, r) {
		ac.upload(e, t, n, r);
	}
}, sc = class {
	constructor(e) {
		this.device = e, this.sampler = e.createSampler({ minFilter: "linear" }), this.pipelines = {};
	}
	_getMipmapPipeline(e) {
		let t = this.pipelines[e];
		return t || (this.mipmapShaderModule ||= this.device.createShaderModule({ code: "\n                        var<private> pos : array<vec2<f32>, 3> = array<vec2<f32>, 3>(\n                        vec2<f32>(-1.0, -1.0), vec2<f32>(-1.0, 3.0), vec2<f32>(3.0, -1.0));\n\n                        struct VertexOutput {\n                        @builtin(position) position : vec4<f32>,\n                        @location(0) texCoord : vec2<f32>,\n                        };\n\n                        @vertex\n                        fn vertexMain(@builtin(vertex_index) vertexIndex : u32) -> VertexOutput {\n                        var output : VertexOutput;\n                        output.texCoord = pos[vertexIndex] * vec2<f32>(0.5, -0.5) + vec2<f32>(0.5);\n                        output.position = vec4<f32>(pos[vertexIndex], 0.0, 1.0);\n                        return output;\n                        }\n\n                        @group(0) @binding(0) var imgSampler : sampler;\n                        @group(0) @binding(1) var img : texture_2d<f32>;\n\n                        @fragment\n                        fn fragmentMain(@location(0) texCoord : vec2<f32>) -> @location(0) vec4<f32> {\n                        return textureSample(img, imgSampler, texCoord);\n                        }\n                    " }), t = this.device.createRenderPipeline({
			layout: "auto",
			vertex: {
				module: this.mipmapShaderModule,
				entryPoint: "vertexMain"
			},
			fragment: {
				module: this.mipmapShaderModule,
				entryPoint: "fragmentMain",
				targets: [{ format: e }]
			}
		}), this.pipelines[e] = t), t;
	}
	generateMipmap(e) {
		let t = this._getMipmapPipeline(e.format);
		if (e.dimension === "3d" || e.dimension === "1d") throw Error("Generating mipmaps for non-2d textures is currently unsupported!");
		let n = e, r = e.depthOrArrayLayers || 1, i = e.usage & GPUTextureUsage.RENDER_ATTACHMENT;
		if (!i) {
			let t = {
				size: {
					width: Math.ceil(e.width / 2),
					height: Math.ceil(e.height / 2),
					depthOrArrayLayers: r
				},
				format: e.format,
				usage: GPUTextureUsage.TEXTURE_BINDING | GPUTextureUsage.COPY_SRC | GPUTextureUsage.RENDER_ATTACHMENT,
				mipLevelCount: e.mipLevelCount - 1
			};
			n = this.device.createTexture(t);
		}
		let a = this.device.createCommandEncoder({}), o = t.getBindGroupLayout(0);
		for (let s = 0; s < r; ++s) {
			let r = e.createView({
				baseMipLevel: 0,
				mipLevelCount: 1,
				dimension: "2d",
				baseArrayLayer: s,
				arrayLayerCount: 1
			}), c = +!!i;
			for (let i = 1; i < e.mipLevelCount; ++i) {
				let e = n.createView({
					baseMipLevel: c++,
					mipLevelCount: 1,
					dimension: "2d",
					baseArrayLayer: s,
					arrayLayerCount: 1
				}), i = a.beginRenderPass({ colorAttachments: [{
					view: e,
					storeOp: "store",
					loadOp: "clear",
					clearValue: {
						r: 0,
						g: 0,
						b: 0,
						a: 0
					}
				}] }), l = this.device.createBindGroup({
					layout: o,
					entries: [{
						binding: 0,
						resource: this.sampler
					}, {
						binding: 1,
						resource: r
					}]
				});
				i.setPipeline(t), i.setBindGroup(0, l), i.draw(3, 1, 0, 0), i.end(), r = e;
			}
		}
		if (!i) {
			let t = {
				width: Math.ceil(e.width / 2),
				height: Math.ceil(e.height / 2),
				depthOrArrayLayers: r
			};
			for (let r = 1; r < e.mipLevelCount; ++r) a.copyTextureToTexture({
				texture: n,
				mipLevel: r - 1
			}, {
				texture: e,
				mipLevel: r
			}, t), t.width = Math.ceil(t.width / 2), t.height = Math.ceil(t.height / 2);
		}
		return this.device.queue.submit([a.finish()]), i || n.destroy(), e;
	}
}, cc = class {
	constructor(e) {
		this.textureView = null, this.textureViews = /* @__PURE__ */ Object.create(null), this.gpuTexture = e;
	}
	destroy() {
		this.gpuTexture.destroy(), this.textureView = null, this.textureViews = null, this.gpuTexture = null;
	}
};
function lc(e) {
	return `${e.format || ""}.${e.dimension || ""}.${e.aspect || ""}.${e.baseMipLevel || 0}.${e.mipLevelCount || ""}.${e.baseArrayLayer || 0}.${e.arrayLayerCount || ""}`;
}
var uc = class e {
	constructor(t) {
		this._gpuSamplers = /* @__PURE__ */ Object.create(null), this._bindGroupHash = /* @__PURE__ */ Object.create(null), this._renderer = t, t.gc.addCollection(this, "_bindGroupHash", "hash"), this._managedTextures = new be({
			renderer: t,
			type: "resource",
			onUnload: this.onSourceUnload.bind(this),
			name: "gpuTextureSource"
		});
		let n = {
			image: ac,
			buffer: $s,
			video: oc,
			compressed: nc,
			...e.uploadExtensions
		};
		this._uploads = {
			...n,
			cube: ic(n)
		};
	}
	get managedTextures() {
		return Object.values(this._managedTextures.items);
	}
	contextChange(e) {
		this._gpu = e;
	}
	initSource(e) {
		return e._gpuData[this._renderer.uid]?.gpuTexture || this._initSource(e);
	}
	_initSource(e) {
		if (e.autoGenerateMipmaps) {
			let t = Math.max(e.pixelWidth, e.pixelHeight);
			e.mipLevelCount = Math.floor(Math.log2(t)) + 1;
		}
		let t;
		e.sampleCount > 1 ? (t = GPUTextureUsage.RENDER_ATTACHMENT, e.transient && this._renderer.device.extensions.transientAttachment && (t |= GPUTextureUsage.TRANSIENT_ATTACHMENT)) : (t = GPUTextureUsage.TEXTURE_BINDING | GPUTextureUsage.COPY_DST, e.uploadMethodId !== "compressed" && (t |= GPUTextureUsage.RENDER_ATTACHMENT, t |= GPUTextureUsage.COPY_SRC));
		let n = ec[e.format] || {
			blockBytes: 4,
			blockWidth: 1,
			blockHeight: 1
		}, r = Math.ceil(e.pixelWidth / n.blockWidth) * n.blockWidth, i = Math.ceil(e.pixelHeight / n.blockHeight) * n.blockHeight, a = {
			label: e.label,
			size: {
				width: r,
				height: i,
				depthOrArrayLayers: e.arrayLayerCount
			},
			format: e.format,
			sampleCount: e.sampleCount,
			mipLevelCount: e.mipLevelCount,
			dimension: e.dimension,
			usage: t
		}, o = this._gpu.device.createTexture(a);
		return e._gpuData[this._renderer.uid] = new cc(o), this._managedTextures.add(e) && (e.on("update", this.onSourceUpdate, this), e.on("resize", this.onSourceResize, this), e.on("updateMipmaps", this.onUpdateMipmaps, this)), this.onSourceUpdate(e), o;
	}
	onSourceUpdate(e) {
		let t = this.getGpuSource(e);
		t && (this._uploads[e.uploadMethodId] && this._uploads[e.uploadMethodId].upload(e, t, this._gpu), e.autoGenerateMipmaps && e.mipLevelCount > 1 && this.onUpdateMipmaps(e));
	}
	onUpdateMipmaps(e) {
		this._mipmapGenerator ||= new sc(this._gpu.device);
		let t = this.getGpuSource(e);
		this._mipmapGenerator.generateMipmap(t);
	}
	onSourceUnload(e) {
		e.off("update", this.onSourceUpdate, this), e.off("resize", this.onSourceResize, this), e.off("updateMipmaps", this.onUpdateMipmaps, this);
	}
	onSourceResize(e) {
		e._gcLastUsed = this._renderer.gc.now;
		let t = e._gpuData[this._renderer.uid], n = t?.gpuTexture;
		n ? (n.width !== e.pixelWidth || n.height !== e.pixelHeight) && (t.destroy(), this._bindGroupHash[e.uid] = null, e._gpuData[this._renderer.uid] = null, this.initSource(e)) : this.initSource(e);
	}
	_initSampler(e) {
		return this._gpuSamplers[e._resourceId] = this._gpu.device.createSampler(e), this._gpuSamplers[e._resourceId];
	}
	getGpuSampler(e) {
		return this._gpuSamplers[e._resourceId] || this._initSampler(e);
	}
	getGpuSource(e) {
		return e._gcLastUsed = this._renderer.gc.now, e._gpuData[this._renderer.uid]?.gpuTexture || this.initSource(e);
	}
	getTextureBindGroup(e) {
		return this._bindGroupHash[e.uid] || this._createTextureBindGroup(e);
	}
	_createTextureBindGroup(e) {
		let t = e.source;
		return this._bindGroupHash[e.uid] = new re({
			0: t,
			1: t.style,
			2: new C({ uTextureMatrix: {
				type: "mat3x3<f32>",
				value: e.textureMatrix.mapCoord
			} })
		}), this._bindGroupHash[e.uid];
	}
	getTextureView(e, t) {
		var n;
		let r = e.source;
		r._gcLastUsed = this._renderer.gc.now;
		let i = r._gpuData[this._renderer.uid];
		i ||= (this.initSource(r), r._gpuData[this._renderer.uid]);
		let a = t ? lc(t) : 0;
		return (n = i.textureViews)[a] || (n[a] = i.gpuTexture.createView({
			dimension: r.viewDimension,
			...t
		})), i.textureViews[a];
	}
	getTextureRenderTargetView(e, t = 0, n = 0, r) {
		var i;
		let a = e.source;
		a._gcLastUsed = this._renderer.gc.now;
		let o = a._gpuData[this._renderer.uid];
		o ||= (this.initSource(a), a._gpuData[this._renderer.uid]);
		let s = n * (a.mipLevelCount || 1) + t + 1;
		return r && (s = `${s}.${lc(r)}`), (i = o.textureViews)[s] || (i[s] = o.gpuTexture.createView({
			dimension: "2d",
			baseMipLevel: t,
			mipLevelCount: 1,
			baseArrayLayer: n,
			arrayLayerCount: 1,
			...r
		})), o.textureViews[s];
	}
	generateCanvas(e) {
		let t = this._renderer, n = t.gpu.device.createCommandEncoder(), r = x.get().createCanvas();
		r.width = e.source.pixelWidth, r.height = e.source.pixelHeight;
		let i = r.getContext("webgpu");
		return i.configure({
			device: t.gpu.device,
			usage: GPUTextureUsage.COPY_DST | GPUTextureUsage.COPY_SRC,
			format: x.get().getNavigator().gpu.getPreferredCanvasFormat(),
			alphaMode: "premultiplied"
		}), n.copyTextureToTexture({
			texture: t.texture.getGpuSource(e.source),
			origin: {
				x: 0,
				y: 0
			}
		}, { texture: i.getCurrentTexture() }, {
			width: r.width,
			height: r.height
		}), t.gpu.device.queue.submit([n.finish()]), r;
	}
	getPixels(e) {
		let t = this.generateCanvas(e), n = ze.getOptimalCanvasAndContext(t.width, t.height), r = n.context;
		r.drawImage(t, 0, 0);
		let { width: i, height: a } = t, o = r.getImageData(0, 0, i, a), s = new Uint8ClampedArray(o.data.buffer);
		return ze.returnCanvasAndContext(n), {
			pixels: s,
			width: i,
			height: a
		};
	}
	destroy() {
		this._managedTextures.destroy();
		for (let e of Object.keys(this._bindGroupHash)) {
			let t = Number(e);
			this._bindGroupHash[t]?.destroy();
		}
		this._renderer = null, this._gpu = null, this._mipmapGenerator = null, this._gpuSamplers = null, this._bindGroupHash = null;
	}
};
uc.extension = {
	type: [D.WebGPUSystem],
	name: "texture"
}, uc.uploadExtensions = /* @__PURE__ */ Object.create(null);
var dc = uc;
b.handleByMap(D.TextureUploaderWebGPU, dc.uploadExtensions);
//#endregion
//#region node_modules/pixi.js/lib/scene/graphics/gpu/GpuGraphicsAdaptor.mjs
var fc = class {
	constructor() {
		this._maxTextures = 0;
	}
	contextChange(e) {
		let t = new C({
			uTransformMatrix: {
				value: new w(),
				type: "mat3x3<f32>"
			},
			uColor: {
				value: new Float32Array([
					1,
					1,
					1,
					1
				]),
				type: "vec4<f32>"
			},
			uRound: {
				value: 0,
				type: "f32"
			}
		});
		this._maxTextures = e.limits.maxBatchableTextures;
		let n = Ie({
			name: "graphics",
			bits: [
				Pe,
				Se(this._maxTextures),
				Je,
				Ee
			]
		});
		this.shader = new te({
			gpuProgram: n,
			resources: { localUniforms: t }
		});
	}
	execute(e, t) {
		let n = t.context, r = n.customShader || this.shader, i = e.renderer, { batcher: a, instructions: o } = i.graphicsContext.getContextRenderData(n), s = i.encoder;
		s.setGeometry(a.geometry, r.gpuProgram);
		let c = i.globalUniforms.bindGroup;
		s.setBindGroup(0, c, r.gpuProgram);
		let l = i.renderPipes.uniformBatch.getUniformBindGroup(r.resources.localUniforms, !0);
		s.setBindGroup(2, l, r.gpuProgram);
		let u = o.instructions, d = null;
		for (let t = 0; t < o.instructionSize; t++) {
			let n = u[t];
			if (n.topology !== d && (d = n.topology, s.setPipelineFromGeometryProgramAndState(a.geometry, r.gpuProgram, e.state, n.topology, r._overrides)), r.groups[1] = n.bindGroup, !n.gpuBindGroup) {
				let e = n.textures;
				n.bindGroup = Re(e.textures, e.count, this._maxTextures), n.gpuBindGroup = i.bindGroup.getBindGroup(n.bindGroup, r.gpuProgram, 1);
			}
			s.setBindGroup(1, n.bindGroup, r.gpuProgram), s.renderPassEncoder.drawIndexed(n.size, 1, n.start);
		}
	}
	destroy() {
		this.shader.destroy(!0), this.shader = null;
	}
};
fc.extension = {
	type: [D.WebGPUPipesAdaptor],
	name: "graphics"
};
//#endregion
//#region node_modules/pixi.js/lib/scene/mesh/gpu/GpuMeshAdapter.mjs
var pc = class {
	init() {
		let e = Ie({
			name: "mesh",
			bits: [
				He,
				Ge,
				Ee
			]
		});
		this._shader = new te({
			gpuProgram: e,
			resources: {
				uTexture: p.EMPTY._source,
				uSampler: p.EMPTY._source.style,
				textureUniforms: { uTextureMatrix: {
					type: "mat3x3<f32>",
					value: new w()
				} }
			}
		});
	}
	execute(e, t) {
		let n = e.renderer, r = t._shader;
		if (!r) r = this._shader, r.groups[2] = n.texture.getTextureBindGroup(t.texture);
		else if (!r.gpuProgram) {
			u("Mesh shader has no gpuProgram", t.shader);
			return;
		}
		let i = r.gpuProgram;
		if (i.autoAssignGlobalUniforms && (r.groups[0] = n.globalUniforms.bindGroup), i.autoAssignLocalUniforms) {
			let t = e.localUniforms;
			r.groups[1] = n.renderPipes.uniformBatch.getUniformBindGroup(t, !0);
		}
		n.encoder.draw({
			geometry: t._geometry,
			shader: r,
			state: t.state
		});
	}
	destroy() {
		this._shader.destroy(!0), this._shader = null;
	}
};
pc.extension = {
	type: [D.WebGPUPipesAdaptor],
	name: "mesh"
};
//#endregion
//#region node_modules/pixi.js/lib/rendering/renderers/gpu/WebGPURenderer.mjs
var mc = /* @__PURE__ */ N({ WebGPURenderer: () => xc }), hc = [
	...Ae,
	js,
	ws,
	Cs,
	Ts,
	bs,
	dc,
	Ys,
	Xs,
	Qs,
	Ws,
	Ss,
	Es,
	vs
], gc = [...De, Ns], _c = [
	Qi,
	pc,
	fc
], vc = [], yc = [], bc = [];
b.handleByNamedList(D.WebGPUSystem, vc), b.handleByNamedList(D.WebGPUPipes, yc), b.handleByNamedList(D.WebGPUPipesAdaptor, bc), b.add(...hc, ...gc, ..._c);
var xc = class extends de {
	constructor() {
		let e = {
			name: "webgpu",
			type: O.WEBGPU,
			systems: vc,
			renderPipes: yc,
			renderPipeAdaptors: bc
		};
		super(e);
	}
};
//#endregion
//#region node_modules/pixi.js/lib/index.mjs
b.add($e, et);
//#endregion
//#region docs/research/2026-10-04-cloud-resume/kernel-display-witness.ts
function Sc(e, t, n) {
	let r = t === null ? "null" : typeof t;
	throw Error(`Display witness:${n}; class=${e.constructor.name}; label=${e.label}; textureKind=${r}`);
}
function Cc(e, t) {
	e instanceof l || Sc(t, e, "Expected public Rectangle");
	let n = {
		x: e.x,
		y: e.y,
		width: e.width,
		height: e.height
	};
	return Object.values(n).every(Number.isFinite) || Sc(t, e, "Nonfinite texture rectangle"), n;
}
function wc(e, t) {
	e instanceof p || Sc(t, e, "Expected public Texture");
	let n = e.source;
	return n instanceof m || Sc(t, n, "Expected public TextureSource"), (!Number.isFinite(n.width) || !Number.isFinite(n.height) || n.width < 0 || n.height < 0) && Sc(t, n, "Invalid public TextureSource dimensions"), {
		frame: Cc(e.frame, t),
		orig: Cc(e.orig, t),
		trim: e.trim === null || e.trim === void 0 ? null : Cc(e.trim, t),
		sourceWidth: n.width,
		sourceHeight: n.height
	};
}
function Tc(e) {
	if (!(e instanceof r)) throw Error("Public Container required");
	if (e instanceof V) return e.texture !== V.prototype.texture && Sc(e, e.texture, "Unrecognized Graphics drawing method"), {
		displayClass: "Graphics",
		anchor: null,
		texture: null,
		textureRole: "public-drawing-method"
	};
	if (e instanceof ae || e instanceof Ki) {
		let t = {
			x: e.anchor.x,
			y: e.anchor.y
		};
		return (!Number.isFinite(t.x) || !Number.isFinite(t.y)) && Sc(e, e.texture, "Invalid public anchor"), {
			displayClass: e instanceof ae ? "Sprite" : "TilingSprite",
			anchor: t,
			texture: wc(e.texture, e),
			textureRole: "public-texture"
		};
	}
	return e instanceof Di ? {
		displayClass: "Mesh",
		anchor: null,
		texture: wc(e.texture, e),
		textureRole: "public-texture"
	} : ("texture" in e && Sc(e, e.texture, "Unknown texture-bearing public class"), "anchor" in e && Sc(e, e.anchor, "Unknown anchor-bearing public class"), {
		displayClass: "Container",
		anchor: null,
		texture: null,
		textureRole: "no-public-texture"
	});
}
//#endregion
//#region src/view/emission-blending.ts
function Ec(e) {
	if (e.type === O.WEBGL) {
		let t = e, n = t.state, r = n.setBlendMode;
		return n.setBlendMode = function(e) {
			let n = this.blendMode;
			if (r.call(this, e), this.blendMode === "add" && n !== "add") {
				let e = t.gl;
				e.blendFuncSeparate(e.ONE, e.ONE, e.ZERO, e.ONE);
			}
		}, () => {
			n.setBlendMode("normal"), n.setBlendMode = r;
		};
	}
	if (e.type !== O.WEBGPU) return () => {};
	let t = e.state, n = t.getColorTargets;
	return t.getColorTargets = function(e, t, r) {
		let i = n.call(this, e, t, r);
		if (e.blend && e.blendMode === "add") for (let e of i) e.blend &&= {
			...e.blend,
			alpha: {
				srcFactor: "zero",
				dstFactor: "one",
				operation: "add"
			}
		};
		return i;
	}, () => {
		t.getColorTargets = n;
	};
}
//#endregion
//#region src/core/units.ts
function W(e) {
	return e;
}
function Dc(e) {
	return e;
}
function Oc(e) {
	return e / 180 * Math.PI;
}
//#endregion
//#region src/core/constants.ts
var G = 6371e3, kc = 2 * G * Math.PI, Ac = 3986004418e5;
kc / 86400;
var jc = 7292115e-11, Mc = Oc(Dc(25.997));
jc * Math.cos(Mc);
var Nc = 9.807, K = kc / 2, Pc = Math.PI * (9 / 2) ** 2, Fc = 35e4, Ic = 47e4, Lc = 3500;
Ic * (9 / 2) ** 2 * .25 + Ic * 2500 / 12;
var Rc = .1, zc = 1 / 2, Bc = 1 / 2, Vc = (e, t) => ({
	kind: e,
	offAxis: t,
	offAxisForceFraction: -t / Math.sqrt(t ** 2 + 625)
}), Hc = [
	Vc("sea-level", -1),
	Vc("sea-level", zc),
	Vc("sea-level", Bc),
	Vc("vacuum", -3),
	Vc("vacuum", 1.5),
	Vc("vacuum", 1.5)
], Uc = Hc.flatMap((e, t) => e.kind === "sea-level" ? [t] : []), Wc = 21.8, Gc = Oc(Dc(15)), Kc = 9.80665, qc = 23e4 * Kc, Jc = 101325;
qc / (327 * Kc) * Kc * 350, 158645.8058103975 / Jc, 258e3 * Kc / (380 * Kc);
var Yc = 2.3;
Math.PI * (Yc / 2) ** 2;
var Xc = qc, Zc = 8e5, Qc = W(1.03), $c = 24.2, el = 23.3, tl = 45.8, nl = 12.6, rl = 17415e-8, il = 5.670374419e-8, al = .85, ol = 1533, sl = 273.15, cl = al * il * ol ** 4, ll = 841800, ul = 8e4, dl = Nc * 1.6, fl = 1 * Xc;
fl * 2, fl * 3, 1 * Xc * 40 * .01;
var pl = Oc(Dc(3)), ml = Oc(Dc(10)), hl = Oc(Dc(20)), gl = 5.5, _l = gl, vl = _l * 1.5;
_l * 2;
var yl = Oc(Dc(55)), bl = Oc(Dc(85)), xl = W(Math.PI * .5), Sl = Oc(Dc(30)), Cl = 7.5, wl = 1.5, Tl = .75;
function El(e, t) {
	return t > 1 ? e * .85 < 7.5 ? e * t : e : e * .85 > 1.95 ? e * t : e;
}
var Dl = 2e4;
function Ol(e) {
	if (Number.isNaN(e) || e <= 500) return 1;
	if (e >= 2e4) return 5;
	let t = Math.log(e / 500) / Math.log(Dl / 500);
	return 1 + 4 * (t * t * (3 - 2 * t));
}
function kl(e, t, n, r, i = 1, a = 0) {
	let o = 4, s = n / o;
	s < 100 && (o = o * s / 100, s = 100), s > 220 && (o = o * s / 220, s = 220);
	let c = i / Ol(a);
	o /= c, s *= c;
	let l = r * o, u = t / n;
	e.width = t, e.height = n, e.physicalHeight = l, e.physicalWidth = l * u, e.scale = s / r;
}
function Al(e, t, n, r = 1, i = 0) {
	let a = {
		width: 0,
		height: 0,
		physicalHeight: 0,
		physicalWidth: 0,
		scale: 0
	};
	return kl(a, e, t, n, r, i), a;
}
function jl(e, t, n, r) {
	return {
		posX: t,
		posY: e.physicalHeight / 2,
		speedX: n,
		speedY: r,
		accX: 0,
		accY: 0,
		sticky: !0,
		shakeX: 0,
		shakeY: 0,
		shakeTime: 0,
		padHeld: !1
	};
}
function Ml(e, t, n, r, i, a = !0) {
	let o = t - e, s = Math.abs(o);
	if (s < n) return o / i;
	if (a && s >= r) return 0;
	let c = s < r ? (r - n) / (r - s) : 2, l = c > 2 ? 2 : c;
	return o / i * l;
}
function Nl(e, t, n) {
	return (t - e) / n;
}
var Pl = .6, Fl = .18;
function Il(e, t) {
	let n = t * .5 * Fl, r = e * Pl;
	return r > n ? n : r < -n ? -n : r;
}
var Ll = .006;
function Rl(e, t) {
	let n = Math.max(0, e) / 30 + Math.max(0, t) / 20 * .5;
	return n > 1 ? 1 : n;
}
function zl(e, t) {
	return Math.sin(e * (37.1 + t) + t) * .6 + Math.sin(e * (11.7 + t * 2) + t) * .4;
}
var Bl = 1.3, Vl = {
	x: 0,
	speedX: 0,
	leadScale: 1,
	pinned: !1,
	held: !1
};
function Hl(e, t, n, r, i, a) {
	switch (a.pinned = !1, a.leadScale = 1, a.x = t.downRangeDistance, a.speedX = t.speedX, a.held = !1, e) {
		case "pad":
			Math.abs(t.downRangeDistance - r) <= n.physicalWidth * (i ? .18 : .12) && (a.x = r, a.speedX = 0, a.leadScale = 0, a.held = !0);
			return;
		case "chase":
			a.leadScale = Bl;
			return;
		case "onboard":
			a.pinned = !0, a.leadScale = 0;
			return;
		default: return;
	}
}
function Ul(e, t) {
	return !(e.landed || e.onTheGround || e.crashed || e.altitude <= t.physicalHeight && e.speedY < 0);
}
var Wl = 1 / 120;
function Gl(e, t, n, r, i, a) {
	if (e.sticky = Ul(t, n), Hl(i, t, n, a, e.padHeld, Vl), e.padHeld = Vl.held, Vl.pinned) {
		e.posX = t.downRangeDistance, e.speedX = t.speedX, e.accX = 0;
		let r = n.physicalHeight * .5;
		e.posY = Math.max(r, t.altitude), e.speedY = t.speedY, e.accY = 0;
		return;
	}
	let o = Il(t.speedX, n.physicalWidth) * Vl.leadScale, s = t.crashed;
	if (e.accX = Ml(e.posX, Vl.x + o, n.physicalWidth * .25, n.physicalWidth / 2, 1, s) + Nl(e.speedX, Vl.speedX, e.sticky ? 1 : 2), e.speedX += e.accX * r, e.posX += e.speedX * r, e.sticky) {
		let i = Il(t.speedY, n.physicalHeight) * Vl.leadScale;
		e.accY = Ml(e.posY, t.altitude + i, n.physicalHeight * .25, n.physicalHeight / 2, 1, s) + Nl(e.speedY, t.speedY, 1), e.speedY += e.accY * r, e.posY += e.speedY * r;
		let a = n.physicalHeight * .5;
		e.posY < a && (e.posY = a);
	} else e.accY = 0, e.speedY = 0, e.posY = n.physicalHeight * .5;
}
function Kl(e, t, n, r, i) {
	let a = r > 0 ? r : 0, o = a > .008333333333333333 ? Math.min(64, Math.ceil(a / Wl)) : 1, s = a / o, c = i?.mode ?? "follow", l = i?.padX ?? K;
	for (let r = 0; r < o; r++) Gl(e, t, n, s, c, l);
	if (i?.reducedMotion) {
		e.shakeX = 0, e.shakeY = 0;
		return;
	}
	e.shakeTime += a;
	let u = Rl(t.dynamicPressure ?? 0, t.thrustAcceleration ?? 0) * n.physicalHeight * Ll;
	e.shakeX = u * zl(e.shakeTime, 1), e.shakeY = u * zl(e.shakeTime, 2);
	let d = n.physicalHeight * .5, f = d - e.posY, p = Infinity;
	!t.crashed && Math.abs(t.altitude - e.posY) <= d && (f = Math.max(f, t.altitude - d - e.posY), p = t.altitude + d - e.posY), e.shakeY = Math.max(f, Math.min(p, e.shakeY));
}
function ql(e, t, n, r) {
	return {
		x: t.width / 2 + (n - e.posX - e.shakeX) * t.scale,
		y: t.height / 2 - (r - e.posY - e.shakeY) * t.scale
	};
}
//#endregion
//#region src/view/app.ts
var Jl = 10599899;
async function Yl(e) {
	let t = e.width ?? globalThis.innerWidth ?? 800, n = e.height ?? globalThis.innerHeight ?? 600, i = new sn();
	await i.init({
		canvas: e.canvas,
		width: t,
		height: n,
		background: Jl,
		antialias: !0,
		resolution: Math.min(globalThis.devicePixelRatio || 1, 2),
		autoDensity: !0,
		...e.preference ? { preference: e.preference } : {}
	});
	let a = Ec(i.renderer), o = {
		sky: new r({ label: "sky" }),
		far: new r({ label: "far" }),
		world: new r({ label: "world" }),
		effectsBehind: new r({ label: "effectsBehind" }),
		vehicle: new r({ label: "vehicle" }),
		effectsFront: new r({ label: "effectsFront" })
	};
	i.stage.addChild(o.sky, o.far, o.world, o.effectsBehind, o.vehicle, o.effectsFront);
	let s = 1, c = 1, l = 0, u = Al(t, n, e.vehicleHeight);
	return {
		app: i,
		layers: o,
		camera: jl(u, e.downRangeDistance, e.speedX ?? 0, e.speedY ?? 0),
		get viewport() {
			return u;
		},
		set viewport(e) {
			u.width = e.width, u.height = e.height, u.physicalHeight = e.physicalHeight, u.physicalWidth = e.physicalWidth, u.scale = e.scale;
		},
		followAltitude(t) {
			l = t, kl(u, u.width, u.height, e.vehicleHeight, s * c, t);
		},
		setModeZoom(t) {
			if (t === c) return;
			c = t;
			let n = Al(u.width, u.height, e.vehicleHeight).scale;
			n * s * c > 7.5 && (s = Cl / (n * c)), kl(u, u.width, u.height, e.vehicleHeight, s * c, l);
		},
		zoom(t) {
			let n = t > 0 ? wl : Tl, r = Al(u.width, u.height, e.vehicleHeight, s), i = t > 0 ? r.scale * c : r.scale;
			El(i, n) !== i && (s *= n, kl(u, u.width, u.height, e.vehicleHeight, s * c, l));
		},
		resize(t, n) {
			i.renderer.resize(t, n), kl(u, t, n, e.vehicleHeight, s * c, l);
		},
		destroy() {
			a(), i.destroy(!0, {
				children: !0,
				texture: !0
			});
		}
	};
}
//#endregion
//#region src/core/vehicles/v3.ts
var Xl = 9.80665, Zl = Object.freeze({
	standardGravity: Xl,
	referencePressurePa: 101325,
	seaLevel: Object.freeze({
		thrustSeaLevel: 25e4 * Xl,
		ispSeaLevel: 327,
		ispVacuum: 350
	}),
	vacuum: Object.freeze({
		thrustVacuum: 275e3 * Xl,
		ispVacuum: 380,
		effectiveExitArea: Math.PI * (2.3 / 2) ** 2
	})
});
function Ql(e, t) {
	return Object.freeze({
		kind: e,
		gimballed: t
	});
}
var $l = Object.freeze({
	id: "ship",
	height: 52,
	diameter: 9,
	dryMass: 12e4,
	propellantCapacity: 16e5,
	engines: Object.freeze([
		Ql("sea-level", !0),
		Ql("sea-level", !0),
		Ql("sea-level", !0),
		Ql("vacuum", !1),
		Ql("vacuum", !1),
		Ql("vacuum", !1)
	]),
	propulsion: Zl
}), eu = Object.freeze({
	id: "super-heavy",
	height: 72,
	diameter: 9,
	dryMass: 2e5,
	propellantCapacity: 365e4,
	engines: Object.freeze(Array.from({ length: 33 }, (e, t) => Ql("sea-level", t < 13))),
	propulsion: Zl,
	gridFins: Object.freeze({
		count: 3,
		area: 27
	})
});
Object.freeze({
	ship: $l,
	superHeavy: eu
});
var tu = 3.6 / 4.6, nu = 1141, ru = $l.propellantCapacity, iu = $l.height / 50, au = 5, ou = Math.PI * (9 / 2) ** 2, su = ru * tu / (nu * ou), cu = ru * .21739130434782605 / (424 * ou), q = Object.freeze({
	id: "ship",
	propulsion: $l.propulsion,
	height: $l.height,
	diameter: $l.diameter,
	dryMass: $l.dryMass,
	propellantCapacity: ru,
	initialPropellant: Fc,
	dryCentreOfMass: Wc * iu,
	tankBottom: au,
	loxTankHeight: su,
	ch4TankHeight: cu,
	ch4TankBottom: au + su,
	aftFinStation: (Wc - nl) * iu,
	frontFinStation: (Wc + el) * iu,
	rcsStation: (Wc + 20) * iu,
	minArea: Pc,
	maxArea: $l.height * $l.diameter,
	frontFinArea: $c,
	aftFinArea: tl,
	engines: Object.freeze(Hc.map((e) => Object.freeze({
		...e,
		offAxisForceFraction: -e.offAxis / Math.sqrt(e.offAxis ** 2 + ($l.height / 2) ** 2)
	}))),
	ignitionGroup: Uc
}), lu = Object.freeze([
	0,
	1,
	2
]), uu = Object.freeze(Array.from({ length: 13 }, (e, t) => t)), du = Object.freeze({
	centre: lu,
	inner: Object.freeze(Array.from({ length: 10 }, (e, t) => t + 3)),
	outer: Object.freeze(Array.from({ length: 20 }, (e, t) => t + 13))
}), fu = eu.height, pu = eu.diameter, mu = eu.propellantCapacity, hu = 3, gu = .9 * fu, _u = 66 / 71 * fu, vu = Math.PI * (pu / 2) ** 2, yu = mu * tu / (nu * vu), bu = mu * (1 - tu) / (424 * vu), xu = (e, t) => Object.freeze({
	kind: "sea-level",
	offAxis: e,
	gimballed: t,
	offAxisForceFraction: 0
}), Su = (e, t, n) => Array.from({ length: e }, (r, i) => xu(t * Math.cos(2 * Math.PI * i / e), n)), J = Object.freeze({
	id: "super-heavy",
	propulsion: eu.propulsion,
	height: fu,
	diameter: pu,
	dryMass: eu.dryMass,
	propellantCapacity: mu,
	initialPropellant: 5e5,
	dryCentreOfMass: fu / 2,
	tankBottom: hu,
	loxTankHeight: yu,
	ch4TankHeight: bu,
	ch4TankBottom: hu + yu,
	aftFinStation: gu,
	frontFinStation: gu,
	rcsStation: _u,
	minArea: vu,
	maxArea: fu * pu,
	frontFinArea: 0,
	aftFinArea: 0,
	engines: Object.freeze([
		xu(0, !0),
		xu(-.65, !0),
		xu(.65, !0),
		...Su(10, 2, !0),
		...Su(20, 3.8, !1)
	]),
	ignitionGroup: uu,
	gridFins: Object.freeze({
		count: 3,
		area: eu.gridFins.area,
		station: gu,
		maxAngle: Math.PI / 4
	})
}), Cu = 65 / 71 * fu, Y = Object.freeze({
	lugStation: Cu,
	planeAltitude: 120,
	bodyCentreAltitude: 120 - (Cu - fu / 2),
	halfWidth: 2.25,
	maxDownSpeed: 4.5,
	maxLateralSpeed: 1,
	maxPitch: 5 * Math.PI / 180
}), wu = 7920, Tu = 293.15, Eu = 1473.15;
function Du(e) {
	if (!Number.isFinite(e) || e < 4 || e > 1473.15) throw RangeError("304 thermal temperature must be within4–1473.15K");
}
var Ou = [
	22.0061,
	-127.5528,
	303.647,
	-381.0098,
	274.0328,
	-112.9212,
	24.7593,
	-2.239153
], ku = [
	-1.4087,
	1.3982,
	.2543,
	-.626,
	.2334,
	.4256,
	-.4658,
	.165,
	-.0199
], Au = 273.15, ju = 20, Mu = .0625, Nu = Math.ceil(269.15 / Mu), Pu = /* @__PURE__ */ new Float64Array(4308), Fu = /* @__PURE__ */ new Float64Array(4308);
function Iu(e, t) {
	let n = Math.log10(e), r = 0;
	for (let e = t.length - 1; e >= 0; e--) r = r * n + t[e];
	return 10 ** r;
}
function Lu(e) {
	return Math.min(Au, 4 + e * Mu);
}
for (let e = 0; e <= Nu; e++) {
	let t = Lu(e);
	if (Pu[e] = Iu(t, Ou), e > 0) {
		let n = t - Lu(e - 1);
		Fu[e] = Fu[e - 1] + n * (Pu[e - 1] + Pu[e]) / 2;
	}
}
function Ru(e) {
	return 6.683 + .04906 * e + 80.74 * Math.log(e);
}
function zu(e) {
	return 9.705 + .0176 * e - 16e-7 * e ** 2;
}
var Bu = Pu[Nu], Vu = Ru(Tu), Hu = Iu(Au, ku), Uu = zu(Tu), Wu = ju * (Bu + Vu) / 2, Gu = -Fu[Nu] - Wu;
function Ku(e) {
	return Math.min(4306, Math.floor((e - 4) / Mu));
}
function qu(e) {
	return (e - Au) / ju;
}
function Ju(e, t, n) {
	return e + (t - e) * n ** 2 * (3 - 2 * n);
}
function Yu(e) {
	if (Du(e), e >= 293.15) return Ru(e);
	if (e >= Au) return Ju(Bu, Vu, qu(e));
	let t = Ku(e), n = (e - Lu(t)) / (Lu(t + 1) - Lu(t));
	return Pu[t] + n * (Pu[t + 1] - Pu[t]);
}
function Xu(e) {
	return Du(e), e >= 293.15 ? zu(e) : e >= Au ? Ju(Hu, Uu, qu(e)) : Iu(e, ku);
}
function Zu(e) {
	return 6.683 * e + .02453 * e ** 2 + 80.74 * (e * Math.log(e) - e);
}
var Qu = Zu(Tu), $u = Zu(Eu) - Qu;
function ed(e) {
	if (e >= 293.15) return Zu(e) - Qu;
	if (e >= Au) {
		let t = qu(e);
		return -Wu + ju * (Bu * t + (Vu - Bu) * (t ** 3 - t ** 4 / 2));
	}
	let t = Ku(e), n = e - Lu(t), r = Lu(t + 1) - Lu(t), i = (Pu[t + 1] - Pu[t]) / r;
	return Gu + Fu[t] + Pu[t] * n + i * n ** 2 / 2;
}
function td(e) {
	return Du(e), ed(e);
}
function nd(e) {
	let t = 4, n = Eu;
	for (let r = 0; r < 48; r++) {
		let r = (t + n) / 2;
		ed(r) < e ? t = r : n = r;
	}
	return (t + n) / 2;
}
function rd(e) {
	if (e < -Wu) {
		let t = 0, n = Nu;
		for (; n - t > 1;) {
			let r = Math.floor((t + n) / 2);
			Gu + Fu[r] <= e ? t = r : n = r;
		}
		let r = Lu(t + 1) - Lu(t), i = Pu[t], a = (Pu[t + 1] - i) / r, o = e - (Gu + Fu[t]), s = 2 * o / (i + Math.sqrt(i * i + 2 * a * o));
		return Lu(t) + s;
	}
	let t = e < 0 ? Au : Tu, n = e < 0 ? Tu : Eu, r = e < 0 ? -Wu : 0, i = e < 0 ? 0 : $u, a = t + (n - t) * (e - r) / (i - r);
	for (let r = 0; r < 6; r++) {
		let r = ed(a);
		if (r === e) break;
		r < e ? t = a : n = a;
		let i = a - (r - e) / Yu(a);
		if (i === a) break;
		a = i > t && i < n ? i : (t + n) / 2;
	}
	return a;
}
function id(e) {
	if (!Number.isFinite(e) || e < Gu || e > $u) throw RangeError("304 specific enthalpy is outside the thermal fit domain");
	if (e === 0) return Tu;
	if (e === Gu) return 4;
	if (e === $u) return Eu;
	let t = rd(e), n = 4, r = Eu, i = n, a = r;
	for (let e = 0; e < 48; e++) {
		let o = (n + r) / 2;
		o < t ? n = o : r = o, e === 39 && (i = n, a = r);
	}
	if (ed(n) < e && ed(r) >= e) return (n + r) / 2;
	if (ed(i) < e && ed(a) >= e) {
		n = i, r = a;
		for (let t = 40; t < 48; t++) {
			let t = (n + r) / 2;
			ed(t) < e ? n = t : r = t;
		}
		return (n + r) / 2;
	}
	return nd(e);
}
var ad = [
	[
		373.15,
		18721e7,
		223e6
	],
	[
		473.15,
		176314e6,
		19e7
	],
	[
		573.15,
		169642e6,
		18e7
	],
	[
		673.15,
		159526e6,
		172e6
	],
	[
		773.15,
		1468e8,
		153e6
	],
	[
		873.15,
		13739e7,
		136e6
	],
	[
		973.15,
		12545e7,
		112e6
	],
	[
		1073.15,
		10808e7,
		62e6
	],
	[
		1173.15,
		6755e7,
		35e6
	]
];
function od(e, t) {
	if (!Number.isFinite(e) || e <= 0) throw RangeError("304 mechanical temperature must be finite and positiveK");
	if (e > 1173.15) return 0;
	let n = 373.15, r = ad[0][t];
	if (e <= n) return r;
	for (let i of ad) {
		if (e <= i[0]) {
			let a = (e - n) / (i[0] - n);
			return r + a * (i[t] - r);
		}
		n = i[0], r = i[t];
	}
	return 0;
}
function sd(e) {
	return od(e, 1);
}
function cd(e) {
	return od(e, 2);
}
//#endregion
//#region src/core/physics/damage-root.ts
function ld(e) {
	let t = .1 * e, n = .15 * e, r = .05 * e, i = .004;
	if (!(t > 2 * i && n > 2 * i)) throw RangeError("Invalid attachment section");
	let a = t * n - (t - 2 * i) * (n - 2 * i), o = (t * n ** 3 - (t - 2 * i) * (n - 2 * i) ** 3) / 12;
	return Object.freeze({
		area: a,
		inertia: o,
		modulus: 2 * o / n,
		length: r,
		heatArea: t * r,
		mass: wu * a * r
	});
}
function ud(e, t) {
	return t === "plate" ? Math.sin(e) : Math.hypot(Math.sin(2 * e), 1.2 * Math.sin(e) ** 2);
}
function dd(e, t, n, r, i, a) {
	let o = Math.abs(e), s = a === "plate" ? Math.PI / 2 : Math.PI / 4;
	if (!Number.isFinite(e) || o > s || t < 0 || n < 0 || !Number.isFinite(t) || !Number.isFinite(n)) throw RangeError("Attachment load outside the monotone force domain");
	let c = sd(r);
	if (c === 0) return 0;
	if (o === 0 || t === 0 || n === 0) return e;
	let l = t * n * i.length / (c * i.inertia), u = o;
	for (let e = 0; e < 2; e++) {
		let e = ud(u, a), t = Math.sin(u), n = Math.cos(u), r = a === "plate" ? n : e === 0 ? 2 : (2 * Math.sin(2 * u) * Math.cos(2 * u) + 2.88 * t ** 3 * n) / e;
		if (u -= (u + l * e - o) / (1 + l * r), !(u > 0 && u <= o)) break;
	}
	if (u > 0 && u <= o) {
		let t = 0, n = o;
		for (let e = 0; e < 40; e++) {
			let e = (t + n) / 2;
			e < u ? t = e : n = e;
		}
		if (t + l * ud(t, a) < o && n + l * ud(n, a) >= o) return Math.sign(e) * (t + n) / 2;
	}
	let d = 0, f = o;
	for (let e = 0; e < 40; e++) {
		let e = (d + f) / 2;
		e + l * ud(e, a) < o ? d = e : f = e;
	}
	return Math.sign(e) * (d + f) / 2;
}
function fd(e, t, n) {
	let r = cd(t) * n.modulus;
	return r === 0 ? Infinity : Math.abs(e) / r;
}
//#endregion
//#region src/core/physics/vehicle-components.ts
var pd = 1525, md = .004, hd = 144, gd = .0254, _d = 20 * Math.PI / 180;
function vd(e, t, n, r, i) {
	if (!(t > 0 && i > 0) || !Number.isFinite(t + n + r + i)) throw RangeError("Component slice requires positive finite mass and inertia");
	return Object.freeze({
		role: e,
		mass: t,
		x: n,
		station: r,
		inertia: i
	});
}
function yd(e, t, n, r, i = 0) {
	let a = n.reduce((e, t) => e + t.mass, 0), o = n.reduce((e, t) => e + t.mass * t.x, 0) / a, s = n.reduce((e, t) => e + t.mass * t.station, 0) / a, c = n.reduce((e, t) => e + t.inertia + t.mass * ((t.x - o) ** 2 + (t.station - s) ** 2), 0);
	return Object.freeze({
		id: e,
		kind: t,
		mass: a,
		x: o,
		station: s,
		inertia: c,
		loadLever: i,
		rootMass: n.reduce((e, t) => e + (t.role === "root" ? t.mass : 0), 0),
		tpsMass: n.reduce((e, t) => e + (t.role === "tps" ? t.mass : 0), 0),
		...r ? { hinge: Object.freeze({ ...r }) } : {},
		slices: Object.freeze(n)
	});
}
function bd(e, t, n, r, i, a, o, s, c) {
	if (!(n > 0 && r > 0)) throw RangeError("Appendage area and span must be positive");
	let l = n / r, u = wu * md * n, d = i * (o + r / 2), f = i * (o + s.length / 2), p = s.heatArea / s.length, m = u * ((r * i) ** 2 + l ** 2) / 12, h = s.mass * ((s.length * i) ** 2 + p ** 2) / 12, g = [vd("structure", u, d, a, m), vd("root", s.mass, f, a, h)];
	if (c) {
		let e = hd * s.heatArea * gd;
		g.push(vd("tps", e, f, a, e * ((s.length * i) ** 2 + p ** 2) / 12));
	}
	return yd(e, t, g, {
		x: i * o,
		station: a
	}, r / 2);
}
function xd(e) {
	let { height: t, diameter: n, dryMass: r, dryCentreOfMass: i } = e;
	if (!(t > 0 && n > 0 && r > 0 && i > 0 && i < t) || !Number.isFinite(t + n + r + i)) throw RangeError("Invalid intact vehicle mass geometry");
	let a = n / 2, o = e.id === "ship", s = ld(n), c = [], l = t * (o ? .035 : .03), u = e.engines.length * pd;
	if (c.push(yd(`${o ? "ship" : "booster"}-engine-support`, "engine-support", [vd("structure", u, 0, l / 2, u * (a ** 2 / 4 + l ** 2 / 12))])), o) {
		let i = r * .05;
		c.push(yd("ship-nose", "nose", [vd("structure", i, 0, t * .87, i * ((.4 * a) ** 2 + (.08 * t) ** 2) / 5)]));
		for (let t of [!0, !1]) for (let r of [-1, 1]) {
			let i = t ? e.frontFinStation : e.aftFinStation;
			c.push(bd(`ship-${t ? "front" : "aft"}-flap-${r < 0 ? "left" : "right"}`, "flap", (t ? e.frontFinArea : e.aftFinArea) / 2, n * (t ? .34 : .46), r, i, a, s, !0));
		}
	} else {
		let i = e.gridFins;
		if (!i || !Number.isInteger(i.count) || i.count < 3) throw RangeError("Booster component partition requires a grid inventory");
		let o = r * .02;
		c.push(yd("booster-hot-stage", "hot-stage", [vd("structure", o, 0, t * .975, o * (a ** 2 / 2 + (.05 * t) ** 2 / 12))]));
		for (let e = 0; e < i.count; e++) c.push(bd(`booster-grid-${e}`, "grid-fin", i.area / i.count, n * .46, Math.sin(_d + e * 2 * Math.PI / i.count), i.station, a, s, !1));
	}
	for (let e of c) if (!(e.station >= 0 && e.station <= t)) throw RangeError("Component centroid outside the hull");
	let d = r - c.reduce((e, t) => e + t.mass, 0);
	if (!(d > 0)) throw RangeError("No positive hull mass remains");
	let f = (r * i - c.reduce((e, t) => e + t.mass * t.station, 0)) / d, p = -c.reduce((e, t) => e + t.mass * t.x, 0) / d, m = r * (a ** 2 / 4 + t ** 2 / 12), h = (m - c.reduce((e, t) => e + t.inertia + t.mass * (t.x ** 2 + (t.station - i) ** 2), 0) - d * (p ** 2 + (f - i) ** 2)) / d - a ** 2 / 4, g = t * (o ? .055 : .05), _ = t * (o ? .72 : .93), v = t * (o ? .3 : .5), y = (f - g) * (_ - f);
	if (!(f > g && f < _ && h > 0 && h < y)) throw RangeError("Hull residual moments have no positive supported partition");
	let b = h / y, x = d * b * (_ - f) / (_ - g), S = d * b * (f - g) / (_ - g), C = d - x - S, w = [
		vd("structure", x, p, g, x * a ** 2 / 4),
		vd("structure", C, p, f, C * a ** 2 / 4),
		vd("structure", S, p, _, S * a ** 2 / 4)
	], T = o ? "ship" : "booster", E = yd(`${T}-hull-aft`, "hull", w.filter((e) => e.station < v)), D = yd(`${T}-hull-forward`, "hull", w.filter((e) => e.station >= v));
	return c.push(E, D), Object.freeze({
		id: e.id,
		dryMass: r,
		dryCentreOfMassX: 0,
		dryCentreOfMass: i,
		dryMomentOfInertia: m,
		hullThermalMass: E.mass + D.mass,
		rootSection: s,
		components: Object.freeze(c)
	});
}
//#endregion
//#region src/core/physics/tps-material.ts
var Sd = 116.483, Cd = 1922.04, wd = 116.667, Td = 1922.22, Ed = 101330, Dd = 293.15, Od = [
	[116.483, 293],
	[172.039, 440],
	[255.372, 628],
	[394.261, 879],
	[533.15, 1060],
	[672.039, 1150],
	[810.928, 1210],
	[949.817, 1240],
	[1088.71, 1260],
	[1199.82, 1260],
	[1227.59, 1270],
	[1366.48, 1270],
	[1533.15, 1270],
	[1922.04, 1270]
], kd = [
	116.667,
	255.556,
	394.444,
	533.333,
	672.222,
	811.111,
	950,
	1088.89,
	1227.78,
	1366.67,
	1533.33,
	1644.44,
	1811.11,
	1922.22
], Ad = [
	[10.133, [
		.00865,
		.013,
		.0159,
		.0216,
		.0303,
		.0403,
		.0533,
		.072,
		.0981,
		.127,
		.167,
		.201,
		.267,
		.329
	]],
	[101.33, [
		.013,
		.0173,
		.0216,
		.0289,
		.0374,
		.0476,
		.0606,
		.0795,
		.106,
		.135,
		.177,
		.213,
		.28,
		.339
	]],
	[1013.3, [
		.026,
		.0317,
		.0389,
		.0478,
		.0563,
		.0679,
		.0852,
		.107,
		.133,
		.163,
		.201,
		.241,
		.312,
		.379
	]],
	[10133, [
		.0374,
		.0433,
		.0547,
		.0692,
		.0852,
		.104,
		.125,
		.151,
		.183,
		.22,
		.268,
		.31,
		.384,
		.454
	]],
	[101330, [
		.0403,
		.0476,
		.059,
		.075,
		.0924,
		.114,
		.135,
		.163,
		.196,
		.235,
		.289,
		.336,
		.419,
		.502
	]]
];
function jd(e, t, n) {
	if (!Number.isFinite(e) || e < t || e > n) throw RangeError("LI900 temperature is outside its material property data domain");
}
function Md(e) {
	if (!Number.isFinite(e) || e < 0 || e > 101330) throw RangeError("LI900 pressure must be within0–101330Pa");
}
var Nd = new Float64Array(Od.length);
for (let e = 1; e < Od.length; e++) {
	let t = Od[e - 1], n = Od[e];
	Nd[e] = Nd[e - 1] + (n[0] - t[0]) * (t[1] + n[1]) / 2;
}
function Pd(e) {
	for (let t = 1; t < Od.length; t++) if (e < Od[t][0]) return t - 1;
	return Od.length - 2;
}
function Fd(e) {
	let t = Pd(e), n = Od[t], r = Od[t + 1];
	if (e === r[0]) return Nd[t + 1];
	let i = e - n[0], a = (r[1] - n[1]) / (r[0] - n[0]);
	return Nd[t] + n[1] * i + a * i ** 2 / 2;
}
var Id = Fd(Dd), Ld = -Id, Rd = Nd[Od.length - 1] - Id;
function zd(e) {
	jd(e, Sd, Cd);
	let t = Pd(e), n = Od[t], r = Od[t + 1];
	if (e === r[0]) return r[1];
	let i = (e - n[0]) / (r[0] - n[0]);
	return n[1] + i * (r[1] - n[1]);
}
function Bd(e) {
	return jd(e, Sd, Cd), Fd(e) - Id;
}
function Vd(e) {
	if (!Number.isFinite(e) || e < Ld || e > Rd) throw RangeError("LI900 specific enthalpy is outside the heat-capacity data domain");
	if (e === 0) return Dd;
	if (e === Ld) return Sd;
	if (e === Rd) return Cd;
	let t = e + Id, n = 0, r = Od.length - 1;
	for (; r - n > 1;) {
		let e = Math.floor((n + r) / 2);
		Nd[e] <= t ? n = e : r = e;
	}
	let i = Od[n], a = Od[n + 1], o = (a[1] - i[1]) / (a[0] - i[0]), s = t - Nd[n], c = 2 * s / (i[1] + Math.sqrt(i[1] ** 2 + 2 * o * s));
	return Math.max(i[0], Math.min(a[0], i[0] + c));
}
function Hd(e, t) {
	let n = Ad[0];
	if (t <= n[0]) return n[1][e];
	for (let n = 1; n < Ad.length; n++) {
		let r = Ad[n];
		if (t === r[0]) return r[1][e];
		if (t < r[0]) {
			let i = Ad[n - 1], a = Math.log(t / i[0]) / Math.log(r[0] / i[0]);
			return i[1][e] + a * (r[1][e] - i[1][e]);
		}
	}
	return Ad[Ad.length - 1][1][e];
}
function Ud(e, t) {
	for (let n = 1; n < kd.length; n++) {
		let r = kd[n];
		if (e === r) return Hd(n, t);
		if (e < r) {
			let i = kd[n - 1], a = Hd(n - 1, t), o = Hd(n, t);
			return a + (e - i) / (r - i) * (o - a);
		}
	}
	return Hd(kd.length - 1, t);
}
function Wd(e, t) {
	return jd(e, wd, Td), Md(t), Ud(e, t);
}
function Gd(e, t, n) {
	if (jd(e, wd, Td), jd(t, wd, Td), Md(n), e === t) return Ud(e, n);
	let r = Math.min(e, t), i = Math.max(e, t), a = 0;
	for (let e = 1; e < kd.length; e++) {
		let t = Math.max(r, kd[e - 1]), o = Math.min(i, kd[e]);
		o > t && (a += (o - t) * (Ud(t, n) + Ud(o, n)) / 2);
	}
	return a / (i - r);
}
var Kd = /* @__PURE__ */ function(e) {
	return e[e.None = 0] = "None", e[e.ProofExceeded = 1] = "ProofExceeded", e[e.MaterialDomain = 2] = "MaterialDomain", e[e.Terminal = 3] = "Terminal", e;
}({});
function qd(e, t) {
	if (!Number.isFinite(e) || !Number.isFinite(t)) throw RangeError("Thermal state requires finite temperature and energy");
	return {
		valid: !0,
		temperature: e,
		energy: t
	};
}
function Jd(e, t) {
	let n = e.components.length;
	if (n < 1 || n > 12) throw RangeError("Damage inventory must contain1–12 components");
	if (!(e.hullThermalMass > 0) || !Number.isFinite(e.hullThermalMass)) throw RangeError("Damage state requires positive finite hull thermal mass");
	let r = td(t), i = e.components.some((e) => e.tpsMass > 0), a = 0;
	if (i) {
		if (t < 116.667 || t > 1922.04) throw RangeError("TPS ambient temperature is outside its thermal data domains");
		a = Bd(t);
	}
	let o = e.components.map((e, n) => {
		if (!(e.rootMass >= 0 && e.tpsMass >= 0) || !Number.isFinite(e.rootMass + e.tpsMass)) throw RangeError("Invalid component thermal mass");
		let i = e.rootMass > 0 ? qd(t, e.rootMass * r) : qd(0, 0), o = () => e.tpsMass > 0 ? qd(t, e.tpsMass / 2 * a) : qd(0, 0);
		return {
			componentIndex: n,
			attached: !0,
			permanentFailure: 0,
			root: i,
			tps: [o(), o()],
			loadedAngle: W(0)
		};
	}), s = o.map((e) => ({
		componentIndex: e.componentIndex,
		active: !1,
		x: 0,
		altitude: 0,
		pitch: W(0),
		speedX: 0,
		speedY: 0,
		angularVelocity: 0
	}));
	return {
		components: o,
		hull: qd(t, e.hullThermalMass * r),
		debris: s,
		terminal: {
			active: !1,
			reason: 0,
			time: 0,
			x: 0,
			altitude: 0,
			pitch: W(0),
			speedX: 0,
			speedY: 0,
			angularVelocity: 0,
			retainedDryMass: 0,
			retainedPropellant: 0,
			releasedEnergy: 0,
			releasedMomentumX: 0,
			releasedMomentumY: 0,
			releasedAngularMomentum: 0,
			releasedKineticEnergy: 0
		},
		revision: 0,
		eventCount: 0
	};
}
function Yd(e) {
	return {
		components: e.components.map((e) => ({
			...e,
			root: { ...e.root },
			tps: [{ ...e.tps[0] }, { ...e.tps[1] }]
		})),
		hull: { ...e.hull },
		debris: e.debris.map((e) => ({ ...e })),
		terminal: { ...e.terminal },
		revision: e.revision,
		eventCount: e.eventCount
	};
}
//#endregion
//#region src/core/physics/damage-thermal.ts
var Xd = 4096, Zd = .8, Qd = 8, $d = .0254, ef = $d / 2, tf = $d / 4, nf = Math.max(Sd, wd), rf = Math.min(Cd, Td), af = Zd * il, of = td(4), sf = td(Eu), cf = Bd(nf), lf = Bd(rf);
function uf(e) {
	let t = e.components.length, n = e.rootSection;
	if (t < 1 || t > 12 || !(e.hullThermalMass > 0 && n.area > 0 && n.length > 0 && n.heatArea > 0) || !Number.isFinite(e.hullThermalMass + n.area + n.length + n.heatArea)) throw RangeError("Invalid thermal catalogue geometry/inventory");
	let r = Yu(4), i = Xu(Eu), a = zd(Sd), o = Wd(Td, Ed), s = n.length / 2, c = n.area / s, l = s / n.area, u = i * c, d = 4 * af * n.heatArea * Eu ** 3, f = 4 * af * n.heatArea * rf ** 3, p = [], m = Infinity, h = 0;
	for (let s = 0; s < t; s++) {
		let t = e.components[s];
		if (!(t.rootMass >= 0 && t.tpsMass >= 0) || !Number.isFinite(t.rootMass + t.tpsMass)) throw RangeError("Invalid component thermal masses");
		if (t.rootMass === 0) {
			if (t.tpsMass > 0) throw RangeError("TPS column requires a finite root");
			continue;
		}
		let g = t.tpsMass / 2, _ = t.rootMass * r;
		if (g > 0) {
			let e = o * n.heatArea / ef, t = 1 / (tf / (o * n.heatArea) + l / i), r = g * a;
			m = Math.min(m, r / (e + f), r / (e + t), _ / (t + u));
		} else m = Math.min(m, _ / (u + d));
		h += u, p.push(Object.freeze({
			componentIndex: s,
			rootMass: t.rootMass,
			tpsCellMass: g,
			heatArea: n.heatArea,
			steelPathRatio: c,
			steelResistanceRatio: l,
			rootMinEnergy: t.rootMass * of,
			rootMaxEnergy: t.rootMass * sf,
			tpsMinEnergy: g * cf,
			tpsMaxEnergy: g * lf
		}));
	}
	return h > 0 && (m = Math.min(m, e.hullThermalMass * r / h)), Object.freeze({
		componentCount: t,
		columns: Object.freeze(p),
		hullMass: e.hullThermalMass,
		hullMinEnergy: e.hullThermalMass * of,
		hullMaxEnergy: e.hullThermalMass * sf,
		safeStep: m
	});
}
function df(e, t, n) {
	if (!Number.isFinite(e.temperature) || e.temperature < t || e.temperature > n || !Number.isFinite(e.energy)) throw RangeError("Valid thermal node has invalid temperature/energy");
}
function ff(e, t, n, r, i, a) {
	return e.energy += t, !Number.isFinite(e.energy) || e.energy < r || e.energy > i ? (e.valid = !1, !1) : (t !== 0 && (e.temperature = e.energy === r ? a ? nf : 4 : e.energy === i ? a ? rf : Eu : a ? Vd(e.energy / n) : id(e.energy / n)), !0);
}
function pf(e, t, n, r, i, a) {
	if (!Number.isFinite(n) || n < 0 || n > t.safeStep * Qd || !Number.isFinite(r) || r < 0 || !Number.isFinite(i) || i < 186 || i > 1473.15 || !Number.isFinite(a) || a < 0 || a > 101330 || e.components.length !== t.componentCount) throw RangeError("Thermal forcing/inventory outside the supported numerical contract");
	let o = e.hull.valid ? 0 : Xd;
	for (let n of t.columns) {
		let t = e.components[n.componentIndex];
		if (t.componentIndex !== n.componentIndex) throw RangeError("Thermal catalogue identity mismatch");
		t.attached && (!t.root.valid || n.tpsCellMass > 0 && (!t.tps[0].valid || !t.tps[1].valid)) && (o |= 1 << n.componentIndex);
	}
	if (o !== 0 || n === 0) return o;
	df(e.hull, 4, Eu);
	for (let n of t.columns) {
		let t = e.components[n.componentIndex];
		t.attached && (df(t.root, 4, Eu), n.tpsCellMass > 0 && (df(t.tps[0], nf, rf), df(t.tps[1], nf, rf)));
	}
	let s = Math.min(Qd, Math.max(1, Math.ceil(n / t.safeStep))), c = n / s, l = i ** 4;
	for (let n = 0; n < s; n++) {
		let n = e.hull.temperature, i = Xu(n), s = 0;
		for (let u of t.columns) {
			let t = e.components[u.componentIndex];
			if (!t.attached) continue;
			let d = t.root.temperature, f = Xu(d), p = c * (f + i) / 2 * u.steelPathRatio * (d - n);
			s += p;
			let m = -p, h = !0;
			if (u.tpsCellMass > 0) {
				let e = t.tps[0], n = t.tps[1], i = e.temperature, o = n.temperature, s = c * Gd(i, o, a) * u.heatArea / ef * (i - o), p = c * (o - d) / (tf / (Wd(o, a) * u.heatArea) + u.steelResistanceRatio / f), g = c * u.heatArea * (r - af * (i ** 4 - l));
				m += p, h = ff(e, g - s, u.tpsCellMass, u.tpsMinEnergy, u.tpsMaxEnergy, !0), ff(n, s - p, u.tpsCellMass, u.tpsMinEnergy, u.tpsMaxEnergy, !0) || (h = !1);
			} else m += c * u.heatArea * (r - af * (d ** 4 - l));
			ff(t.root, m, u.rootMass, u.rootMinEnergy, u.rootMaxEnergy, !1) || (h = !1), h || (o |= 1 << u.componentIndex);
		}
		if (ff(e.hull, s, t.hullMass, t.hullMinEnergy, t.hullMaxEnergy, !1) || (o |= Xd), o !== 0) return o;
	}
	return 0;
}
//#endregion
//#region src/core/physics/damage-controls.ts
function mf(e, t) {
	let n = [];
	for (let r = 0; r < e.components.length; r++) {
		let i = e.components[r];
		if (i.kind === "grid-fin") {
			let e = t.gridFins;
			if (!e) throw RangeError("Grid component requires grid geometry");
			n.push(Object.freeze({
				index: r,
				group: "grid",
				area: e.area / e.count,
				lever: i.loadLever
			}));
		} else if (i.kind === "flap") {
			let e = i.id.includes("-front-");
			n.push(Object.freeze({
				index: r,
				group: e ? "front" : "aft",
				area: (e ? t.frontFinArea : t.aftFinArea) / 2,
				lever: i.loadLever
			}));
		}
	}
	return Object.freeze({
		componentCount: e.components.length,
		root: e.rootSection,
		columns: Object.freeze(n)
	});
}
function hf(e) {
	return {
		frontArea: 0,
		aftArea: 0,
		frontFraction: 0,
		aftFraction: 0,
		gridLiftArea: 0,
		gridDragArea: 0,
		loadedAngles: Array(e).fill(0),
		proofMask: 0,
		domainMask: 0
	};
}
function gf(e, t, n, r, i) {
	if (!(n >= 0 && r >= 0 && r <= 1) || !Number.isFinite(n) || e.components.length !== t.componentCount || i.loadedAngles.length < t.componentCount) throw RangeError("Invalid component control forcing or inventory");
}
function _f(e, t, n, r, i, a, o) {
	gf(e, t, n, r, o), o.frontArea = o.aftArea = o.gridLiftArea = o.gridDragArea = 0, o.frontFraction = o.aftFraction = 0, o.proofMask = o.domainMask = 0, o.loadedAngles.fill(0);
	for (let s of t.columns) {
		let c = e.components[s.index];
		if (!c.attached || c.permanentFailure !== Kd.None) continue;
		if (!c.root.valid || cd(c.root.temperature) === 0) {
			o.domainMask |= 1 << s.index;
			continue;
		}
		let l = s.group === "grid", u = s.group === "aft" ? a : i, d = n * s.area * (l ? 1 : 2 * r), f = l ? "grid" : "plate", p = dd(u, d, s.lever, c.root.temperature, t.root, f);
		if (o.loadedAngles[s.index] = p, fd(d * ud(Math.abs(p), f) * s.lever, c.root.temperature, t.root) > 1) {
			o.proofMask |= 1 << s.index;
			continue;
		}
		if (l) o.gridLiftArea += s.area * Math.sin(2 * p), o.gridDragArea += s.area * 1.2 * Math.sin(p) ** 2;
		else {
			let e = Math.sin(p);
			s.group === "front" ? (o.frontArea += s.area * e, o.frontFraction += .5 * e) : (o.aftArea += s.area * e, o.aftFraction += .5 * e);
		}
	}
}
//#endregion
//#region src/core/physics/isa.ts
var vf = Kc, yf = 287.053, bf = 288.15, xf = Jc;
function Sf() {
	let e = [
		[0, -.0065],
		[11e3, 0],
		[2e4, .001],
		[32e3, .0028],
		[47e3, 0],
		[51e3, -.0028],
		[71e3, -.002]
	], t = [], n = bf, r = xf;
	for (let i = 0; i < e.length; i++) {
		let [a, o] = e[i];
		t.push({
			baseAltitude: a,
			baseTemperature: n,
			basePressure: r,
			lapseRate: o
		});
		let s = e[i + 1];
		if (!s) break;
		let c = s[0] - a, l = n + o * c;
		r = Cf(r, n, o, c), n = l;
	}
	return t;
}
function Cf(e, t, n, r) {
	return n === 0 ? e * Math.exp(-vf * r / (yf * t)) : e * ((t + n * r) / t) ** (-vf / (yf * n));
}
var wf = Sf(), Tf = 84852, Ef = 6356766;
function Df(e) {
	return Ef * e / (Ef + e);
}
function Of(e) {
	let t = wf[0];
	for (let n of wf) if (e >= n.baseAltitude) t = n;
	else break;
	return t;
}
var kf = 86e3, Af = [
	[86e3, 5440],
	[1e5, 5877],
	[11e4, 7263],
	[12e4, 9473],
	[13e4, 12636],
	[14e4, 16149],
	[15e4, 22523],
	[18e4, 29740],
	[2e5, 37105],
	[25e4, 45546],
	[3e5, 53628],
	[35e4, 53298],
	[4e5, 58515],
	[45e4, 60828],
	[5e5, 63822],
	[6e5, 71835],
	[7e5, 88667],
	[8e5, 124640],
	[9e5, 181050],
	[1e6, 268e3]
], jf = 1e3, Mf = (() => {
	let e = [], t = Nf(kf);
	for (let n = 0; n < Af.length; n++) {
		let [r, i] = Af[n];
		e.push({
			base: r,
			density: t,
			scaleHeight: i
		});
		let a = Af[n + 1];
		a && (t *= Math.exp(-(a[0] - r) / i));
	}
	return e;
})();
function Nf(e) {
	let { pressurePascal: t, temperatureKelvin: n } = Pf(e);
	return t / (yf * n);
}
function Pf(e) {
	let t = {
		pressurePascal: 0,
		temperatureKelvin: 0
	};
	return Ff(e, t), t;
}
function Ff(e, t) {
	let n = Math.max(Df(e), 0), r = Math.min(n, Tf), i = Of(r), a = r - i.baseAltitude;
	t.temperatureKelvin = i.baseTemperature + i.lapseRate * a, t.pressurePascal = Cf(i.basePressure, i.baseTemperature, i.lapseRate, a);
}
function If(e) {
	let t = {
		airTemperature: 0,
		airPressure: 0,
		airDensity: 0
	};
	return Kf(e, t), t;
}
var Lf = 186.8673, Rf = 263.1905, zf = -76.3232, Bf = -19.9429, Vf = 240, Hf = 12, Uf = Ef / 1e3;
function Wf(e) {
	let t = e / 1e3;
	if (t <= 91) return Lf;
	if (t <= 110) return Rf + zf * Math.sqrt(1 - ((t - 91) / Bf) ** 2);
	if (t <= 120) return Vf + Hf * (t - 110);
	let n = (t - 120) * 6476.766 / (Uf + t);
	return jf - 640 * Math.exp(-.01875 * n);
}
var Gf = {
	pressurePascal: 0,
	temperatureKelvin: 0
};
function Kf(e, t) {
	if (e <= 86e3) {
		Ff(e, Gf);
		let { pressurePascal: n, temperatureKelvin: r } = Gf;
		t.airTemperature = r - 273.15, t.airPressure = n / 1e3, t.airDensity = n / (yf * r);
		return;
	}
	let n = Mf[0];
	for (let t of Mf) if (e >= t.base) n = t;
	else break;
	let r = n.density * Math.exp(-(e - n.base) / n.scaleHeight), i = Wf(e);
	t.airTemperature = i - 273.15, t.airPressure = r * yf * i / 1e3, t.airDensity = r;
}
//#endregion
//#region src/core/physics/atmosphere.ts
function qf(e) {
	return If(e);
}
var Jf = 1.4, Yf = 287.053;
function Xf(e) {
	return Math.sqrt(Jf * Yf * (e + 273.15));
}
//#endregion
//#region src/core/physics/aero.ts
var Zf = /* @__PURE__ */ N({
	foldedIntoWind: () => dp,
	getAcceleration: () => ip,
	getAftFinDrag: () => mp,
	getAngleOfMotion: () => op,
	getAngularAcceleration: () => ap,
	getAngularDragAcceleration: () => fp,
	getAttackAngles: () => lp,
	getBodyDragCoefficient: () => rp,
	getCrossSectionalArea: () => $f,
	getDrag: () => ep,
	getDynamicPressure: () => Qf,
	getFrontFinDrag: () => pp,
	getLift: () => np,
	getLiftCoefficient: () => tp,
	isCanonicalBurnAero: () => gp,
	relativeAirspeed: () => sp,
	relativeWindAngle: () => cp,
	updateVehicleInFlightMaxArea: () => hp,
	wrappedAttackAngle: () => up
});
function Qf(e, t) {
	return e * t ** 2 * 5e-4;
}
function $f(e, t, n = q) {
	return Math.abs(Math.sin(e) * t) + Math.abs(Math.cos(e) * n.minArea) / 2.1;
}
function ep(e, t, n, r) {
	return 1 / 2 * e * t ** 2 * r * n;
}
function tp(e) {
	let t = Math.abs(e);
	return t >= 1.48 ? -1.1 * t + 1.728 : t >= .52 ? -1 / 9.6 * t + .254 : t >= .47 ? -8 * t + 4.36 : t >= .35 ? 5 / 6 * t + .2083 : 5 / 3.5 * t;
}
function np(e, t, n, r) {
	return tp(n) * e * t ** 2 * r * .5;
}
function rp(e) {
	return e >= 10 ? 2.5 : e * .1347 + 1.153;
}
function ip(e, t) {
	return e / t;
}
function ap(e, t, n) {
	return e * t / n;
}
function op(e, t) {
	return W(Math.atan2(e, t));
}
function sp(e, t, n, r) {
	return Math.sqrt((e - n) ** 2 + (t - r) ** 2);
}
function cp(e, t, n, r) {
	return op(e - n, t - r);
}
function lp(e, t) {
	let n = up(e, t);
	return {
		angleOfAttack: W(n),
		angleInToTheWind: W(dp(n))
	};
}
function up(e, t) {
	let n = e - t;
	return n < -Math.PI ? n = Math.PI * 2 + n : n > Math.PI && (n = -(Math.PI * 2 - n)), n;
}
function dp(e) {
	return e > Math.PI / 2 ? Math.PI - e : e < -Math.PI / 2 ? -Math.PI - e : e;
}
function fp(e, t, n, r, i = q) {
	let a = e * i.diameter * t ** 2 * r / n;
	return t > 0 ? -a : a;
}
function pp(e, t, n, r, i, a = q) {
	let o = ep(e, t, Math.abs(Math.sin(r)) * a.frontFinArea, 2) * i;
	return n < 0 ? -o : o;
}
function mp(e, t, n, r, i, a = q) {
	let o = ep(e, t, Math.abs(Math.sin(r)) * a.aftFinArea, 2) * i;
	return n < 0 ? o : -o;
}
function hp(e, t, n = q) {
	let r = Math.sin(Qc * e * .01), i = Math.sin(Qc * t * .01), a = r * n.frontFinArea + i * n.aftFinArea;
	return {
		frontFinEffectiveAreaFraction: r,
		aftFinEffectiveAreaFraction: i,
		totalFinSurfaceArea: a,
		vehicleInFlightMaxArea: n.maxArea + a * 1.8
	};
}
function gp(e, t) {
	return e === gp && t === $f;
}
//#endregion
//#region src/core/physics/gravity.ts
var _p = Ac;
function vp(e) {
	return _p / e ** 2;
}
function yp(e) {
	return Math.sqrt(_p / e);
}
function bp(e, t, n = 0) {
	return Sp(e, t, n) ** 2 / e - vp(e);
}
function xp(e, t = 0) {
	return -bp(e, 0, t);
}
function Sp(e, t, n = 0) {
	return n === 0 ? t : t + n * e;
}
function Cp(e, t, n = 0) {
	return n === 0 ? t : t - n * e;
}
function wp(e, t, n, r = 0) {
	let i = r === 0 ? t : t + 2 * r * e;
	return -n * i / e;
}
function Tp(e, t, n, r, i = 0) {
	let a = Sp(e, t, i), o = (a ** 2 + n ** 2) / 2 - _p / e, s = e * a, c = 1 + 2 * o * s ** 2 / _p ** 2, l = Math.sqrt(Math.max(c, 0)), u = s ** 2 / _p;
	if (l < 1e-9 || u / (1 + l) > r) return Infinity;
	let d = (e, t) => {
		let n = (u / e - 1) / l, r = Math.acos(Math.min(1, Math.max(-1, n)));
		return t ? r : 2 * Math.PI - r;
	}, f = d(e, n >= 0), p = d(r, !1);
	if (p < f && (p += 2 * Math.PI), !(p > f)) {
		if (i === 0) return 0;
		if (n > 0 && o >= 0) return Infinity;
		let t = Op(e, n, r);
		return Number.isFinite(t) ? -i * t : Infinity;
	}
	let m = (p - f) / 64, h = (e) => u / (1 + l * Math.cos(e)), g = h(f) + h(p);
	for (let e = 1; e < 64; e++) g += h(f + e * m) * (e % 2 == 0 ? 2 : 4);
	let _ = g * m / 3;
	if (i === 0) return _;
	let v = h(f) ** 3 + h(p) ** 3;
	for (let e = 1; e < 64; e++) v += h(f + e * m) ** 3 * (e % 2 == 0 ? 2 : 4);
	return _ - v * m * i / 3 / s;
}
var Ep = .1, Dp = 1e6;
function Op(e, t, n) {
	let r = e, i = t, a = -vp(r), o = 0;
	for (let e = 0; e < Dp; e++) {
		let e = r + i * Ep + .5 * a * Ep * Ep;
		if (e <= n) {
			let t = (r - n) / (r - e);
			return o + .5 * (r + n) * t * Ep;
		}
		let t = -vp(e);
		i += .5 * (a + t) * Ep, o += .5 * (r + e) * Ep, r = e, a = t;
	}
	return Infinity;
}
//#endregion
//#region src/core/physics/damage-debris.ts
function kp(e, t) {
	if (e.id !== t.id || e.dryMass !== t.dryMass) throw RangeError("Debris requires matching source vehicle inventory");
	let n = t.diameter, r = t.height, i = t.id === "ship", a = e.components.map((a) => {
		let o, s, c, l = a.kind === "flap" || a.kind === "grid-fin";
		if (l) {
			let r = a.id.startsWith("ship-front"), i = n * (a.kind === "grid-fin" || !r ? .46 : .34);
			o = a.kind === "grid-fin" ? t.gridFins.area / t.gridFins.count : (r ? t.frontFinArea : t.aftFinArea) / 2;
			let l = o / i;
			s = o + .004 * (i + l) + e.rootSection.heatArea, c = 0;
			for (let t of a.slices) {
				let n = t.role === "structure" ? Math.hypot(i, l) / 2 : Math.hypot(e.rootSection.length, e.rootSection.heatArea / e.rootSection.length) / 2;
				c = Math.max(c, Math.hypot(t.x - a.x, t.station - a.station) + n);
			}
		} else {
			let e, t = n;
			a.kind === "engine-support" ? e = r * (i ? .035 : .03) : a.kind === "nose" ? (e = .08 * r, t = .4 * n) : e = a.kind === "hot-stage" ? .05 * r : r * (a.id.endsWith("-aft") ? i ? .3 : .5 : i ? .7 : .5), o = t * e, s = o + Math.PI * t * t / 4;
			let l = 0;
			for (let e of a.slices) l = Math.max(l, Math.hypot(e.x - a.x, e.station - a.station));
			c = l + Math.hypot(t, e) / 2;
		}
		if (!(a.mass > 0 && a.inertia > 0 && s > 0 && c > 0) || !Number.isFinite(a.mass + a.inertia + s + c)) throw RangeError("Debris source geometry must be positive and finite");
		return Object.freeze({
			mass: a.mass,
			inertia: a.inertia,
			broadsideArea: o,
			dragArea: s,
			supportRadius: c,
			dragMultiplier: l ? 1.8 : 1
		});
	});
	return Object.freeze({ pieces: Object.freeze(a) });
}
var Ap = {
	airDensity: 0,
	airTemperature: 0,
	airPressure: 0
};
function jp(e, t, n) {
	if (!(t >= 0 && n >= 0) || !Number.isFinite(t + n)) throw RangeError("Debris drag requires finite nonnegative coefficient and time");
	let r = Math.hypot(e.speedX, e.speedY), i = 1 / (1 + t * r * n);
	return e.speedX *= i, e.speedY *= i, -.5 * r * r * (1 - i) * (1 + i);
}
function Mp(e, t, n) {
	Kf(e.altitude, Ap);
	let r = rp(Math.hypot(e.speedX, e.speedY) / Xf(Ap.airTemperature));
	jp(e, Ap.airDensity * r * t.dragMultiplier * t.dragArea / (2 * t.mass), n);
}
function Np(e, t, n) {
	if (!(n >= 0) || !Number.isFinite(n) || e.debris.length !== t.pieces.length) throw RangeError("Debris advance requires matching inventory and finite nonnegative time");
	for (let t = 0; t < e.debris.length; t++) {
		let n = e.debris[t];
		if (n.componentIndex !== t || n.active && !Number.isFinite(n.x + n.altitude + n.speedX + n.speedY + n.pitch + n.angularVelocity)) throw RangeError("Debris active pose and source index must be finite and valid");
	}
	if (n !== 0) for (let r = 0; r < e.debris.length; r++) {
		let i = e.debris[r];
		if (!i.active) continue;
		let a = t.pieces[r];
		if (i.altitude <= a.supportRadius) {
			i.altitude = a.supportRadius, i.speedX = i.speedY = i.angularVelocity = 0;
			continue;
		}
		Mp(i, a, n / 2);
		let o = i.x, s = i.altitude, c = i.speedX, l = i.speedY, u = G + s, d = wp(u, c, l), f = bp(u, c), p = o + c * n + .5 * d * n * n, m = s + l * n + .5 * f * n * n;
		if (m <= a.supportRadius) {
			let e = (s - a.supportRadius) / (s - m);
			i.x = o + (p - o) * e, i.altitude = a.supportRadius, i.pitch = W(i.pitch + i.angularVelocity * n * e), i.speedX = i.speedY = i.angularVelocity = 0;
			continue;
		}
		let h = G + m;
		i.x = p, i.altitude = m, i.speedX = c + .5 * (d + wp(h, c + d * n, l + f * n)) * n, i.speedY = l + .5 * (f + bp(h, c + d * n)) * n, i.pitch = W(i.pitch + i.angularVelocity * n), Mp(i, a, n / 2);
	}
}
//#endregion
//#region src/core/physics/damage-model.ts
var Pp = /* @__PURE__ */ new WeakMap();
function X(e) {
	let t = Pp.get(e);
	if (t) return t;
	let n = xd(e), r = Object.freeze({
		partition: n,
		thermal: uf(n),
		controls: mf(n, e),
		debris: kp(n, e)
	});
	return Pp.set(e, r), r;
}
//#endregion
//#region src/view/assets.ts
var Fp = "assets/", Ip = [
	{
		id: "starBaseBackGround2",
		src: `${Fp}starBaseBackGround2.webp`,
		height: 75,
		width: 100,
		x: K - 100,
		roams: !1
	},
	{
		id: "starBaseBackGround",
		src: `${Fp}starBaseBackGround.webp`,
		height: 30,
		width: 25770 / 200,
		x: K + 100,
		roams: !1
	},
	{
		id: "sn15",
		src: `${Fp}sn15.webp`,
		height: 30 / 52 * 60,
		width: 30 / 52 * 60 * 137 / 600,
		x: K - 100,
		roams: !1
	},
	{
		id: "starhopper",
		src: `${Fp}starhopper.webp`,
		height: 18,
		width: 24,
		x: K - 200,
		roams: !1
	},
	{
		id: "lunchpad_Light1",
		src: `${Fp}lunchpad_Light1.webp`,
		height: 2,
		width: 2 / 4.85,
		x: K - 30,
		roams: !1
	},
	{
		id: "lunchpad_Light2",
		src: `${Fp}lunchpad_Light2.webp`,
		height: 9,
		width: 9 / 4.85,
		x: K + 30,
		roams: !1
	},
	{
		id: "tree1",
		src: `${Fp}tree1.webp`,
		height: 10,
		width: 10 / 197 * 150,
		x: K + 90,
		roams: !0
	},
	{
		id: "tree2",
		src: `${Fp}tree2.webp`,
		height: 7,
		width: 7.5,
		x: K - 40,
		roams: !0
	},
	{
		id: "pig",
		src: `${Fp}pig.webp`,
		height: 1,
		width: 1.19,
		x: 0,
		roams: !0
	},
	{
		id: "tree1b",
		src: `${Fp}tree1.webp`,
		height: 12,
		width: 12 / 197 * 150,
		x: K + 260,
		roams: !0
	},
	{
		id: "tree1c",
		src: `${Fp}tree1.webp`,
		height: 8,
		width: 8 / 197 * 150,
		x: K - 320,
		roams: !0
	},
	{
		id: "tree1d",
		src: `${Fp}tree1.webp`,
		height: 14,
		width: 14 / 197 * 150,
		x: K + 640,
		roams: !0
	},
	{
		id: "tree2b",
		src: `${Fp}tree2.webp`,
		height: 9,
		width: 9 / 14 * 15,
		x: K - 520,
		roams: !0
	},
	{
		id: "tree2c",
		src: `${Fp}tree2.webp`,
		height: 6,
		width: 6 / 14 * 15,
		x: K + 410,
		roams: !0
	},
	{
		id: "tree2d",
		src: `${Fp}tree2.webp`,
		height: 11,
		width: 11 / 14 * 15,
		x: K - 780,
		roams: !0
	},
	{
		id: "tree2e",
		src: `${Fp}tree2.webp`,
		height: 7,
		width: 7.5,
		x: K + 900,
		roams: !0
	},
	{
		id: "tree1e",
		src: `${Fp}tree1.webp`,
		height: 10,
		width: 10 / 197 * 150,
		x: K - 1150,
		roams: !0
	},
	{
		id: "starBaseBackGroundB",
		src: `${Fp}starBaseBackGround.webp`,
		height: 22,
		width: 18898 / 200,
		x: K + 2600,
		roams: !1
	},
	{
		id: "starBaseBackGroundC",
		src: `${Fp}starBaseBackGround.webp`,
		height: 16,
		width: 13744 / 200,
		x: K - 3100,
		roams: !1
	},
	{
		id: "starhopperB",
		src: `${Fp}starhopper.webp`,
		height: 14,
		width: 728 / 39,
		x: K + 1800,
		roams: !1
	},
	{
		id: "sn15B",
		src: `${Fp}sn15.webp`,
		height: 30 / 52 * 44,
		width: 30 / 52 * 44 * 137 / 600,
		x: K - 2200,
		roams: !1
	}
], Lp = [...new Set(Ip.map((e) => e.src))], Rp = /* @__PURE__ */ new Map();
function zp(e) {
	let t = Rp.get(e);
	if (t) return t;
	let n = new Promise((t, n) => {
		let r = x.get().createImage();
		r.crossOrigin = "anonymous";
		let i = () => {
			r.onload = null, r.onerror = null;
		};
		r.onload = () => {
			i(), t(r);
		}, r.onerror = () => {
			i(), n(/* @__PURE__ */ Error(`Failed to load scenery image: ${e}`));
		}, r.src = e;
	}).then(async (t) => {
		typeof t.decode == "function" && await t.decode();
		let r = p.from(t);
		return r.once("destroy", () => {
			Rp.get(e) === n && Rp.delete(e);
		}), r;
	}).catch((t) => {
		throw Rp.get(e) === n && Rp.delete(e), t;
	});
	return Rp.set(e, n), n;
}
async function Bp() {
	let e = await Promise.all(Lp.map(zp)), t = /* @__PURE__ */ new Map();
	for (let n = 0; n < Lp.length; n++) t.set(Lp[n], e[n]);
	return t;
}
//#endregion
//#region src/view/colour.ts
function Vp(e, t) {
	return e >> t & 255;
}
function Hp(e) {
	return e < 0 ? 0 : e > 255 ? 255 : e;
}
function Up(e, t, n) {
	return Hp(e) << 16 | Hp(t) << 8 | Hp(n);
}
function Wp(e, t, n) {
	let r = n < 0 ? 0 : n > 1 ? 1 : n;
	return Up(Math.round(Vp(e, 16) + (Vp(t, 16) - Vp(e, 16)) * r), Math.round(Vp(e, 8) + (Vp(t, 8) - Vp(e, 8)) * r), Math.round(Vp(e, 0) + (Vp(t, 0) - Vp(e, 0)) * r));
}
function Gp(e, t, n) {
	let r = Vp(e, 16), i = Vp(e, 8), a = Vp(e, 0);
	return (r + (Vp(t, 16) - r) * n | 0) << 16 | (i + (Vp(t, 8) - i) * n | 0) << 8 | a + (Vp(t, 0) - a) * n | 0;
}
function Kp(e, t) {
	return Up(Math.round(Vp(e, 16) * t), Math.round(Vp(e, 8) * t), Math.round(Vp(e, 0) * t));
}
//#endregion
//#region src/view/atmosphere-look.ts
function qp(e) {
	let t = Math.max(0, e);
	return Math.sqrt(2 * G * t + t * t);
}
function Jp(e) {
	return Math.min(.25, qp(e) / (2 * G));
}
var Yp = 1200;
function Xp(e) {
	let t = Math.max(0, e), n = Math.exp(-t / Yp), r = 1 - Math.exp(-t / (Yp * 2.5));
	return Math.min(1, n * r * 4);
}
var Zp = 101.325;
function Qp(e) {
	return 1 + 2.6 * (1 - Math.min(1, Math.max(0, e / Zp))) ** .55;
}
function $p(e) {
	return 1 + 1.3 * (1 - Math.min(1, Math.max(0, e / Zp))) ** .55;
}
var em = 1.3, tm = Zp, nm = 1.5;
function rm(e, t = em) {
	if (!Number.isFinite(e) || e >= 101.325) return nm;
	let n = tm / Math.max(1e-6, e) - 1, r = 5.224 * t * Math.sqrt(Math.max(0, n));
	return Math.min(60, Math.max(nm, r));
}
var im = .02;
function am(e) {
	if (!Number.isFinite(e) || e <= 0) return 0;
	let t = e / tm;
	if (t >= .25) return 1;
	if (t <= .02) return 0;
	let n = (t - im) / .23;
	return n * n * (3 - 2 * n);
}
function om(e, t) {
	let n = e / (t * .8);
	return n < .05 ? 0 : Math.min(1, n);
}
function sm(e) {
	let t = 1 - e;
	return Math.min(1, Math.max(0, t / .6));
}
function cm(e, t) {
	return Kp(e, .45 + .55 * t);
}
//#endregion
//#region src/view/sun.ts
var lm = 25.997 * Math.PI / 180, um = {
	intro: 9.5,
	"launch-pad": 9.5,
	"booster-sep": 9.55,
	rtls: 9.6,
	"before-flip": 9.75,
	"landing-burn": 16,
	reentry: 15.5,
	circularize: 11,
	deorbit: 11
}, dm = 15 * Math.PI / 180, fm = -6 * Math.PI / 180, pm = -10 * Math.PI / 180, mm = {
	r: .95,
	g: .62,
	b: .42
}, hm = {
	r: .1,
	g: .12,
	b: .2
}, gm = .12;
function _m() {
	let e = {
		hour: 0,
		hourAngle: 0,
		east: 0,
		up: 1,
		south: 0,
		elevation: Math.PI / 2,
		daylight: 1,
		skyR: 1,
		skyG: 1,
		skyB: 1,
		stars: 0
	};
	return km(e, "intro", 0, K), e;
}
function vm(e, t, n, r) {
	return (((r !== void 0 && Number.isFinite(r) ? r : um[e] ?? 9.5) + t / 3600 + (n - K) / kc * 24) % 24 + 24) % 24;
}
function ym(e) {
	return (e - 12) / 12 * Math.PI;
}
function bm(e) {
	return Math.cos(lm) * Math.cos(e);
}
function xm(e, t, n) {
	let r = Math.min(1, Math.max(0, (n - e) / (t - e)));
	return r * r * (3 - 2 * r);
}
function Sm(e) {
	return e >= dm ? 1 : xm(fm, dm, e);
}
function Cm(e, t) {
	if (e >= dm) {
		t.r = 1, t.g = 1, t.b = 1;
		return;
	}
	if (e >= 0) {
		let n = xm(0, dm, e);
		t.r = mm.r + (1 - mm.r) * n, t.g = mm.g + (1 - mm.g) * n, t.b = mm.b + (1 - mm.b) * n;
		return;
	}
	let n = xm(pm, 0, e);
	t.r = hm.r + (mm.r - hm.r) * n, t.g = hm.g + (mm.g - hm.g) * n, t.b = hm.b + (mm.b - hm.b) * n;
}
function wm(e) {
	return 1 - xm(pm, -2 * Math.PI / 180, e);
}
function Tm(e) {
	return gm + .88 * e.daylight;
}
function Em(e, t) {
	return Math.asin(Math.max(-1, Math.min(1, bm(e + t))));
}
function Dm(e) {
	return 1 - (gm + .88 * Sm(e));
}
var Om = {
	r: 1,
	g: 1,
	b: 1
};
function km(e, t, n, r, i) {
	let a = vm(t, n, r, i), o = ym(a), s = Math.cos(o);
	e.hour = a, e.hourAngle = o, e.east = -Math.sin(o), e.up = Math.cos(lm) * s, e.south = Math.sin(lm) * s, e.elevation = Math.asin(Math.max(-1, Math.min(1, e.up))), e.daylight = Sm(e.elevation), Cm(e.elevation, Om), e.skyR = Om.r, e.skyG = Om.g, e.skyB = Om.b, e.stars = wm(e.elevation);
}
function Am(e, t, n) {
	let r = Math.cos(t), i = Math.sin(t);
	n.x = r * e.east - i * e.up, n.y = i * e.east + r * e.up, n.z = e.south;
}
var jm = .42;
function Mm(e, t, n, r, i, a) {
	let o = n / 2, s = e - o * Math.abs(Math.cos(t));
	if (i.up <= .05 || s >= 400 || i.daylight <= 0) {
		a.visible = !1, a.alpha = 0;
		return;
	}
	let c = i.east / i.up, l = o * Math.sin(t), u = e + o * Math.cos(t), d = -l, f = e - o * Math.cos(t), p = l - u * c, m = d - f * c;
	a.visible = !0, a.centreX = (p + m) / 2, a.length = Math.abs(p - m) + r, a.width = r, a.alpha = jm * i.daylight * (1 - Math.max(0, s) / 400);
}
//#endregion
//#region src/view/stars-data.ts
var Nm = [
	[
		2491,
		101.29,
		-16.72,
		-1.46
	],
	[
		2326,
		95.99,
		-52.7,
		-.72
	],
	[
		5340,
		213.92,
		19.18,
		-.04
	],
	[
		5459,
		219.9,
		-60.84,
		-.01
	],
	[
		7001,
		279.23,
		38.78,
		.03
	],
	[
		1708,
		79.17,
		46,
		.08
	],
	[
		1713,
		78.63,
		-8.2,
		.12
	],
	[
		2943,
		114.83,
		5.23,
		.38
	],
	[
		472,
		24.43,
		-57.24,
		.46
	],
	[
		2061,
		88.79,
		7.41,
		.5
	],
	[
		5267,
		210.96,
		-60.37,
		.61
	],
	[
		7557,
		297.7,
		8.87,
		.77
	],
	[
		1457,
		68.98,
		16.51,
		.85
	],
	[
		6134,
		247.35,
		-26.43,
		.96
	],
	[
		5056,
		201.3,
		-11.16,
		.98
	],
	[
		2990,
		116.33,
		28.03,
		1.14
	],
	[
		8728,
		344.41,
		-29.62,
		1.16
	],
	[
		4853,
		191.93,
		-59.69,
		1.25
	],
	[
		7924,
		310.36,
		45.28,
		1.25
	],
	[
		4730,
		186.65,
		-63.1,
		1.33
	],
	[
		5460,
		219.9,
		-60.84,
		1.33
	],
	[
		3982,
		152.09,
		11.97,
		1.35
	],
	[
		2618,
		104.66,
		-28.97,
		1.5
	],
	[
		4763,
		187.79,
		-57.11,
		1.63
	],
	[
		6527,
		263.4,
		-37.1,
		1.63
	],
	[
		1790,
		81.28,
		6.35,
		1.64
	],
	[
		1791,
		81.57,
		28.61,
		1.65
	],
	[
		3685,
		138.3,
		-69.72,
		1.68
	],
	[
		1903,
		84.05,
		-1.2,
		1.7
	],
	[
		4731,
		186.65,
		-63.1,
		1.73
	],
	[
		8425,
		332.06,
		-46.96,
		1.74
	],
	[
		4905,
		193.51,
		55.96,
		1.77
	],
	[
		3207,
		122.38,
		-47.34,
		1.78
	],
	[
		1017,
		51.08,
		49.86,
		1.79
	],
	[
		4301,
		165.93,
		61.75,
		1.79
	],
	[
		2693,
		107.1,
		-26.39,
		1.84
	],
	[
		6879,
		276.04,
		-34.38,
		1.85
	],
	[
		3307,
		125.63,
		-59.51,
		1.86
	],
	[
		5191,
		206.88,
		49.31,
		1.86
	],
	[
		6553,
		264.33,
		-43,
		1.87
	],
	[
		2088,
		89.88,
		44.95,
		1.9
	],
	[
		6217,
		252.17,
		-69.03,
		1.92
	],
	[
		2421,
		99.43,
		16.4,
		1.93
	],
	[
		7790,
		306.41,
		-56.73,
		1.94
	],
	[
		3485,
		131.18,
		-54.71,
		1.96
	],
	[
		2294,
		95.67,
		-17.96,
		1.98
	],
	[
		2891,
		113.65,
		31.89,
		1.98
	],
	[
		3748,
		141.9,
		-8.66,
		1.98
	],
	[
		617,
		31.79,
		23.46,
		2
	],
	[
		5958,
		239.88,
		25.92,
		2
	],
	[
		424,
		37.95,
		89.26,
		2.02
	],
	[
		7121,
		283.82,
		-26.3,
		2.02
	],
	[
		188,
		10.9,
		-17.99,
		2.04
	],
	[
		1948,
		85.19,
		-1.94,
		2.05
	],
	[
		15,
		2.1,
		29.09,
		2.06
	],
	[
		337,
		17.43,
		35.62,
		2.06
	],
	[
		2004,
		86.94,
		-9.67,
		2.06
	],
	[
		5288,
		211.67,
		-36.37,
		2.06
	],
	[
		5563,
		222.68,
		74.16,
		2.08
	],
	[
		6556,
		263.73,
		12.56,
		2.08
	],
	[
		8636,
		340.67,
		-46.88,
		2.1
	],
	[
		936,
		47.04,
		40.96,
		2.12
	],
	[
		4534,
		177.26,
		14.57,
		2.14
	],
	[
		4819,
		190.38,
		-48.96,
		2.17
	],
	[
		7796,
		305.56,
		40.26,
		2.2
	],
	[
		3634,
		137,
		-43.43,
		2.21
	],
	[
		168,
		10.13,
		56.54,
		2.23
	],
	[
		1852,
		83,
		-.3,
		2.23
	],
	[
		5793,
		233.67,
		26.71,
		2.23
	],
	[
		6705,
		269.15,
		51.49,
		2.23
	],
	[
		3165,
		120.9,
		-40,
		2.25
	],
	[
		3699,
		139.27,
		-59.28,
		2.25
	],
	[
		603,
		30.97,
		42.33,
		2.26
	],
	[
		21,
		2.29,
		59.15,
		2.27
	],
	[
		5054,
		200.98,
		54.93,
		2.27
	],
	[
		6241,
		252.54,
		-34.29,
		2.29
	],
	[
		5132,
		204.97,
		-53.47,
		2.3
	],
	[
		5469,
		220.48,
		-47.39,
		2.3
	],
	[
		5440,
		218.88,
		-42.16,
		2.31
	],
	[
		5953,
		240.08,
		-22.62,
		2.32
	],
	[
		4295,
		165.46,
		56.38,
		2.37
	],
	[
		99,
		6.57,
		-42.31,
		2.39
	],
	[
		8308,
		326.05,
		9.88,
		2.39
	],
	[
		6580,
		265.62,
		-39.03,
		2.41
	],
	[
		8775,
		345.94,
		28.08,
		2.42
	],
	[
		6378,
		257.59,
		-15.72,
		2.43
	],
	[
		4554,
		178.46,
		53.69,
		2.44
	],
	[
		8162,
		319.65,
		62.59,
		2.44
	],
	[
		2827,
		111.02,
		-29.3,
		2.45
	],
	[
		7949,
		311.55,
		33.97,
		2.46
	],
	[
		264,
		14.18,
		60.72,
		2.47
	],
	[
		8781,
		346.19,
		15.21,
		2.49
	],
	[
		3734,
		140.53,
		-55.01,
		2.5
	],
	[
		911,
		45.57,
		4.09,
		2.53
	],
	[
		5231,
		208.88,
		-47.29,
		2.55
	],
	[
		4357,
		168.53,
		20.52,
		2.56
	],
	[
		6175,
		249.29,
		-10.57,
		2.56
	],
	[
		1865,
		83.18,
		-17.82,
		2.58
	],
	[
		4662,
		183.95,
		-17.54,
		2.59
	],
	[
		4621,
		182.09,
		-50.72,
		2.6
	],
	[
		7194,
		285.65,
		-29.88,
		2.6
	],
	[
		4057,
		154.99,
		19.84,
		2.61
	],
	[
		5685,
		229.25,
		-9.38,
		2.61
	],
	[
		2095,
		89.93,
		37.21,
		2.62
	],
	[
		5984,
		241.36,
		-19.81,
		2.62
	],
	[
		553,
		28.66,
		20.81,
		2.64
	],
	[
		1956,
		84.91,
		-34.07,
		2.64
	],
	[
		4786,
		188.6,
		-23.4,
		2.65
	],
	[
		5854,
		236.07,
		6.43,
		2.65
	],
	[
		403,
		21.45,
		60.24,
		2.68
	],
	[
		5235,
		208.67,
		18.4,
		2.68
	],
	[
		5571,
		224.63,
		-43.13,
		2.68
	],
	[
		1577,
		74.25,
		33.17,
		2.69
	],
	[
		4216,
		161.69,
		-49.42,
		2.69
	],
	[
		4798,
		189.3,
		-69.14,
		2.69
	],
	[
		6508,
		262.69,
		-37.3,
		2.69
	],
	[
		2773,
		109.29,
		-37.1,
		2.7
	],
	[
		5506,
		221.25,
		27.07,
		2.7
	],
	[
		6859,
		275.25,
		-29.83,
		2.7
	],
	[
		7525,
		296.56,
		10.61,
		2.72
	],
	[
		6056,
		243.59,
		-3.69,
		2.74
	],
	[
		6132,
		246,
		61.51,
		2.74
	],
	[
		5028,
		200.15,
		-36.71,
		2.75
	],
	[
		5531,
		222.72,
		-16.04,
		2.75
	],
	[
		4199,
		160.74,
		-64.39,
		2.76
	],
	[
		1899,
		83.86,
		-5.91,
		2.77
	],
	[
		6148,
		247.56,
		21.49,
		2.77
	],
	[
		6603,
		265.87,
		4.57,
		2.77
	],
	[
		5776,
		233.79,
		-41.17,
		2.78
	],
	[
		1666,
		76.96,
		-5.09,
		2.79
	],
	[
		6536,
		262.61,
		52.3,
		2.79
	],
	[
		98,
		6.44,
		-77.25,
		2.8
	],
	[
		4656,
		183.79,
		-58.75,
		2.8
	],
	[
		3185,
		121.89,
		-24.3,
		2.81
	],
	[
		6212,
		250.32,
		31.6,
		2.81
	],
	[
		6913,
		276.99,
		-25.42,
		2.81
	],
	[
		6165,
		248.97,
		-28.22,
		2.82
	],
	[
		39,
		3.31,
		15.18,
		2.83
	],
	[
		4932,
		195.54,
		10.96,
		2.83
	],
	[
		1829,
		82.06,
		-20.76,
		2.84
	],
	[
		1203,
		58.53,
		31.88,
		2.85
	],
	[
		5897,
		238.79,
		-63.43,
		2.85
	],
	[
		6461,
		261.32,
		-55.53,
		2.85
	],
	[
		591,
		29.69,
		-61.57,
		2.86
	],
	[
		8502,
		334.63,
		-60.26,
		2.86
	],
	[
		1165,
		56.87,
		24.11,
		2.87
	],
	[
		7528,
		296.24,
		45.13,
		2.87
	],
	[
		8322,
		326.76,
		-16.13,
		2.87
	],
	[
		2286,
		95.74,
		22.51,
		2.88
	],
	[
		2890,
		113.65,
		31.89,
		2.88
	],
	[
		1220,
		59.46,
		40.01,
		2.89
	],
	[
		5671,
		229.73,
		-68.68,
		2.89
	],
	[
		5944,
		239.71,
		-26.11,
		2.89
	],
	[
		6084,
		245.3,
		-25.59,
		2.89
	],
	[
		7264,
		287.44,
		-21.02,
		2.89
	],
	[
		2845,
		111.79,
		8.29,
		2.9
	],
	[
		4915,
		194.01,
		38.32,
		2.9
	],
	[
		8232,
		322.89,
		-5.57,
		2.91
	],
	[
		915,
		46.2,
		53.51,
		2.93
	],
	[
		2553,
		102.48,
		-50.61,
		2.93
	],
	[
		8650,
		340.75,
		30.22,
		2.94
	],
	[
		1231,
		59.51,
		-13.51,
		2.95
	],
	[
		4757,
		187.47,
		-16.52,
		2.95
	],
	[
		6510,
		262.96,
		-49.88,
		2.95
	],
	[
		8414,
		331.45,
		-.32,
		2.96
	],
	[
		2473,
		100.98,
		25.13,
		2.98
	],
	[
		3873,
		146.46,
		23.77,
		2.98
	],
	[
		1605,
		75.49,
		43.82,
		2.99
	],
	[
		6746,
		271.45,
		-30.42,
		2.99
	],
	[
		7235,
		286.35,
		13.86,
		2.99
	],
	[
		622,
		32.39,
		34.99,
		3
	],
	[
		1910,
		84.41,
		21.14,
		3
	],
	[
		4630,
		182.53,
		-22.62,
		3
	],
	[
		5020,
		199.73,
		-23.17,
		3
	],
	[
		1122,
		55.73,
		47.79,
		3.01
	],
	[
		3890,
		146.78,
		-65.07,
		3.01
	],
	[
		4335,
		167.42,
		44.5,
		3.01
	],
	[
		8353,
		328.48,
		-37.37,
		3.01
	],
	[
		2282,
		95.08,
		-30.06,
		3.02
	],
	[
		2653,
		105.76,
		-23.83,
		3.02
	],
	[
		5435,
		218.02,
		38.31,
		3.03
	],
	[
		6615,
		266.9,
		-40.13,
		3.03
	],
	[
		681,
		34.84,
		-2.98,
		3.04
	],
	[
		5193,
		207.4,
		-42.47,
		3.04
	],
	[
		4069,
		155.58,
		41.5,
		3.05
	],
	[
		4844,
		191.57,
		-68.11,
		3.05
	],
	[
		5735,
		230.18,
		71.83,
		3.05
	],
	[
		7310,
		288.14,
		67.66,
		3.07
	],
	[
		6247,
		252.97,
		-38.05,
		3.08
	],
	[
		7417,
		292.68,
		27.96,
		3.08
	],
	[
		7776,
		305.25,
		-14.78,
		3.08
	],
	[
		3547,
		133.85,
		5.95,
		3.11
	],
	[
		4232,
		162.41,
		-16.19,
		3.11
	],
	[
		6832,
		274.41,
		-36.76,
		3.11
	],
	[
		7869,
		309.39,
		-47.29,
		3.11
	],
	[
		2040,
		87.74,
		-35.77,
		3.12
	],
	[
		3705,
		140.26,
		34.39,
		3.13
	],
	[
		3803,
		142.81,
		-57.03,
		3.13
	],
	[
		4467,
		173.94,
		-63.02,
		3.13
	],
	[
		5576,
		224.79,
		-42.1,
		3.13
	],
	[
		6285,
		254.65,
		-55.99,
		3.13
	],
	[
		3569,
		134.8,
		48.04,
		3.14
	],
	[
		6410,
		258.76,
		24.84,
		3.14
	],
	[
		6418,
		258.76,
		36.81,
		3.16
	],
	[
		1641,
		76.63,
		41.23,
		3.17
	],
	[
		2451,
		99.44,
		-43.2,
		3.17
	],
	[
		3775,
		143.21,
		51.68,
		3.17
	],
	[
		6396,
		257.2,
		65.71,
		3.17
	],
	[
		7039,
		281.41,
		-26.99,
		3.17
	],
	[
		1543,
		72.46,
		6.96,
		3.19
	],
	[
		1654,
		76.37,
		-22.37,
		3.19
	],
	[
		5463,
		220.63,
		-64.98,
		3.19
	],
	[
		6299,
		254.42,
		9.38,
		3.2
	],
	[
		8115,
		318.23,
		30.23,
		3.2
	],
	[
		6630,
		267.46,
		-37.04,
		3.21
	],
	[
		8974,
		354.84,
		77.63,
		3.21
	],
	[
		5695,
		230.34,
		-40.65,
		3.22
	],
	[
		7710,
		302.83,
		-.82,
		3.23
	],
	[
		8238,
		322.16,
		70.56,
		3.23
	],
	[
		897,
		44.57,
		-40.3,
		3.24
	],
	[
		1208,
		56.81,
		-74.24,
		3.24
	],
	[
		6075,
		244.58,
		-4.69,
		3.24
	],
	[
		7178,
		284.74,
		32.69,
		3.24
	],
	[
		2878,
		112.31,
		-43.3,
		3.25
	],
	[
		6869,
		275.33,
		-2.9,
		3.26
	],
	[
		165,
		9.83,
		30.86,
		3.27
	],
	[
		1465,
		68.5,
		-55.04,
		3.27
	],
	[
		2550,
		102.05,
		-61.94,
		3.27
	],
	[
		5287,
		211.59,
		-26.68,
		3.27
	],
	[
		6453,
		260.5,
		-25,
		3.27
	],
	[
		8709,
		343.66,
		-15.82,
		3.27
	],
	[
		2216,
		93.72,
		22.51,
		3.28
	],
	[
		5603,
		226.02,
		-25.28,
		3.29
	],
	[
		5744,
		231.23,
		58.97,
		3.29
	],
	[
		322,
		16.52,
		-46.72,
		3.31
	],
	[
		1702,
		78.23,
		-16.21,
		3.31
	],
	[
		4660,
		183.86,
		57.03,
		3.31
	],
	[
		4037,
		153.43,
		-70.04,
		3.32
	],
	[
		4140,
		158.01,
		-61.69,
		3.32
	],
	[
		7234,
		286.74,
		-27.67,
		3.32
	],
	[
		6380,
		258.04,
		-43.24,
		3.33
	],
	[
		3045,
		117.32,
		-24.86,
		3.34
	],
	[
		4359,
		168.56,
		15.43,
		3.34
	],
	[
		6462,
		261.35,
		-56.38,
		3.34
	],
	[
		6698,
		269.76,
		-9.77,
		3.34
	],
	[
		1336,
		63.61,
		-62.47,
		3.35
	],
	[
		8465,
		332.71,
		58.2,
		3.35
	],
	[
		1788,
		81.12,
		-2.4,
		3.36
	],
	[
		2484,
		101.32,
		12.9,
		3.36
	],
	[
		3323,
		127.57,
		60.72,
		3.36
	],
	[
		7377,
		291.37,
		3.11,
		3.36
	],
	[
		5107,
		203.67,
		-.6,
		3.37
	],
	[
		5708,
		230.67,
		-44.69,
		3.37
	],
	[
		542,
		28.6,
		63.67,
		3.38
	],
	[
		3482,
		131.69,
		6.42,
		3.38
	],
	[
		4910,
		193.9,
		3.4,
		3.38
	],
	[
		921,
		46.29,
		38.84,
		3.39
	],
	[
		1412,
		67.17,
		15.87,
		3.4
	],
	[
		4050,
		154.27,
		-61.33,
		3.4
	],
	[
		8634,
		340.37,
		10.83,
		3.4
	],
	[
		429,
		22.09,
		-43.32,
		3.41
	],
	[
		544,
		28.27,
		29.58,
		3.41
	],
	[
		5190,
		207.38,
		-41.69,
		3.41
	],
	[
		5649,
		228.07,
		-52.1,
		3.41
	],
	[
		5948,
		240.03,
		-38.4,
		3.41
	],
	[
		6623,
		266.61,
		27.72,
		3.42
	],
	[
		7913,
		311.24,
		-66.2,
		3.42
	],
	[
		7957,
		311.32,
		61.84,
		3.43
	],
	[
		219,
		12.28,
		57.82,
		3.44
	],
	[
		3659,
		137.74,
		-58.97,
		3.44
	],
	[
		4031,
		154.17,
		23.42,
		3.44
	],
	[
		7236,
		286.56,
		-4.88,
		3.44
	],
	[
		334,
		17.15,
		-10.18,
		3.45
	],
	[
		4033,
		154.27,
		42.91,
		3.45
	],
	[
		7106,
		282.52,
		33.36,
		3.45
	],
	[
		804,
		40.83,
		3.24,
		3.47
	],
	[
		1239,
		60.17,
		12.49,
		3.47
	],
	[
		2646,
		105.43,
		-27.93,
		3.47
	],
	[
		3117,
		119.19,
		-52.98,
		3.47
	],
	[
		5681,
		228.88,
		33.31,
		3.47
	],
	[
		7635,
		299.69,
		19.49,
		3.47
	],
	[
		4377,
		169.62,
		33.09,
		3.48
	],
	[
		6406,
		258.66,
		14.39,
		3.48
	],
	[
		8684,
		342.5,
		24.6,
		3.48
	],
	[
		8675,
		342.14,
		-51.32,
		3.49
	],
	[
		509,
		26.02,
		-15.94,
		3.5
	],
	[
		5602,
		225.49,
		40.39,
		3.5
	],
	[
		6897,
		276.74,
		-45.97,
		3.51
	],
	[
		7150,
		284.43,
		-21.11,
		3.51
	],
	[
		3249,
		124.13,
		9.19,
		3.52
	],
	[
		3852,
		145.29,
		9.89,
		3.52
	],
	[
		3975,
		151.83,
		16.76,
		3.52
	],
	[
		8694,
		342.42,
		66.2,
		3.52
	],
	[
		1409,
		67.15,
		19.18,
		3.53
	],
	[
		2777,
		110.03,
		21.98,
		3.53
	],
	[
		5881,
		237.41,
		-3.43,
		3.53
	],
	[
		6220,
		250.72,
		38.92,
		3.53
	],
	[
		8450,
		332.55,
		6.2,
		3.53
	],
	[
		1136,
		55.81,
		-9.76,
		3.54
	],
	[
		1879,
		83.78,
		9.93,
		3.54
	],
	[
		3940,
		149.22,
		-54.57,
		3.54
	],
	[
		4450,
		173.25,
		-31.86,
		3.54
	],
	[
		6561,
		264.4,
		-15.4,
		3.54
	],
	[
		1998,
		86.74,
		-14.82,
		3.55
	],
	[
		5354,
		214.85,
		-46.06,
		3.55
	],
	[
		74,
		4.86,
		-8.82,
		3.56
	],
	[
		674,
		34.13,
		-51.51,
		3.56
	],
	[
		1347,
		64.47,
		-33.8,
		3.56
	],
	[
		4382,
		169.84,
		-14.78,
		3.56
	],
	[
		5705,
		230.45,
		-36.26,
		3.56
	],
	[
		7665,
		302.18,
		-66.18,
		3.56
	],
	[
		464,
		24.5,
		48.63,
		3.57
	],
	[
		2985,
		116.11,
		24.4,
		3.57
	],
	[
		6252,
		253.08,
		-38.02,
		3.57
	],
	[
		6927,
		275.26,
		72.73,
		3.57
	],
	[
		7754,
		304.51,
		-12.54,
		3.57
	],
	[
		2763,
		109.52,
		16.54,
		3.58
	],
	[
		5429,
		217.96,
		30.37,
		3.58
	],
	[
		5794,
		234.26,
		-28.13,
		3.58
	],
	[
		4700,
		185.34,
		-60.4,
		3.59
	]
], Pm = Math.PI / 180;
function Fm(e) {
	return ((e - 12 + 12) % 24 + 24) % 24;
}
function Im(e, t, n, r, i) {
	let a = n * 15 * Pm - e * Pm, o = t * Pm, s = Math.sin(r) * Math.sin(o) + Math.cos(r) * Math.cos(o) * Math.cos(a);
	i.altitude = Math.asin(Math.max(-1, Math.min(1, s)));
	let c = -Math.cos(o) * Math.sin(a), l = Math.sin(o) * Math.cos(r) - Math.cos(o) * Math.sin(r) * Math.cos(a);
	i.azimuth = Math.atan2(c, l);
}
var Lm = .62;
function Rm(e) {
	return e * Lm / 70;
}
function zm(e, t) {
	return Math.min(90, e / 2 / Rm(t));
}
function Bm(e, t, n, r, i) {
	let a = e.azimuth / Pm, o = e.altitude / Pm;
	if (Math.abs(a) > zm(n, r) || o < 0 || o > 70) {
		i.visible = !1;
		return;
	}
	i.visible = !0;
	let s = Rm(r);
	i.x = n / 2 + a * s, i.y = r * Lm - o * s;
	let c = Math.min(1, Math.max(0, (t + 1.5) / 5.5));
	i.radius = .7 + 1.6 * (1 - c), i.alpha = .2 + .8 * (1 - c);
}
function Vm(e, t, n, r = lm, i = Nm) {
	let a = Fm(e), o = {
		altitude: 0,
		azimuth: 0
	}, s = [];
	for (let [, e, c, l] of i) {
		Im(e, c, a, r, o);
		let i = {
			x: 0,
			y: 0,
			radius: 0,
			alpha: 0,
			visible: !1
		};
		Bm(o, l, t, n, i), i.visible && s.push(i);
	}
	return s;
}
//#endregion
//#region src/view/sky.ts
var Hm = {
	r: 195,
	g: 211,
	b: 226
}, Um = 2e4, Wm = .6;
function Gm(e) {
	return e < 2e4 ? 1 : e >= 8e4 ? .4 : 1 - (e - Um) / 6e4 * Wm;
}
function Km(e) {
	let t = Gm(e), n = t * t, r = Math.round(Hm.r * n), i = Math.round(Hm.g * n), a = Math.round(Hm.b * n);
	return r << 16 | i << 8 | a;
}
function qm(e, t, n, r) {
	if (t === 1 && n === 1 && r === 1) return Km(e);
	let i = Gm(e), a = i * i, o = Math.round(Hm.r * a * t), s = Math.round(Hm.g * a * n), c = Math.round(Hm.b * a * r);
	return o << 16 | s << 8 | c;
}
function Jm(e) {
	return e <= 2e4 ? 0 : e >= 8e4 ? 1 : (e - Um) / 6e4;
}
var Ym = [
	{
		at: 0,
		r: 103,
		g: 152,
		b: 219
	},
	{
		at: .35,
		r: 150,
		g: 186,
		b: 231
	},
	{
		at: .7,
		r: 210,
		g: 228,
		b: 247
	},
	{
		at: 1,
		r: 255,
		g: 255,
		b: 255
	}
];
function Xm(e = 256) {
	let t = document.createElement("canvas");
	t.width = 1, t.height = e;
	let n = t.getContext("2d");
	if (!n) throw Error("2d context unavailable for sky gradient");
	let r = n.createLinearGradient(0, 0, 0, e);
	for (let e = 0; e < Ym.length; e++) {
		let t = Ym[e];
		r.addColorStop(t.at, `rgb(${t.r},${t.g},${t.b})`);
	}
	return n.fillStyle = r, n.fillRect(0, 0, 1, e), p.from(t);
}
var Zm = 9.5;
function Qm(e) {
	let t = new r({ label: "skyContents" }), n = new ae(Xm());
	n.anchor.set(0, 0), t.addChild(n);
	let i = new V();
	t.addChild(i);
	let a = -1, o = -1, s = NaN, c = Zm, l = (e, t) => {
		c = t, s = Fm(t), i.clear();
		for (let n of Vm(t, e.width, e.height)) i.circle(n.x, n.y, n.radius), i.fill({
			color: 16777215,
			alpha: n.alpha
		});
	}, u = (e) => {
		if (Number.isNaN(s)) return Infinity;
		let t = Fm(e), n = Math.abs(t - s);
		return Math.min(n, 24 - n) * 15;
	};
	return {
		container: t,
		resize(e) {
			n.width = e.width, n.height = e.height, l(e, c), a = e.width, o = e.height;
		},
		update(e, t, r, s) {
			let c = s ? s.hour : Zm;
			(a !== t.width || o !== t.height || u(c) >= .25) && (n.width = t.width, n.height = t.height, l(t, c), a = t.width, o = t.height), n.tint = s ? qm(r, s.skyR, s.skyG, s.skyB) : Km(r), i.alpha = Math.max(Jm(r), s ? s.stars : 0);
		},
		destroy() {
			t.destroy({ children: !0 });
		}
	};
}
//#endregion
//#region src/view/particles.ts
var $m = [
	"core",
	"soft",
	"smoke",
	"wisp"
];
function eh(e, t, n) {
	let r = Math.imul(e + 1, 2654435769) ^ Math.imul(t + 1, 2246822507);
	return r = Math.imul(r ^ r >>> 15, 3266489909), r ^= Math.imul(n + 1, 668265263), r = Math.imul(r ^ r >>> 13, 374761393), r ^= r >>> 16, (r >>> 0) / 4294967296;
}
var th = (e) => e * e * (3 - 2 * e);
function nh(e, t, n, r) {
	let i = e * n, a = t * n, o = Math.floor(i), s = Math.floor(a), c = th(i - o), l = th(a - s), u = (e) => (e % n + n) % n, d = eh(u(o), u(s), r), f = eh(u(o + 1), u(s), r), p = eh(u(o), u(s + 1), r), m = eh(u(o + 1), u(s + 1), r), h = d + (f - d) * c;
	return h + (p + (m - p) * c - h) * l;
}
function rh(e) {
	return e >= 1 ? 0 : e < .4 ? 1 - e / .4 * .35 : .65 * (1 - (e - .4) / .6);
}
function ih(e, t, n) {
	let r = t / 2;
	for (let i = 0; i < t; i++) for (let a = 0; a < t; a++) {
		let o = (a + .5 - r) / r, s = (i + .5 - r) / r, c;
		switch (e) {
			case "soft":
				c = rh(Math.hypot(o, s));
				break;
			case "core": {
				let e = Math.hypot(o, s);
				if (e >= 1) c = 0;
				else if (e < .14) c = 1;
				else {
					let t = 1 - (e - .14) / .86;
					c = t * t * t;
				}
				break;
			}
			case "smoke": {
				let e = Math.hypot(o, s), t = .82 + .18 * nh((Math.atan2(s, o) + Math.PI) / (Math.PI * 2), .5, 6, 20973);
				if (e >= t) {
					c = 0;
					break;
				}
				let n = 1 - th(Math.min(1, e / t)), r = nh((o + 1) / 2, (s + 1) / 2, 4, 23552), i = nh((o + 1) / 2, (s + 1) / 2, 9, 31249);
				c = n * (.42 + .44 * r + .24 * i);
				break;
			}
			case "wisp": {
				let e = o / 1, t = s * 2.4, n = Math.hypot(e, t);
				c = n >= 1 ? 0 : (1 - n) * (1 - n) * (.75 + .5 * nh((o + 1) / 2, (s + 1) / 2, 5, 7034));
				break;
			}
		}
		(a < 2 || i < 2 || a >= t - 2 || i >= t - 2) && (c = 0);
		let l = (i * t + a) * 4;
		n[l] = 255, n[l + 1] = 255, n[l + 2] = 255, n[l + 3] = Math.max(0, Math.min(1, c)) * 255;
	}
}
var ah = {
	raptorPlumeCore: {
		rate: 300,
		life: .55,
		lifeJitter: .22,
		speed: 300,
		speedJitter: .14,
		spread: .035,
		gravityY: 0,
		drag: .85,
		startSize: 1.5,
		endSize: 4.2,
		startColor: 16777215,
		endColor: 16761962,
		startAlpha: .85,
		endAlpha: 0,
		additive: !0,
		texture: "core"
	},
	raptorPlume: {
		rate: 240,
		life: .42,
		lifeJitter: .35,
		speed: 110,
		speedJitter: .32,
		spread: .2,
		gravityY: 0,
		drag: 1.9,
		startSize: 3.4,
		endSize: 13,
		startColor: 16773312,
		endColor: 16734750,
		startAlpha: .5,
		endAlpha: 0,
		additive: !0,
		texture: "soft"
	},
	raptorShutdown: {
		rate: 400,
		life: .75,
		lifeJitter: .4,
		speed: 34,
		speedJitter: .6,
		spread: .7,
		gravityY: 2,
		drag: 3.2,
		startSize: 2,
		endSize: 14,
		startColor: 16767392,
		endColor: 6974066,
		startAlpha: .7,
		endAlpha: 0,
		additive: !1,
		texture: "smoke"
	},
	plasmaTrail: {
		rate: 260,
		life: 1.6,
		lifeJitter: .4,
		speed: 130,
		speedJitter: .35,
		spread: .22,
		gravityY: 0,
		drag: .6,
		startSize: 1.6,
		endSize: 22,
		startColor: 16774358,
		endColor: 11741704,
		startAlpha: .55,
		endAlpha: 0,
		additive: !0,
		texture: "core"
	},
	velocityStreak: {
		rate: 150,
		life: .5,
		lifeJitter: .35,
		speed: 900,
		speedJitter: .3,
		spread: .05,
		gravityY: 0,
		drag: 0,
		startSize: 3,
		endSize: 2,
		startColor: 16777215,
		endColor: 14477557,
		startAlpha: .3,
		endAlpha: 0,
		additive: !0,
		stretch: 9,
		texture: "wisp"
	},
	aeroTrail: {
		rate: 90,
		life: .9,
		lifeJitter: .3,
		speed: 12,
		speedJitter: .5,
		spread: .5,
		gravityY: 0,
		drag: 1.4,
		startSize: 1.2,
		endSize: 9,
		startColor: 16777215,
		endColor: 13621476,
		startAlpha: .35,
		endAlpha: 0,
		additive: !1,
		texture: "wisp"
	},
	groundSmoke: {
		rate: 300,
		life: 1.8,
		lifeJitter: .45,
		speed: 46,
		speedJitter: .7,
		spread: 1.25,
		gravityY: 3.5,
		drag: 1.9,
		startSize: 4,
		endSize: 30,
		startColor: 14273458,
		endColor: 9274743,
		startAlpha: .55,
		endAlpha: 0,
		additive: !1,
		texture: "smoke"
	},
	sonicBoom: {
		rate: 60,
		life: .45,
		lifeJitter: .2,
		speed: 26,
		speedJitter: .25,
		spread: 1.5,
		gravityY: 0,
		drag: 2.6,
		startSize: 6,
		endSize: 22,
		startColor: 16777215,
		endColor: 14411506,
		startAlpha: .3,
		endAlpha: 0,
		additive: !1,
		texture: "soft"
	},
	aeroHeat: {
		rate: 260,
		life: .55,
		lifeJitter: .4,
		speed: 55,
		speedJitter: .4,
		spread: .85,
		gravityY: 0,
		drag: 2,
		startSize: 3,
		endSize: 13,
		startColor: 16774354,
		endColor: 16727060,
		startAlpha: .8,
		endAlpha: 0,
		additive: !0,
		texture: "core"
	},
	explosion: {
		rate: 2600,
		life: 1.5,
		lifeJitter: .55,
		speed: 130,
		speedJitter: .8,
		spread: Math.PI,
		gravityY: -9,
		drag: 1.1,
		startSize: 5,
		endSize: 30,
		startColor: 16773828,
		endColor: 5460046,
		startAlpha: 1,
		endAlpha: 0,
		additive: !1,
		texture: "smoke"
	}
}, oh = {
	core: [0, 0],
	soft: [1, 0],
	smoke: [0, 1],
	wisp: [1, 1]
};
function sh(e, t = 64) {
	let n = document.createElement("canvas");
	n.width = t * 2, n.height = t * 2;
	let r = n.getContext("2d");
	if (!r) throw Error("2d context unavailable for particle textures");
	let i = new Uint8ClampedArray(t * t * 4), a = r.createImageData(t, t);
	for (let e of $m) {
		ih(e, t, i), a.data.set(i);
		let [n, o] = oh[e];
		r.putImageData(a, n * t, o * t);
	}
	let o = p.from(n).source;
	o.scaleMode = "linear";
	let s = {};
	for (let e of $m) {
		let [n, r] = oh[e];
		s[e] = new p({
			source: o,
			frame: new l(n * t, r * t, t, t),
			label: `particle-${e}`
		});
	}
	return s;
}
function ch(e) {
	let t = e >>> 0 || 1, n = t, r = () => (n ^= n << 13, n ^= n >>> 17, n ^= n << 5, n >>>= 0, n / 4294967296);
	return r.reset = () => {
		n = t;
	}, r;
}
function lh(e, t) {
	let n = 2166136261;
	for (let e = 0; e < t.length; e++) n = Math.imul(n ^ t.charCodeAt(e), 16777619);
	return (e ^ n) >>> 0;
}
function uh(e, t = 4e3, n = 2654435769) {
	let i = new r({ label: "particles" }), a = e instanceof p ? e : void 0, o = a === void 0 ? e : {
		core: a,
		soft: a,
		smoke: a,
		wisp: a
	}, s = Array(t), c = new Float32Array(t), l = new Float32Array(t), u = new Float32Array(t), d = new Float32Array(t), f = new Float32Array(t), m = new Float64Array(t), h = new Uint8Array(t), g = new Uint8Array(t), _ = new Float32Array(t), v = Array(t), y = new Float32Array(t), b = new Float32Array(t), x = new Float32Array(t), S = new Float32Array(t), C = new Float32Array(t), w = /* @__PURE__ */ new Float64Array(16), T = /* @__PURE__ */ new Float64Array(16), E = /* @__PURE__ */ new Float64Array(16), D = /* @__PURE__ */ new Float64Array(16), O = new Float32Array(t), k = new Uint32Array(t), A = new Uint32Array(t), j = new Float32Array(t), M = new Float32Array(t), N = new Float32Array(t), ee = new Float32Array(t), P = new Float32Array(t), F = new Int32Array(t), te = t, ne = new Int32Array(t), I = 0;
	for (let e = 0; e < t; e++) {
		let n = new ae(o.soft);
		n.anchor.set(.5), n.visible = !1, i.addChild(n), s[e] = n, F[e] = t - 1 - e;
	}
	let re = /* @__PURE__ */ new Map();
	for (let e of Object.keys(ah)) re.set(e, Array.from({ length: 34 }, (t, r) => ch(lh(n, e) ^ Math.imul(r, 2654435769))));
	let ie = /* @__PURE__ */ new Map();
	for (let e of Object.keys(ah)) ie.set(e, {
		total: /* @__PURE__ */ new Float64Array(34),
		correction: /* @__PURE__ */ new Float64Array(34),
		emitted: /* @__PURE__ */ new Float64Array(34)
	});
	let L = /* @__PURE__ */ new Map();
	for (let e of Object.values(ah)) L.set(e, {
		dt: 0,
		scale: 0,
		intensity: 0,
		spread: 0
	});
	let R = (e, t, n, r, i, a, p = 1, w = 0, T = 0) => {
		if (te === 0) return;
		let E = F[--te];
		v[E] = e;
		let D = i + (t() * 2 - 1) * e.spread * p, re = e.speed * a * (1 + (t() * 2 - 1) * e.speedJitter);
		c[E] = n, l[E] = r, u[E] = Math.cos(D) * re, d[E] = Math.sin(D) * re, f[E] = 0, m[E] = 0, h[E] = e === ah.velocityStreak ? 0 : 1, g[E] = +(e === ah.raptorPlume || e === ah.raptorPlumeCore), _[E] = e.life * (1 + (t() * 2 - 1) * e.lifeJitter), y[E] = e.startSize * a, b[E] = e.endSize * a, x[E] = e.startAlpha, S[E] = e.endAlpha, C[E] = e.drag, O[E] = e.gravityY * a, k[E] = e.startColor, A[E] = e.endColor, P[E] = e.stretch ?? 1, j[E] = n, M[E] = r, N[E] = T > 0 ? w : 0, ee[E] = T;
		let ie = s[E];
		return ie.visible = !0, ie.blendMode = e.additive ? "add" : "normal", ie.texture = o[e.texture], P[E] === 1 && (ie.rotation = 0), ne[I++] = E, E;
	};
	return {
		container: i,
		capacity: t,
		get alive() {
			return I;
		},
		inspect() {
			let e = Object.entries(ah).map(([e, t]) => ({
				effect: e,
				count: 0,
				ageMin: Infinity,
				ageMax: 0,
				lifeMin: Infinity,
				lifeMax: 0,
				alphaMin: Infinity,
				alphaMax: 0,
				left: Infinity,
				right: -Infinity,
				top: Infinity,
				bottom: -Infinity,
				...L.get(t)
			})), t = new Map(Object.values(ah).map((t, n) => [t, e[n]]));
			for (let e = 0; e < I; e++) {
				let n = ne[e], r = t.get(v[n]), i = s[n];
				r.count++, r.ageMin = Math.min(r.ageMin, f[n]), r.ageMax = Math.max(r.ageMax, f[n]), r.lifeMin = Math.min(r.lifeMin, _[n]), r.lifeMax = Math.max(r.lifeMax, _[n]), r.alphaMin = Math.min(r.alphaMin, i.alpha), r.alphaMax = Math.max(r.alphaMax, i.alpha);
				let a = Math.abs(Math.cos(i.rotation)), o = Math.abs(Math.sin(i.rotation)), c = (a * i.width + o * i.height) / 2, l = (o * i.width + a * i.height) / 2;
				r.left = Math.min(r.left, i.x - c), r.right = Math.max(r.right, i.x + c), r.top = Math.min(r.top, i.y - l), r.bottom = Math.max(r.bottom, i.y + l);
			}
			for (let t of e) t.count === 0 && Object.assign(t, {
				ageMin: 0,
				lifeMin: 0,
				alphaMin: 0,
				left: 0,
				right: 0,
				top: 0,
				bottom: 0
			});
			return e;
		},
		emit(e, t, n, r, i, a, o, s = 1, c = 0, l = 0, u = 0) {
			if (i <= 0 || a <= 0 || !Number.isInteger(u) || u < 0 || u >= 34) return;
			let d = ah[e], f = re.get(e)[u], p = L.get(d);
			p.dt = a, p.scale = o, p.intensity = i, p.spread = s;
			let h = d.rate * i, g = ie.get(e), _ = g.total[u], v = _ - g.emitted[u], y = h * a - g.correction[u], b = _ + y;
			g.correction[u] = b - _ - y, g.total[u] = b;
			let x = Math.floor(b), S = x - g.emitted[u];
			g.emitted[u] = x;
			for (let e = 0; e < S; e++) {
				let i = Math.min(a, (e + 1 - v) / h), u = R(d, f, t, n, r, o, s, c, l);
				u !== void 0 && (m[u] = i);
			}
		},
		burst(e, t, n, r, i) {
			let a = ah[e], o = re.get(e)[0];
			for (let e = 0; e < r; e++) R(a, o, t, n, o() * Math.PI * 2, i);
		},
		reproject(e, t, n, r = 0, i = 0) {
			if (e !== 1 || t !== 0 || n !== 0 || r !== 0 || i !== 0) for (let a = 0; a < I; a++) {
				let o = ne[a];
				if (!h[o]) continue;
				let f = t + (g[o] ? r : 0), p = n + (g[o] ? i : 0);
				c[o] = c[o] * e + f, l[o] = l[o] * e + p, j[o] = j[o] * e + f, M[o] = M[o] * e + p, u[o] *= e, d[o] *= e, O[o] *= e, y[o] *= e, b[o] *= e, N[o] *= e;
				let m = s[o];
				m.x = c[o], m.y = l[o], m.width *= e, m.height *= e;
			}
		},
		update(e) {
			let t = 0, n = 0;
			for (let r = 0; r < I; r++) {
				let i = ne[r], a = m[i], o = Math.max(0, e - a);
				m[i] = Math.max(0, a - e), f[i] += o;
				let p = f[i] / _[i];
				if (p >= 1) {
					s[i].visible = !1, F[te++] = i;
					continue;
				}
				let h = C[i], g = -1;
				for (let e = 0; e < t; e++) if (w[e] === h && T[e] === o) {
					g = e;
					break;
				}
				let v = g >= 0 ? E[g] : h > 0 ? Math.exp(-h * o) : 1, I = g >= 0 ? D[g] : h > 0 ? (1 - v) / h : o;
				g < 0 && t < 16 && (w[t] = h, T[t] = o, E[t] = v, D[t] = I, t += 1);
				let re = O[i], ie = h > 0 ? re / h : 0, ae = u[i], L = d[i];
				c[i] += ae * I, l[i] += (L + ie) * I - ie * o - (h > 0 ? 0 : .5 * re * o * o), u[i] = ae * v, d[i] = (L + ie) * v - ie - (h > 0 ? 0 : re * o);
				let R = s[i], oe = y[i] + (b[i] - y[i]) * p;
				R.x = c[i], R.y = l[i];
				let se = P[i];
				se === 1 ? (R.width = oe, R.height = oe) : (R.width = oe * se, R.height = oe, R.rotation = Math.atan2(d[i], u[i]));
				let ce = x[i] + (S[i] - x[i]) * p, le = N[i];
				if (le > 0) {
					let e = c[i] - j[i], t = l[i] - M[i], n = Math.sqrt(e * e + t * t);
					ce *= 1 + ee[i] * Math.cos(n / le * Math.PI * 2);
				}
				R.alpha = ce, R.tint = Gp(k[i], A[i], p), ne[n++] = i;
			}
			I = n;
		},
		clear() {
			for (let e = 0; e < I; e++) {
				let t = ne[e];
				s[t].visible = !1, F[te++] = t;
			}
			I = 0;
			for (let e of ie.values()) e.total.fill(0), e.correction.fill(0), e.emitted.fill(0);
			for (let e of re.values()) for (let t of e) t.reset();
			for (let e of L.values()) e.dt = 0, e.scale = 0, e.intensity = 0, e.spread = 0;
		},
		destroy() {
			i.destroy({ children: !0 });
		}
	};
}
function dh(e, t) {
	return (2 * e - 1) * (2 * e - 1) * t * 1;
}
function fh(e) {
	return e * 1;
}
var ph = 45e3;
function mh(e, t, n) {
	let r = e * t, i = Math.floor(r), a = r - i, o = a * a * (3 - 2 * a), s = (e) => (e % t + t) % t, c = eh(s(i), 0, n);
	return c + (eh(s(i + 1), 0, n) - c) * o;
}
function hh(e, t) {
	let n = 40225 + t * 12055, r = e - Math.floor(e);
	return .55 * mh(r, 5 + t, n) + .3 * mh(r, 11 + t * 3, n ^ 20899) + .15 * mh(r, 23 + t * 5, n ^ 42945);
}
function gh(e, t) {
	let n = (e + 1) / 3;
	return Math.max(.06, n * (1 - .55 * Math.min(1, Math.max(0, t))));
}
function _h(e) {
	let t = Math.max(0, e);
	return t / (t + 35e3);
}
function vh(e) {
	return Math.max(.25, 1 - .75 * _h(e));
}
var yh = .798, bh = .5, xh = 2.3, Sh = (e) => e * e * (3 - 2 * e);
function Ch(e, t) {
	return (e % t + t) % t;
}
function wh(e, t) {
	let n = new Float64Array(e * e);
	for (let r = 0; r < e; r++) for (let i = 0; i < e; i++) n[r * e + i] = eh(i, r, t);
	return n;
}
function Th(e, t, n, r) {
	let i = e * n, a = t * n, o = Math.floor(i), s = Math.floor(a), c = Sh(i - o), l = Sh(a - s), u = Ch(o, n), d = Ch(s, n), f = Ch(o + 1, n), p = Ch(s + 1, n), m = r[d * n + u], h = r[d * n + f], g = r[p * n + u], _ = r[p * n + f], v = m + (h - m) * c;
	return v + (g + (_ - g) * c - v) * l;
}
function Eh(e, t) {
	let n = wh(2, 32324), r = wh(5, 7173), i = wh(13, 15249), a = wh(29, 27927);
	for (let o = 0; o < e; o++) for (let s = 0; s < e; s++) {
		let c = s / e, l = o / e, u = .56 * Th(c, l, 2, n) + .22 * Th(c, l, 5, r) + .14 * Th(c, l, 13, i) + .08 * Th(c, l, 29, a), d = bh + .5 * Math.max(0, Math.min(1, (u - .5) * xh + .5)), f = Math.round(Math.max(0, Math.min(1, d)) * 255), p = (o * e + s) * 4;
		t[p] = f, t[p + 1] = f, t[p + 2] = f, t[p + 3] = 255;
	}
}
function Dh(e, t) {
	for (let n = 0; n < e; n++) {
		let r = e <= 1 ? 0 : n / (e - 1), i = 1 - r * r * .28, a = Math.round(Math.max(0, Math.min(1, i)) * 255), o = n * 4;
		t[o] = a, t[o + 1] = a, t[o + 2] = a, t[o + 3] = 255;
	}
}
function Oh(e, t) {
	for (let n = 0; n < e; n++) {
		let r = (1 - (e <= 1 ? 0 : n / (e - 1))) ** 2, i = n * 4;
		t[i] = 255, t[i + 1] = 255, t[i + 2] = 255, t[i + 3] = Math.round(Math.max(0, Math.min(1, r)) * 255);
	}
}
function kh(e, t) {
	for (let n = 0; n < e; n++) {
		let r = e <= 1 ? 1 : n / (e - 1), i = r * r * r, a = n * 4;
		t[a] = 255, t[a + 1] = 255, t[a + 2] = 255, t[a + 3] = Math.round(Math.max(0, Math.min(1, i)) * 255);
	}
}
function Ah() {
	let e = /* @__PURE__ */ new Uint8ClampedArray(262144);
	Eh(256, e);
	let t = document.createElement("canvas");
	t.width = 256, t.height = 256;
	let n = t.getContext("2d");
	if (!n) throw Error("2d context unavailable for the terrain mottle");
	let r = n.createImageData(256, 256);
	r.data.set(e), n.putImageData(r, 0, 0);
	let i = p.from(t);
	i.source.addressMode = "repeat";
	let a = /* @__PURE__ */ new Uint8ClampedArray(256);
	Dh(64, a);
	let o = document.createElement("canvas");
	o.width = 1, o.height = 64;
	let s = o.getContext("2d");
	if (!s) throw Error("2d context unavailable for the terrain ramp");
	let c = s.createImageData(1, 64);
	c.data.set(a), s.putImageData(c, 0, 0);
	let l = p.from(o), u = /* @__PURE__ */ new Uint8ClampedArray(256);
	Oh(64, u);
	let d = document.createElement("canvas");
	d.width = 1, d.height = 64;
	let f = d.getContext("2d");
	if (!f) throw Error("2d context unavailable for the horizon haze");
	let m = f.createImageData(1, 64);
	m.data.set(u), f.putImageData(m, 0, 0);
	let h = p.from(d), g = /* @__PURE__ */ new Uint8ClampedArray(256);
	kh(64, g);
	let _ = document.createElement("canvas");
	_.width = 1, _.height = 64;
	let v = _.getContext("2d");
	if (!v) throw Error("2d context unavailable for the limb");
	let y = v.createImageData(1, 64);
	return y.data.set(g), v.putImageData(y, 0, 0), {
		mottle: i,
		ramp: l,
		haze: h,
		limb: p.from(_)
	};
}
//#endregion
//#region src/view/coast.ts
var jh = 2640476;
function Mh() {
	let e = new r({ label: "coast" }), t = new V({ label: "coast-ocean" });
	t.poly([
		160,
		0,
		12e3,
		0,
		12e3,
		3e3,
		240,
		3e3,
		185,
		180,
		145,
		65
	]).fill(16777215);
	let n = new V({ label: "coast-shore" });
	n.poly([
		145,
		0,
		160,
		0,
		145,
		65,
		185,
		180,
		240,
		3e3,
		228,
		3e3,
		173,
		180,
		133,
		65
	]).fill(16777215);
	let i = new V({ label: "coast-pad" });
	i.rect(-48, 0, 96, 9).rect(-600, 14, 695, 5).rect(80, 0, 7, 80).fill(16777215);
	for (let e = -40; e < 48; e += 16) i.moveTo(e, 0).lineTo(e, 9);
	i.stroke({
		color: 7831946,
		width: .2
	});
	let a = new V({ label: "coast-lights" });
	a.blendMode = "add";
	for (let e of [
		-45,
		45,
		85
	]) a.ellipse(e, 2, 6, 2).fill({
		color: 16760180,
		alpha: .3
	}), a.rect(e - .3, 0, .6, .7).fill(16768153);
	e.addChild(t, n, i, a);
	for (let t of e.children) t.x = K;
	let o = [
		{
			node: t,
			left: 133,
			right: 12e3,
			depth: 3e3,
			colour: jh
		},
		{
			node: n,
			left: 133,
			right: 240,
			depth: 3e3,
			colour: 11051142
		},
		{
			node: i,
			left: -600,
			right: 95,
			depth: 80,
			colour: 11383475
		},
		{
			node: a,
			left: -51,
			right: 91,
			depth: 5,
			colour: 16777215
		}
	];
	return {
		container: e,
		update(t, n, r) {
			e.position.set(n.width / 2 - (t.posX + t.shakeX) * n.scale, n.height / 2 + (t.posY + t.shakeY) * n.scale), e.scale.set(n.scale);
			let i = Tm(r);
			for (let t of o) t.node.visible = e.x + (K + t.right) * n.scale > 0 && e.x + (K + t.left) * n.scale < n.width && e.y < n.height && e.y + t.depth * n.scale > 0, t.node.tint = t.node === a ? 16777215 : Kp(t.colour, i * yh);
			a.alpha = 1 - r.daylight;
		}
	};
}
function Nh(e) {
	let t = new r({ label: "distant-coast" });
	t.mask = e;
	let n = new V(), i = new V();
	t.addChild(i, n);
	let a = -1, o = -1;
	return {
		container: t,
		update(e, r, s) {
			if (a !== e.width || o !== e.height) {
				a = e.width, o = e.height, n.clear(), i.clear();
				let t = a * .57, r = Math.max(.5, a * .0015);
				n.moveTo(t, 0).lineTo(a * 2, 0).lineTo(a * 2, o * 2).lineTo(t - a * .1, o * 2).bezierCurveTo(t + a * .05, o * 1.4, t + a * .06, o * .45, t, 0).closePath().fill(16777215), i.moveTo(t - r, 0).lineTo(t, 0).bezierCurveTo(t + a * .06, o * .45, t + a * .05, o * 1.4, t - a * .1, o * 2).lineTo(t - a * .1 - r, o * 2).bezierCurveTo(t + a * .05 - r, o * 1.4, t + a * .06 - r, o * .45, t - r, 0).closePath().fill(12038552);
			}
			t.y = r, n.tint = s;
		}
	};
}
//#endregion
//#region src/view/world.ts
var Ph = 10783334, Fh = .3;
function Ih(e, t) {
	let n = new r({ label: "worldContents" }), i = new V();
	n.addChild(i);
	let a = t ? new Ki({
		texture: t.mottle,
		width: 1,
		height: 1
	}) : void 0, o = t ? new ae(t.ramp) : void 0;
	a && n.addChild(a), o && (o.blendMode = "multiply", n.addChild(o));
	let s = t ? new ae(t.haze) : void 0;
	s && n.addChild(s);
	let c = Mh(), l = new V({ context: i.context });
	l.label = "coast-ground-mask", n.addChild(c.container, l), c.container.mask = l;
	let u = _m(), d = new V();
	n.addChild(d);
	let f = {
		visible: !1,
		centreX: 0,
		length: 0,
		width: 0,
		alpha: 0
	}, p = -1, m = Ip.map((t) => {
		let r = e.get(t.src), i = new ae(r);
		return i.anchor.set(.5, 1), i.label = t.id, n.addChild(i), {
			object: t,
			sprite: i,
			x: t.x
		};
	}), h = new V();
	h.blendMode = "add", n.addChild(h);
	let g = new V();
	g.blendMode = "add", n.addChild(g);
	let _ = 0, v = -1, y = -1, b = -1, x = -1;
	return {
		container: n,
		update(e, t, n, r, S) {
			let C = ql(e, t, e.posX, 0), w = S?.sun, T = Gm(r) * (w ? Tm(w) : 1), E = w ? qm(r, w.skyR, w.skyG, w.skyB) : Km(r), D = Math.round(Jp(r) * t.width);
			if (_ !== t.width || v !== D) {
				if (_ = t.width, v = D, i.clear(), D <= 0) i.rect(-t.width, 0, t.width * 3, t.height * 2);
				else {
					let e = -t.width, n = t.width * 3;
					i.moveTo(e, t.height * 2);
					for (let t = 0; t <= 48; t++) {
						let r = t / 48, a = e + n * r, o = dh(r, D);
						i.lineTo(a, o);
					}
					i.lineTo(e + n, t.height * 2);
				}
				i.fill(Ph);
			}
			if (i.x = 0, i.y = C.y, i.tint = Kp(cm(Ph, Gm(r)), yh * (w ? Tm(w) : 1)), i.visible = C.y < t.height, l.position.set(i.x, i.y), c.update(e, t, w ?? u), c.container.visible = i.visible, a && o && (a.visible = i.visible, o.visible = i.visible, i.visible)) {
				let n = C.y + fh(D), r = Math.max(1, t.height * 2 - n);
				a.x = -t.width, a.y = n, a.width = t.width * 3, a.height = r;
				let s = Math.max(.5, t.scale * .35);
				a.tileScale.set(s, s), a.tilePosition.x = -(e.posX * t.scale) % (256 * s), a.tint = i.tint, o.x = -t.width, o.y = n, o.width = t.width * 3, o.height = Math.max(1, (t.height - n) * 1.6);
			}
			if (s && (s.visible = i.visible, i.visible)) {
				let e = Xp(r);
				s.x = -t.width, s.y = C.y, s.width = t.width * 3, s.height = Math.max(8, t.height * (.05 + .22 * e)), s.tint = E, s.alpha = Math.min(1, .55 + .45 * e);
			}
			let O = Xp(r);
			if (h.visible = O > .01 && i.visible, h.visible) {
				let e = Math.max(6, t.height * .06);
				(y !== e || _ !== b) && (y = e, b = _, h.clear(), h.rect(-t.width, -e, t.width * 3, e), h.fill(16777215)), h.y = C.y, h.alpha = O * .35 * (w ? w.daylight : 1), h.tint = 13623538;
			}
			if (S && C.y <= t.height + 6 ? Mm(S.altitude, S.pitch, S.vehicleHeight ?? q.height, S.vehicleDiameter ?? q.diameter, S.sun, f) : f.visible = !1, d.visible = f.visible && f.alpha > .01, d.visible && S) {
				let n = Math.max(2, Math.round(f.length * t.scale)), r = Math.max(6, Math.round(f.width * t.scale * Fh)), i = n * 4096 + r;
				i !== p && (p = i, d.clear(), d.ellipse(0, 0, n / 2, r / 2), d.fill({
					color: 0,
					alpha: 1
				}));
				let a = ql(e, t, S.downRangeDistance + f.centreX, 0);
				d.x = a.x, d.y = a.y - r / 2, d.alpha = f.alpha;
			}
			if (g.visible = i.visible && sm(T) > .02, g.visible) {
				let n = ql(e, t, 0, 0);
				g.x = n.x, g.y = n.y;
				let r = Math.max(24, 90 * t.scale);
				x !== Math.round(r) && (x = Math.round(r), g.clear(), g.circle(0, 0, x), g.fill({
					color: 16761707,
					alpha: .5
				})), g.alpha = sm(T) * .55;
			}
			let k = t.physicalWidth * .5;
			for (let i of m) {
				i.object.roams && Math.abs(i.x - e.posX) > k + i.object.width * .5 && (i.x = n > 0 ? e.posX + k + i.object.width * .5 : e.posX - k - i.object.width * .5);
				let a = ql(e, t, i.x, 0);
				i.sprite.x = a.x, i.sprite.y = a.y, i.sprite.width = i.object.width * t.scale, i.sprite.height = i.object.height * t.scale, i.sprite.tint = Kp(cm(16777215, Gm(r)), w ? Tm(w) : 1);
				let o = i.sprite.width * .5;
				i.sprite.visible = a.x + o > 0 && a.x - o < t.width && a.y > 0 && a.y - i.sprite.height < t.height;
			}
		}
	};
}
//#endregion
//#region src/view/catch-tower.ts
function Lh() {
	let e = new r({ label: "catch-tower" }), t = new V({ label: "tower-mast" });
	t.rect(-22, -Y.planeAltitude - 10, 6, Y.planeAltitude + 10).fill(6450549);
	for (let e = 0; e < Y.planeAltitude + 10; e += 10) t.moveTo(-22, -e).lineTo(-16, -e - 10).moveTo(-16, -e).lineTo(-22, -e - 10);
	t.stroke({
		color: 3753036,
		width: .3
	});
	let n = new V({ label: "catch-arms" });
	n.rect(-16, -Y.planeAltitude, 16 - Y.halfWidth, 1.5).rect(Y.halfWidth, -Y.planeAltitude, 6, 1.5).fill(10792887);
	let i = new V({ label: "tower-carriage" });
	i.rect(-23, -Y.planeAltitude - 5, 8, 10).fill(9016733), i.moveTo(-15, -Y.planeAltitude - 4).lineTo(-8, -Y.planeAltitude).moveTo(-15, -Y.planeAltitude + 4).lineTo(-8, -Y.planeAltitude), i.stroke({
		color: 4806753,
		width: .7
	});
	let a = new V({ label: "tower-lights" });
	a.blendMode = "add";
	for (let e of [
		30,
		70,
		Y.planeAltitude + 10
	]) a.circle(-19, -e, 1.2).fill({
		color: 16761467,
		alpha: .4
	}), a.circle(-19, -e, .35).fill(16769978);
	let o = new V({ label: "tower-secured" });
	return o.rect(-Y.halfWidth, -Y.planeAltitude - .4, Y.halfWidth * 2, .4).fill(8567968), o.visible = !1, e.addChild(t, n, i, a, o), e.visible = !1, {
		container: e,
		update(r, s, c, l) {
			if (e.visible = c !== void 0, !c) return;
			e.position.set(s.width / 2 + (K - r.posX - r.shakeX) * s.scale, s.height / 2 + (r.posY + r.shakeY) * s.scale), e.scale.set(s.scale);
			let u = l ? Tm(l) : 1;
			t.tint = n.tint = i.tint = Math.round(255 * u) * 65793, a.alpha = l ? 1 - l.daylight : 0, o.visible = c.status.landed && !c.status.onTheGround && !c.failures.crashed && !c.failures.inFlightBreakUp;
		}
	};
}
//#endregion
//#region src/view/distant-earth.ts
var Rh = .05, zh = .03;
function Bh(e, t) {
	if (!Number.isFinite(e) || !Number.isFinite(t) || t <= 0) return .5;
	let n = Math.max(0, e) / t;
	if (n <= .05) return .5 + n;
	let r = n - Rh;
	return .55 + zh * (1 - Math.exp(-r / zh));
}
function Vh(e) {
	if (!Number.isFinite(e)) return 0;
	let t = e < 0 ? -1 : 1, n = Math.abs(e);
	return n <= 420 ? e : t * (420 + 30 * Math.log1p((n - 420) / 30));
}
var Hh = .5, Uh = .7;
function Wh(e, t) {
	return !Number.isFinite(e) || !Number.isFinite(t) || t <= 0 ? !1 : e / t > Hh;
}
function Gh(e, t) {
	if (!Number.isFinite(e) || !Number.isFinite(t) || t <= 0) return 0;
	let n = e / t;
	if (n <= .5) return 0;
	let r = Math.min(1, (n - Hh) / Uh);
	return r * r * (3 - 2 * r);
}
var Kh = .34;
function qh(e) {
	let t = new r({ label: "distantEarth" }), n = [];
	for (let e = 0; e < 3; e++) {
		let e = new V();
		t.addChild(e), n.push(e);
	}
	let i = new V({ label: "distant-ground" });
	t.addChild(i);
	let a = new V({ context: i.context });
	t.addChild(a);
	let o = e ? new Ki({
		texture: e.mottle,
		width: 1,
		height: 1
	}) : void 0;
	o && (t.addChild(o), o.mask = a);
	let s = Nh(a);
	t.addChild(s.container);
	let c = e ? new ae(e.haze) : void 0;
	c && t.addChild(c);
	let l = new V();
	t.addChild(l), l.mask = a;
	let u = -1, d = new V();
	d.blendMode = "add", t.addChild(d);
	let f = 0, p = 0, m = -1, h = -1, g = 0, _ = (/* @__PURE__ */ new Int32Array(3)).fill(-1);
	return {
		container: t,
		get scrollOffset() {
			return g;
		},
		update(e, r, v, y, b) {
			let x = Wh(r, e.physicalHeight);
			if (t.visible = x, !x) return;
			let S = Bh(r, e.physicalHeight) * e.height, C = Xp(r), w = Math.round(Jp(r) * e.width);
			if (f !== e.width || p !== e.height || m !== w) {
				f = e.width, p = e.height, m = w, i.clear();
				let t = -e.width, n = e.width * 3;
				if (w <= 0) i.rect(t, 0, n, e.height * 2);
				else {
					i.moveTo(t, e.height * 2);
					for (let e = 0; e <= 48; e++) {
						let r = e / 48;
						i.lineTo(t + n * r, dh(r, w));
					}
					i.lineTo(t + n, e.height * 2);
				}
				i.fill(16777215);
			}
			let T = Gm(r), E = Wp(Km(r), cm(Ph, T), vh(r)), D = Kp(E, yh);
			i.tint = b ? Kp(D, 1 - Dm(b.elevation)) : D, i.x = 0, i.y = S, a.position.set(0, S), i.alpha = 1, s.update(e, S, Wp(Km(r), cm(jh, T), vh(r))), o && (o.x = -e.width, o.y = S, o.width = e.width * 3, o.height = Math.max(1, e.height * 2 - o.y), o.tileScale.set(2.4, 2.4 * Kh), o.tilePosition.x = g * .5, o.tint = E), t.alpha = (.82 + .14 * (1 - C)) * Gh(r, e.physicalHeight);
			let O = Vh(v * e.scale);
			g -= O * y, g = (g % 130 + 130) % 130;
			let k = Math.max(0, 1 - r / ph), A = Math.max(.6, e.width / 1280), j = b ? qm(r, b.skyR, b.skyG, b.skyB) : Km(r);
			for (let t = 0; t < n.length; t++) {
				let r = n[t];
				if (r.visible = k > .01, !r.visible) continue;
				let a = (5 + t * 9) * A * k, o = Math.round(a * 4) * 4096 + Math.round(e.width) + w * 1048576;
				if (_[t] !== o) {
					_[t] = o, r.clear();
					let n = -e.width, i = e.width * 3;
					r.moveTo(n, dh(0, w) + 2);
					for (let e = 0; e <= 384; e++) {
						let o = e / 384;
						r.lineTo(n + i * o, -a * hh(o * 3, t));
					}
					for (let e = 384; e >= 0; e--) {
						let t = e / 384;
						r.lineTo(n + i * t, dh(t, w) + 2);
					}
					r.fill(16777215);
				}
				let s = .35 + .3 * t;
				r.x = -(g * s % e.width), r.y = S + 1, r.tint = Wp(j, i.tint, gh(t, C));
			}
			if (c && (c.x = -e.width, c.y = S + fh(w), c.width = e.width * 3, c.height = Math.max(8, e.height * (.05 + .3 * C)), c.tint = Km(r), c.alpha = Math.min(1, .55 + .45 * C)), b) {
				let t = qp(r) / kc * 2 * Math.PI, n = Math.round(b.hourAngle * 180 / Math.PI * 2) * 1000003 + Math.round(t * 1e3) * 4096 + w * 16 + Math.round(e.width / 8);
				if (n !== u) {
					u = n, l.clear();
					let r = !1, i = -e.width, a = e.width * 3;
					for (let n = 0; n < 48; n++) {
						let o = ((n + .5) / 48 * 3 - 1.5) * 2, s = Dm(Em(b.hourAngle, o * t));
						if (s > .005) {
							r = !0;
							let t = Math.round(i + n * a / 48), o = Math.round(i + (n + 1) * a / 48);
							l.rect(t, 0, o - t, e.height * 2), l.fill({
								color: 0,
								alpha: s
							});
						}
					}
					l.visible = r;
				}
				l.x = 0, l.y = S;
			} else l.visible = !1;
			let M = _h(r);
			if (d.visible = M > .02, d.visible) {
				let t = Math.max(6, e.height * (.02 + .05 * M)), n = Math.round(t) * 8192 + w * 4 + Math.round(e.width / 8);
				if (h !== n) {
					h = n, d.clear();
					let r = -e.width, i = e.width * 3;
					for (let e = 0; e < 14; e++) {
						let n = (e + 1) / 14 * t, a = e / 14 * t, o = 1 - (e + .5) / 14;
						d.moveTo(r, dh(0, w) - a);
						for (let e = 0; e <= 48; e++) {
							let t = e / 48;
							d.lineTo(r + i * t, dh(t, w) - a);
						}
						for (let e = 48; e >= 0; e--) {
							let t = e / 48;
							d.lineTo(r + i * t, dh(t, w) - n);
						}
						d.fill({
							color: 9418495,
							alpha: o * o * o
						});
					}
				}
				d.x = 0, d.y = S, d.alpha = (.35 + .65 * M) * (b ? 1 - Dm(b.elevation) : 1);
			}
		}
	};
}
function Jh(e) {
	if (!Number.isFinite(e)) return 0;
	let t = Math.abs(e);
	if (t <= 150) return 0;
	if (t >= 2e3) return 1;
	let n = (t - 150) / 1850;
	return n * n * (3 - 2 * n);
}
function Yh(e, t) {
	return e <= 0 ? 0 : t * (.02 + .1 * e);
}
function Xh(e) {
	return Number.isFinite(e) ? e : 0;
}
function Zh(e) {
	return Number.isFinite(e) && Math.abs(e) >= 5;
}
function Qh() {
	let e = new r({ label: "flightPathMarker" }), t = new V();
	return t.circle(0, 0, 10), t.stroke({
		width: 1.5,
		color: 16777215,
		alpha: .75
	}), t.moveTo(-10, 0), t.lineTo(-17, 0), t.moveTo(10, 0), t.lineTo(17, 0), t.moveTo(0, -10), t.lineTo(0, -16), t.stroke({
		width: 1.5,
		color: 16777215,
		alpha: .75
	}), e.addChild(t), {
		container: e,
		update(t, n, r, i, a) {
			let o = Zh(i);
			if (e.visible = o, !o) return;
			e.x = t, e.y = n, e.rotation = Xh(r);
			let s = Math.max(.7, a / 800);
			e.scale.set(s, s);
		}
	};
}
//#endregion
//#region src/view/clouds.ts
var $h = 2500, eg = 2.5, tg = .4, ng = .06, rg = .02, ig = .02;
function ag(e, t, n) {
	return e <= t ? e : t + n * (1 - Math.exp(-(e - t) / n));
}
function og(e, t) {
	if (!Number.isFinite(e) || !Number.isFinite(t) || t <= 0) return .5;
	let n = ($h - e) / t;
	return .5 - (n >= 0 ? ag(n, tg, ng) : -ag(-n, rg, ig));
}
var sg = 9e3;
function cg(e) {
	if (!Number.isFinite(e)) return 0;
	if (e <= 9e3) return 1;
	if (e >= 45e3) return 0;
	let t = (e - sg) / 36e3;
	return 1 - t * t * (3 - 2 * t);
}
var lg = .72, ug = .85, dg = .62, fg = .016;
function pg(e, t) {
	let n = Math.imul(e + 1, 2654435769) ^ Math.imul(t + 1, 2246822507);
	return n = Math.imul(n ^ n >>> 15, 3266489909), n ^= n >>> 16, (n >>> 0) / 4294967296;
}
var mg = 30;
function hg(e = p.EMPTY) {
	let t = new r({ label: "cloudDeck" }), n = e.width > 0 ? e.width : 1, i = /* @__PURE__ */ new Float32Array(60), a = /* @__PURE__ */ new Float32Array(60), o = /* @__PURE__ */ new Float32Array(60), s = /* @__PURE__ */ new Float32Array(60), c = /* @__PURE__ */ new Float32Array(60), l = [];
	for (let n = 0; n < 60; n++) {
		n < mg || n - mg, i[n] = (pg(n, 1) - .5) * 114 * .7, a[n] = (pg(n, 2) - .5) * 96, o[n] = 120 + pg(n, 3) * 300, s[n] = .46 + pg(n, 4) * .5, c[n] = .25 + pg(n, 5) * .35;
		let r = new ae(e);
		r.anchor.set(.5), t.addChild(r), l.push(r);
	}
	let u = 0, d = 0;
	return {
		container: t,
		get scrollOffset() {
			return u;
		},
		get farScrollOffset() {
			return d;
		},
		update(e, r, f, p, m) {
			let h = cg(r);
			if (t.visible = h > .01, !t.visible) return;
			let g = og(r, e.physicalHeight) * e.height, _ = Vh(f * e.scale) * eg;
			u -= _ * p, u = (u % 114 + 114) % 114, d -= _ * lg * p, d = (d % 114 + 114) % 114;
			let v = Gm(r), y = m ? Tm(m) : 1, b = Math.round(255 * (.55 + .45 * v) * y), x = b << 16 | b << 8 | Math.min(255, b + 6), S = Math.max(.55, e.width / 1280), C = (g < e.height * .5 ? 1 : -1) * fg * e.height;
			for (let e = 0; e < l.length; e++) {
				let t = l[e], r = e < mg, f = r ? e : e - mg;
				t.x = -114 + (r ? d : u) + f * 114 + i[e], t.y = g + a[e] + (r ? C : 0);
				let p = o[e] * S * (r ? ug : 1);
				t.scale.set(p / n, p * s[e] / n), t.tint = x, t.alpha = h * c[e] * (r ? dg : 1);
			}
		}
	};
}
//#endregion
//#region src/view/post.ts
var gg = "\nin vec2 aPosition;\nout vec2 vTextureCoord;\n\nuniform highp vec4 uInputSize;\nuniform vec4 uOutputFrame;\nuniform vec4 uOutputTexture;\n\nvec4 filterVertexPosition( void ) {\n  vec2 position = aPosition * uOutputFrame.zw + uOutputFrame.xy;\n  position.x = position.x * (2.0 / uOutputTexture.x) - 1.0;\n  position.y = position.y * (2.0 * uOutputTexture.z / uOutputTexture.y) - uOutputTexture.z;\n  return vec4(position, 0.0, 1.0);\n}\n\nvec2 filterTextureCoord( void ) {\n  return aPosition * (uOutputFrame.zw * uInputSize.zw);\n}\n\nvoid main(void) {\n  gl_Position = filterVertexPosition();\n  vTextureCoord = filterTextureCoord();\n}\n", _g = "\nin vec2 vTextureCoord;\nout vec4 finalColor;\n\nuniform sampler2D uTexture;\n// Pixi's cropped filter-input dimensions in logical pixels, not the canvas.\nuniform highp vec4 uInputSize;\nuniform float uStrength;\nuniform float uThreshold;\n\nvec3 brightPass(vec2 uv) {\n  vec3 c = texture(uTexture, uv).rgb;\n  float luma = dot(c, vec3(0.2126, 0.7152, 0.0722));\n  return c * max(luma - uThreshold, 0.0) / max(1.0 - uThreshold, 0.0001);\n}\n\nvoid main(void) {\n  vec4 base = texture(uTexture, vTextureCoord);\n\n  // Nine taps on a widening cross. Enough for a soft halo, cheap enough to run\n  // every frame on a phone.\n  vec3 bleed = vec3(0.0);\n  bleed += brightPass(vTextureCoord) * 0.24;\n  for (int i = 1; i <= 4; i++) {\n    float o = float(i) * 1.6;\n    float w = 0.19 / float(i);\n    bleed += brightPass(vTextureCoord + vec2( o, 0.0) * uInputSize.zw) * w;\n    bleed += brightPass(vTextureCoord + vec2(-o, 0.0) * uInputSize.zw) * w;\n    bleed += brightPass(vTextureCoord + vec2(0.0,  o) * uInputSize.zw) * w;\n    bleed += brightPass(vTextureCoord + vec2(0.0, -o) * uInputSize.zw) * w;\n  }\n\n  finalColor = vec4(base.rgb + bleed * uStrength, base.a);\n}\n", vg = "\nin vec2 vTextureCoord;\nout vec4 finalColor;\n\nuniform sampler2D uTexture;\nuniform float uTime;\nuniform float uIntensity;\nuniform vec2 uCenter;\nuniform vec2 uTexelSize;\n\nvoid main(void) {\n  vec2 uv = vTextureCoord;\n\n  // Displacement grows with distance behind the vehicle, so the wake shimmers\n  // and the nose stays sharp.\n  vec2 toCenter = uv - uCenter;\n  float distance = length(toCenter);\n  float wake = smoothstep(0.0, 0.45, distance);\n\n  float wobble = sin(uv.y * 190.0 + uTime * 11.0) * 0.5\n               + sin(uv.y * 91.0 - uTime * 7.3) * 0.5;\n  uv.x += wobble * 0.0032 * uIntensity * wake;\n\n  vec4 color = texture(uTexture, uv);\n\n  // Shock front: a thin bright arc standing off the nose.\n  float ring = smoothstep(0.055, 0.040, abs(distance - 0.052));\n  vec3 shock = vec3(1.0, 0.62, 0.34) * ring * uIntensity * 0.55;\n\n  finalColor = vec4(color.rgb + shock * color.a, color.a);\n}\n";
function yg(e, t, n, r) {
	let i = new E({
		resolution: "inherit",
		antialias: "inherit",
		glProgram: k.from({
			vertex: gg,
			fragment: _g,
			name: "bloom"
		}),
		resources: { bloomUniforms: {
			uStrength: {
				value: 0,
				type: "f32"
			},
			uThreshold: {
				value: .62,
				type: "f32"
			}
		} }
	}), a = new E({
		glProgram: k.from({
			vertex: gg,
			fragment: vg,
			name: "heat"
		}),
		resources: { heatUniforms: {
			uTime: {
				value: 0,
				type: "f32"
			},
			uIntensity: {
				value: 0,
				type: "f32"
			},
			uCenter: {
				value: new Float32Array([.5, .5]),
				type: "vec2<f32>"
			},
			uTexelSize: {
				value: new Float32Array([1 / n, 1 / r]),
				type: "vec2<f32>"
			}
		} }
	}), o = !1, s = !1, c = i.resources.bloomUniforms, l = a.resources.heatUniforms;
	return {
		get active() {
			return o || s;
		},
		metadata(n) {
			return [[
				"bloom",
				i,
				e
			], [
				"heat",
				a,
				t
			]].map(([e, t, r]) => {
				let i = r.filters?.includes(t) ?? !1, a = !!(t.compatibleRenderers & n.backendType), o = i && t.enabled && a;
				return {
					id: e,
					attached: i,
					enabled: t.enabled,
					compatible: a,
					resolution: t.resolution,
					antialias: t.antialias,
					inputResolution: o ? t.resolution === "inherit" ? n.resolution : t.resolution : null,
					inputAntialias: o ? t.antialias === "inherit" ? n.antialias : t.antialias === "on" : null
				};
			});
		},
		update(n, r, u, d) {
			n > .02 ? (c.uniforms.uStrength = Math.min(n, 1) * 1.35, o ||= (e.filters = [i], !0)) : o &&= (e.filters = [], !1), r > .02 ? (l.uniforms.uIntensity = Math.min(r, 1), l.uniforms.uTime = d, l.uniforms.uCenter[0] = u.x, l.uniforms.uCenter[1] = u.y, s ||= (t.filters = [a], !0)) : s &&= (t.filters = [], !1);
		},
		destroy() {
			e.filters = [], t.filters = [], i.destroy(), a.destroy();
		}
	};
}
function bg(e, t) {
	return e === 0 ? 0 : e / 3 * (t / 100);
}
function xg(e, t) {
	return e <= 0 ? 0 : Math.min(e / t, 1);
}
//#endregion
//#region src/view/vehicle-geometry.ts
var Sg = Object.freeze({
	azimuthRadians: 20 * Math.PI / 180,
	perspective: !1
}), Cg = Object.freeze({
	frontFlap: .87,
	aftFlap: .15,
	gridFin: .9,
	noseBase: .74,
	crownBase: .95
});
function wg(e, t, n, r, i = "flat") {
	return Object.freeze({
		id: e,
		material: t,
		depth: n,
		normalMode: i,
		points: Object.freeze(r.map(([e, t]) => Object.freeze({
			x: e,
			station: t
		})))
	});
}
function Tg(e, t, n, r, i, a, o, s = "flat") {
	return wg(e, t, n, [
		[r, a],
		[i, a],
		[i, o],
		[r, o]
	], s);
}
function Eg(e, t, n, r, i, a, o) {
	return Object.freeze({
		id: e,
		kind: t,
		material: n,
		x: r,
		station: i,
		depth: a,
		retainedAfterStaging: !0,
		polygons: Object.freeze(o)
	});
}
var Dg = {
	"sea-level": 1.3,
	vacuum: 2.3
};
function Og(e, t) {
	let { height: n, diameter: r } = e, i = r / 9, a = e.id === "ship" ? "ship" : "booster", o = e.id === "ship" ? 6 : 33;
	if (e.engines && e.engines.length !== o) throw RangeError("V3 engine geometry inventory must match its physical model");
	let s = [];
	for (let r = 0; r < o; r++) {
		let o = "sea-level", c, l;
		if (e.id === "ship") {
			o = r < 3 ? "sea-level" : "vacuum";
			let e = (r < 3 ? 1 : 3) * i, t = Math.PI + r % 3 * 2 * Math.PI / 3;
			c = e * Math.cos(t), l = e * Math.sin(t);
		} else if (r < 3) c = [
			0,
			-.65,
			.65
		][r] * i, l = [
			0,
			-.35,
			.35
		][r] * i;
		else {
			let e = r < 13, t = (e ? 2 : 3.8) * i, n = 2 * Math.PI * (r - (e ? 3 : 13)) / (e ? 10 : 20);
			c = t * Math.cos(n), l = t * Math.sin(n);
		}
		let u = e.engines?.[r];
		if (u && (o = u.kind, c = u.offAxis, l = u.depth ?? l), !Number.isFinite(c + l)) throw RangeError("engine geometry mounts require finite physical coordinates");
		let d = Dg[o] * i / 2, f = Math.min((o === "vacuum" ? 2.05 : 1.55) * i, n * t * .97), p = [
			[c - d, 0],
			[c + d, 0],
			[c + d * .72, f * .35],
			[c + d * .42, f * .72],
			[c + d * .28, f],
			[c - d * .28, f],
			[c - d * .42, f * .72],
			[c - d * .72, f * .35]
		], m = `${a}-engine-${r}`, h = (e, t, n) => Object.freeze({
			...wg(`${m}-${e}`, "steel", n, t, e === "bell-shell" ? "nozzle" : "flat"),
			engineIndex: r,
			engineKind: o,
			surfaceRole: e
		});
		s.push(h("bell-shell", p, l));
		for (let e of [!1, !0]) {
			let t = [], n = d * .16;
			for (let r = 0; r < 12; r++) {
				let i = r * 2 * Math.PI / 12, a = e ? .8 : .98;
				t.push([c + d * a * Math.cos(i), n + n * a * Math.sin(i)]);
			}
			s.push(h(e ? "bell-mouth" : "bell-lip", t, l + (e ? .002 : .001) * i));
		}
	}
	let c = Object.freeze({
		...Tg(`${a}-engine-rim`, "steel", r / 2, -r / 2, r / 2, n * t * .7, n * t, "cylinder"),
		surfaceRole: "engine-rim"
	});
	return s.push(c), s.sort((e, t) => e.depth - t.depth), Eg(`${a}-engine-support`, "engine-support", "steel", 0, n * t / 2, 0, s);
}
var kg = Object.freeze([
	[1, .74],
	[.99, .79],
	[.93, .84],
	[.83, .88],
	[.69, .915],
	[.53, .945],
	[.36, .968],
	[.19, .987],
	[.07, .997],
	[0, 1]
].map(([e, t]) => Object.freeze([e, t])));
function Ag(e) {
	let { height: t, diameter: n } = e, r = n / 2, i = [], a = kg.map(([e, n]) => [-e * r, n * t]);
	a.push(...kg.slice(0, -1).reverse().map(([e, n]) => [e * r, n * t]));
	let o = kg.map(([e, n]) => [-e * r * .96, n * t]);
	o.push(...kg.slice(0, -1).reverse().map(([e, n]) => [e * r * Math.cos(Sg.azimuthRadians), n * t])), i.push(Eg("ship-nose", "nose", "steel", 0, t * .87, 0, [wg("ship-nose-steel", "steel", 0, a, "nose"), wg("ship-nose-tps", "tile", .01 * n, o, "nose")]));
	let s = (e) => r * (Math.cos(Sg.azimuthRadians) - .02 * (Cg.noseBase - e) / (Cg.noseBase - .035));
	for (let [e, a, o] of [[
		"ship-hull-forward",
		.3,
		Cg.noseBase
	], [
		"ship-hull-aft",
		.035,
		.3
	]]) i.push(Eg(e, "hull", "steel", 0, (a + o) * t / 2, 0, [Tg(`${e}-steel`, "steel", 0, -r, r, a * t, o * t, "cylinder"), wg(`${e}-tps`, "tile", n * .01, [
		[-r * .96, a * t],
		[s(a), a * t],
		[s(o), o * t],
		[-r * .96, o * t]
	], "cylinder")]));
	i.push(Og(e, .035));
	for (let a of [!0, !1]) for (let o of [-1, 1]) {
		let s = a ? e.frontFinStation ?? t * Cg.frontFlap : e.aftFinStation ?? t * Cg.aftFlap, c = t * (a ? .8 : .015), l = t * (a ? .94 : .3), u = l - c, d = o * n * .075, f = n * (a ? .34 : .46) * (o < 0 ? .78 : 1), p = o * r * .94, m = `ship-${a ? "front" : "aft"}-flap-${o < 0 ? "left" : "right"}`, h = [
			[p, l],
			[p + o * f, c + u * .67],
			[p + o * f * .94, c + u * .07],
			[p, c]
		];
		i.push(Eg(m, "flap", "tile", p, s, d, [wg(`${m}-face`, "tile", d, h)]));
	}
	return i;
}
function jg(e, t, n, r, i) {
	let a = n[0] - t[0], o = n[1] - t[1], s = Math.hypot(a, o), c = -o / s * r / 2, l = a / s * r / 2;
	return wg(e, "steel", i, [
		[t[0] + c, t[1] + l],
		[t[0] - c, t[1] - l],
		[n[0] - c, n[1] - l],
		[n[0] + c, n[1] + l]
	]);
}
function Mg(e) {
	let { height: t, diameter: n } = e, r = n / 2, i = t * Cg.crownBase, a = [], o = [[-r, i]];
	for (let e = 1; e < 12; e++) {
		let t = Math.PI - e * Math.PI / 12;
		o.push([r * Math.cos(t), i + n * .26 * Math.sin(t)]);
	}
	o.push([r, i]), a.push(Eg("booster-hull-forward", "hull", "steel", 0, t * .725, 0, [
		Tg("booster-forward-wall", "steel", 0, -r, r, t * .5, i, "cylinder"),
		wg("booster-dome", "steel", 0, o, "dome"),
		Tg("booster-raceway-forward", "steel", n * .48, r * .78, r * .84, t * .5, i)
	])), a.push(Eg("booster-hull-aft", "hull", "steel", 0, t * .265, 0, [
		Tg("booster-aft-wall", "steel", 0, -r, r, t * .03, t * .5, "cylinder"),
		Tg("booster-raceway-aft", "steel", n * .48, r * .78, r * .84, t * .08, t * .5),
		...[-1, 1].map((e) => wg(`booster-strake-${e}`, "steel", n * .01, [
			[e * r, t * .05],
			[e * (r + n * .055), t * .06],
			[e * r, t * .2]
		]))
	])), a.push(Og(e, .03));
	let s = [], c = n * .014, l = t - n * .028, u = i + c / 2;
	s.push(Tg("booster-crown-top", "steel", r, -r, r, l, t, "cylinder"), Tg("booster-crown-bottom", "steel", r, -r, r, i, i + c, "cylinder"));
	for (let e = 0; e < 6; e++) {
		let t = -Math.PI / 2 + Math.PI * e / 6, n = t + Math.PI / 6, i = r * Math.sin(t), a = r * Math.sin(n), o = r * Math.sin((t + n) / 2), d = r * Math.cos((t + n) / 2);
		s.push(jg(`booster-crown-brace-${e}-up`, [i, u], [o, l], c, d), jg(`booster-crown-brace-${e}-down`, [o, l], [a, u], c, d));
	}
	a.push(Eg("booster-hot-stage", "hot-stage", "steel", 0, (t + i) / 2, n * .06, s));
	for (let i = 0; i < 3; i++) {
		let o = Sg.azimuthRadians + i * 2 * Math.PI / 3, s = Math.sin(o), c = r * Math.cos(o), l = r * s, u = e.gridFinStation ?? t * Cg.gridFin, d = n * .46 * s, f = n * .18, p = `booster-grid-${i}`, m = [
			[l, u + f],
			[l + d * .86, u + f],
			[l + d, u + f * .7],
			[l + d * .94, u + f * .35],
			[l + d, u],
			[l + d * .94, u - f * .35],
			[l + d, u - f * .7],
			[l + d * .86, u - f],
			[l, u - f]
		], h = [];
		for (let e = 0; e < 12; e++) {
			let t = e * Math.PI / 6;
			h.push([l + Math.cos(t) * n * .045, u + Math.sin(t) * n * .06]);
		}
		let g = Object.freeze({
			...wg(`${p}-face`, "grid", c, m),
			surfaceRole: "grid-face"
		}), _ = Object.freeze({
			...Tg(`${p}-edge`, "steel", c + .001, Math.min(l, l + d), Math.max(l, l + d), u - f - n * .005, u - f + n * .005),
			surfaceRole: "grid-edge"
		}), v = Object.freeze({
			...wg(`${p}-collar`, "steel", c + .002, h),
			surfaceRole: "grid-collar"
		});
		a.push(Eg(p, "grid-fin", "grid", l, u, c, [
			g,
			_,
			v
		]));
	}
	return a;
}
function Ng(e) {
	if (!Number.isFinite(e.height) || !Number.isFinite(e.diameter) || e.height <= 0 || e.diameter <= 0) throw RangeError("vehicle geometry requires finite positive dimensions");
	for (let t of [
		e.frontFinStation,
		e.aftFinStation,
		e.gridFinStation
	]) if (t !== void 0 && (!Number.isFinite(t) || t < 0 || t > e.height)) throw RangeError("component station must be inside the physical hull");
	let t = e.id === "ship" ? Ag(e) : Mg(e);
	for (let n of t) for (let t of n.polygons) for (let n of t.points) if (n.station < 0 || n.station > e.height) throw RangeError("authored component extends beyond the physical hull");
	return t.sort((e, t) => e.depth - t.depth), Object.freeze({
		id: e.id,
		height: e.height,
		diameter: e.diameter,
		projection: Sg,
		components: Object.freeze(t)
	});
}
//#endregion
//#region src/view/heat-look.ts
function Pg(e) {
	if (!Number.isFinite(e)) return 0;
	let t = Math.max(0, Math.min(1, (e - 800) / 733));
	return t * t * (3 - 2 * t);
}
//#endregion
//#region src/view/vehicle-material.ts
var Fg = "\nin vec2 aPosition;\nin vec2 aUV;\nout vec2 vPoint;\nout vec4 vColor;\nuniform mat3 uProjectionMatrix;\nuniform mat3 uWorldTransformMatrix;\nuniform mat3 uTransformMatrix;\nuniform vec4 uWorldColorAlpha;\nuniform vec4 uColor;\nvoid main(void) {\n  gl_Position = vec4((uProjectionMatrix * uWorldTransformMatrix * uTransformMatrix * vec3(aPosition, 1.0)).xy, 0.0, 1.0);\n  vPoint = aUV;\n  vColor = uColor * uWorldColorAlpha;\n}\n", Ig = "\nin vec2 vPoint;\nin vec4 vColor;\nout vec4 finalColor;\nuniform vec3 uLight;\nuniform vec3 uFlatNormal;\nuniform vec3 uEnvironmentUp;\nuniform vec3 uSkyTone;\nuniform vec4 uBounds;\nuniform float uDaylight;\nuniform float uGlow;\nuniform float uPixelsPerMetre;\nuniform float uDetail;\nuniform float uRadius;\nuniform float uHeight;\nuniform float uNormalMode;\nuniform float uMaterial;\n\nfloat line(float coord, float period, float width) {\n  float edge = min(fract(coord / period), 1.0 - fract(coord / period)) * period;\n  // Derivatives require an optional WebGL1 extension. The renderer already\n  // supplies projected metre scale (including articulation compression), so\n  // use its reciprocal footprint on every backend. sqrt(2) conservatively\n  // covers a line rotated across a square pixel without unresolved shimmer.\n  float aa = max(1.41421356 / max(uPixelsPerMetre, 0.001), 0.001);\n  // Box-filtered physical coverage: narrow lines lose opacity rather than\n  // expanding to a full pixel. Unresolved repetition retains its area mean.\n  if (aa >= period) return min(1.0, 2.0 * width / period);\n  return clamp((width + aa * 0.5 - edge) / aa, 0.0, 1.0)\n    - clamp((-width + aa * 0.5 - edge) / aa, 0.0, 1.0);\n}\nvoid main(void) {\n  vec3 n = normalize(uFlatNormal);\n  if (uNormalMode > 0.5) {\n    float radius = uRadius;\n    float slope = 0.0;\n    float axisX = 0.0;\n    if (uNormalMode > 3.5) {\n      // The booster dome is the authored half-ellipse, not the Ship nose taper.\n      float span = max(0.001, uBounds.w - uBounds.y);\n      float t = clamp((vPoint.y - uBounds.y) / span, 0.0, 0.998);\n      float section = sqrt(max(0.001, 1.0 - t * t));\n      radius *= section;\n      slope = -uRadius * t / (span * section);\n    } else if (uNormalMode > 2.5) {\n      // Each tapered bell has its own centre/radius, never the hull's normal.\n      float span = max(0.001, uBounds.w - uBounds.y);\n      float t = clamp((vPoint.y - uBounds.y) / span, 0.0, 1.0);\n      axisX = (uBounds.x + uBounds.z) * 0.5;\n      float exitRadius = (uBounds.z - uBounds.x) * 0.5;\n      radius = exitRadius * (1.0 - 0.72 * t);\n      slope = -exitRadius * 0.72 / span;\n    } else if (uNormalMode > 1.5) {\n      // Rounded authored taper approximates the geometry's curved nose.\n      // Slope faces toward the nose; image y/light y retain existing convention.\n      // Component envelope also handles the booster dome; never apply the\n      // Ship's nose station/length to a differently placed curved surface.\n      float span = max(0.001, uBounds.w - uBounds.y);\n      float t = clamp((vPoint.y - uBounds.y) / span, 0.0, 0.998);\n      float base = max(0.001, 1.0 - t * t);\n      radius *= pow(base, 0.6);\n      slope = -uRadius * 1.2 * t * pow(base, -0.4) / span;\n    }\n    float sideways = clamp((vPoint.x - axisX) / max(radius, 0.001), -0.999, 0.999);\n    n = normalize(vec3(sideways, slope, sqrt(max(0.0, 1.0 - sideways * sideways))));\n    if (uNormalMode < 1.5 && uMaterial < 0.5) {\n      // Rolled steel around circumferential welds is not an optically perfect\n      // cylinder. This small authored normal variation bends the same sky/ground\n      // reflection into axial bands; it does not paint light onto the albedo.\n      // Its amplitude/spacing are visual approximations, not measured B19 data.\n      float period = uHeight / 20.0;\n      float weldResolved = smoothstep(2.0, 5.0, period * uPixelsPerMetre) * uDetail;\n      n = normalize(n + vec3(0.0, 0.012 * sin(vPoint.y / period * 6.2831853) * weldResolved, 0.0));\n    }\n  }\n  vec3 l = normalize(vec3(uLight.x, -uLight.y, uLight.z));\n  vec3 halfLight = normalize(l + vec3(0.0, 0.0, 1.0));\n  float diffuse = max(0.0, dot(n, l));\n  float night = 0.14 + 0.86 * uDaylight;\n  float nh = max(0.0, dot(n, halfLight));\n  float grazing = pow(1.0 - max(0.0, n.z), 5.0);\n  float lh = max(0.0, halfLight.z);\n  // Broad sky/ground illumination exists even when the high sun cannot reflect\n  // directly into this orthographic camera. Its world-up direction rotates\n  // with the vehicle/piece; the brighter sky opening follows solar azimuth.\n  // These neutral finite lobes are authored environment compression, not a\n  // factory panorama or measured V3 optical constants.\n  vec3 reflectedView = reflect(vec3(0.0, 0.0, -1.0), n);\n  vec3 horizonLight = l - uEnvironmentUp * dot(l, uEnvironmentUp);\n  horizonLight /= max(length(horizonLight), 0.001);\n  float opening = pow(max(0.0, dot(reflectedView, horizonLight)), 4.0);\n  float skyShare = smoothstep(-0.25, 0.35, dot(reflectedView, uEnvironmentUp) + 0.16 * max(0.0, n.z));\n  vec3 environment = mix(vec3(0.18, 0.17, 0.15), vec3(0.78, 0.84, 0.90) * uSkyTone, skyShare)\n    * (0.50 + 1.25 * opening);\n  // S39 resolves many tens of cells across the barrel. Original visual pitch\n  // estimates (not measured tile dimensions) stay in metres and filter away;\n  // grid lattice has its own denser pitch rather than sharing TPS cell size.\n  float cell = uRadius * (uMaterial > 1.5 ? 0.035 : 0.04);\n  float resolved = smoothstep(2.0, 5.0, cell * uPixelsPerMetre) * uDetail;\n  vec3 albedo = vec3(0.52, 0.55, 0.58);\n  float f0 = 0.64;\n  float diffuseWeight = 0.14;\n  float broadLobe = 0.25 * pow(nh, 12.0);\n  float narrowLobe = 0.50 * pow(nh, 64.0);\n  float environmentWeight = 1.0;\n  float surfaceReflection = 1.0;\n  float alpha = 1.0;\n  if (uMaterial > 0.5 && uMaterial < 1.5) {\n    albedo = vec3(0.11, 0.12, 0.13);\n    // Coated dark ceramic remains dark between broad achromatic highlights.\n    // The coating assumption is visual, not a claim about proprietary TPS IOR.\n    f0 = 0.055;\n    diffuseWeight = 1.0;\n    broadLobe = 2.2 * pow(nh, 14.0);\n    narrowLobe = 2.0 * pow(nh, 48.0);\n    environmentWeight = 0.45;\n    // Original analytic hex-cell field, not one object per tile. Fade before\n    // the actual cell pitch becomes unresolved; preserve a dark area mean.\n    vec2 pitch = vec2(cell * 1.7320508, cell * 3.0);\n    vec2 a = mod(vPoint, pitch) - pitch * 0.5;\n    vec2 b = mod(vPoint - pitch * 0.5, pitch) - pitch * 0.5;\n    vec2 q = dot(a, a) < dot(b, b) ? a : b;\n    float edge = max(abs(q.x), abs(q.x) * 0.5 + abs(q.y) * 0.8660254);\n    float aa = max(1.41421356 / max(uPixelsPerMetre, 0.001), 0.001);\n    float seam = clamp((edge - cell * 0.84) / aa + 0.5, 0.0, 1.0);\n    resolved = smoothstep(2.0, 5.0, cell * 1.7320508 * uPixelsPerMetre) * uDetail;\n    albedo *= 1.0 - seam * resolved * 0.38;\n    surfaceReflection = 1.0 - seam * resolved * 0.35;\n  } else if (uMaterial > 1.5) {\n    // Resolve actual openings only when they cover several pixels. At small\n    // scales the lattice becomes its area-average dark metal, not enlarged bars.\n    vec2 uv = (vPoint - uBounds.xy) / max(uBounds.zw - uBounds.xy, vec2(0.001));\n    float frame = 1.0 - smoothstep(0.045, 0.075, min(min(uv.x, 1.0 - uv.x), min(uv.y, 1.0 - uv.y)));\n    float bars = max(line(vPoint.x, cell * 2.0, cell * 0.11), line(vPoint.y, cell * 2.0, cell * 0.11));\n    resolved = smoothstep(2.0, 5.0, cell * 2.0 * uPixelsPerMetre) * uDetail;\n    // Unresolved holes retain authored area coverage instead of becoming an\n    // opaque grey plate: ~0.21 lattice coverage plus the perimeter frame.\n    alpha = mix(0.36, max(frame, bars), resolved);\n    albedo *= mix(0.48, 0.85, resolved);\n    f0 = 0.26;\n    diffuseWeight = 0.70;\n    broadLobe *= 0.50;\n    narrowLobe *= 0.30;\n    environmentWeight = 0.35;\n  } else {\n    float weld = line(vPoint.y, uHeight / 20.0, uRadius * 0.007);\n    float weldLOD = smoothstep(2.0, 5.0, uHeight / 20.0 * uPixelsPerMetre) * uDetail;\n    albedo *= 1.0 - weld * weldLOD * 0.10;\n    surfaceReflection = 1.0 - weld * weldLOD * 0.35;\n  }\n  float directFresnel = f0 + (1.0 - f0) * pow(1.0 - lh, 5.0);\n  float viewFresnel = f0 + (1.0 - f0) * grazing;\n  vec3 reflection = vec3(directFresnel * (broadLobe + narrowLobe) * diffuse * uDaylight)\n    + viewFresnel * environment * environmentWeight * night;\n  vec3 rgb = albedo * (0.42 + 0.68 * diffuse) * diffuseWeight * night + reflection * surfaceReflection;\n  rgb += vec3(0.85, 0.16, 0.025) * uGlow;\n  // Premultiplied colour: lattice holes and parent fading keep coverage.\n  finalColor = vec4(clamp(rgb, 0.0, 1.0) * alpha, alpha) * vColor;\n}\n", Lg;
function Rg(e, t, n, r = [
	0,
	0,
	1
]) {
	Lg ??= k.from({
		vertex: Fg,
		fragment: Ig,
		name: "v3-component-material"
	});
	let i = Infinity, a = Infinity, o = -Infinity, s = -Infinity;
	for (let t of e.points) i = Math.min(i, t.x), o = Math.max(o, t.x), a = Math.min(a, t.station), s = Math.max(s, t.station);
	let c = new te({
		glProgram: Lg,
		resources: { componentUniforms: {
			uLight: {
				value: new Float32Array([
					.6,
					.7,
					.3
				]),
				type: "vec3<f32>"
			},
			uFlatNormal: {
				value: new Float32Array(r),
				type: "vec3<f32>"
			},
			uEnvironmentUp: {
				value: new Float32Array([
					0,
					-1,
					0
				]),
				type: "vec3<f32>"
			},
			uSkyTone: {
				value: new Float32Array([
					1,
					1,
					1
				]),
				type: "vec3<f32>"
			},
			uBounds: {
				value: new Float32Array([
					i,
					a,
					o,
					s
				]),
				type: "vec4<f32>"
			},
			uDaylight: {
				value: 1,
				type: "f32"
			},
			uGlow: {
				value: 0,
				type: "f32"
			},
			uPixelsPerMetre: {
				value: 1,
				type: "f32"
			},
			uDetail: {
				value: 1,
				type: "f32"
			},
			uRadius: {
				value: n / 2,
				type: "f32"
			},
			uHeight: {
				value: t,
				type: "f32"
			},
			uNormalMode: {
				value: e.normalMode === "flat" ? 0 : e.normalMode === "cylinder" ? 1 : e.normalMode === "nose" ? 2 : e.normalMode === "nozzle" ? 3 : 4,
				type: "f32"
			},
			uMaterial: {
				value: {
					steel: 0,
					tile: 1,
					grid: 2
				}[e.material],
				type: "f32"
			}
		} }
	}), l = c.resources.componentUniforms.uniforms;
	return {
		shader: c,
		uniforms: l,
		setLight(e, t, n, r) {
			l.uLight[0] = e, l.uLight[1] = t, l.uLight[2] = n, l.uDaylight = Math.max(0, Math.min(1, r));
		},
		setTemperature(e) {
			l.uGlow = Pg(e);
		},
		setEnvironment(e, t, n, r) {
			l.uEnvironmentUp[0] = -Math.sin(e), l.uEnvironmentUp[1] = -Math.cos(e), l.uSkyTone[0] = t, l.uSkyTone[1] = n, l.uSkyTone[2] = r;
		},
		setScale(e, t) {
			l.uPixelsPerMetre = Math.max(0, e), l.uDetail = +!!t;
		},
		destroy() {
			c.destroy();
		}
	};
}
//#endregion
//#region src/view/component-vehicle.ts
function zg(e) {
	let t = new r({ label: e.id === "ship" ? "starship" : "super-heavy" });
	if (e.components.length > 12) throw RangeError("Component rendering supports at most twelve debris slots");
	let n = new r({ label: `${e.id}-debris` }), i = /* @__PURE__ */ new Map(), a = [], o = /* @__PURE__ */ new Map();
	for (let s of e.components) {
		let c = new r({ label: s.id });
		c.position.set(s.x, e.height / 2 - s.station);
		let l = [], u = [], d = s.kind === "grid-fin" ? [
			s.x / (e.diameter / 2),
			0,
			Math.max(.1, Math.abs(s.depth) / (e.diameter / 2))
		] : [
			0,
			0,
			1
		], f = [...s.polygons].sort((e, t) => e.depth - t.depth);
		for (let t of f) {
			let n = [], r = [];
			for (let e of t.points) n.push(e.x - s.x, s.station - e.station), r.push(e.x, e.station);
			let i = new Ci({
				positions: new Float32Array(n),
				uvs: new Float32Array(r),
				indices: new Uint32Array(Xt(n, void 0, 2))
			}), a = s.kind === "hot-stage" && t.normalMode === "flat" ? [
				(Math.min(...t.points.map((e) => e.x)) + Math.max(...t.points.map((e) => e.x))) / e.diameter,
				0,
				Math.max(.1, t.depth / (e.diameter / 2))
			] : d, o = Rg(t, e.height, e.diameter, a), f = new Di({
				geometry: i,
				shader: o.shader,
				label: t.id
			});
			t.surfaceRole === "bell-mouth" ? f.tint = 2568249 : t.surfaceRole === "bell-shell" ? f.tint = 13357268 : t.surfaceRole === "bell-lip" && (f.tint = 14146784), c.addChild(f), l.push(f), u.push(o);
		}
		let p = Object.freeze({
			component: s,
			container: c,
			meshes: Object.freeze(l),
			materials: Object.freeze(u)
		}), m = new r({ label: `${s.id}-debris-pose` });
		m.visible = !1, n.addChild(m);
		let h = {
			part: p,
			slot: m,
			detached: !1,
			attachedVisible: !0,
			attachedRotation: 0,
			gridAngle: NaN,
			altitude: 0,
			downRangeDistance: 0,
			pitch: 0,
			offsetX: 0,
			offsetY: 0
		};
		i.set(s.id, p), a.push(h), o.set(s.id, h), t.addChild(c);
	}
	let s = {
		x: .6,
		y: .7,
		z: .3
	}, c, l = 0, u = 1, d = !0, f = 0, p = 0, m = 0, h = 0, g = 0, _ = 0, v = !1, y = {
		x: .6,
		y: .7,
		z: .3
	};
	function b(t, n) {
		if (t.gridAngle === n) return;
		t.gridAngle = n;
		let { part: r } = t, i = r.component, a = i.x / (e.diameter / 2), o = i.depth / (e.diameter / 2), s = Math.sin(n), c = Math.cos(n);
		for (let t = 0; t < r.meshes.length; t++) {
			let n = r.meshes[t], l = n.label.endsWith("-face"), u = n.label.endsWith("-edge");
			if (!l && !u) continue;
			let d = n.geometry.positions, f = n.geometry.uvs;
			for (let t = 0; t < d.length; t += 2) {
				let n = l ? f[t + 1] - i.station : -e.diameter * .18;
				d[t] = f[t] - i.x + n * o * c, d[t + 1] = -n * s - (u ? f[t + 1] - i.station - n : 0);
			}
			if (n.geometry.getBuffer("aPosition").update(), l) {
				let e = r.materials[t].uniforms.uFlatNormal, n = a * s < 0 ? -1 : 1;
				e[0] = -o * s * n, e[1] = -c * n, e[2] = a * s * n;
			}
		}
	}
	for (let e of a) e.part.component.kind === "grid-fin" && b(e, 0);
	function x(t) {
		let { part: n } = t;
		for (let r = 0; r < n.materials.length; r++) {
			let i = n.meshes[r].label.endsWith("-face") && n.component.kind === "grid-fin" ? Math.max(.001, Math.abs(Math.sin(t.gridAngle))) / (1 + Math.abs(n.component.depth / (e.diameter / 2) * Math.cos(t.gridAngle))) : 1;
			n.materials[r].setScale(u * Math.abs(n.container.scale.x) * i, d);
		}
	}
	function S(e) {
		let { part: t } = e, n = e.detached ? y : s;
		e.detached && c && Am(c, e.pitch, y);
		let r = t.container.rotation, i = Math.cos(r), a = Math.sin(r), o = i * n.x - a * n.y, u = a * n.x + i * n.y;
		for (let i of t.materials) i.setLight(o, u, n.z, c?.daylight ?? 1), i.setEnvironment((e.detached ? e.pitch : l) + r, c?.skyR ?? 1, c?.skyG ?? 1, c?.skyB ?? 1);
	}
	function C(e) {
		let t = Math.cos(e.pitch), n = Math.sin(e.pitch);
		e.slot.position.set(f / 2 + (e.downRangeDistance - m - g - t * e.offsetX + n * e.offsetY) * u, p / 2 - (e.altitude - h - _) * u - (n * e.offsetX + t * e.offsetY) * u), e.slot.rotation = e.pitch, e.slot.scale.set(u);
	}
	function w(n) {
		let r = n.part;
		n.detached = !1, n.slot.visible = !1;
		let i, o = a.indexOf(n);
		for (let e = o + 1; e < a.length; e++) {
			let n = a[e].part.container;
			if (n.parent === t) {
				i = n;
				break;
			}
		}
		if (i) t.addChildAt(r.container, t.getChildIndex(i));
		else {
			let e = 0;
			for (let n = 0; n < o; n++) {
				let r = a[n].part.container;
				r.parent === t && (e = t.getChildIndex(r) + 1);
			}
			t.addChildAt(r.container, e);
		}
		r.container.position.set(r.component.x, e.height / 2 - r.component.station), r.container.rotation = n.attachedRotation, r.container.visible = n.attachedVisible;
	}
	return {
		container: t,
		debrisContainer: n,
		partsById: i,
		updatePose(e, n, r, i) {
			t.position.set(n.width / 2 + (r.downRangeDistance - e.posX - e.shakeX) * n.scale, n.height / 2 - (r.altitude - e.posY - e.shakeY) * n.scale), t.rotation = r.pitch, t.scale.set(n.scale), l = r.pitch, u = n.scale, c = i, f = n.width, p = n.height, m = e.posX, h = e.posY, g = e.shakeX, _ = e.shakeY, i && Am(i, l, s);
			for (let e of a) e.detached && C(e), S(e), x(e);
		},
		setComponentState(e, t, n) {
			let r = o.get(e);
			if (!r) return;
			let { part: i } = r;
			r.attachedVisible = t, i.container.visible = r.detached || t;
			for (let e of i.materials) e.setTemperature(n);
		},
		setArticulation(e, t, n = 1) {
			let r = o.get(e);
			if (!r || r.detached) return;
			let { part: i } = r, a = Number.isFinite(t) ? t : 0;
			i.component.kind === "grid-fin" ? (b(r, a), i.container.rotation = 0, i.container.scale.x = 1) : (i.container.rotation = a, i.container.scale.x = Number.isFinite(n) ? Math.max(0, Math.min(1, n)) : 1), r.attachedRotation = i.container.rotation, S(r), x(r);
		},
		setDetachedPose(e, t) {
			let n = o.get(e);
			if (n) {
				if (!t) {
					n.detached && w(n), S(n);
					return;
				}
				if (!Number.isFinite(t.altitude) || !Number.isFinite(t.downRangeDistance) || !Number.isFinite(t.pitch) || !Number.isFinite(t.pivotToCentroidX) || !Number.isFinite(t.pivotToCentroidY)) throw RangeError("Detached rendering requires finite physical pose and centroid offset");
				n.altitude = t.altitude, n.downRangeDistance = t.downRangeDistance, n.pitch = t.pitch, n.offsetX = t.pivotToCentroidX, n.offsetY = t.pivotToCentroidY, n.detached ||= (n.attachedRotation = n.part.container.rotation, n.slot.addChild(n.part.container), n.part.container.position.set(0, 0), n.part.container.rotation = 0, !0), n.slot.visible = !0, n.part.container.visible = !0, C(n), S(n);
			}
		},
		reset() {
			for (let e of a) {
				e.detached && w(e), e.attachedVisible = !0, e.attachedRotation = 0, e.part.container.visible = !0, e.part.container.rotation = 0, e.part.container.scale.set(1), e.part.component.kind === "grid-fin" && b(e, 0);
				for (let t of e.part.materials) t.setTemperature(293.15);
				S(e);
			}
		},
		setDetail(e) {
			d = e;
			for (let e of a) x(e);
		},
		destroy() {
			if (!v) {
				v = !0;
				for (let { part: e } of a) {
					for (let t of e.meshes) t.geometry.destroy(!0);
					for (let t of e.materials) t.destroy();
				}
				t.destroy({ children: !0 }), n.destroy({ children: !0 });
			}
		}
	};
}
//#endregion
//#region src/view/vehicle.ts
var Bg = q.diameter * 1.92;
function Vg(e, t) {
	let n = X(e).partition.components.map((e, n) => {
		let r = t.partsById.get(e.id);
		if (!r) throw Error(`Missing original vehicle component: ${e.id}`);
		return {
			physical: e,
			index: n,
			part: r
		};
	}), r = {
		altitude: 0,
		downRangeDistance: 0,
		pitch: 0,
		pivotToCentroidX: 0,
		pivotToCentroidY: 0
	};
	return (e, i) => {
		for (let { physical: a, index: o, part: s } of n) {
			let n = e.components[o], c = e.debris[o];
			if (c.active || t.setDetachedPose(a.id, null), a.kind === "flap") {
				let e = .04 + .96 * Math.sin(Math.max(0, Math.min(Qc, n.loadedAngle))) / Math.sin(Qc);
				t.setArticulation(a.id, 0, e);
			} else a.kind === "grid-fin" && t.setArticulation(a.id, n.loadedAngle);
			if (t.setComponentState(a.id, n.attached && !e.terminal.active, i), a.kind === "hull") for (let t = 0; t < s.materials.length; t++) s.component.polygons[t].material === "steel" && s.materials[t].setTemperature(e.hull.temperature);
			if (!c.active) continue;
			let l = a.x - s.component.x, u = s.component.station - a.station;
			r.altitude = c.altitude, r.downRangeDistance = c.x, r.pitch = c.pitch, r.pivotToCentroidX = l, r.pivotToCentroidY = u, t.setDetachedPose(a.id, r);
		}
	};
}
function Hg() {
	let e = Ng({
		id: "ship",
		height: q.height,
		diameter: q.diameter,
		frontFinStation: q.frontFinStation,
		aftFinStation: q.aftFinStation,
		engines: q.engines
	}), t = zg(e), n = Vg(q, t);
	return {
		container: t.container,
		components: t,
		update(r, i, a, o) {
			if (t.updatePose(r, i, a, o), a.damage) {
				n(a.damage, a.surfaceTemperature ?? 293.15);
				return;
			}
			for (let n of e.components) {
				let e = t.partsById.get(n.id);
				if (t.setComponentState(n.id, e.container.visible, a.surfaceTemperature ?? 293.15), n.kind !== "flap") continue;
				let r = n.id.includes("-front-") ? a.frontFinExtension : a.aftFinExtension, i = .04 + .96 * Math.max(0, Math.min(100, r)) / 100;
				t.setArticulation(n.id, 0, i);
			}
		},
		destroy() {
			t.destroy();
		}
	};
}
//#endregion
//#region src/view/booster.ts
function Ug() {
	let e = Ng({
		id: "super-heavy",
		height: J.height,
		diameter: J.diameter,
		gridFinStation: J.gridFins.station,
		engines: J.engines
	}), t = zg(e), n = Vg(J, t);
	return {
		container: t.container,
		components: t,
		update(r, i, a, o) {
			if (t.updatePose(r, i, a, o), a.damage) {
				n(a.damage, a.surfaceTemperature ?? 293.15);
				return;
			}
			let s = Math.max(-1, Math.min(1, (a.frontFinExtension - 50) / 50)) * J.gridFins.maxAngle;
			for (let n of e.components) {
				let e = t.partsById.get(n.id);
				t.setComponentState(n.id, e.container.visible, a.surfaceTemperature ?? 293.15), n.kind === "grid-fin" && t.setArticulation(n.id, s);
			}
		},
		destroy() {
			t.destroy();
		}
	};
}
//#endregion
//#region src/view/reentry.ts
var Wg = q.diameter, Gg = q.height;
function Kg(e, t) {
	t.x = -Math.sin(e), t.y = Math.cos(e);
}
var qg = .1, Jg = .06;
function Yg(e, t) {
	return t ? e > Jg : e > qg;
}
var Xg = .16;
function Zg(e) {
	let t = Math.min(220, Math.max(100, e / 4));
	return e / 2 - t / 2;
}
function Qg(e, t) {
	let n = Math.min(150, Math.max(72, e.width * Xg)), r = Zg(e.height) - 8 - 60;
	t.size = Math.round(Math.max(72, Math.min(n, r))), t.x = Math.round((e.width - t.size) / 2), t.y = 60;
}
var $g = 1.7, e_ = 2.2, t_ = .28, n_ = "\nin vec2 aPosition;\nin vec2 aUV;\nout vec2 vUV;\n\nuniform mat3 uProjectionMatrix;\nuniform mat3 uWorldTransformMatrix;\nuniform mat3 uTransformMatrix;\n\nvoid main(void) {\n  mat3 mvp = uProjectionMatrix * uWorldTransformMatrix * uTransformMatrix;\n  gl_Position = vec4((mvp * vec3(aPosition, 1.0)).xy, 0.0, 1.0);\n  vUV = aUV;\n}\n", r_ = `
in vec2 vUV;
out vec4 finalColor;

uniform float uStrength;
uniform float uSurfaceGlow;
uniform vec2 uWind;
uniform float uAspect;
uniform float uTime;

// Distance from a point to a segment on the y axis from -L to +L.
float capsule(vec2 p, float L, float r) {
  float y = clamp(p.y, -L, L);
  return length(vec2(p.x, p.y - y)) - r;
}

void main(void) {
  // Hull-height units, centred, y down (image space).
  vec2 p = (vUV - 0.5) * ${e_.toFixed(2)};
  float r = uAspect * 0.5;
  float d = capsule(p, 0.5 - r, r);
  float reach = ${t_.toFixed(2)} * (0.55 + 0.45 * uStrength);
  float t = clamp(d / reach, 0.0, 1.0);
  float shell = (1.0 - t) * (1.0 - t);
  // Windward: the direction from the hull's axis to this point, against the
  // air's direction. The leeward side gets nothing; the flanks a little.
  vec2 fromAxis = normalize(vec2(p.x, p.y - clamp(p.y, -(0.5 - r), 0.5 - r)) + vec2(1e-5, 0.0));
  float facing = smoothstep(-0.25, 0.7, dot(fromAxis, uWind));
  // A little turbulence along the shell, so it is a fire and not a halo.
  float flicker = 0.85 + 0.15 * sin(p.y * 40.0 + uTime * 23.0) * sin(p.x * 31.0 - uTime * 17.0);
  // The strength is the HEAT readout's fraction of amber (0.8 of the limit);
  // a third of the way there is already a bright shell, because that is what
  // a third of a fatal heat flux looks like, and a glow the eye reads as a
  // tint is not a re-entry. Saturates at one.
  float glow = min(1.0, shell * facing * (0.35 + 1.15 * uStrength) * flicker);
  // Orange-white against the skin, red at the edge: ionised air, not a lamp.
  // The first ramp was near-white at the skin, and additive white over a
  // grey hull is grey — the harness saw a tint where a fire was claimed.
  vec3 near = vec3(1.0, 0.72, 0.42);
  vec3 far = vec3(1.0, 0.22, 0.04);
  vec3 colour = mix(near, far, sqrt(t));
  // The sheath is drawn OVER the hull, additively. Inside the silhouette the
  // shell is 1, and a quarter remains as overlapping plasma light on the
  // windward hull. Skin emission below has its own temperature authority.
  float inside = d < 0.0 ? 0.25 : 1.0;
  // Plasma remains flux-driven. Independent equilibrium-temperature emission
  // is confined to windward skin, with no atmosphere glow or invented inertia.
  float plasma = uStrength > 0.001 ? glow * inside : 0.0;
  float skin = (1.0 - smoothstep(-0.006, 0.0, d)) * facing * uSurfaceGlow * 0.55;
  vec3 emission = colour * plasma + vec3(1.0, 0.18, 0.035) * skin;
  finalColor = vec4(emission, min(1.0, plasma + skin));
}
`, i_;
function a_() {
	i_ ??= k.from({
		vertex: n_,
		fragment: r_,
		name: "plasma-sheath"
	});
	let e = new te({
		glProgram: i_,
		resources: { sheathUniforms: {
			uStrength: {
				value: 0,
				type: "f32"
			},
			uSurfaceGlow: {
				value: 0,
				type: "f32"
			},
			uWind: {
				value: new Float32Array([0, -1]),
				type: "vec2<f32>"
			},
			uAspect: {
				value: Wg / Gg,
				type: "f32"
			},
			uTime: {
				value: 0,
				type: "f32"
			}
		} }
	}), t = e.resources.sheathUniforms, n = new Di({
		geometry: new Ci({
			positions: new Float32Array([
				-.5,
				-.5,
				.5,
				-.5,
				.5,
				.5,
				-.5,
				.5
			]),
			uvs: new Float32Array([
				0,
				0,
				1,
				0,
				1,
				1,
				0,
				1
			]),
			indices: new Uint32Array([
				0,
				1,
				2,
				0,
				2,
				3
			])
		}),
		shader: e
	});
	return n.label = "plasma-sheath", n.blendMode = "add", n.visible = !1, {
		mesh: n,
		place(e) {
			n.scale.set(e * e_, e * e_);
		},
		set(e, r, i, a, o = 0) {
			n.visible = e > .001 || o > 0, t.uniforms.uStrength = e, t.uniforms.uSurfaceGlow = o, t.uniforms.uWind[0] = r, t.uniforms.uWind[1] = -i, t.uniforms.uTime = a;
		},
		destroy() {
			n.destroy(), e.destroy();
		}
	};
}
function o_() {
	let e = new r({ label: "onboard-inset" });
	e.visible = !1;
	let t = new V(), n = new V(), i = new V(), a = Hg(), o = a_(), s = new r({ label: "onboard-scene" });
	s.addChild(a.container), a.container.addChild(o.mesh), s.mask = n, e.addChild(t, s, n, i);
	let c = {
		x: 0,
		y: 0,
		size: 0
	}, l = {
		x: 0,
		y: 1
	}, u = !1, d = -1, f = {
		posX: 0,
		posY: 0,
		speedX: 0,
		speedY: 0,
		accX: 0,
		accY: 0,
		sticky: !0,
		shakeX: 0,
		shakeY: 0,
		shakeTime: 0,
		padHeld: !1
	}, p = {
		width: 1,
		height: 1,
		physicalHeight: 1,
		physicalWidth: 1,
		scale: 1
	};
	return {
		container: e,
		get shown() {
			return u;
		},
		update(r, s, m, h, g, _ = 0) {
			u = Yg(m, u), e.visible = u, u && (Qg(r, c), e.x = c.x, e.y = c.y, d !== c.size && (d = c.size, t.clear(), t.rect(0, 0, c.size, c.size), t.fill(16777215), n.clear(), n.rect(0, 0, c.size, c.size), n.fill(16777215), i.clear(), i.rect(.5, .5, c.size - 1, c.size - 1), i.stroke({
				color: 16777215,
				alpha: .25,
				width: 1
			}), p.width = c.size, p.height = c.size, p.scale = c.size / (Gg * $g), p.physicalHeight = c.size / p.scale, p.physicalWidth = p.physicalHeight), t.tint = h ? qm(s.altitude, h.skyR, h.skyG, h.skyB) : qm(s.altitude, 1, 1, 1), f.posX = s.downRangeDistance, f.posY = s.altitude, a.update(f, p, s, h), Kg(s.angleOfAttack, l), o.place(Gg * p.scale), o.set(m, l.x, l.y, g, _));
		},
		destroy() {
			o.destroy(), a.destroy(), e.destroy({ children: !0 });
		}
	};
}
//#endregion
//#region src/view/engine-look.ts
function s_(e, t, n, r) {
	let i = Number.isFinite(e) ? Math.max(0, e) : Zp, a = Number.isFinite(t) ? Math.max(0, Math.min(1, t / 100)) : 0, o = n ? Yc : em, s = n ? Math.sqrt(o / em) : 1;
	r.spread = Qp(i) * (n ? 1.2 : 1), r.scale = a > 0 ? $p(i) * s * (.5 + .5 * a) : 0, r.diamonds = a > 0 ? am(i) * (n ? .35 : 1) : 0, r.cellLength = rm(i, o) * (n ? o / em : 1);
}
var c_ = .55, l_ = .45, u_ = .5;
function d_(e = q, t = e.height / 2) {
	let n = {
		x: 0,
		y: 0
	}, r = e.engines.map(() => ({
		spread: 0,
		scale: 0,
		diamonds: 0,
		cellLength: 0
	})), i = !1, a = !1, o = 0, s = 0, c = 0, l = 0, u = 0;
	return {
		nozzle: n,
		reset() {
			i = !1, a = !1, o = 0;
		},
		update(d, f, p, m, h, g) {
			let { kinematics: _, forces: v, engines: y, vehicle: b, failures: x, status: S } = m, C = p.scale, w = p.width / 2 - (f.posX + f.shakeX) * C, T = p.height / 2 + (f.posY + f.shakeY) * C, E = o > 0, D = w + _.downRangeDistance * C, O = T - _.altitude * C, k = _.pitch, A = k + Math.PI / 2, j = t * C, M = D + Math.cos(A) * j, N = O + Math.sin(A) * j;
			n.x = M, n.y = N;
			let ee = E ? M - (w + l * C) : 0, P = E ? N - (T - u * C) : 0;
			if (E) {
				let e = C / o;
				d.reproject(e, w - s * e, T - c * e, ee, P);
			}
			o = C, s = w, c = T, l = _.downRangeDistance + Math.cos(A) * t, u = _.altitude - Math.sin(A) * t;
			let F = 0;
			for (let e = 0; e < y.running.length; e++) y.running[e] && !y.failed[e] && F++;
			if (F > 0 && v.thrust > 0) {
				let t = b.throttleCurrent / 100, n = m.atmosphere.airPressure, i = l_ + .55 * (F / (e.id === "ship" ? 3 : e.ignitionGroup.length) * t);
				for (let t = 0; t < e.engines.length; t++) {
					if (!y.running[t] || y.failed[t]) continue;
					let a = e.engines[t], o = r[t];
					s_(n, b.throttleCurrent, a.kind === "vacuum", o);
					let s = M + Math.cos(k) * a.offAxis * C, c = N + Math.sin(k) * a.offAxis * C, l = (a.gimballed ?? a.kind === "sea-level" ? b.gimbalPointingDirection : k) + Math.PI / 2;
					d.emit("raptorPlumeCore", s, c, l, i / F, g, C * .9 * o.scale, 1 + (o.spread - 1) * .55, o.cellLength * C, o.diamonds * c_, t + 1), d.emit("raptorPlume", s, c, l, i / F, g, C * .9 * o.scale, o.spread, 0, 0, t + 1);
				}
			}
			for (let e = 0; e < y.running.length; e++) h.engines.running[e] && !y.running[e] && d.burst("raptorShutdown", M, N, 30, C * .8);
			if (v.dynamicPressure > .2) {
				let t = Math.min(Math.sqrt(v.dynamicPressure / 50), 1), n = D - Math.cos(A) * (e.id === "ship" ? e.height * .25 : e.gridFins.station - e.height / 2) * C, r = O - Math.sin(A) * (e.id === "ship" ? e.height * .25 : e.gridFins.station - e.height / 2) * C;
				d.emit("aeroTrail", n, r, A, t, g, C * .7);
			}
			if (v.thrust > 0 && _.altitude < 200 && k > -Math.PI * .15 && k < Math.PI * .15) {
				let e = 1 - _.altitude / 200, t = ql(f, p, _.downRangeDistance, 0);
				d.emit("groundSmoke", t.x, t.y, -Math.PI / 2, e, g, C);
			}
			if (_.machSpeed > .9 && _.machSpeed < 1.3 && v.dynamicPressure > 1) {
				let e = 1 - Math.abs(_.machSpeed - 1.1) / .2;
				d.emit("sonicBoom", D, O, A + Math.PI, Math.max(e, 0), g, C);
			}
			if (v.thermalPower > 1) {
				let t = Math.min(v.thermalPower / 20, 1), n = D - Math.cos(A) * e.height * .5 * C, r = O - Math.sin(A) * e.height * .5 * C;
				d.emit("aeroHeat", n, r, A + Math.PI, t, g, C * .8);
			}
			let te = om(v.thermalPower, cl);
			if (te > 0) {
				let t = D - Math.cos(A) * e.height * .5 * C, n = O - Math.sin(A) * e.height * .5 * C;
				d.emit("plasmaTrail", t, n, A, te, g, C * .9);
			}
			let ne = Jh(_.trueSpeed);
			if (ne > .01) {
				let e = _.speedX, t = -_.speedY, n = Math.hypot(e, t);
				if (n > 1e-6) {
					let r = p.height * .75, i = Math.atan2(-t, -e);
					d.emit("velocityStreak", D + e / n * r, O + t / n * r, i, ne, g, Yh(ne, p.height) / (ah.velocityStreak.startSize * 9));
				}
			}
			x.crashed && !i && (d.burst("explosion", D, O, 600, C), i = !0), x.inFlightBreakUp && !a && (d.burst("explosion", D, O, 800, C), a = !0), !x.crashed && !x.inFlightBreakUp && (i || a) && (i = !1, a = !1), d.update(g);
		}
	};
}
var f_ = 5;
function p_(e, t, n, r, i, a) {
	let o = ah.raptorPlume, s = .9 * n * i, c = o.spread * r;
	for (let n = 0; n < 32; n++) {
		let r = Math.min(n / 31, Math.max(0, a) / o.life, 1), i = o.speed / o.drag * (1 - Math.exp(-o.drag * r * o.life)) * s, l = i * Math.sin(c), u = l + (o.startSize + (o.endSize - o.startSize) * r) * s / 2, d = i * Math.cos(c);
		for (let i = 0; i < f_; i++) {
			let a = (n * f_ + i) * 2, o = i === 0 ? -u : i === 1 ? -l : i === 2 ? 0 : i === 3 ? l : u;
			e[a] = o, e[a + 1] = d, t[a] = u > 0 ? .5 + o / (2 * u) : .5, t[a + 1] = r;
		}
	}
}
function m_() {
	let e = /* @__PURE__ */ new Uint8Array(16640), t = ah.raptorPlume;
	for (let n = 0; n < 64; n++) {
		let r = n / 63, i = Gp(t.startColor, t.endColor, r);
		for (let a = 0; a < 65; a++) {
			let o = (n * 65 + a) * 4, s = (t.startAlpha + (t.endAlpha - t.startAlpha) * r) * rh(Math.abs(2 * a / 64 - 1));
			e[o] = Math.round((i >> 16 & 255) * s), e[o + 1] = Math.round((i >> 8 & 255) * s), e[o + 2] = Math.round((i & 255) * s), e[o + 3] = Math.round(255 * s);
		}
	}
	return new p({ source: new f({
		resource: e,
		width: 65,
		height: 64,
		format: "rgba8unorm",
		alphaMode: "premultiplied-alpha",
		scaleMode: "linear"
	}) });
}
function h_(e = q) {
	let t = new r(), n = m_(), i = new Float64Array(e.engines.length), a = e.engines.map(() => ({
		spread: 0,
		scale: 0,
		diamonds: 0,
		cellLength: 0
	})), o = e.engines.map(() => {
		let e = /* @__PURE__ */ new Uint32Array(744), r = 0;
		for (let t = 0; t < 31; t++) for (let n = 0; n < 4; n++) {
			let i = t * f_ + n;
			e[r++] = i, e[r++] = i + 1, e[r++] = i + f_, e[r++] = i + 1, e[r++] = i + f_ + 1, e[r++] = i + f_;
		}
		let i = new Di({
			geometry: new Ci({
				positions: /* @__PURE__ */ new Float32Array(320),
				uvs: /* @__PURE__ */ new Float32Array(320),
				indices: e
			}),
			texture: n
		});
		return i.blendMode = "add", i.visible = !1, t.addChild(i), i;
	});
	return {
		container: t,
		update(t, n, r, s, c) {
			let l = t.kinematics.pitch;
			for (let u = 0; u < o.length; u++) {
				let d = o[u];
				if (d.visible = !!t.engines.running[u] && !t.engines.failed[u] && t.forces.thrust > 0, !d.visible) {
					i[u] = 0;
					continue;
				}
				i[u] = Math.min(ah.raptorPlume.life, i[u] + Math.max(0, c));
				let f = e.engines[u], p = a[u];
				s_(t.atmosphere.airPressure, t.vehicle.throttleCurrent, f.kind === "vacuum", p), p.scale === 0 && (s_(t.atmosphere.airPressure, 100, f.kind === "vacuum", p), p.scale *= u_), p_(d.geometry.positions, d.geometry.uvs, p.scale, p.spread, 1, i[u]), d.geometry.getBuffer("aPosition").update(), d.geometry.getBuffer("aUV").update();
				let m = e.engines[u].offAxis * n;
				d.position.set(r + Math.cos(l) * m, s + Math.sin(l) * m), d.rotation = f.gimballed ?? f.kind === "sea-level" ? t.vehicle.gimbalPointingDirection : l, d.scale.set(n);
			}
		},
		reset() {
			i.fill(0);
			for (let e of o) e.visible = !1;
		},
		destroy() {
			for (let e of o) {
				let t = e.geometry;
				e.destroy(), t.destroy(!0);
			}
			t.destroy(), n.destroy(!0);
		}
	};
}
//#endregion
//#region src/view/engine-glare.ts
function g_(e, t = q) {
	let n = new r({ label: "engine-glare" }), i = t.engines.map(() => {
		let t = new ae(e);
		return t.anchor.set(.5), t.blendMode = "add", t.tint = 16760440, t.visible = !1, n.addChild(t), t;
	}), a = new ae(e);
	return a.label = "engine-ground-wash", a.anchor.set(.5), a.blendMode = "add", a.tint = 16757610, a.visible = !1, n.addChild(a), {
		container: n,
		update(e, n, r, o, s, c) {
			let l = e.kinematics.pitch, u = e.vehicle.throttleCurrent, d = Number.isFinite(u) ? Math.max(0, Math.min(1, u / 100)) : 0, f = 0;
			for (let a = 0; a < i.length; a++) {
				let s = i[a];
				if (s.visible = !!e.engines.running[a] && !e.engines.failed[a] && e.forces.thrust > 0, !s.visible) continue;
				f++;
				let c = t.engines[a];
				s.position.set(r + Math.cos(l) * c.offAxis * n, o + Math.sin(l) * c.offAxis * n), s.width = s.height = (c.kind === "vacuum" ? 11 : 8) * n, s.alpha = (.08 + d * .12) / Math.sqrt(t.engines.length);
			}
			let p = Math.max(0, Math.cos(l)), m = Number.isFinite(c) ? Math.max(0, 1 - Math.max(0, c) / 160) : 0;
			a.visible = f > 0 && m > 0 && p > .8, a.visible && (a.position.set(r, s), a.width = (18 + Math.max(0, c) * .3) * n, a.height = 3 * n, a.alpha = (.1 + d * .25) * m * p * Math.min(1, f / 3));
		},
		reset() {
			for (let e of i) e.visible = !1;
			a.visible = !1;
		},
		destroy() {
			n.destroy({ children: !0 });
		}
	};
}
//#endregion
//#region src/ui/session/scene-vehicles.ts
function __(e) {
	let t = X(e).partition.components.findIndex((e) => e.kind === "engine-support"), n = {}, r = {}, i = Array(e.engines.length).fill(!1), a = Array(e.engines.length).fill(!0);
	return (e) => {
		let o = e.damage;
		return !o || !o.terminal.active && o.components[t].attached ? e : (Object.assign(n, e), Object.assign(r, e.engines), r.running = i, r.failed = a, n.engines = r, n);
	};
}
function v_(e, t) {
	let n = Hg(), r = Ug(), i = a_();
	n.container.addChild(i.mesh);
	let a = o_();
	e.layers.vehicle.addChild(r.container, r.components.debrisContainer, n.container, n.components.debrisContainer), e.layers.effectsFront.addChild(a.container);
	let o = uh(t), s = uh(t), c = d_(), l = d_(q, q.height / 2), u = d_(J), d = h_(), f = h_(J), p = g_(t.soft), m = g_(t.soft, J), h = __(q), g = __(J);
	e.layers.effectsBehind.addChild(p.container, d.container, o.container, m.container, f.container, s.container);
	let _ = {
		altitude: 0,
		downRangeDistance: 0,
		pitch: 0,
		frontFinExtension: 0,
		aftFinExtension: 0,
		angleOfAttack: 0,
		surfaceTemperature: 293.15,
		damage: null
	}, v = {
		x: 0,
		y: 1
	}, y = !1, b = !1, x = !0, S = !0;
	function C(e) {
		_.altitude = e.kinematics.altitude, _.downRangeDistance = e.kinematics.downRangeDistance, _.pitch = e.kinematics.pitch, _.frontFinExtension = e.vehicle.frontFinExtension, _.aftFinExtension = e.vehicle.aftFinExtension, _.angleOfAttack = e.kinematics.angleOfAttack, _.surfaceTemperature = e.forces.surfaceTemperature, _.damage = e.damage;
	}
	return {
		draw(t, w, T, E, D, O) {
			y = O.model.id === "super-heavy";
			let k = O.mission, A = O.previousMission;
			b = !!k;
			let j = !!k || !y, M = !!k || y, N = k?.ship ?? t, ee = k?.booster ?? t;
			n.container.visible = j && S && !N.damage?.terminal.active, r.container.visible = M && S && !ee.damage?.terminal.active, n.components.debrisContainer.visible = j && S, r.components.debrisContainer.visible = M && S, o.container.visible = d.container.visible = j && x, s.container.visible = f.container.visible = M && x, p.container.visible = j && x, m.container.visible = M && x;
			let P = e.viewport.height / 2 + (e.camera.posY + e.camera.shakeY) * e.viewport.scale;
			if (j) {
				let t = N, r = h(t);
				C(t), n.update(e.camera, e.viewport, _, E);
				let s = k ? l : c;
				s.update(o, e.camera, e.viewport, r, A?.ship ?? w, T), d.update(r, e.viewport.scale, s.nozzle.x, s.nozzle.y, T), p.update(r, e.viewport.scale, s.nozzle.x, s.nozzle.y, P, t.kinematics.altitude - Math.cos(t.kinematics.pitch) * (q.height / 2));
				let u = om(t.forces.thermalPower, cl), f = Pg(t.forces.surfaceTemperature);
				Kg(t.kinematics.angleOfAttack, v), i.place(q.height * e.viewport.scale), i.set(u, v.x, v.y, D, f), y || a.update(e.viewport, _, u, E, D, f);
			}
			if (a.container.visible = S && !y && !N.damage?.terminal.active && a.container.visible, M) {
				let t = ee, n = g(t);
				C(t), r.update(e.camera, e.viewport, _, E), u.update(s, e.camera, e.viewport, n, A?.booster ?? w, T), f.update(n, e.viewport.scale, u.nozzle.x, u.nozzle.y, T), m.update(n, e.viewport.scale, u.nozzle.x, u.nozzle.y, P, t.kinematics.altitude - Math.cos(t.kinematics.pitch) * J.height / 2);
			}
		},
		presentation() {
			let e = y ? u : b ? l : c, t = y ? f : d, i = y ? s : o;
			return {
				nozzleX: e.nozzle.x,
				nozzleY: e.nozzle.y,
				bell: { visibleMounts: t.container.visible ? t.container.children.filter((e) => e.visible).length : 0 },
				particles: i.inspect(),
				components: [n, r].flatMap((e) => [...e.components.partsById.values()].map((t) => {
					let n = t.container.parent !== e.container, r = n ? e.components.debrisContainer.visible : e.container.visible, i = t.container.toGlobal({
						x: 0,
						y: 0
					}), a = t.container.getBounds();
					return {
						id: t.component.id,
						vehicle: e.container.label,
						detached: n,
						visible: r && t.container.visible && t.container.renderable && !!t.container.parent?.visible,
						meshes: t.container.children.filter((e) => e.visible).length,
						meshIds: t.meshes.map((e) => e.uid),
						x: i.x,
						y: i.y,
						left: a.x,
						top: a.y,
						width: a.width,
						height: a.height
					};
				})),
				bodies: [n.container, r.container].filter((e) => e.visible).map((e) => ({
					id: e.label,
					x: e.x,
					y: e.y,
					rotation: e.rotation,
					width: e.width,
					height: e.height
				}))
			};
		},
		setVehiclesVisible(e) {
			S = e;
		},
		setComponentVisible(e, t) {
			let i = n.components.partsById.get(e) ?? r.components.partsById.get(e);
			i && (i.container.renderable = t);
		},
		setParticlesVisible(e) {
			x = e, o.container.visible = d.container.visible = n.container.visible && e, s.container.visible = f.container.visible = r.container.visible && e, p.container.visible = n.container.visible && e, m.container.visible = r.container.visible && e;
		},
		reset() {
			S = !0;
			for (let e of [n, r]) for (let t of e.components.partsById.values()) t.container.renderable = !0;
			n.components.reset(), r.components.reset(), o.clear(), s.clear(), d.reset(), f.reset(), p.reset(), m.reset(), c.reset(), l.reset(), u.reset();
		},
		destroy() {
			d.destroy(), f.destroy(), p.destroy(), m.destroy(), i.destroy(), a.destroy(), n.destroy(), r.destroy();
		}
	};
}
//#endregion
//#region src/ui/session/scene.ts
function y_(e, t) {
	if (e.damage && (e.damage.terminal.active || !e.damage.components[t].attached)) return 0;
	let n = 0;
	for (let t = 0; t < e.engines.running.length; t++) e.engines.running[t] && !e.engines.failed[t] && n++;
	return n;
}
async function b_(e, t) {
	let n = await Bp();
	if (t()) return;
	let r = Ah(), i = Ih(n, r), a = Lh(), o = _m(), s = {
		sun: o,
		downRangeDistance: 0,
		altitude: 0,
		pitch: 0,
		vehicleHeight: 52,
		vehicleDiameter: 9
	}, c = {
		x: 0,
		y: 0
	}, l = sh(e.app.renderer), u = qh(r);
	e.layers.far.addChild(u.container);
	let d = hg(l.wisp);
	e.layers.far.addChild(d.container), e.layers.world.addChild(i.container, a.container);
	let f = Qm(e.app.renderer);
	e.layers.sky.addChild(f.container);
	let p = v_(e, l), m = X(q).partition.components.findIndex((e) => e.kind === "engine-support"), h = X(J).partition.components.findIndex((e) => e.kind === "engine-support"), g = Qh();
	e.layers.effectsFront.addChildAt(g.container, 0);
	let _ = yg(e.layers.effectsBehind, e.layers.vehicle, e.viewport.width, e.viewport.height), v = 0, y = 0;
	return {
		draw(t, n, r, l, b) {
			r > 0 && (y = r), km(o, l.basedOn ?? l.id, t.world.environmentTime, t.kinematics.downRangeDistance, l.launchHour), s.downRangeDistance = t.kinematics.downRangeDistance, s.altitude = t.kinematics.altitude, s.pitch = t.kinematics.pitch, s.vehicleHeight = b.model.height, s.vehicleDiameter = b.model.diameter, f.update(e.camera, e.viewport, t.kinematics.altitude, o), u.update(e.viewport, t.kinematics.altitude, t.kinematics.speedX, r, o), d.update(e.viewport, t.kinematics.altitude, t.kinematics.speedX, r, o), i.update(e.camera, e.viewport, t.kinematics.speedX, t.kinematics.altitude, s), a.update(e.camera, e.viewport, b.mission?.booster ?? (b.model.id === "super-heavy" ? t : void 0), o), p.draw(t, n, r, o, v, b);
			let x = ql(e.camera, e.viewport, t.kinematics.downRangeDistance, t.kinematics.altitude);
			g.update(x.x, x.y, t.kinematics.angleOfMotion, t.damage?.terminal.active ? 0 : t.kinematics.trueSpeed, e.viewport.height), v += r, c.x = x.x / e.viewport.width, c.y = x.y / e.viewport.height, _.update(bg(y_(t, b.model.id === "ship" ? m : h), t.vehicle.throttleCurrent), t.damage?.terminal.active ? 0 : xg(t.forces.thermalPower, cl), c, v);
		},
		resize(t, n) {
			e.resize(t, n), f.resize(e.viewport);
		},
		presentation() {
			let t = e.app.renderer, n = t.view.texture.source, r = t.type === O.WEBGL ? t.gl : void 0;
			return {
				...p.presentation(),
				width: e.viewport.width,
				height: e.viewport.height,
				worldDt: y,
				renderer: {
					backend: t.type === O.WEBGL ? "webgl" : t.type === O.WEBGPU ? "webgpu" : t.type === O.CANVAS ? "canvas" : "unknown",
					backendType: t.type,
					resolution: n.resolution,
					screen: {
						width: t.screen.width,
						height: t.screen.height
					},
					backing: {
						width: t.canvas.width,
						height: t.canvas.height
					},
					antialias: n.antialias,
					webgl: r ? {
						drawingBufferWidth: r.drawingBufferWidth,
						drawingBufferHeight: r.drawingBufferHeight,
						antialias: r.getContextAttributes()?.antialias ?? null,
						contextLost: r.isContextLost()
					} : null,
					filters: _.metadata({
						resolution: n.resolution,
						antialias: n.antialias,
						backendType: t.type
					})
				}
			};
		},
		setComponentVisible(e, t) {
			p.setComponentVisible(e, t);
		},
		setVehiclesVisible(e) {
			p.setVehiclesVisible(e);
		},
		setParticlesVisible(e) {
			p.setParticlesVisible(e);
		},
		resetFlight() {
			y = 0, p.reset();
		},
		destroy() {
			p.destroy();
		}
	};
}
//#endregion
//#region src/core/physics/grid-fins.ts
function x_() {
	return {
		forceX: 0,
		forceY: 0,
		torque: 0,
		drag: 0,
		lift: 0
	};
}
function S_(e, t, n, r, i, a, o, s) {
	s.forceX = s.forceY = s.torque = s.drag = s.lift = 0;
	let c = o.gridFins, l = Math.hypot(t, n);
	if (!c || e <= 0 || l === 0 || r === 0) return;
	let u = Math.max(-c.maxAngle, Math.min(c.maxAngle, r)), d = .5 * e * l * l * c.area;
	s.lift = d * Math.sin(2 * u), s.drag = d * 1.2 * Math.sin(u) ** 2, s.forceX = (-n * s.lift - t * s.drag) / l, s.forceY = (t * s.lift - n * s.drag) / l, s.torque = (c.station - a) * (Math.cos(i) * s.forceX - Math.sin(i) * s.forceY);
}
//#endregion
//#region src/core/physics/thermal.ts
function C_(e, t, n) {
	return rl * e ** 3 * Math.sqrt(t / n);
}
function w_(e, t, n, r) {
	let i = 1 - Math.abs(Math.sin(r)) * (1 - Math.SQRT1_2);
	return C_(e, t, n) * i;
}
function T_(e, t = 0) {
	return (Math.max(0, e) / (al * il) + t ** 4) ** .25;
}
var E_ = If(kf).airTemperature + sl;
function D_(e, t) {
	return e < 86e3 ? t + sl : E_;
}
//#endregion
//#region src/core/physics/components.ts
var O_ = Math.PI / 2;
function k_(e) {
	return -Math.sin(e);
}
function A_(e) {
	return -Math.cos(e);
}
function j_(e) {
	return -Math.cos(e);
}
function M_(e) {
	return Math.sin(e);
}
function N_(e) {
	return Math.sin(e);
}
function P_(e) {
	return Math.cos(e);
}
function F_(e) {
	return 0 < e && e < O_ || -Math.PI < e && e < -O_;
}
function I_(e, t) {
	let n = t(e.gimbalPointingDirection) * e.thrustAcceleration, r = e.fixedThrustAcceleration;
	return r === 0 ? n : n + t(e.pitch) * r;
}
function L_(e) {
	let t = k_(e.angleOfMotion) * e.aerodynamicDragAcceleration, n = j_(e.angleOfMotion), r = F_(e.angleOfAttack) ? -n * e.aerodynamicLiftAcceleration : n * e.aerodynamicLiftAcceleration;
	return t + I_(e, N_) + r;
}
function R_(e, t) {
	let n = A_(e.angleOfMotion) * e.aerodynamicDragAcceleration, r = M_(e.angleOfMotion), i = F_(e.angleOfAttack) ? -r * e.aerodynamicLiftAcceleration : r * e.aerodynamicLiftAcceleration, a = I_(e, P_);
	return -t + n + a + i;
}
function z_(e, t, n) {
	let r = Math.sin(e.angleOfMotion), i = Math.cos(e.angleOfMotion), a = F_(e.angleOfAttack), o = -r * e.aerodynamicDragAcceleration, s = -i * e.aerodynamicDragAcceleration, c = -i, l = r, u = a ? -c * e.aerodynamicLiftAcceleration : c * e.aerodynamicLiftAcceleration, d = a ? -l * e.aerodynamicLiftAcceleration : l * e.aerodynamicLiftAcceleration, f = Math.sin(e.gimbalPointingDirection) * e.thrustAcceleration, p = Math.cos(e.gimbalPointingDirection) * e.thrustAcceleration;
	e.fixedThrustAcceleration !== 0 && (f += Math.sin(e.pitch) * e.fixedThrustAcceleration, p += Math.cos(e.pitch) * e.fixedThrustAcceleration), n.x = o + f + u, n.y = -t + s + p + d;
}
//#endregion
//#region src/core/physics/propulsion.ts
var B_ = /* @__PURE__ */ N({
	engineMassFlow: () => V_,
	engineThrust: () => H_,
	isCanonicalBurnPropulsion: () => U_
});
function V_(e, t) {
	return t === "sea-level" ? e.seaLevel.thrustSeaLevel / (e.seaLevel.ispSeaLevel * e.standardGravity) : e.vacuum.thrustVacuum / (e.vacuum.ispVacuum * e.standardGravity);
}
function H_(e, t, n) {
	let r = Math.max(0, n) * 1e3, i = t === "sea-level" ? V_(e, t) * e.standardGravity * e.seaLevel.ispVacuum : e.vacuum.thrustVacuum, a = t === "sea-level" ? (i - e.seaLevel.thrustSeaLevel) / e.referencePressurePa : e.vacuum.effectiveExitArea;
	return Math.max(0, i - r * a);
}
function U_(e, t, n) {
	return e === U_ && t === V_ && n === H_;
}
//#endregion
//#region src/core/rng.ts
function W_(e) {
	return {
		seed: e >>> 0,
		counters: {
			ignitionDelay: 0,
			ignitionFailure: 0,
			turbulence: 0
		}
	};
}
function G_(e) {
	let t = 2166136261;
	for (let n = 0; n < e.length; n++) t ^= e.charCodeAt(n), t = Math.imul(t, 16777619);
	return t >>> 0;
}
var K_ = {
	ignitionDelay: G_("ignitionDelay"),
	ignitionFailure: G_("ignitionFailure"),
	turbulence: G_("turbulence")
};
function q_(e) {
	let t = e >>> 0;
	return t = Math.imul(t ^ t >>> 16, 569420461), t = Math.imul(t ^ t >>> 15, 3545902487), (t ^ t >>> 15) >>> 0;
}
function J_(e, t, n) {
	let r = K_[t], i = q_(e >>> 0 ^ r);
	return i = q_(i ^ n >>> 0), i = q_(i ^ Math.imul(n >>> 0, 2654435769)), i >>> 0;
}
function Y_(e, t, n) {
	return J_(e.seed, t, n) / 4294967296;
}
function X_(e, t) {
	let n = Y_(e, t, e.counters[t]);
	return e.counters[t] += 1, n;
}
q.tankBottom, q.propellantCapacity, q.loxTankHeight, q.ch4TankHeight, q.ch4TankBottom, q.dryCentreOfMass, q.aftFinStation, q.rcsStation, q.frontFinStation;
function Z_(e, t = q) {
	return Math.min(1, Math.max(0, e / t.propellantCapacity));
}
function Q_(e, t = q) {
	let n = Z_(e, t), r = t.tankBottom + n * t.loxTankHeight / 2, i = t.ch4TankBottom + n * t.ch4TankHeight / 2;
	return tu * r + (1 - tu) * i;
}
function $_(e, t = q) {
	let n = Math.max(0, e);
	return (t.dryMass * t.dryCentreOfMass + n * Q_(n, t)) / (t.dryMass + n);
}
function ev(e, t, n) {
	return e * ((n.diameter / 2) ** 2 / 4 + t ** 2 / 12);
}
function tv(e, t = q) {
	let n = Math.max(0, e), r = $_(n, t), i = Z_(n, t), a = ev(t.dryMass, t.height, t) + t.dryMass * (t.dryCentreOfMass - r) ** 2, o = n * tu, s = i * t.loxTankHeight, c = t.tankBottom + s / 2, l = ev(o, s, t) + o * (c - r) ** 2, u = n * (1 - tu), d = i * t.ch4TankHeight, f = t.ch4TankBottom + d / 2, p = ev(u, d, t) + u * (f - r) ** 2;
	return a + l + p;
}
function nv(e, t = q.height) {
	return (e ** 4 + (t - e) ** 4) / 4;
}
function rv(e, t, n = q) {
	let r = $_(e, n);
	t.centreOfMassX = 0, t.centreOfMass = r, t.momentOfInertia = tv(e, n), t.engineArm = r, t.aftFinArm = r - n.aftFinStation, t.frontFinArm = n.frontFinStation - r, t.rcsArm = n.rcsStation - r, t.rCubedIntegral = nv(r, n.height);
}
function iv(e = 0, t = q) {
	let n = {
		centreOfMassX: 0,
		centreOfMass: 0,
		momentOfInertia: 0,
		engineArm: 0,
		aftFinArm: 0,
		frontFinArm: 0,
		rcsArm: 0,
		rCubedIntegral: 0
	};
	return rv(e, n, t), n;
}
//#endregion
//#region src/core/physics/damage-mass.ts
function av() {
	return {
		hasMass: !1,
		retainedDryMass: 0,
		propellantMass: 0,
		totalMass: 0,
		dryCentreOfMassX: 0,
		dryCentreOfMass: 0,
		dryMomentOfInertia: 0,
		centreOfMassX: 0,
		centreOfMass: 0,
		momentOfInertia: 0,
		frontFinCount: 0,
		aftFinCount: 0,
		gridFinCount: 0,
		frontFinArea: 0,
		aftFinArea: 0,
		gridFinArea: 0,
		engineSupportAvailable: !1
	};
}
function ov(e, t, n, r, i) {
	if (!Number.isFinite(n) || t.id !== r.id || t.dryMass !== r.dryMass || t.dryCentreOfMass !== r.dryCentreOfMass || t.dryMomentOfInertia !== r.dryMass * ((r.diameter / 2) ** 2 / 4 + r.height ** 2 / 12) || e.components.length !== t.components.length) throw RangeError("Retained mass requires matching component/model inventory and finite propellant");
	i.hasMass = !1, i.retainedDryMass = 0, i.propellantMass = Math.max(0, n), i.totalMass = 0, i.dryCentreOfMassX = i.dryCentreOfMass = i.dryMomentOfInertia = 0, i.centreOfMassX = i.centreOfMass = i.momentOfInertia = 0, i.frontFinCount = i.aftFinCount = i.gridFinCount = 0, i.frontFinArea = i.aftFinArea = i.gridFinArea = 0, i.engineSupportAvailable = !1;
	let a = !0, o = 0, s = 0;
	for (let n = 0; n < t.components.length; n++) {
		let r = e.components[n];
		if (r.componentIndex !== n) throw RangeError("Component indices must retain catalogue order");
		if (!r.attached) {
			a = !1;
			continue;
		}
		let c = t.components[n];
		i.retainedDryMass += c.mass, o += c.mass * c.x, s += c.mass * c.station, c.kind === "flap" ? c.id.startsWith("ship-front-flap-") ? i.frontFinCount++ : c.id.startsWith("ship-aft-flap-") && i.aftFinCount++ : c.kind === "grid-fin" ? i.gridFinCount++ : c.kind === "engine-support" && (i.engineSupportAvailable = r.permanentFailure === Kd.None);
	}
	if (i.frontFinArea = r.frontFinArea * i.frontFinCount / 2, i.aftFinArea = r.aftFinArea * i.aftFinCount / 2, i.gridFinArea = r.gridFins ? r.gridFins.area * i.gridFinCount / r.gridFins.count : 0, a) {
		i.retainedDryMass = r.dryMass, i.dryCentreOfMassX = t.dryCentreOfMassX, i.dryCentreOfMass = r.dryCentreOfMass, i.dryMomentOfInertia = t.dryMomentOfInertia, i.totalMass = r.dryMass + i.propellantMass, i.hasMass = !0, i.centreOfMassX = 0, i.centreOfMass = $_(i.propellantMass, r), i.momentOfInertia = tv(i.propellantMass, r);
		return;
	}
	if (i.retainedDryMass > 0) {
		i.dryCentreOfMassX = o / i.retainedDryMass, i.dryCentreOfMass = s / i.retainedDryMass;
		for (let n = 0; n < t.components.length; n++) if (e.components[n].attached) {
			let e = t.components[n];
			i.dryMomentOfInertia += e.inertia + e.mass * ((e.x - i.dryCentreOfMassX) ** 2 + (e.station - i.dryCentreOfMass) ** 2);
		}
	}
	if (i.totalMass = i.retainedDryMass + i.propellantMass, i.totalMass === 0) return;
	i.hasMass = !0;
	let c = Math.min(1, i.propellantMass / r.propellantCapacity), l = i.propellantMass * tu, u = i.propellantMass * (1 - tu), d = r.loxTankHeight * c, f = r.ch4TankHeight * c, p = r.tankBottom + d / 2, m = r.ch4TankBottom + f / 2;
	i.centreOfMassX = o / i.totalMass, i.centreOfMass = (s + l * p + u * m) / i.totalMass;
	for (let n = 0; n < t.components.length; n++) if (e.components[n].attached) {
		let e = t.components[n];
		i.momentOfInertia += e.inertia + e.mass * ((e.x - i.centreOfMassX) ** 2 + (e.station - i.centreOfMass) ** 2);
	}
	let h = (r.diameter / 2) ** 2 / 4;
	i.momentOfInertia += l * (h + d ** 2 / 12 + i.centreOfMassX ** 2 + (p - i.centreOfMass) ** 2), i.momentOfInertia += u * (h + f ** 2 / 12 + i.centreOfMassX ** 2 + (m - i.centreOfMass) ** 2);
}
//#endregion
//#region src/core/physics/flight-mass-query.ts
function Z(e, t, n, r) {
	if (e.damage ? ov(e.damage, X(t).partition, e.vehicle.propellantMass, t, n) : (n.hasMass = !0, n.retainedDryMass = t.dryMass, n.propellantMass = Math.max(0, e.vehicle.propellantMass), n.totalMass = t.dryMass + n.propellantMass, n.dryCentreOfMassX = n.centreOfMassX = 0, n.dryCentreOfMass = t.dryCentreOfMass, n.dryMomentOfInertia = t.dryMass * ((t.diameter / 2) ** 2 / 4 + t.height ** 2 / 12), n.centreOfMass = $_(n.propellantMass, t), n.momentOfInertia = tv(n.propellantMass, t), n.frontFinCount = t.frontFinArea > 0 ? 2 : 0, n.aftFinCount = t.aftFinArea > 0 ? 2 : 0, n.gridFinCount = t.gridFins?.count ?? 0, n.frontFinArea = t.frontFinArea, n.aftFinArea = t.aftFinArea, n.gridFinArea = t.gridFins?.area ?? 0, n.engineSupportAvailable = !0), r) {
		if (!e.damage) {
			rv(e.vehicle.propellantMass, r, t);
			return;
		}
		r.centreOfMassX = n.centreOfMassX, r.centreOfMass = n.centreOfMass, r.momentOfInertia = n.momentOfInertia, r.engineArm = n.centreOfMass, r.aftFinArm = n.centreOfMass - t.aftFinStation, r.frontFinArm = t.frontFinStation - n.centreOfMass, r.rcsArm = t.rcsStation - n.centreOfMass, r.rCubedIntegral = nv(n.centreOfMass, t.height);
	}
}
//#endregion
//#region src/core/physics/damage-detachment.ts
function sv() {
	return {
		before: av(),
		after: av()
	};
}
function cv(e, t, n, r, i, a, o, s) {
	let c = t.components.length;
	if (c < 1 || c > 12 || e.components.length !== c || e.debris.length !== c || !Number.isInteger(a) || a < 0 || a > (1 << c) - 1) throw RangeError("Detachment requires a bounded matching component mask");
	if (s.before === s.after) throw RangeError("Detachment mass snapshots require distinct scratch");
	if (!Number.isFinite(i.x) || !Number.isFinite(i.altitude) || !Number.isFinite(i.pitch) || !Number.isFinite(i.vx) || !Number.isFinite(i.vy) || !Number.isFinite(i.omega)) throw RangeError("Detachment requires a finite physical COM pose");
	let l = 0, u = 0;
	for (let t = 0; t < c; t++) if (a & 1 << t && e.components[t].attached) {
		let n = e.debris[t];
		if (n.active || n.componentIndex !== t) throw RangeError("An attached component cannot already have a debris owner");
		l |= 1 << t, u++;
	}
	if (l === 0) return 0;
	if (o !== Kd.ProofExceeded && o !== Kd.MaterialDomain && o !== Kd.Terminal) throw RangeError("Detachment requires a permanent connection disposition");
	if (ov(e, t, r, n, s.before), !s.before.hasMass) throw RangeError("Cannot detach from an empty physical owner");
	let d = s.before, f = Math.cos(i.pitch), p = Math.sin(i.pitch);
	for (let n = 0; n < c; n++) if (l & 1 << n) {
		let r = t.components[n], a = e.components[n], s = e.debris[n], c = r.x - d.centreOfMassX, l = r.station - d.centreOfMass, u = f * c + p * l, m = -p * c + f * l;
		s.x = i.x + u, s.altitude = i.altitude + m, s.pitch = i.pitch, s.speedX = i.vx + i.omega * m, s.speedY = i.vy - i.omega * u, s.angularVelocity = i.omega, s.active = !0, a.attached = !1, a.permanentFailure === Kd.None && (a.permanentFailure = o);
	}
	if (ov(e, t, r, n, s.after), s.after.hasMass) {
		let e = s.after.centreOfMassX - d.centreOfMassX, t = s.after.centreOfMass - d.centreOfMass, n = f * e + p * t, r = -p * e + f * t;
		i.x += n, i.altitude += r, i.vx += i.omega * r, i.vy -= i.omega * n;
	}
	return e.revision++, e.eventCount += u, l;
}
//#endregion
//#region src/core/physics/damage-terminal.ts
var lv = /* @__PURE__ */ function(e) {
	return e[e.Impact = 1] = "Impact", e[e.Pressure = 2] = "Pressure", e[e.Temperature = 4] = "Temperature", e[e.Acceleration = 8] = "Acceleration", e[e.MaterialDomain = 16] = "MaterialDomain", e;
}({}), uv = av(), dv = sv(), Q = {
	x: 0,
	altitude: 0,
	pitch: W(0),
	vx: 0,
	vy: 0,
	omega: 0
};
function fv(e) {
	let t = e.forces;
	e.engines.running.fill(!1), e.engines.ignitionCountdown.fill(null), t.thrust = t.thrustAcceleration = t.twr = 0, t.paidThrustAccelerationX = t.paidThrustAccelerationY = 0, t.thrustVectorForce = t.thrustVectorAcceleration = 0, t.offAxisThrustDifferenceAcceleration = 0, t.rcsThrust = t.rcsThrustAngularAcceleration = 0;
}
function pv(e, t, n, r) {
	let i = e.damage;
	if (!i || i.terminal.active) return;
	let a = X(t).partition, o = e.kinematics;
	ov(i, a, e.vehicle.propellantMass, t, uv);
	let s = Math.sin(o.pitch), c = Math.cos(o.pitch), l = uv.centreOfMassX, u = uv.centreOfMass - t.height / 2, d = c * l + s * u, f = -s * l + c * u;
	Q.x = o.downRangeDistance + d, Q.altitude = o.altitude + f, Q.pitch = o.pitch, Q.omega = o.angularVelocity, Q.vx = o.speedX + Q.omega * f, Q.vy = o.speedY - Q.omega * d;
	let p = i.terminal;
	p.reason = n, p.time = r, p.x = Q.x, p.altitude = Q.altitude, p.pitch = Q.pitch, p.speedX = Q.vx, p.speedY = Q.vy, p.angularVelocity = Q.omega, p.retainedDryMass = uv.retainedDryMass, p.retainedPropellant = uv.propellantMass, p.releasedEnergy = 0;
	let m = (1 << a.components.length) - 1;
	cv(i, a, t, e.vehicle.propellantMass, Q, m, Kd.Terminal, dv), ov(i, a, e.vehicle.propellantMass, t, uv);
	let h = uv.totalMass;
	p.releasedMomentumX = h * Q.vx, p.releasedMomentumY = h * Q.vy, p.releasedAngularMomentum = uv.momentOfInertia * Q.omega + (Q.altitude - p.altitude) * p.releasedMomentumX - (Q.x - p.x) * p.releasedMomentumY, p.releasedKineticEnergy = .5 * h * (Q.vx ** 2 + Q.vy ** 2) + .5 * uv.momentOfInertia * Q.omega ** 2, e.engines.running.fill(!1), e.engines.failed.fill(!0), e.engines.ignitionCountdown.fill(null), e.vehicle.propellantMass = 0, e.vehicle.vehicleMass = 0, e.vehicle.vehicleMomentOfInertia = 0, p.active = !0;
}
function mv(e) {
	return (e.forces.perceivedG > 13 ? 8 : 0) | (e.forces.surfaceTemperature > 1533 ? 4 : 0) | (e.forces.dynamicPressure > 50 ? 2 : 0) | (e.damage && !e.damage.hull.valid ? 16 : 0);
}
//#endregion
//#region src/core/physics/damage-flight.ts
var hv = av(), gv = hf(12);
function _v(e, t, n) {
	Z(e, t, hv, n), e.vehicle.vehicleMass = hv.totalMass, (e.damage || n) && (e.vehicle.vehicleMomentOfInertia = hv.momentOfInertia);
}
function vv(e, t) {
	e.damage && (ov(e.damage, X(t).partition, e.vehicle.propellantMass, t, hv), !hv.engineSupportAvailable && (e.engines.running.fill(!1), e.engines.failed.fill(!0), e.engines.ignitionCountdown.fill(null)));
}
function yv(e, t, n, r, i) {
	let a = t.gridFins ? i ?? (e.vehicle.frontFinExtension - 50) / 50 * t.gridFins.maxAngle : e.vehicle.frontFinExtension * .01 * Qc;
	_f(e.damage, X(t).controls, n, r, a, e.vehicle.aftFinExtension * .01 * Qc, gv);
}
function bv(e, t, n, r) {
	if (e.damage) {
		yv(e, t, n, r);
		for (let t = 0; t < e.damage.components.length; t++) {
			let n = e.damage.components[t];
			n.attached && (n.loadedAngle = W(gv.loadedAngles[t]));
		}
		e.forces.frontFinEffectiveAreaFraction = gv.frontFraction, e.forces.aftFinEffectiveAreaFraction = gv.aftFraction, e.vehicle.vehicleInFlightMaxArea = t.maxArea + 1.8 * (gv.frontArea + gv.aftArea);
	}
}
function xv(e, t, n, r, i, a, o, s, c) {
	if (!e.damage) {
		S_(t, n, r, c ?? W((e.vehicle.frontFinExtension - 50) / 50 * (o.gridFins?.maxAngle ?? 0)), i, a.centreOfMass, o, s);
		return;
	}
	s.forceX = s.forceY = s.torque = s.drag = s.lift = 0;
	let l = o.gridFins, u = Math.hypot(n, r);
	if (!l || t <= 0 || u === 0) return;
	let d = .5 * t * u * u;
	yv(e, o, d, 0, c);
	let f = X(o).partition.components, p = Math.sin(i), m = Math.cos(i);
	for (let t = 0; t < f.length; t++) {
		let i = f[t];
		if (i.kind !== "grid-fin" || !e.damage.components[t].attached || (gv.proofMask | gv.domainMask) & 1 << t) continue;
		let o = gv.loadedAngles[t], c = d * l.area / l.count * Math.sin(2 * o), h = d * l.area / l.count * 1.2 * Math.sin(o) ** 2, g = (-r * c - n * h) / u, _ = (n * c - r * h) / u, v = i.x - a.centreOfMassX, y = i.station - a.centreOfMass, b = m * v + p * y, x = -p * v + m * y;
		s.forceX += g, s.forceY += _, s.lift += c, s.drag += h, s.torque += x * g - b * _;
	}
}
var Sv = sv(), Cv = {
	x: 0,
	altitude: 0,
	pitch: W(0),
	vx: 0,
	vy: 0,
	omega: 0
};
function wv(e, t, n, r) {
	let i = e.damage;
	if (!i || i.terminal.active) return 0;
	let a = X(n), o = pf(i, a.thermal, t, e.forces.thermalPower, D_(e.kinematics.altitude, e.atmosphere.airTemperature), e.atmosphere.airPressure * 1e3), s = mv(e);
	if (s !== 0) {
		if (r !== "hull") throw RangeError("Terminal live state must publish its hull reference");
		return pv(e, n, s, e.world.environmentTime + t), o;
	}
	yv(e, n, e.forces.dynamicPressure * 1e3, Math.abs(Math.sin(e.kinematics.angleInToTheWind)));
	let c = o & ~Xd | gv.domainMask, l = gv.proofMask & ~c;
	for (let e = 0; e < i.components.length; e++) {
		let t = i.components[e];
		t.attached && !(c & 1 << e) && (t.loadedAngle = W(gv.loadedAngles[e]));
	}
	if ((c | l) === 0) return o;
	ov(i, a.partition, e.vehicle.propellantMass, n, hv);
	let u = e.kinematics, d = Math.sin(u.pitch), f = Math.cos(u.pitch), p = r === "hull" ? hv.centreOfMassX : 0, m = r === "hull" ? hv.centreOfMass - n.height / 2 : 0, h = f * p + d * m, g = -d * p + f * m;
	Cv.x = u.downRangeDistance + h, Cv.altitude = u.altitude + g, Cv.pitch = u.pitch, Cv.vx = u.speedX + u.angularVelocity * g, Cv.vy = u.speedY - u.angularVelocity * h, Cv.omega = u.angularVelocity;
	let _ = i.revision, v = cv(i, a.partition, n, e.vehicle.propellantMass, Cv, c, Kd.MaterialDomain, Sv);
	return v |= cv(i, a.partition, n, e.vehicle.propellantMass, Cv, l, Kd.ProofExceeded, Sv), v !== 0 && (i.revision = _ + 1), r === "mass" && (u.downRangeDistance = Cv.x, u.downRangeDistanceNextFrame = Cv.x, u.altitude = Cv.altitude, u.speedX = Cv.vx, u.speedY = Cv.vy), _v(e, n), vv(e, n), v | o & Xd;
}
//#endregion
//#region src/core/physics/engines.ts
function Tv(e) {
	let t = 0;
	for (let n of e) n && (t += 1);
	return t;
}
function Ev(e, t, n, r) {
	let i = 0;
	for (let a = 0; a < r.engines.length; a++) r.engines[a].kind === t && e[a] === !0 === n && (i += 1);
	return i;
}
function Dv(e, t = q) {
	return Ev(e, "sea-level", !0, t);
}
function Ov(e, t = q) {
	return Ev(e, "sea-level", !1, t);
}
function kv(e, t, n = q) {
	return Ev(e, "sea-level", !0, n) * H_(n.propulsion, "sea-level", t) + Ev(e, "vacuum", !0, n) * H_(n.propulsion, "vacuum", t);
}
function Av(e, t, n = q) {
	return kv(e, t, n) * 40 * .01;
}
function jv(e, t, n, r = q) {
	return kv(e, n, r) * t * .01;
}
function Mv(e, t, n = q) {
	if (n.engines.some((e) => e.gimballed === !1 && e.kind === "sea-level")) {
		let t = 0, r = 0;
		for (let i = 0; i < n.engines.length; i++) e[i] && (t++, n.engines[i].gimballed === !0 && r++);
		return t > 0 ? r / t : 0;
	}
	if (Ev(e, "vacuum", !0, n) === 0) return 1;
	let r = kv(e, t, n);
	return r > 0 ? Ev(e, "sea-level", !0, n) * H_(n.propulsion, "sea-level", t) / r : 0;
}
function Nv(e, t) {
	return e * Math.sin(.01 * t * Gc);
}
function Pv(e, t, n, r = q) {
	let i = 0, a = 0;
	for (let t = 0; t < r.engines.length; t++) {
		let n = r.engines[t], o = +!!e[t] * n.offAxisForceFraction;
		n.kind === "sea-level" ? i += o : a += o;
	}
	return i * t * .01 * H_(r.propulsion, "sea-level", n) + a * t * .01 * H_(r.propulsion, "vacuum", n);
}
function Fv(e, t) {
	let n = e - .01 * t * Gc;
	return n > Math.PI ? n -= 2 * Math.PI : n < -Math.PI && (n += 2 * Math.PI), W(n);
}
function Iv(e, t, n = q) {
	return Ev(e, "sea-level", !0, n) * t * .01 * V_(n.propulsion, "sea-level") + Ev(e, "vacuum", !0, n) * t * .01 * V_(n.propulsion, "vacuum");
}
function Lv(e, t, n = q) {
	vv(e, n);
	let { vehicle: r, engines: i, status: a } = e, o = 1;
	if (r.propellantMass > 0) {
		let e = Iv(i.running, r.throttleCurrent, n) * t;
		e > r.propellantMass && (o = r.propellantMass / e), r.propellantMass = Math.max(0, r.propellantMass - e);
	} else r.propellantMass = 0;
	return a.dumpingFuel && ((r.propellantMass > 12e3 || a.forceDump) && r.propellantMass > 0 ? r.propellantMass = Math.max(0, r.propellantMass - Lc * t) : a.dumpingFuel = !a.dumpingFuel), _v(e, n), o;
}
var Rv = 1.2;
function zv(e, t) {
	let { engines: n } = e;
	if (n.running[t] || n.failed[t] || n.ignitionCountdown[t] !== null) return;
	let r = X_(e.rng, "ignitionDelay");
	n.ignitionCountdown[t] = (r * 1.5 + .5) * (600 / 1e3);
}
function Bv(e, t) {
	let n = e.failures.randomFailure ? Rc : 0, r = X_(e.rng, "ignitionFailure") < n;
	return r && (e.engines.failed[t] = !0), r;
}
function Vv(e, t) {
	let { engines: n } = e;
	for (let e = 0; e < n.ignitionCountdown.length; e++) {
		let r = n.ignitionCountdown[e];
		if (r == null) continue;
		let i = r - t;
		i <= 0 ? (n.ignitionCountdown[e] = null, n.running[e] = !0) : n.ignitionCountdown[e] = i;
	}
}
function Hv(e, t) {
	e.engines.running[t] = !1, e.engines.ignitionCountdown[t] = null;
}
function Uv(e) {
	e.failures.fuelRunOut && (e.engines.running.fill(!1), e.engines.ignitionCountdown.fill(null));
}
function Wv(e, t, n, r, i) {
	let a = 0;
	for (let o = 0; o < i.engines.length; o++) if (e[o]) {
		let e = i.engines[o], s = H_(i.propulsion, e.kind, n);
		a -= e.offAxis * s * t * .01 * Math.cos(e.gimballed ?? e.kind === "sea-level" ? r : 0);
	}
	return a;
}
//#endregion
//#region src/core/physics/wind.ts
var Gv = 18.3, Kv = .52, qv = 2, Jv = 1, Yv = .3048, Xv = 20 * Yv, Zv = 10 * Yv, Qv = 1e3 * Yv;
function $v(e) {
	return Kv * Math.max(Math.abs(e), qv) ** -.75;
}
function ey(e, t) {
	return e === 0 ? 0 : e * (Math.min(Math.max(t, Jv), 150) / Gv) ** $v(e);
}
function ty(e, t) {
	return ey(e.wind, t) + e.gust;
}
function ny(e, t, n) {
	let r = Math.min(Math.max(t, Zv), Qv) / Yv, i = .177 + 823e-6 * r, a = .1 * Math.abs(e);
	return n.sigmaW = a, n.sigmaU = a / i ** .4, n.lengthW = r * Yv, n.lengthU = r / i ** 1.2 * Yv, n;
}
var ry = {
	sigmaU: 0,
	sigmaW: 0,
	lengthU: 0,
	lengthW: 0
}, iy = Math.sqrt(3), ay = 2;
function oy(e, t, n, r, i, a) {
	if (e.wind === 0) return;
	ny(ey(e.wind, Xv), n, ry);
	let o = Math.hypot(r - ey(e.wind, n), i), s = Math.sqrt(-2 * Math.log(1 - X_(t, "turbulence"))), c = 2 * Math.PI * X_(t, "turbulence"), l = s * Math.cos(c), u = s * Math.sin(c), d = Math.exp(-o * a / ry.lengthU);
	e.turbulenceU = d * e.turbulenceU + Math.sqrt(1 - d * d) * l;
	let f = Math.exp(-o * a / ry.lengthW), p = e.turbulenceW1;
	e.turbulenceW1 = f * p + Math.sqrt(1 - f * f) * u, e.turbulenceW2 = f * e.turbulenceW2 + (1 - f) * p, e.gust = ry.sigmaU * e.turbulenceU, e.gustVertical = ry.sigmaW / Math.sqrt(ay) * (iy * e.turbulenceW1 + (1 - iy) * e.turbulenceW2);
}
//#endregion
//#region src/core/physics/step-dynamics.ts
function sy() {
	return {
		omega0: 0,
		alpha0: 0,
		bodyAccelerationX: 0,
		bodyAccelerationY: 0,
		burnedFraction: 0,
		gimballedThrust: 0,
		airspeed: 0,
		massProperties: iv(),
		gridFinForces: x_()
	};
}
function cy(e, t) {
	let { kinematics: n } = e;
	n.pitchRecord.push(n.pitch), n.pitchRecord.shift();
	let r = n.pitchRecord[0];
	n.pitchRateOfChange = e.damage && !Number.isFinite(r) ? n.angularVelocity : (n.pitch - r) / t;
}
function ly(e) {
	let { kinematics: t } = e;
	t.distanceToPlanetCenter = G + t.altitude, t.orbitalVelocityAtCurrentAltitude = yp(t.distanceToPlanetCenter);
}
function uy(e, t) {
	let { kinematics: n, status: r, failures: i, vehicle: a, engines: o } = e;
	n.altitude <= t.height * Math.abs(Math.cos(n.pitch)) * .5 ? (n.speedY < -.5 || t.id === "super-heavy" && n.speedY < 0) && (t.id === "ship" && Math.abs(n.speedX) < 2 && Math.abs(n.speedY) < 10 && Math.abs(n.pitch) < .09 ? (r.landed = !0, n.speedX = 0, n.speedY = 0, n.angularVelocity = 0) : (pv(e, t, lv.Impact, e.world.environmentTime), i.crashed = !0, n.speedX = 0, n.speedY = 0, n.angularVelocity = 0, n.pitch = W(0), a.propellantMass = 0, o.running.fill(!1), a.rcsRunTimeRemaining = 0)) : (r.landed = !1, r.onTheGround = !1);
}
function dy(e, t, n, r = n.height * Math.abs(Math.cos(e.kinematics.pitch)) * .5) {
	let { kinematics: i, status: a } = e;
	i.altitude > r || i.speedY < -.5 || e.failures.crashed || a.landed || (a.onTheGround = t <= xp(i.distanceToPlanetCenter), a.onTheGround && (i.speedX = 0, i.speedY = 0, i.angularVelocity = 0));
}
function fy(e, t, n) {
	let { kinematics: r, forces: i, failures: a, vehicle: o, engines: s } = e;
	(i.perceivedG > 13 || i.surfaceTemperature > 1533 || i.dynamicPressure > 50 || e.damage !== null && (e.damage.terminal.active || !e.damage.hull.valid)) && (pv(e, t, mv(e), e.world.environmentTime), a.inFlightBreakUp = !0, r.angularVelocity = 0, o.propellantMass = 0, e.damage || (o.vehicleMass = t.dryMass, rv(0, n.massProperties, t), o.vehicleMomentOfInertia = n.massProperties.momentOfInertia), s.running.fill(!1), s.ignitionCountdown.fill(null), o.rcsRunTimeRemaining = 0, i.rcsThrust = 0);
}
function py(e) {
	e.vehicle.propellantMass <= 0 && (e.failures.fuelRunOut = !0);
}
function my(e, t, n) {
	let { forces: r } = e;
	r.perceivedG_Y = n / Kc, r.perceivedG_X = t / Kc, r.perceivedG = Math.sqrt(r.perceivedG_Y ** 2 + r.perceivedG_X ** 2);
}
function hy(e, t, n, r) {
	let { massProperties: i, gridFinForces: a } = r, o = sp(e.kinematics.speedX, e.kinematics.speedY, ty(e.world, e.kinematics.altitude), e.world.gustVertical);
	e.world.updatedFrameCount += 1;
	let s = qf(e.kinematics.altitude);
	if (e.atmosphere.airTemperature = s.airTemperature, e.atmosphere.airPressure = s.airPressure, e.atmosphere.airDensity = s.airDensity, uy(e, n), e.damage?.terminal.active) {
		fv(e), r.bodyAccelerationX = r.bodyAccelerationY = r.burnedFraction = r.gimballedThrust = 0;
		return;
	}
	py(e);
	let c = Lv(e, t, n);
	Uv(e), e.vehicle.propellantMass <= 0 && e.engines.ignitionCountdown.fill(null), Vv(e, t);
	let l = hp(e.vehicle.frontFinExtension, e.vehicle.aftFinExtension, n);
	e.forces.frontFinEffectiveAreaFraction = l.frontFinEffectiveAreaFraction, e.forces.aftFinEffectiveAreaFraction = l.aftFinEffectiveAreaFraction, e.vehicle.vehicleInFlightMaxArea = l.vehicleInFlightMaxArea, e.forces.crossSectionalArea = $f(e.kinematics.angleInToTheWind, e.vehicle.vehicleInFlightMaxArea, n), e.kinematics.angleOfMotion = op(e.kinematics.speedX, e.kinematics.speedY);
	let u = cp(e.kinematics.speedX, e.kinematics.speedY, ty(e.world, e.kinematics.altitude), e.world.gustVertical), d = lp(e.kinematics.pitch, u);
	e.kinematics.angleOfAttack = d.angleOfAttack, e.kinematics.angleInToTheWind = d.angleInToTheWind, e.vehicle.gimbalPointingDirection = Fv(e.kinematics.pitch, e.vehicle.gimbalPosition), e.forces.thermalPower = w_(o, e.atmosphere.airDensity, n.diameter / 2, e.kinematics.angleInToTheWind), e.forces.surfaceTemperature = T_(e.forces.thermalPower, D_(e.kinematics.altitude, e.atmosphere.airTemperature)), e.forces.dynamicPressure = Qf(e.atmosphere.airDensity, o), e.damage && (bv(e, n, e.forces.dynamicPressure * 1e3, Math.abs(Math.sin(e.kinematics.angleInToTheWind))), e.forces.crossSectionalArea = $f(e.kinematics.angleInToTheWind, e.vehicle.vehicleInFlightMaxArea, n)), cy(e, t), e.forces.aerodynamicDrag = ep(e.atmosphere.airDensity, o, e.forces.crossSectionalArea, rp(e.kinematics.machSpeed)), e.forces.aerodynamicLift = np(e.atmosphere.airDensity, o, e.kinematics.angleInToTheWind, e.vehicle.vehicleInFlightMaxArea), e.forces.thrust = jv(e.engines.running, e.vehicle.throttleCurrent, e.atmosphere.airPressure, n) * c, e.forces.aerodynamicDragAcceleration = ip(e.forces.aerodynamicDrag, e.vehicle.vehicleMass), e.forces.aerodynamicLiftAcceleration = ip(e.forces.aerodynamicLift, e.vehicle.vehicleMass), e.forces.thrustAcceleration = ip(e.forces.thrust, e.vehicle.vehicleMass), e.forces.twr = e.forces.thrustAcceleration / Nc;
	let f = Mv(e.engines.running, e.atmosphere.airPressure, n), p = e.forces.thrust * f;
	e.damage && (e.forces.paidThrustAccelerationX = e.forces.thrustAcceleration * (f * Math.sin(e.vehicle.gimbalPointingDirection) + (1 - f) * Math.sin(e.kinematics.pitch)), e.forces.paidThrustAccelerationY = e.forces.thrustAcceleration * (f * Math.cos(e.vehicle.gimbalPointingDirection) + (1 - f) * Math.cos(e.kinematics.pitch)));
	let m = e.forces.thrust - p, h = {
		angleOfMotion: u,
		angleOfAttack: e.kinematics.angleOfAttack,
		gimbalPointingDirection: e.vehicle.gimbalPointingDirection,
		aerodynamicDragAcceleration: e.forces.aerodynamicDragAcceleration,
		aerodynamicLiftAcceleration: e.forces.aerodynamicLiftAcceleration,
		thrustAcceleration: ip(p, e.vehicle.vehicleMass),
		fixedThrustAcceleration: ip(m, e.vehicle.vehicleMass),
		pitch: e.kinematics.pitch
	};
	n.gridFins && (_v(e, n, i), xv(e, e.atmosphere.airDensity, e.kinematics.speedX - ty(e.world, e.kinematics.altitude), e.kinematics.speedY - e.world.gustVertical, e.kinematics.pitch, i, n, a));
	let g = n.gridFins ? L_(h) + a.forceX / e.vehicle.vehicleMass : L_(h), _ = n.gridFins ? R_(h, Nc) + Nc + a.forceY / e.vehicle.vehicleMass : R_(h, Nc) + Nc;
	r.bodyAccelerationX = g, r.bodyAccelerationY = _, r.burnedFraction = c, r.gimballedThrust = p;
}
function gy(e, t, n, r, i, a) {
	dy(e, r, i, a);
	let o = e.kinematics.distanceToPlanetCenter, s = e.kinematics.speedX, c = e.kinematics.speedY, l = n + wp(o, s, c), u = r + bp(o, s), d = (e.status.onTheGround || e.status.landed || e.failures.crashed) && u <= 0;
	d && (l = 0, u = 0), my(e, d ? -wp(o, s, c) : n, d ? -bp(o, s) : r);
	let f = .5 * t * t;
	e.kinematics.altitude += c * t + u * f, e.kinematics.downRangeDistanceNextFrame = e.kinematics.downRangeDistance + s * t + l * f, e.kinematics.downRangeDistanceNextFrame > kc ? e.kinematics.downRangeDistance = e.kinematics.downRangeDistanceNextFrame - kc : e.kinematics.downRangeDistanceNextFrame < 0 ? e.kinematics.downRangeDistance = e.kinematics.downRangeDistanceNextFrame + kc : e.kinematics.downRangeDistance = e.kinematics.downRangeDistanceNextFrame, ly(e);
	let p = e.kinematics.distanceToPlanetCenter, m = s + l * t, h = c + u * t, g = d ? 0 : n + wp(p, m, h), _ = d ? 0 : r + bp(p, m);
	return e.kinematics.speedX = s + .5 * (l + g) * t, e.kinematics.speedY = c + .5 * (u + _) * t, e.kinematics.accelerationX = g, e.kinematics.accelerationY = _, e.kinematics.totalAcceleration = Math.sqrt(g ** 2 + _ ** 2), e.kinematics.trueSpeed = Math.sqrt(e.kinematics.speedX ** 2 + e.kinematics.speedY ** 2), d;
}
function _y(e, t, n) {
	let r = sp(e.kinematics.speedX, e.kinematics.speedY, ty(e.world, e.kinematics.altitude), e.world.gustVertical);
	e.kinematics.machSpeed = r / Xf(e.atmosphere.airTemperature), oy(e.world, e.rng, e.kinematics.altitude, e.kinematics.speedX, e.kinematics.speedY, t), n.airspeed = r;
}
function vy(e, t, n, r) {
	let i = .5 * t * t;
	e.kinematics.pitch > Math.PI ? e.kinematics.pitch = W(e.kinematics.pitch - 2 * Math.PI) : e.kinematics.pitch < -Math.PI && (e.kinematics.pitch = W(e.kinematics.pitch + 2 * Math.PI));
	let a = e.kinematics.angularVelocity, o = n ? 0 : e.kinematics.angularAcceleration;
	e.kinematics.pitch = W(e.kinematics.pitch + a * t + o * i), e.kinematics.angularVelocity = a + o * t, r.omega0 = a, r.alpha0 = o;
}
function yy(e, t, n) {
	let { massProperties: r, gridFinForces: i, gimballedThrust: a, burnedFraction: o, airspeed: s } = n;
	e.forces.thrustVectorForce = Nv(a, e.vehicle.gimbalPosition), e.forces.frontFinDrag = pp(e.atmosphere.airDensity, s, e.kinematics.angleOfAttack, e.kinematics.angleInToTheWind, e.forces.frontFinEffectiveAreaFraction, t), e.forces.aftFinDrag = mp(e.atmosphere.airDensity, s, e.kinematics.angleOfAttack, e.kinematics.angleInToTheWind, e.forces.aftFinEffectiveAreaFraction, t);
	let c = e.vehicle.vehicleMomentOfInertia;
	if (e.forces.thrustVectorAcceleration = ap(e.forces.thrustVectorForce, r.engineArm, c), e.forces.angularDragAcceleration = fp(e.atmosphere.airDensity, e.kinematics.angularVelocity, c, r.rCubedIntegral, t), e.forces.frontFinDragAngularAcceleration = ap(e.forces.frontFinDrag, r.frontFinArm, c), e.forces.aftFinDragAngularAcceleration = ap(e.forces.aftFinDrag, r.aftFinArm, c), e.forces.rcsThrustAngularAcceleration = ap(e.forces.rcsThrust, r.rcsArm, c), e.forces.offAxisThrustDifferenceAcceleration = ap(Pv(e.engines.running, e.vehicle.throttleCurrent, e.atmosphere.airPressure, t), r.engineArm, c), t.gridFins && (xv(e, e.atmosphere.airDensity, e.kinematics.speedX - ty(e.world, e.kinematics.altitude), e.kinematics.speedY - e.world.gustVertical, e.kinematics.pitch, r, t, i), e.forces.frontFinDrag = i.lift, e.forces.frontFinDragAngularAcceleration = i.torque / c, e.forces.offAxisThrustDifferenceAcceleration = Wv(e.engines.running, e.vehicle.throttleCurrent, e.atmosphere.airPressure, W(e.vehicle.gimbalPosition * .01 * Gc), t) * o / c), e.damage) {
		let n = e.vehicle.gimbalPosition * .01 * Gc, i = a * Math.cos(n) + e.forces.thrust - a;
		e.forces.offAxisThrustDifferenceAcceleration = (Wv(e.engines.running, e.vehicle.throttleCurrent, e.atmosphere.airPressure, W(n), t) * o + r.centreOfMassX * i) / c;
	}
	return e.forces.thrustVectorAcceleration + e.forces.angularDragAcceleration + e.forces.frontFinDragAngularAcceleration + e.forces.aftFinDragAngularAcceleration + e.forces.rcsThrustAngularAcceleration + e.forces.offAxisThrustDifferenceAcceleration;
}
function by(e, t, n, r, i, a) {
	e.kinematics.angularVelocity = n ? 0 : r + .5 * (i + a) * t, e.kinematics.angularAcceleration = n ? 0 : a;
}
function xy(e, t, n, r, i) {
	_v(e, n, r.massProperties), e.vehicle.vehicleMomentOfInertia = r.massProperties.momentOfInertia, vy(e, t, i, r);
	let a = yy(e, n, r);
	by(e, t, i, r.omega0, r.alpha0, a);
}
//#endregion
//#region src/core/control/guidance-physics.ts
var Sy = .1;
function Cy(e) {
	let t = G + e.kinematics.altitude;
	return Math.max(Sy, -bp(t, e.kinematics.speedX));
}
function wy(e, t, n = q) {
	return e * H_(n.propulsion, "sea-level", t);
}
function Ty() {
	return {
		fallWork: Xy(),
		atmosphere: {
			airTemperature: 0,
			airPressure: 0,
			airDensity: 0
		},
		duration: 0,
		capped: !1,
		inputs: {
			angleOfMotion: W(0),
			angleOfAttack: W(0),
			gimbalPointingDirection: W(0),
			aerodynamicDragAcceleration: 0,
			aerodynamicLiftAcceleration: 0,
			thrustAcceleration: 0,
			fixedThrustAcceleration: 0,
			pitch: W(0)
		},
		acc: {
			x: 0,
			y: 0
		}
	};
}
function Ey() {
	if (!("isCanonicalBurnPropulsion" in B_)) return !1;
	try {
		let e = U_;
		return typeof e == "function" && e(e, V_, H_);
	} catch {
		return !1;
	}
}
function Dy() {
	if (!("isCanonicalBurnAero" in Zf)) return !1;
	try {
		let e = gp;
		return typeof e == "function" && e(e, $f);
	} catch {
		return !1;
	}
}
function Oy(e, t, n, r, i = q) {
	let a = r.atmosphere;
	Kf(e, a);
	let o = t / Xf(a.airTemperature);
	return ep(a.airDensity, t, $f(W(0), i.maxArea, i), rp(o)) / n;
}
var ky = .05, Ay = 1200;
function jy(e, t, n, r, i, a) {
	let o = e * V_(a.propulsion, "sea-level"), s = ky * .5, c = r, l = 0, u = t;
	i.capped = !1;
	for (let t = 0; t < Ay; t++) {
		let r = My(e, c, l, u, i, a), d = l + r * s, f = My(e, c + (l + d) * .5 * s, d, u + o * s, i, a);
		if (f <= 0) return NaN;
		let p = l + f * ky;
		if (p >= n) {
			let e = (n - l) / (p - l);
			return i.duration = (t + e) * ky, c + (l + .5 * (n - l)) * e * ky;
		}
		c += (l + p) * .5 * ky, l = p, u += o * ky;
	}
	return i.capped = !0, NaN;
}
function My(e, t, n, r, i, a) {
	let o = Oy(t, n, r, i, a);
	return wy(e, i.atmosphere.airPressure, a) / r + o - xp(G + t);
}
function Ny(e, t, n, r, i, a, o, s, c, l) {
	let u = e * (Ey() ? o : V_(a.propulsion, "sea-level")), d = ky * .5, f = r, p = 0, m = t;
	i.capped = !1;
	for (let t = 0; t < Ay; t++) {
		let r = Fy(e, f, p, m, i, a, s, c, l), o = p + r * d, h = Fy(e, f + (p + o) * .5 * d, o, m + u * d, i, a, s, c, l);
		if (h <= 0) return NaN;
		let g = p + h * ky;
		if (g >= n) {
			let e = (n - p) / (g - p);
			return i.duration = (t + e) * ky, f + (p + .5 * (n - p)) * e * ky;
		}
		f += (p + g) * .5 * ky, p = g, m += u * ky;
	}
	return i.capped = !0, NaN;
}
function Py(e, t, n, r, i, a) {
	let o = r.atmosphere;
	Kf(e, o);
	let s = t / Xf(o.airTemperature), c = ep, l = o.airDensity;
	return c(l, t, Dy() ? a : $f(W(0), i.maxArea, i), rp(s)) / n;
}
function Fy(e, t, n, r, i, a, o, s, c) {
	let l = Py(t, n, r, i, a, c), u = i.atmosphere.airPressure, d;
	if (Ey()) {
		let t = Math.max(0, u) * 1e3;
		d = e * Math.max(0, o - t * s);
	} else d = wy(e, u, a);
	return d / r + l - xp(G + t);
}
var Iy = 24, Ly = 1;
function Ry(e, t, n, r, i = q) {
	if (e <= 0 || t <= 0) return Infinity;
	let a = t + e * V_(i.propulsion, "sea-level") * ky + Ly, o = wy(e, Jc / 1e3, i) / a - xp(G + r);
	return o <= 0 ? Infinity : r + Math.max(0, n) ** 2 / (2 * o);
}
function zy(e, t, n, r, i, a = q, o = a.dryMass) {
	if (e <= 0 || t <= 0 || !(o > 0 && o <= t)) return null;
	if (n <= 0) return r;
	let s = e * V_(a.propulsion, "sea-level"), c = wy(e, Jc / 1e3, a) / t - xp(G);
	if (c <= 0) return null;
	let l = a === J && Ey() && Dy(), u = l ? V_(a.propulsion, "sea-level") : 0, d = l ? u * a.propulsion.standardGravity * a.propulsion.seaLevel.ispVacuum : 0, f = l ? (d - a.propulsion.seaLevel.thrustSeaLevel) / a.propulsion.referencePressurePa : 0, p = l ? $f(W(0), a.maxArea, a) : 0, m = Math.max(t - n / c * s, o), h = l ? Ny(e, m, n, r, i, a, u, d, f, p) : jy(e, m, n, r, i, a);
	if (Number.isNaN(h)) return null;
	let g = t - s * i.duration - m;
	if (g < 0) return null;
	if (g < Ly) return h;
	let _ = t - s * i.duration, v = NaN, y = 0;
	for (let o = 0; o < Iy; o++) {
		let c = Number.isNaN(v) ? o === 0 ? _ : (m + _) / 2 : _ - v * (_ - m) / (v - g), b = l ? Ny(e, c, n, r, i, a, u, d, f, p) : jy(e, c, n, r, i, a);
		if (i.capped) return null;
		let x = Number.isNaN(b) ? NaN : t - s * i.duration - c;
		if (!Number.isNaN(x) && Math.abs(x) < Ly) return b;
		if (!Number.isNaN(x) && x > 0 ? (m = c, g = x, h = b, y === 1 && !Number.isNaN(v) && (v *= .5), y = 1) : (_ = c, v = x, y === -1 && (g *= .5), y = -1), _ - m < Ly) break;
	}
	return h;
}
function By() {
	return {
		reached: !1,
		time: NaN,
		downRange: 0
	};
}
var Vy = .25, Hy = 4e3, Uy = 2;
function Wy(e, t, n, r, i, a, o, s, c, l = 0, u = 0, d, f) {
	let { inputs: p, acc: m } = s, h = G + e, g = s.atmosphere;
	Kf(Math.max(e, 0), g);
	let _ = t - ey(o, e), v = l === 0 ? _ : _ - l, y = u === 0 ? n : n - u, b = Math.sqrt(v * v + y * y), x = Math.atan2(v, y), S = up(r, x), C = dp(S);
	if (d?.damage) {
		let e = f?.controlModel ?? X(c).controls, t = .5 * g.airDensity * b ** 2;
		if (f && f.zeroControlArea !== null && Number.isFinite(t * f.zeroControlColumnArea * Uy)) gf(d.damage, e, t, Number.isFinite(C) ? 0 : NaN, Jy), a = f.zeroControlArea;
		else {
			let n = c.gridFins ? (d.vehicle.frontFinExtension - 50) / 50 * c.gridFins.maxAngle : d.vehicle.frontFinExtension * .01 * Qc, r = d.vehicle.aftFinExtension * .01 * Qc;
			if (_f(d.damage, e, t, Math.abs(Math.sin(C)), n, r, Jy), a = c.maxArea + 1.8 * (Jy.frontArea + Jy.aftArea), f && n === 0 && r === 0) {
				f.zeroControlArea = a, f.zeroControlColumnArea = 0;
				for (let t of e.columns) f.zeroControlColumnArea = Math.max(f.zeroControlColumnArea, t.area);
			}
		}
	}
	let w = $f(W(C), a, c), T = b / Xf(g.airTemperature);
	p.angleOfMotion = W(x), p.angleOfAttack = W(S), p.aerodynamicDragAcceleration = ep(g.airDensity, b, w, rp(T)) / i, p.aerodynamicLiftAcceleration = np(g.airDensity, b, W(C), a) / i, z_(p, Nc, m), m.x += wp(h, t, n), m.y = m.y + Nc + bp(h, t);
}
var Gy = iv(), Ky = x_(), qy = av(), Jy = hf(12);
function Yy(e, t, n, r) {
	let i = e.kinematics;
	e.damage && Z(e, n, qy, Gy);
	let a = e.damage ? qy.totalMass : e.vehicle.vehicleMass;
	if (!(a > 0)) {
		r.acc.x = r.acc.y = 0;
		return;
	}
	Wy(i.altitude, i.speedX, i.speedY, t, a, e.vehicle.vehicleInFlightMaxArea, e.world.wind, r, n, e.world.gust, e.world.gustVertical, e), n.gridFins && (e.damage || rv(e.vehicle.propellantMass, Gy, n), xv(e, r.atmosphere.airDensity, i.speedX - ey(e.world.wind, i.altitude) - e.world.gust, i.speedY - e.world.gustVertical, t, Gy, n, Ky), r.acc.x += Ky.forceX / a, r.acc.y += Ky.forceY / a);
}
function Xy() {
	return {
		state: null,
		model: q,
		groundAltitude: 0,
		pitch: W(0),
		mass: 0,
		maxArea: 0,
		referenceWind: 0,
		zeroControlArea: null,
		zeroControlColumnArea: 0,
		controlModel: null,
		h: 0,
		x: 0,
		vx: 0,
		vy: 0,
		steps: 0,
		done: !0,
		result: By()
	};
}
function Zy(e, t, n, r, i) {
	t.damage && Z(t, r, qy), e.state = t, e.model = r, e.groundAltitude = n, e.pitch = i, e.mass = t.damage ? qy.totalMass : t.vehicle.vehicleMass, e.maxArea = t.vehicle.vehicleInFlightMaxArea, e.referenceWind = t.world.wind, e.zeroControlArea = null, e.zeroControlColumnArea = 0, e.controlModel = t.damage ? X(r).controls : null, e.h = t.kinematics.altitude, e.x = 0, e.vx = t.kinematics.speedX, e.vy = t.kinematics.speedY, e.steps = 0, e.done = !(e.mass > 0), e.result.reached = !1, e.result.time = NaN, e.result.downRange = e.done ? NaN : 0;
}
function Qy(e, t, n = q, r = e.kinematics.pitch) {
	let i = Xy();
	return Zy(i, e, t, n, r), i;
}
function $y(e, t, n) {
	if (e.done) return 0;
	let r = e.state, i = e.model, a = e.pitch, o = e.mass, s = e.maxArea, c = e.referenceWind, l = n.acc, u = Vy * .5, d = e.h, f = e.x, p = e.vx, m = e.vy, h = e.steps, g = 0, _ = Math.min(Math.floor(t), Hy - h);
	for (let t = 0; t < _; t++) {
		Wy(d, p, m, a, o, s, c, n, i, 0, 0, r, e);
		let t = p + l.x * u, _ = m + l.y * u;
		Wy(d + m * u, t, _, a, o, s, c, n, i, 0, 0, r, e);
		let v = p + l.x * Vy, y = m + l.y * Vy, b = d + _ * Vy, x = f + t * Vy, S = h;
		if (h++, g++, b <= e.groundAltitude) {
			let t = (d - e.groundAltitude) / (d - b);
			e.result.reached = !0, e.result.time = (S + t) * Vy, e.result.downRange = f + (x - f) * t, d = b, f = x, p = v, m = y, e.done = !0;
			break;
		}
		d = b, f = x, p = v, m = y;
	}
	return e.h = d, e.x = f, e.vx = p, e.vy = m, e.steps = h, e.result.reached || (e.result.downRange = f), h >= 4e3 && (e.done = !0), g;
}
function eb(e, t, n, r, i = q, a = e.kinematics.pitch) {
	let o = n.fallWork;
	Zy(o, e, t, i, a), $y(o, Hy, n), r.reached = o.result.reached, r.time = o.result.time, r.downRange = o.result.downRange, o.state = null;
}
//#endregion
//#region src/core/control/primitives.ts
var tb = iv(), nb = av(), rb = hf(12), ib = x_();
function ab(e, t) {
	let n = e - t;
	return n < -Math.PI ? n = Math.PI * 2 + n : n > Math.PI && (n = -(Math.PI * 2 - n)), n;
}
function ob(e, t, n, r = t, i = q) {
	let a = kv(e, n, i), o = Mv(e, n, i);
	return o === 1 ? a * Math.cos(t) : a * o * Math.cos(t) + a * (1 - o) * Math.cos(r);
}
function sb(e) {
	return Math.sqrt(35 / e * 2e3);
}
function cb(e, t, n, r = q) {
	let { kinematics: i, forces: a, status: o, vehicle: s, autopilot: c } = e, l = ab(i.pitch, t);
	e.damage ? Z(e, r, nb, tb) : rv(s.propellantMass, tb, r);
	let u = !e.damage || nb.engineSupportAvailable, d = (-l / n ** 2 - 2 * i.angularVelocity / n - (u ? a.offAxisThrustDifferenceAcceleration : 0)) * (e.damage ? nb.momentOfInertia : s.vehicleMomentOfInertia), f = 0, p = () => {
		if (Math.abs(l) > .1) {
			let e = d / tb.rcsArm;
			e > 0 ? e > 8e5 ? f = 100 : c.rcsThrustCommand = e : e < 0 ? e < -8e5 ? f = -100 : c.rcsThrustCommand = e : f = 0, c.pitchControl = f;
		}
	}, m = u ? a.thrust * Mv(e.engines.running, e.atmosphere.airPressure, r) : 0;
	m > 0 ? (() => {
		let e = d / tb.engineArm / m;
		e >= 1 ? f = 100 : e <= -1 ? f = -100 : (f = Math.asin(e) * 100 / Gc, f >= 100 ? f = 100 : f <= -100 && (f = -100)), o.rcsActive && (f *= .98), c.pitchControl = f;
	})() : o.finActive ? (() => {
		let t = sp(i.speedX, i.speedY, ty(e.world, i.altitude), e.world.gustVertical);
		if (e.damage) {
			let n = 0, a = 0, s = .5 * e.atmosphere.airDensity * t ** 2;
			if (r.gridFins) for (let t = -1; t <= 1; t += 2) xv(e, e.atmosphere.airDensity, i.speedX - ty(e.world, i.altitude), i.speedY - e.world.gustVertical, i.pitch, tb, r, ib, W(t * r.gridFins.maxAngle)), ib.torque * d > 0 && Math.abs(ib.torque) > Math.abs(n) && (n = ib.torque, a = t * 100);
			else {
				let t = Math.abs(Math.sin(i.angleInToTheWind)), o = i.angleOfAttack < 0 ? -1 : 1;
				for (let i = 0; i < 2; i++) {
					let c = i === 0;
					_f(e.damage, X(r).controls, s, t, c ? Qc : 0, c ? 0 : Qc, rb);
					let l = s * 2 * t * o * (rb.frontArea * tb.frontFinArm - rb.aftArea * tb.aftFinArm);
					l * d > 0 && Math.abs(l) > Math.abs(n) && (n = l, a = (c ? o : -o) * 100);
				}
			}
			f = n === 0 ? 0 : a * Math.min(1, Math.abs(d / n)), o.rcsActive && (f *= .99, p()), c.pitchControl = f;
			return;
		}
		if (d > 0) {
			let n = ep(e.atmosphere.airDensity, t, r.frontFinArea, 2) * Math.sin(Qc) * tb.frontFinArm + ep(e.atmosphere.airDensity, t, r.aftFinArea, 2) * tb.aftFinArm;
			f = d / n * 100, f >= 100 && (f = 100);
		} else if (d < 0) {
			let n = ep(e.atmosphere.airDensity, t, r.aftFinArea, 2) * Math.sin(Qc) * tb.aftFinArm + ep(e.atmosphere.airDensity, t, r.frontFinArea, 2) * tb.frontFinArm;
			f = d / n * 100, f <= -100 && (f = -100);
		} else f = 0;
		o.rcsActive && (f *= .99, p()), c.pitchControl = f;
	})() : p();
}
function lb(e, t, n = q) {
	ub(e, t * Cy(e), n);
}
function ub(e, t, n = q) {
	let { vehicle: r, engines: i } = e;
	e.damage && Z(e, n, nb);
	let a = !e.damage || nb.engineSupportAvailable, o = t * (e.damage ? nb.totalMass : r.vehicleMass) / (a ? kv(i.running, e.atmosphere.airPressure, n) : 0) * 100;
	Number.isNaN(o) && (o = 40), o > 100 ? o = 100 : o < 40 && (o = 40), r.throttle = o;
}
function db(e, t, n = q) {
	let { vehicle: r, engines: i } = e;
	e.damage && Z(e, n, nb);
	let a = !e.damage || nb.engineSupportAvailable, o = t * (e.damage ? nb.totalMass : r.vehicleMass) * Cy(e) / (a ? ob(i.running, r.gimbalPointingDirection, e.atmosphere.airPressure, e.kinematics.pitch, n) : 0) * 100;
	Number.isNaN(o) && (o = 40), o > 100 ? o = 100 : o < 40 && (o = 40), r.throttle = o;
}
function fb(e, t, n, r, i) {
	let a = e.kinematics.speedX - t;
	a < 0 ? (cb(e, n, i), -a < r && cb(e, W(n * -a / r), i)) : (cb(e, W(-n), i), a < r && cb(e, W(-n * a / r), i));
}
function pb(e, t, n, r) {
	let i = e.kinematics.speedY - t;
	i < 0 ? (db(e, r), -i < n && db(e, 1 - i / n)) : (db(e, 0), i < n && db(e, 1 - i / n));
}
function mb(e, t, n, r, i = q) {
	let a = t - e.kinematics.trueSpeed;
	a < 0 ? lb(e, 0, i) : (lb(e, r, i), a < n && lb(e, 1 + a / n, i));
}
function hb(e, t, n) {
	return e / (t * n);
}
function gb(e, t, n, r) {
	let { status: i, kinematics: a, autopilot: o } = e;
	i.finActive || r(e), o.horizontalAccelerationByAeroBreakingCorrectionAngle = Math.abs(a.accelerationX) > Math.abs(t) ? W(o.horizontalAccelerationByAeroBreakingCorrectionAngle - Sl * n) : W(o.horizontalAccelerationByAeroBreakingCorrectionAngle + Sl * n), o.horizontalAccelerationByAeroBreakingCorrectionAngle > xl ? o.horizontalAccelerationByAeroBreakingCorrectionAngle = xl : o.horizontalAccelerationByAeroBreakingCorrectionAngle < 0 && (o.horizontalAccelerationByAeroBreakingCorrectionAngle = W(0)), t < 0 ? cb(e, W(o.horizontalAccelerationByAeroBreakingCorrectionAngle - Math.PI / 2), 1.5) : cb(e, W(-o.horizontalAccelerationByAeroBreakingCorrectionAngle + Math.PI / 2), 1.5);
}
function _b(e, t, n = q) {
	let { engines: r } = e;
	if (Z(e, n, nb), !nb.engineSupportAvailable || !nb.hasMass) return;
	let i = r.running;
	if (hb(Av(i, e.atmosphere.airPressure, n), nb.totalMass, Cy(e)) > 1) {
		let r = Dv(i, n);
		if (r === 0) return;
		let a = r === 3 ? 0 : r === 2 ? i[0] && i[1] ? 0 : i[1] && i[2] ? 1 : 2 : i[0] ? 0 : i[1] ? 1 : 2;
		if (i[a] && n.engines[a]?.kind === "sea-level") t(e, a);
		else for (let r = 0; r < n.engines.length; r++) if (i[r] && n.engines[r].kind === "sea-level") {
			t(e, r);
			break;
		}
	}
}
//#endregion
//#region src/core/physics/tower-catch.ts
function vb() {
	return {
		x: 0,
		altitude: 0,
		speedX: 0,
		speedY: 0
	};
}
function yb(e, t, n) {
	let r = e.kinematics, i = Y.lugStation - t.height / 2;
	n.x = r.downRangeDistance + i * Math.sin(r.pitch), n.altitude = r.altitude + i * Math.cos(r.pitch), n.speedX = r.speedX + i * Math.cos(r.pitch) * r.angularVelocity, n.speedY = r.speedY - i * Math.sin(r.pitch) * r.angularVelocity;
}
var bb = vb(), xb = vb(), Sb = {
	fraction: 0,
	pitch: 0,
	x: 0,
	speedX: 0,
	speedY: 0
};
function Cb(e, t, n) {
	if (n.id !== "super-heavy" || t.status.landed) return !1;
	let r = t.failures;
	if (r.crashed || r.inFlightBreakUp || r.fuelRunOut) return !1;
	let i = t.kinematics, a = n.height * Math.abs(Math.cos(i.pitch)) / 2 + n.diameter * Math.abs(Math.sin(i.pitch)) / 2;
	if (i.altitude <= a || (yb(e, n, bb), yb(t, n, xb), !(bb.altitude > Y.planeAltitude && xb.altitude <= Y.planeAltitude))) return !1;
	let o = (bb.altitude - Y.planeAltitude) / (bb.altitude - xb.altitude), s = e.kinematics, c = Math.atan2(Math.sin(i.pitch - s.pitch), Math.cos(i.pitch - s.pitch));
	return Sb.fraction = o, Sb.pitch = s.pitch + c * o, Sb.x = s.downRangeDistance + (i.downRangeDistance - s.downRangeDistance) * o + (Y.lugStation - n.height / 2) * Math.sin(Sb.pitch), Sb.speedX = bb.speedX + (xb.speedX - bb.speedX) * o, Sb.speedY = bb.speedY + (xb.speedY - bb.speedY) * o, Number.isFinite(Sb.x) && Number.isFinite(Sb.pitch) && Number.isFinite(Sb.speedX) && Number.isFinite(Sb.speedY) && Math.abs(Sb.x - K) <= Y.halfWidth && Math.abs(Sb.speedX) <= Y.maxLateralSpeed && Sb.speedY < 0 && Sb.speedY >= -Y.maxDownSpeed && Math.abs(Sb.pitch) <= Y.maxPitch;
}
function wb(e, t, n) {
	if (!Cb(e, t, n)) return !1;
	let r = t.kinematics, i = e.kinematics;
	return r.downRangeDistance = i.downRangeDistance + (r.downRangeDistance - i.downRangeDistance) * Sb.fraction, r.downRangeDistanceNextFrame = r.downRangeDistance, r.pitch = W(Sb.pitch), r.altitude = Y.planeAltitude - (Y.lugStation - n.height / 2) * Math.cos(r.pitch), r.distanceToPlanetCenter = G + r.altitude, r.speedX = r.speedY = r.trueSpeed = r.angularVelocity = 0, r.accelerationX = r.accelerationY = r.totalAcceleration = r.angularAcceleration = 0, t.status.landed = !0, t.status.onTheGround = !1, t.engines.running.fill(!1), t.engines.ignitionCountdown.fill(null), t.forces.thrust = t.forces.thrustAcceleration = t.forces.twr = t.forces.rcsThrust = 0, t.autopilot.pitchControl = t.autopilot.rcsThrustCommand = 0, !0;
}
//#endregion
//#region src/core/control/booster-arrival.ts
var Tb = av(), Eb = .3;
function Db() {
	return {
		pitch: W(0),
		throttle: 100,
		requiredX: 0,
		requiredY: 0,
		deliveredX: 0,
		deliveredY: 0
	};
}
function Ob(e, t, n, r, i) {
	Z(e, r, Tb);
	let a = e.kinematics, o = Tb.totalMass;
	if (!Tb.hasMass) {
		i.pitch = W(0), i.throttle = 100, i.requiredX = i.requiredY = i.deliveredX = i.deliveredY = 0;
		return;
	}
	let s = Mv(e.engines.running, e.atmosphere.airPressure, r), c = e.forces.thrust / o, l = e.damage ? e.forces.paidThrustAccelerationX : c * (s * Math.sin(e.vehicle.gimbalPointingDirection) + (1 - s) * Math.sin(a.pitch)), u = e.damage ? e.forces.paidThrustAccelerationY : c * (s * Math.cos(e.vehicle.gimbalPointingDirection) + (1 - s) * Math.cos(a.pitch));
	i.requiredX = t - (a.accelerationX - l), i.requiredY = n - (a.accelerationY - u), i.pitch = W(Math.max(-.3, Math.min(Eb, Math.atan2(i.requiredX, Math.max(0, i.requiredY)))));
	let d = Math.max(0, i.requiredY) / Math.cos(i.pitch), f = Tb.engineSupportAvailable ? kv(e.engines.running, e.atmosphere.airPressure, r) / o : 0;
	i.throttle = f > 0 ? Math.max(40, Math.min(100, 100 * d / f)) : 100, i.deliveredX = f * i.throttle * .01 * Math.sin(i.pitch), i.deliveredY = f * i.throttle * .01 * Math.cos(i.pitch);
}
var kb = Ty(), Ab = Db();
function jb(e, t, n, r, i, a) {
	return Yy(e, W(a), r, kb), Ab.requiredX = t - kb.acc.x, Ab.requiredY = n - kb.acc.y, Ab.pitch = W(a), Ab.throttle = i > 0 ? Math.max(40, Math.min(100, 100 * Math.max(0, Ab.requiredY) / (i * Math.cos(a)))) : 100, Ab.deliveredX = i * Ab.throttle * .01 * Math.sin(a), Ab.deliveredY = i * Ab.throttle * .01 * Math.cos(a), Ab.deliveredX - Ab.requiredX;
}
function Mb(e, t) {
	let n = (Ab.deliveredX - Ab.requiredX) ** 2 + (Ab.deliveredY - Ab.requiredY) ** 2;
	return n >= t ? t : (Object.assign(e, Ab), n);
}
function Nb(e, t, n, r, i, a = Eb) {
	Z(e, r, Tb);
	let o = Tb.engineSupportAvailable && Tb.hasMass ? kv(e.engines.running, e.atmosphere.airPressure, r) / Tb.totalMass : 0, s = Math.max(0, Math.min(Eb, a)), c = -s, l = jb(e, t, n, r, o, c), u = Mb(i, Infinity);
	for (let a = 1; a <= 16; a++) {
		let d = -s + 2 * s * a / 16, f = jb(e, t, n, r, o, d);
		if (u = Mb(i, u), l * f < 0) {
			let a = c, s = d, f = l;
			for (let c = 0; c < 12; c++) {
				let c = (a + s) / 2, l = jb(e, t, n, r, o, c);
				u = Mb(i, u), f * l <= 0 ? s = c : (a = c, f = l);
			}
		}
		c = d, l = f;
	}
}
function Pb(e, t, n) {
	if (Z(e, n, Tb), !Tb.engineSupportAvailable || !Tb.hasMass) return 100;
	let r = Mv(e.engines.running, e.atmosphere.airPressure, n), i = r * Math.cos(e.vehicle.gimbalPointingDirection) + (1 - r) * Math.cos(e.kinematics.pitch), a = e.damage ? e.forces.paidThrustAccelerationY : e.forces.thrust / Tb.totalMass * i, o = e.kinematics.accelerationY - a;
	Z(e, n, Tb);
	let s = Tb.engineSupportAvailable && Tb.hasMass ? kv(e.engines.running, e.atmosphere.airPressure, n) / Tb.totalMass : 0;
	return s <= 0 || i <= 0 ? 100 : Math.max(40, Math.min(100, 100 * Math.max(0, t - o) / (s * i)));
}
function Fb() {
	return {
		x: 0,
		height: 0,
		vx: 0,
		vy: 0,
		time: 0,
		ax: 0,
		ay: 0,
		bodyAX: 0,
		bodyAY: 0,
		centreAX: 0,
		centreAY: 0,
		lateralFeasible: !0
	};
}
var Ib = vb(), Lb = Object.freeze([
	!0,
	!0,
	!0
]), Rb = Db();
function zb(e, t, n, r) {
	Z(e, n, Tb);
	let i = Tb.engineSupportAvailable && Tb.hasMass && Lb.every((t, n) => !e.engines.failed[n]), a = Tb.totalMass;
	yb(e, n, Ib), r.x = Ib.x - K, r.height = Ib.altitude - Y.planeAltitude, r.vx = Ib.speedX, r.vy = Ib.speedY;
	let o = e.autopilot;
	if (o.boosterArrivalTime === void 0) {
		let e = Math.max(0, r.height), t = Math.max(0, -r.vy), s = 2 * e / (t + 2), c = (i ? kv(Lb, Jc / 1e3, n) / a : 0) + bp(G + Y.bodyCentreAltitude, 0), l = c > 0 ? 6 * e / (Math.sqrt((t + 4) ** 2 + 6 * c * e) + t + 4) : 60;
		o.boosterArrivalTime = Math.max(.5, Math.min(60, Math.max(s, l)));
	}
	o.boosterArrivalTime = Math.max(0, o.boosterArrivalTime - t), r.time = Math.max(.25, o.boosterArrivalTime), r.ax = -6 * r.x / r.time ** 2 - 4 * r.vx / r.time, r.ay = -6 * r.height / r.time ** 2 - 4 * r.vy / r.time + 4 / r.time;
	let s = e.kinematics, c = Y.lugStation - n.height / 2;
	r.bodyAX = r.ax - c * (Math.cos(s.pitch) * s.angularAcceleration - Math.sin(s.pitch) * s.angularVelocity ** 2), r.bodyAY = r.ay + c * (Math.sin(s.pitch) * s.angularAcceleration + Math.cos(s.pitch) * s.angularVelocity ** 2), r.centreAX = -6 * (s.downRangeDistance - K) / r.time ** 2 - 4 * s.speedX / r.time, r.centreAY = -6 * (s.altitude - Y.bodyCentreAltitude) / r.time ** 2 - 4 * s.speedY / r.time + 4 / r.time;
	let l = i ? kv(Lb, e.atmosphere.airPressure, n) / a * Math.sin(Eb) : 0;
	Ob(e, r.ax, r.ay, n, Rb);
	let u = Rb.requiredX;
	Ob(e, 6 * r.x / r.time ** 2 + 2 * r.vx / r.time, 6 * r.height / r.time ** 2 + 2 * r.vy / r.time - 8 / r.time, n, Rb), r.lateralFeasible = i && Number.isFinite(u) && Number.isFinite(Rb.requiredX) && Math.abs(u) <= l && Math.abs(Rb.requiredX) <= l;
}
//#endregion
//#region src/core/control/booster-return-plan.ts
function Bb(e) {
	delete e.boosterPrediction, delete e.boosterReturnPlan;
}
function Vb(e) {
	let t = e.autopilot, n = e.damage?.revision, r = t.boosterPrediction && t.boosterPrediction.origin.damage?.revision !== n, i = t.boosterReturnPlan && t.boosterReturnPlan.damageRevision !== n;
	return !r && !i ? !1 : (Bb(t), delete t.boosterCoastPitch, delete t.boosterForecastReached, delete t.boosterRangeError, delete t.boosterFallTime, !0);
}
function Hb(e) {
	let t = e.forecast;
	return t.reached && !t.failed && t.fuel > 0 && t.handoff !== void 0 && Number.isFinite(t.rangeError) && Number.isFinite(e.shutdownAt) && Number.isFinite(e.burnDuration) && e.burnDuration >= 0;
}
function Ub(e, t) {
	if (!Hb(e) || !Hb(t) || e.originTime !== t.originTime || e.damageRevision !== t.damageRevision || e.sourceLineage !== t.sourceLineage || e.coastPitch !== t.coastPitch || t.burnDuration <= e.burnDuration || e.forecast.rangeError * t.forecast.rangeError >= 0) return;
	let n = e.forecast.rangeError / (e.forecast.rangeError - t.forecast.rangeError);
	return e.burnDuration + (t.burnDuration - e.burnDuration) * n;
}
function Wb(e, t, n, r = 0) {
	if (!Hb(e) || !Hb(t) || e.originTime !== t.originTime || e.damageRevision !== t.damageRevision || e.sourceLineage !== t.sourceLineage || e.coastPitch !== t.coastPitch || e.burnDuration === t.burnDuration || e.forecast.rangeError * t.forecast.rangeError <= 0) return;
	let i = t.forecast.rangeError - e.forecast.rangeError, a = t.burnDuration - t.forecast.rangeError * (t.burnDuration - e.burnDuration) / i, o = t.burnDuration > e.burnDuration ? a > t.burnDuration : a < t.burnDuration;
	return Number.isFinite(a) && o && a > r && a < n ? a : void 0;
}
function Gb(e, t, n) {
	if (!(!Hb(e) || !t || !e.forecast.handoff.lateralFeasible || e.shutdownAt <= n)) return {
		originTime: e.originTime,
		shutdownAt: e.shutdownAt,
		...e.damageRevision === void 0 ? {} : { damageRevision: e.damageRevision },
		...e.sourceLineage === void 0 ? {} : { sourceLineage: e.sourceLineage },
		coastPitch: e.coastPitch,
		handoff: { ...e.forecast.handoff }
	};
}
function Kb(e, t, n, r) {
	if (Ub(n, r) === void 0 || !Hb(e) || !Hb(t) || e.originTime !== t.originTime || e.damageRevision !== t.damageRevision || e.sourceLineage !== t.sourceLineage || t.damageRevision !== n.damageRevision || t.sourceLineage !== n.sourceLineage || t.originTime !== n.originTime || e.coastPitch !== t.coastPitch || t.coastPitch !== n.coastPitch || e.burnDuration === t.burnDuration) return;
	let i = t.forecast.rangeError - e.forecast.rangeError, a = t.burnDuration - t.forecast.rangeError * (t.burnDuration - e.burnDuration) / i;
	return Number.isFinite(a) && a > n.burnDuration && a < r.burnDuration ? a : void 0;
}
//#endregion
//#region src/core/control/commands.ts
function qb(e, t) {
	let { engines: n, failures: r } = e, i = n.ignitionCountdown[t] !== null;
	!n.running[t] && !i && !n.failed[t] && !r.fuelRunOut ? Bv(e, t) || zv(e, t) : Hv(e, t);
}
function Jb(e, t = q) {
	let { running: n } = e.engines;
	if (n.some(Boolean)) for (let t = 0; t < n.length; t++) n[t] && qb(e, t);
	else for (let r of t.ignitionGroup) n[r] || qb(e, r);
}
function Yb(e) {
	e.status.finActive = !e.status.finActive;
}
function Xb(e) {
	e.status.rcsActive = !e.status.rcsActive;
}
function Zb(e) {
	e.status.dumpingFuel = !e.status.dumpingFuel;
}
function Qb(e) {
	e.autopilot.holdingPitch = e.kinematics.pitch;
}
function $b(e, t) {
	e.vehicle.throttle = Math.min(100, Math.max(40, t));
}
function ex(e, t) {
	e.autopilot.pitchControl = Math.min(100, Math.max(-100, t));
}
function tx(e) {
	e.autopilot.pitchHoldOn && rx(e, !0);
}
function nx(e) {
	e.autopilot.pitchHoldOn && (Qb(e), rx(e, !1));
}
function rx(e, t) {
	e.autopilot.manualControlOn = t;
}
function ix(e) {
	e.autopilot.pitchHoldOn = !e.autopilot.pitchHoldOn;
}
function ax(e) {
	e.autopilot.autoMaxThrustOn = !e.autopilot.autoMaxThrustOn;
}
function ox(e) {
	e.autopilot.autoTakeOffOn = !e.autopilot.autoTakeOffOn;
}
function sx(e) {
	e.autopilot.autoBoostBackOn = !e.autopilot.autoBoostBackOn;
}
function cx(e) {
	e.autopilot.autoLandOn = !e.autopilot.autoLandOn;
}
function lx(e) {
	let { autopilot: t } = e;
	t.autoDeorbitOn = !t.autoDeorbitOn, t.autoDeorbitOn || (t.deorbitInitCompleted = !1, t.deorbitBurnStarted = !1, t.deorbitBurnCompleted = !1, t.deorbitTargetSpeed = void 0);
}
//#endregion
//#region src/core/state.ts
var ux = 1463897163;
function dx(e = ux, t = q) {
	let n = t.height / 2, r = G + n, i = t.dryMass + t.initialPropellant;
	return {
		damage: Jd(X(t).partition, D_(n, If(n).airTemperature)),
		rng: W_(e),
		world: {
			environmentTime: 0,
			timeSpent: 0,
			updatedFrameCount: 0,
			wind: 0,
			gust: 0,
			gustVertical: 0,
			turbulenceU: 0,
			turbulenceW1: 0,
			turbulenceW2: 0
		},
		atmosphere: {
			airDensity: 0,
			airPressure: 0,
			airTemperature: 0
		},
		kinematics: {
			altitude: n,
			downRangeDistance: K,
			downRangeDistanceNextFrame: K,
			distanceToPlanetCenter: r,
			orbitalVelocityAtCurrentAltitude: yp(r),
			trueSpeed: 0,
			speedX: 0,
			speedY: 0,
			machSpeed: 0,
			accelerationX: 0,
			accelerationY: 0,
			totalAcceleration: Math.sqrt(0 + (-Nc) ** 2),
			pitch: W(0),
			pitchRateOfChange: 0,
			pitchRecord: t.gridFins ? [0, 0] : [Infinity, Infinity],
			angularVelocity: 0,
			angularAcceleration: 0,
			angleOfMotion: W(0),
			angleOfAttack: W(0),
			angleInToTheWind: W(0)
		},
		forces: {
			thrust: 0,
			thrustAcceleration: 0,
			paidThrustAccelerationX: 0,
			paidThrustAccelerationY: 0,
			offAxisThrustDifferenceAcceleration: 0,
			twr: 0,
			thrustVectorForce: 0,
			thrustVectorAcceleration: 0,
			rcsThrust: 0,
			rcsThrustAngularAcceleration: 0,
			angularDragAcceleration: 0,
			crossSectionalArea: 100,
			aerodynamicDrag: 0,
			aerodynamicLift: 0,
			aerodynamicDragAcceleration: 0,
			aerodynamicLiftAcceleration: 0,
			frontFinDrag: 0,
			aftFinDrag: 0,
			frontFinDragAngularAcceleration: 0,
			aftFinDragAngularAcceleration: 0,
			frontFinEffectiveAreaFraction: hp(0, 0, t).frontFinEffectiveAreaFraction,
			aftFinEffectiveAreaFraction: hp(0, 0, t).aftFinEffectiveAreaFraction,
			thermalPower: 0,
			surfaceTemperature: 0,
			dynamicPressure: 0,
			perceivedG: 0,
			perceivedG_X: 0,
			perceivedG_Y: 0
		},
		vehicle: {
			vehicleMass: i,
			propellantMass: t.initialPropellant,
			vehicleMomentOfInertia: t.gridFins ? tv(t.initialPropellant, t) : i * (t.diameter / 2) ** 2 * .25 + i * t.height ** 2 / 12,
			vehicleInFlightMaxArea: t.maxArea,
			throttle: 100,
			throttleCurrent: 100,
			gimbalPosition: 0,
			gimbalPointingDirection: W(0),
			frontFinExtension: t.gridFins ? 50 : 0,
			aftFinExtension: t.gridFins ? 50 : 0,
			rcsRunTimeRemaining: 25
		},
		engines: {
			running: t.engines.map(() => !1),
			failed: t.engines.map(() => !1),
			ignitionCountdown: t.engines.map(() => null)
		},
		status: {
			onTheGround: !1,
			landed: !1,
			rcsActive: !1,
			finActive: !1,
			finLocked: !1,
			gearDown: !1,
			dumpingFuel: !1,
			forceDump: !1,
			translationModeOn: !0
		},
		warnings: {
			coldGasLow: !1,
			fuelLow: !1,
			heatDamagedWarning: !1,
			overPressureWarning: !1,
			overGLoadWarning: !1
		},
		failures: {
			crashed: !1,
			inFlightBreakUp: !1,
			coldGasRunOut: !1,
			fuelRunOut: !1,
			heatDamaged: !1,
			overPressure: !1,
			overGLoad: !1,
			flippedOver: !1,
			randomFailure: !1
		},
		autopilot: {
			manualControlOn: !1,
			rcsThrustCommand: 0,
			pitchControl: 0,
			holdingPitch: W(0),
			pitchHoldOn: !1,
			autoBoostBackOn: !1,
			boostBackInitCompleted: !1,
			boostBackAeroDeceleration: !0,
			boostBackDecelerationStageInitCompleted: !1,
			boostBackDecelerationCheckCountdown: null,
			accelerationStageCompleted: !1,
			boostBackDirection: 0,
			decelerationStageEstDuration: 0,
			autoDeorbitOn: !1,
			deorbitInitCompleted: !1,
			deorbitBurnStarted: !1,
			deorbitBurnCompleted: !1,
			deorbitTargetSpeed: void 0,
			autoLandOn: !1,
			initVehicleConfigCompleted: !1,
			landingSiteXPos: K,
			aeroDescentCompleted: !1,
			fineTunePercentage: void 0,
			bellyFlopTriggerAltitude: 0,
			flipStageInitialised: !1,
			flipCompleted: !1,
			horizontalAdjustmentStageCompleted: !1,
			horizontalAdjustmentStageInitialised: !1,
			horizontalAdjustmentTimeLeft: void 0,
			horizontalAdjustmentDesiredSpeed: void 0,
			effectiveVerticalMaxThrust: void 0,
			finalStagePessimisticAltitude: void 0,
			finalDescentStageInitialised: !1,
			distanceToGround: void 0,
			finalDescentStageCompleted: !1,
			autoMaxThrustOn: !1,
			autoTakeOffOn: !1,
			autoTakeOffInitialised: !1,
			horizontalAdjustmentVerticalSpeedLimit: -30,
			horizontalAdjustmentHorizontalSpeedLimit: 5,
			demoAutoLandOn: !1,
			horizontalAccelerationByAeroBreakingCorrectionAngle: W(0)
		}
	};
}
function fx(e) {
	return {
		damage: e.damage ? Yd(e.damage) : null,
		rng: {
			seed: e.rng.seed,
			counters: { ...e.rng.counters }
		},
		world: { ...e.world },
		atmosphere: { ...e.atmosphere },
		kinematics: {
			...e.kinematics,
			pitchRecord: [e.kinematics.pitchRecord[0], e.kinematics.pitchRecord[1]]
		},
		forces: { ...e.forces },
		vehicle: { ...e.vehicle },
		engines: {
			running: [...e.engines.running],
			failed: [...e.engines.failed],
			ignitionCountdown: [...e.engines.ignitionCountdown]
		},
		status: { ...e.status },
		warnings: { ...e.warnings },
		failures: { ...e.failures },
		autopilot: {
			...e.autopilot,
			...e.autopilot.boosterReturnPlan ? { boosterReturnPlan: xx(e.autopilot.boosterReturnPlan) } : {},
			...e.autopilot.boosterSource ? { boosterSource: {
				...e.autopilot.boosterSource,
				returned: fx(e.autopilot.boosterSource.returned),
				expected: e.autopilot.boosterSource.expected ? fx(e.autopilot.boosterSource.expected) : void 0,
				event: Sx(e.autopilot.boosterSource.event)
			} } : {}
		}
	};
}
//#endregion
//#region src/core/control/booster-receipts.ts
function px(e, t) {
	let n = e.autopilot;
	return t === 1 / 120 && !!e.damage && !n.manualControlOn && (n.autoLandOn || n.autoBoostBackOn) && !n.boosterReturnPlan && (n.boosterPhase === "align-boost" || n.boosterPhase === "boostback" && !uu.every((t) => e.engines.running[t]));
}
function mx(e, t) {
	for (let n of [
		"boosterFallTime",
		"boosterCoastPitch",
		"boosterForecastBurn"
	]) Object.hasOwn(t.autopilot, n) ? Object.assign(e.autopilot, { [n]: t.autopilot[n] }) : delete e.autopilot[n];
}
function hx(e) {
	if (e && typeof e == "object") {
		for (let t in e) hx(e[t]);
		Object.freeze(e);
	}
	return e;
}
function gx(e) {
	if (!e || typeof e != "object") return e;
	let t = Array.isArray(e) ? [] : {};
	for (let n in e) t[n] = gx(e[n]);
	return t;
}
function _x(e, t, n, r, i, a, o, s, c) {
	return Object.freeze({
		input: hx($(e)),
		expected: hx($(t)),
		returned: hx($(n)),
		dt: r,
		advance: i,
		policy: a,
		model: o,
		modelSnapshot: hx(gx(o)),
		lineage: s,
		revision: c
	});
}
function vx(e, t) {
	let n = e?.chunks, r = n?.[n.length - 1], i = r?.[r.length - 1];
	return (e?.size ?? 0) < 1024 && (!i || t > i.input.world.environmentTime) && (!r || r.length < 32 || n.length < 32);
}
function yx(e, t) {
	if (!vx(e, t.input.world.environmentTime)) return e;
	let n = [...e?.chunks ?? []], r = n[n.length - 1];
	return r && r.length < 32 ? n[n.length - 1] = Object.freeze([...r, t]) : n.push(Object.freeze([t])), Object.freeze({
		chunks: Object.freeze(n),
		size: (e?.size ?? 0) + 1
	});
}
function bx(e, t, n, r, i, a, o, s) {
	let c = 0, l = 0, u = 0;
	for (; c < e.chunks.length;) {
		let n = e.chunks[c];
		for (; l < n.length && n[l].input.world.environmentTime < t.world.environmentTime;) l++, u++;
		if (l < n.length) break;
		c++, l = 0;
	}
	let d = e.chunks[c]?.[l], f;
	if (d && d.input.world.environmentTime === t.world.environmentTime && d.lineage === o && d.revision === s && d.dt === n && d.advance === r && d.policy === i && d.model === a && Ex(d.modelSnapshot, a)) {
		let e = $(d.input);
		mx(e, t), Ex(e, t) && (f = d, l++, u++);
	}
	if (!u) return {
		receipt: f,
		queue: e
	};
	let p = e.chunks.slice(c);
	return p[0] && (l === p[0].length ? p.shift() : l > 0 && (p[0] = Object.freeze(p[0].slice(l)))), {
		receipt: f,
		queue: Object.freeze({
			chunks: Object.freeze(p),
			size: e.size - u
		})
	};
}
//#endregion
//#region src/core/control/booster-source.ts
function xx(e) {
	return e ? {
		...e,
		handoff: { ...e.handoff }
	} : void 0;
}
function Sx(e) {
	let t = xx(e.plan);
	return t && (Object.freeze(t.handoff), Object.freeze(t)), Object.freeze({
		...e,
		plan: t
	});
}
function $(e) {
	let t = { ...e.autopilot };
	return delete t.boosterSource, delete t.boosterPrediction, fx({
		...e,
		autopilot: t
	});
}
function Cx(e, t) {
	let n = e.autopilot;
	return Sx({
		phase: "post-step",
		time: e.world.environmentTime,
		sequence: t,
		rangeError: n.boosterRangeError,
		fallTime: n.boosterFallTime,
		coastPitch: n.boosterCoastPitch,
		reached: n.boosterForecastReached,
		plan: n.boosterReturnPlan
	});
}
function wx(e, t) {
	let n = e.autopilot;
	t.rangeError === void 0 ? delete n.boosterRangeError : n.boosterRangeError = t.rangeError, t.fallTime === void 0 ? delete n.boosterFallTime : n.boosterFallTime = t.fallTime, t.coastPitch === void 0 ? delete n.boosterCoastPitch : n.boosterCoastPitch = t.coastPitch, t.reached === void 0 ? delete n.boosterForecastReached : n.boosterForecastReached = t.reached;
	let r = xx(t.plan);
	r ? n.boosterReturnPlan = r : delete n.boosterReturnPlan;
}
function Tx(e) {
	let t = e.autopilot;
	t.boosterSource && (t.boosterSource.valid = !1), delete t.boosterReturnPlan, delete t.boosterCoastPitch, delete t.boosterForecastReached, t.boosterPrediction?.published && (t.boosterPrediction = {
		...t.boosterPrediction,
		published: void 0
	});
}
function Ex(e, t, n = !1) {
	if (Object.is(e, t)) return !0;
	if (e === null || t === null || typeof e != "object" || typeof t != "object" || Array.isArray(e) !== Array.isArray(t) || Array.isArray(e) && e.length !== t.length) return !1;
	let r = e, i = t;
	for (let e in r) if (!(n && (e === "boosterSource" || e === "boosterPrediction")) && (!(e in i) || !Ex(r[e], i[e], e === "autopilot"))) return !1;
	for (let e in i) if (!(n && (e === "boosterSource" || e === "boosterPrediction")) && !(e in r)) return !1;
	return !0;
}
function Dx(e, t) {
	if (!e.damage) return !0;
	let n = e.autopilot, r = n.boosterSource;
	return r ? r.revision !== e.damage.revision || !r.valid || !r.expected || r.expectedDt !== t || !Ex(r.expected, e) || n.boosterReturnPlan && n.boosterReturnPlan.sourceLineage !== r.lineageId ? (Tx(e), !1) : (r.checked = !0, !0) : !n.boosterReturnPlan || (Tx(e), !1);
}
function Ox(e) {
	if (!e.damage) return;
	let t = e.autopilot, n = t.boosterSource;
	if (n && n.revision === e.damage.revision && (n.valid || t.boosterPrediction && !t.boosterPrediction.done)) return;
	n && delete t.boosterPrediction, delete t.boosterReturnPlan;
	let r = $(e);
	t.boosterSource = {
		lineageId: (n?.lineageId ?? 0) + 1,
		revision: e.damage.revision,
		originTime: e.world.environmentTime,
		valid: !0,
		checked: !0,
		returned: r,
		expected: void 0,
		expectedDt: 0,
		event: Cx(e, 0)
	};
}
function kx(e, t, n, r, i, a) {
	let o = e.autopilot.boosterSource;
	if (!o || !o.valid) return 0;
	if (!o.checked || o.returned.world.environmentTime !== e.world.environmentTime) return Tx(e), 0;
	let s = Cx(e, o.event.sequence + 1), c = $(o.returned);
	if (wx(c, s), a) return Ex(s, a.event) ? (e.autopilot.boosterSource = {
		...o,
		event: s,
		returned: $(a.returned),
		expected: $(a.expected),
		expectedDt: t,
		checked: !1
	}, 0) : (Tx(e), 0);
	let l, u = n(c, t, (e, t, n) => {
		l = $(e), r(e, t, n);
	}, i);
	return e.autopilot.boosterSource = {
		...o,
		event: s,
		returned: $(u),
		expected: l,
		expectedDt: t,
		checked: !1,
		valid: l !== void 0
	}, l || Tx(e), 1;
}
function Ax(e, t, n, r, i) {
	let a = e.autopilot.boosterSource;
	if (!a?.valid || !a.checked || !a.receipts || a.returned.world.environmentTime !== e.world.environmentTime) return;
	let o = Cx(e, a.event.sequence + 1), s = $(a.returned);
	if (wx(s, o), !px(s, t)) return;
	let c = bx(a.receipts, s, t, n, r, i, a.lineageId, a.revision);
	if (e.autopilot.boosterSource = {
		...a,
		receipts: c.queue
	}, !c.receipt) return;
	let l = $(c.receipt.expected), u = $(c.receipt.returned);
	return mx(l, s), mx(u, s), {
		event: o,
		expected: l,
		returned: u
	};
}
function jx(e, t, n, r, i, a, o, s) {
	let c = e.autopilot.boosterSource;
	if (!n || !Nx(e, t, i)) return;
	let l = _x(t, n, r, i, a, o, s, c.lineageId, c.revision);
	e.autopilot.boosterSource = {
		...c,
		receipts: yx(c.receipts, l)
	};
}
function Mx(e, t) {
	let n = e.autopilot.boosterSource;
	return !!n && Ex(Cx(e, n.event.sequence + 1), t.event);
}
function Nx(e, t, n) {
	let r = e.autopilot.boosterSource;
	return !!r?.valid && px(t, n) && vx(r.receipts, t.world.environmentTime);
}
//#endregion
//#region src/core/control/booster-forecast.ts
function Px() {
	return {
		reached: !1,
		rangeError: 0,
		time: 0,
		fuel: 0,
		speedX: 0,
		speedY: 0,
		pitch: 0,
		steps: 0,
		ignitionDraws: 0,
		failed: !1
	};
}
var Fx = vb(), Ix = vb(), Lx = Fb();
function Rx(e) {
	let t = e * 120, n = Math.round(t);
	return e === n / 120 ? n : Math.ceil(t);
}
function zx(e) {
	return Rx(e) / 120;
}
function Bx(e, t) {
	return Math.max(0, Rx(e) - t.boostSteps - 6 * t.steadySteps) / 120;
}
function Vx(e, t, n = 0) {
	let r = $(e);
	if (delete r.autopilot.boosterPrediction, delete r.autopilot.boosterForecastHandoff, r.autopilot.boosterPhase === "align-boost" || r.autopilot.boosterPhase === "boostback" && n <= 0 || !r.autopilot.boosterPhase) {
		r.autopilot.boosterPhase = "coast";
		for (let e = 0; e < r.engines.running.length; e++) Hv(r, e);
	}
	return r.autopilot.boosterCoastPitch = t, {
		state: r,
		initialTime: r.autopilot.boosterFallTime ?? 900,
		initialDraws: r.rng.counters.ignitionFailure,
		burnRemaining: zx(n),
		burnTicks: Rx(n),
		cutoffClock: r.world.environmentTime,
		done: !1,
		result: Px()
	};
}
function Hx(e, t, n, r, i, a) {
	let o = e.result, s = e.state, c = 0, l = e.reusePrefix, u = e.burnRemaining;
	l && (u = Bx(u, l)), l && l.origin === e.origin && l.advance === n && l.policy === r && l.model === i && e.step === void 0 && e.initialTime === l.initialTime && s.autopilot.boosterCoastPitch === l.coastPitch && u > 0 && o.steps === 0 && (s = $(l.state), s.autopilot.boosterForecastBurn = !0, o.time = l.time, o.steps = l.steps, e.prefix = l, e.burnRemaining = u, e.burnTicks = Math.round(u * 120), e.cutoffClock = l.cutoffClock, e.boostSteps = l.boostSteps, e.steadySteps = l.steadySteps), delete e.reusePrefix;
	for (let l = 0; l < t && !e.done; l++) {
		yb(s, i, Fx);
		let t = s.autopilot.boosterPhase, l = t === "align-boost" || t === "boostback" || t === "entry" || t === "terminal", u = t === "boostback" && !uu.every((e) => s.engines.running[e]), d = u || t === "entry" && !(s.autopilot.boosterEntryCentreOnly ? lu : uu).every((e) => s.engines.running[e]) || t === "terminal" && !lu.every((e) => s.engines.running[e]), f = t === "align-boost" || d || t === "terminal" && s.autopilot.boosterArrivalTime === void 0 ? 1 / 120 : e.step ?? (e.stopAtHandoff && l || s.kinematics.altitude < 2e3 ? .05 : .25), p = t === "boostback" || !e.stopAtHandoff && e.burnRemaining > 0, m = p && e.burnTicks > 0 ? e.burnTicks < 6 ? 1 / 120 : Math.min(f, .05) : f;
		e.burnRemaining > 0 && (s.autopilot.boosterForecastBurn = !0), s.autopilot.boosterFallTime = Math.max(2, e.initialTime - o.time);
		let h = a?.eligible(s, m), g = h ? $(s) : void 0, _;
		if (s = n(s, m, h ? (e, t, n) => {
			_ = $(e), r(e, t, n);
		} : r, i), o.steps++, c++, g && a.paid(g, _, s, m), u && (e.boostSteps = (e.boostSteps ?? 0) + 1), t === "boostback" && !u && m === .05 && (e.steadySteps = (e.steadySteps ?? 0) + 1), t === "align-boost" || p) for (let t = 0; t < Math.round(m * 120); t++) e.cutoffClock += 1 / 120;
		if (p && e.burnTicks > 0 && (e.burnTicks = Math.max(0, e.burnTicks - Math.round(m * 120)), e.burnRemaining = e.burnTicks / 120), e.readyHandoff && e.step === void 0 && e.origin && (t === "align-boost" && s.autopilot.boosterPhase === "boostback" || u && e.burnRemaining > 0 && uu.every((e) => s.engines.running[e]) || t === "boostback" && !u && m === .05)) {
			e.prefix = {
				origin: e.origin,
				state: $(s),
				time: o.time + m,
				steps: o.steps,
				advance: n,
				policy: r,
				model: i,
				coastPitch: s.autopilot.boosterCoastPitch,
				initialTime: e.initialTime,
				boostSteps: e.boostSteps ?? 0,
				steadySteps: e.steadySteps ?? 0,
				cutoffClock: e.cutoffClock
			}, u && (e.startupPrefix = e.prefix);
			let t = e.prefix.steadySteps;
			t > 0 && (e.rollingPrefixes = Kx(e.rollingPrefixes, [e.prefix])), t > 0 && !(t & t - 1) && !(e.checkpoints ?? []).some((e) => e.steadySteps === t) && (e.checkpoints = [...e.checkpoints ?? [], e.prefix]);
		}
		if ((p || e.stopAtHandoff && s.autopilot.boosterPhase === "boostback") && e.burnRemaining === 0) {
			delete s.autopilot.boosterForecastBurn, s.autopilot.boosterPhase = "coast";
			for (let e = 0; e < s.engines.running.length; e++) Hv(s, e);
			e.shutdownAt = e.cutoffClock, e.stopAtCutoff && (e.done = !0);
		}
		yb(s, i, Ix);
		let v = Fx.altitude > Y.planeAltitude && Ix.altitude <= Y.planeAltitude;
		if (o.time += m, e.stopAtHandoff && s.autopilot.boosterPhase === "terminal" && (!e.readyHandoff || t === "terminal" && lu.every((e) => s.engines.running[e]))) {
			let t = s.autopilot.boosterArrivalTime;
			zb(s, 0, i, Lx), t === void 0 ? delete s.autopilot.boosterArrivalTime : s.autopilot.boosterArrivalTime = t, o.handoff = {
				x: Lx.x,
				height: Lx.height,
				vx: Lx.vx,
				vy: Lx.vy,
				time: Lx.time,
				lateralFeasible: Lx.lateralFeasible
			}, o.rangeError = s.kinematics.downRangeDistance - K + s.kinematics.speedX * Lx.time / 3, o.speedX = Lx.vx, o.speedY = Lx.vy, o.reached = !0, e.done = !0;
		} else if (v) {
			let t = (Fx.altitude - Y.planeAltitude) / (Fx.altitude - Ix.altitude);
			o.rangeError = Fx.x + (Ix.x - Fx.x) * t - K, o.time -= m * (1 - t), o.speedX = Fx.speedX + (Ix.speedX - Fx.speedX) * t, o.speedY = Fx.speedY + (Ix.speedY - Fx.speedY) * t, o.reached = !0, e.done = !0;
		}
		(s.status.landed || s.failures.crashed || s.failures.inFlightBreakUp || o.time >= 900 || o.steps >= 4e3) && (e.done = !0);
	}
	return o.reached || (o.rangeError = Ix.x - K, o.speedX = Ix.speedX, o.speedY = Ix.speedY), o.fuel = s.vehicle.propellantMass, o.pitch = s.kinematics.pitch, o.ignitionDraws = s.rng.counters.ignitionFailure - e.initialDraws, o.failed = s.failures.crashed || s.failures.inFlightBreakUp || s.failures.fuelRunOut, e.state = s, c;
}
function Ux(e, t, n, r) {
	let i = Vx(e, t, n);
	if (i.state = $(e), delete i.state.autopilot.boosterPrediction, i.state.autopilot.boosterPhase || (i.state.autopilot.boosterPhase = "align-boost"), i.state.autopilot.boosterPhase === "boostback" && n <= 0) {
		i.state.autopilot.boosterPhase = "coast";
		for (let e = 0; e < i.state.engines.running.length; e++) Hv(i.state, e);
		i.shutdownAt = e.world.environmentTime;
	}
	return delete i.state.autopilot.boosterReturnPlan, i.state.autopilot.boosterCoastPitch = t, i.stopAtHandoff = !0, r !== void 0 && (i.step = r), i;
}
function Wx(e, t, n, r, i) {
	let a = Ux(e, t, n, r);
	return a.readyHandoff = !0, a.origin = e, i && (a.reusePrefix = i), a;
}
function Gx(e, t, n, r) {
	let i = Wx(e, t, n, void 0, r);
	return i.stopAtCutoff = !0, i;
}
function Kx(e, t) {
	let n = [...e ?? []], r = n[0] ?? t[0];
	for (let e of t) !r || e.steadySteps <= 0 || e.origin !== r.origin || e.advance !== r.advance || e.policy !== r.policy || e.model !== r.model || e.coastPitch !== r.coastPitch || e.initialTime !== r.initialTime || e.boostSteps !== r.boostSteps || n.some((t) => t.steadySteps === e.steadySteps) || n.push(e);
	return n.sort((e, t) => e.steadySteps - t.steadySteps).slice(-8);
}
//#endregion
//#region src/core/control/booster-cutoff-hint.ts
function qx(e, t, n, r, i) {
	if (!e.forecast.reached || e.forecast.failed || e.forecast.fuel <= 0 || !e.forecast.handoff || t.origin !== n.origin || t.model !== n.model || t.origin.world.environmentTime !== e.originTime || t.origin.damage?.revision !== e.damageRevision || !Number.isFinite(t.range) || !Number.isFinite(n.range) || !(t.duration < e.burnDuration && n.duration > e.burnDuration)) return;
	let a = (n.range - t.range) / (n.duration - t.duration), o = e.burnDuration - e.forecast.rangeError / a;
	if (!Number.isFinite(a) || a === 0 || !Number.isFinite(o)) return;
	let s = zx(o);
	return s > r && s < i && s !== e.burnDuration ? s : void 0;
}
//#endregion
//#region src/core/control/booster-prediction.ts
var Jx = av(), Yx = Ty(), Xx = 512, Zx = Object.freeze(uu.map(() => !0));
function Qx(e, t, n) {
	let r = $(e);
	delete r.autopilot.boosterPrediction;
	let i = Math.floor(120 * r.vehicle.propellantMass / (uu.length * V_(t.propulsion, "sea-level"))) / 120;
	Z(r, t, Jx);
	let a = uu.some((e) => r.engines.failed[e]) ? Zx.map((e, t) => e && !r.engines.failed[t]) : Zx, o = Jx.engineSupportAvailable && Jx.hasMass ? kv(a, r.atmosphere.airPressure, t) / Jx.totalMass : 0, s = Math.abs(r.autopilot.boosterRangeError ?? 0) / (o * (r.autopilot.boosterFallTime ?? 0)), c = zx(Number.isFinite(s) && s > 0 && s < i ? Math.max(i / 4, s) : i / 4), l = r.autopilot.boosterPhase === "align-boost" || r.autopilot.boosterPhase === "boostback", u = l ? c : 0;
	return {
		...e.autopilot.boosterSource ? { sourceLineage: e.autopilot.boosterSource.lineageId } : {},
		origin: r,
		rollout: Wx(r, W(0), u),
		stage: l ? "upper" : "low",
		duration: u,
		lowerDuration: 0,
		upperDuration: i,
		firstDuration: c,
		iterations: +!!l,
		attemptedTicks: l ? [Math.round(u * 120)] : [],
		published: n,
		done: !1
	};
}
function $x(e) {
	return {
		...e.sourceLineage === void 0 ? {} : { sourceLineage: e.sourceLineage },
		...e.origin.damage ? { damageRevision: e.origin.damage.revision } : {},
		originTime: e.origin.world.environmentTime,
		burnDuration: e.duration,
		shutdownAt: e.rollout.shutdownAt ?? e.origin.world.environmentTime,
		coastPitch: W(0),
		forecast: { ...e.rollout.result }
	};
}
function eS(e) {
	return e.forecast.reached && !e.forecast.failed && e.forecast.fuel > 0 && e.forecast.handoff !== void 0 && Number.isFinite(e.forecast.rangeError);
}
function tS(e, t, n) {
	if (e.iterations >= 16) {
		dS(e) || (e.done = !0);
		return;
	}
	let r = e.low?.burnDuration ?? e.lowerDuration, i = e.high?.burnDuration ?? e.upperDuration, a = Rx(r) + 1, o = Rx(i) - 1, s = Math.max(a, Math.min(o, Rx(t))), c;
	for (let t = 0; t <= e.attemptedTicks.length && a <= o; t++) {
		for (let n of [s - t, s + t]) if (n >= a && n <= o && !e.attemptedTicks.includes(n)) {
			c = n;
			break;
		}
		if (c !== void 0) break;
	}
	if (c === void 0) {
		dS(e) || (e.done = !0);
		return;
	}
	let l = c / 120;
	e.attemptedTicks = [...e.attemptedTicks, c], e.duration = l, e.stage = n, e.iterations++;
	let u = nS(e, l);
	e.rollout = Wx(e.origin, W(0), l, void 0, u);
}
function nS(e, t) {
	return [
		e.prefix,
		e.startupPrefix,
		...e.checkpoints ?? [],
		...e.rollingPrefixes ?? []
	].filter((e) => !!e && Bx(t, e) > 0).sort((e, t) => t.steps - e.steps)[0];
}
function rS(e) {
	e.rollingPrefixes = Kx(e.rollingPrefixes, e.rollout.rollingPrefixes ?? []), e.rollout.startupPrefix && (e.startupPrefix = e.rollout.startupPrefix), e.rollout.prefix && (!e.prefix || e.rollout.prefix.steadySteps < e.prefix.steadySteps) && (e.prefix = e.rollout.prefix);
	for (let t of e.rollout.checkpoints ?? []) (e.checkpoints ?? []).some((e) => e.steadySteps === t.steadySteps) || (e.checkpoints = [...e.checkpoints ?? [], t]);
}
function iS(e, t) {
	e.hintTicks = [...e.hintTicks ?? [], Rx(t)], e.iterations++, e.duration = t, e.stage = "hint", e.rollout = Gx(e.origin, W(0), t, nS(e, t));
}
function aS(e, t) {
	if (!e.rollout.prefix || e.rollout.shutdownAt === void 0 || e.hintTried || e.iterations + 2 > 16 || e.origin.autopilot.boosterPhase === "coast") return !1;
	e.hintTried = !0;
	let n = [(Rx(t.burnDuration) - 6) / 120, (Rx(t.burnDuration) + 6) / 120];
	return !n.some((t) => t <= e.lowerDuration || t >= e.upperDuration || e.attemptedTicks.includes(Rx(t)) || (e.hintTicks ?? []).includes(Rx(t))) && (e.hintAnchor = t, e.hintScores = [], e.hintDurations = n, iS(e, n[0]), !0);
}
function oS(e, t, n) {
	let r = 0;
	rS(e);
	let i = e.rollout.state;
	if (!e.hintFallWork && e.rollout.shutdownAt !== void 0 && i.vehicle.propellantMass > 0 && !e.rollout.result.failed && !i.damage?.terminal.active && (e.hintFallWork = Qy(i, Y.bodyCentreAltitude, t, W(0))), e.hintFallWork) {
		let a = $y(e.hintFallWork, n, Yx);
		if (r = a, e.hintForceIterations = (e.hintForceIterations ?? 0) + a, a > 0 && (e.hintForceSlices = (e.hintForceSlices ?? 0) + 1), !e.hintFallWork.done) return r;
		let o = e.hintFallWork.result;
		o.reached && Number.isFinite(o.downRange) && (e.hintScores = [...e.hintScores ?? [], {
			duration: e.duration,
			range: i.kinematics.downRangeDistance - K + o.downRange,
			origin: e.origin,
			model: t
		}]), delete e.hintFallWork;
	}
	if (e.duration === e.hintDurations[0]) return iS(e, e.hintDurations[1]), r;
	let a = e.hintScores ?? [], o = a.length === 2 ? qx(e.hintAnchor, a[0], a[1], e.lowerDuration, e.upperDuration) : void 0;
	return o === void 0 ? pS(e) : tS(e, o, "root"), r;
}
function sS(e) {
	e.stage = "validate", e.rollout = Vx(e.terminalOrigin, e.selected.coastPitch), e.rollout.step = 1 / 120;
}
function cS(e, t, n = e.rollout.state) {
	e.validatedTicks = [...e.validatedTicks ?? [], Rx(t.burnDuration)], e.selected = t, e.terminalOrigin = $(n), sS(e);
}
function lS(e) {
	let t = e.forecast.handoff, n = t.time, r = 6 * t.x / n ** 2 + 2 * t.vx / n, i = 6 * t.height / n ** 2 + 2 * t.vy / n - 8 / n - bp(G + Y.bodyCentreAltitude, 0);
	return Math.atan2(r, Math.max(0, i));
}
function uS(e) {
	return e.forecast.handoff.lateralFeasible && Math.abs(lS(e)) <= Y.maxPitch;
}
function dS(e) {
	let t = [{
		candidate: e.low,
		ready: e.lowReady
	}, {
		candidate: e.high,
		ready: e.highReady
	}].filter((e) => !!e.candidate && !!e.ready).sort((e, t) => Math.abs(e.candidate.forecast.rangeError) - Math.abs(t.candidate.forecast.rangeError));
	for (let n of t) if (uS(n.candidate) && !(e.validatedTicks ?? []).includes(Rx(n.candidate.burnDuration))) return cS(e, n.candidate, n.ready), !0;
	return !1;
}
function fS(e) {
	return e.status.landed && !e.status.onTheGround && e.vehicle.propellantMass > 0 && !Object.entries(e.failures).some(([e, t]) => e !== "randomFailure" && t);
}
function pS(e) {
	if (e.iterations >= 16) {
		dS(e) || (e.done = !0);
		return;
	}
	if (e.low && e.high) {
		let t = (e.previousCandidate && e.lastCandidate ? Kb(e.previousCandidate, e.lastCandidate, e.low, e.high) : void 0) ?? Ub(e.low, e.high);
		t === void 0 ? e.done = !0 : tS(e, t, "root");
		return;
	}
	let t = e.low?.burnDuration ?? e.lowerDuration, n = e.high?.burnDuration ?? e.upperDuration, r = e.probeDuration ?? (e.low && !e.high && t === e.firstDuration ? Math.min((Rx(t) + 1) / 120, n) : e.high && !e.low && n === e.firstDuration ? Math.max((Rx(n) - 1) / 120, t) : (t + n) / 2);
	if (delete e.probeDuration, r <= t || r >= n) {
		let r = (t + n) / 2;
		r <= t || r >= n ? e.done = !0 : tS(e, r, "upper");
	} else tS(e, r, "upper");
}
function mS(e) {
	let t = $x(e);
	rS(e), e.lastCandidate ? e.previousCandidate = e.lastCandidate : delete e.previousCandidate, e.lastCandidate = t;
	let n = Math.sign(e.origin.autopilot.boosterRangeError ?? e.origin.kinematics.downRangeDistance - K) || 1;
	if (e.stage === "low") {
		if (eS(t) && (e.low = t, e.lowReady = $(e.rollout.state), e.origin.autopilot.boosterPhase === "coast" || uS(t))) {
			cS(e, t);
			return;
		}
		tS(e, e.firstDuration, "upper");
		return;
	}
	if (eS(t)) {
		if (t.forecast.rangeError * n >= 0) {
			let n = e.low ? Wb(e.low, t, e.upperDuration) : void 0;
			n !== void 0 && (e.probeDuration = n), e.low = t, e.lowReady = $(e.rollout.state);
		} else {
			let n = e.high ? Wb(e.high, t, e.upperDuration, e.lowerDuration) : void 0;
			n !== void 0 && (e.probeDuration = n), e.high = t, e.highReady = $(e.rollout.state);
		}
		if ((!e.low || !e.high) && uS(t)) {
			cS(e, t);
			return;
		}
		if (e.low && e.high && !e.bracketRefined) {
			e.bracketRefined = !0;
			let t = Ub(e.low, e.high), n = t === void 0 ? void 0 : Rx(t);
			if (n !== void 0 && n > Rx(e.low.burnDuration) && n < Rx(e.high.burnDuration) && !e.attemptedTicks.includes(n) && e.iterations < 16) {
				tS(e, t, "root");
				return;
			}
		}
		if (aS(e, t)) return;
		if (e.hintAnchor && !e.hintRefined && t !== e.hintAnchor) {
			e.hintRefined = !0;
			let n = e.low && e.high ? Ub(e.low, e.high) : Wb(e.hintAnchor, t, e.upperDuration, e.lowerDuration);
			if (n !== void 0) {
				tS(e, n, "root");
				return;
			}
		}
		if (uS(t)) {
			cS(e, t);
			return;
		}
	} else Number.isFinite(t.forecast.rangeError) && t.forecast.rangeError * n > 0 ? e.lowerDuration = e.duration : e.upperDuration = e.duration;
	pS(e);
}
function hS(e, t, n, r, i, a = !1) {
	Vb(e);
	let o = e.autopilot, s = o.boosterPrediction, c = !s || s.done ? Qx(e, i, s?.published) : {
		...s,
		...s.hintFallWork ? { hintFallWork: {
			...s.hintFallWork,
			result: { ...s.hintFallWork.result }
		} } : {},
		rollout: {
			...s.rollout,
			state: $(s.rollout.state),
			result: { ...s.rollout.result }
		}
	}, l = Math.max(1, Math.floor(480 * t)), u = o.boosterSource && !a ? Math.max(0, l - 1) : l, d = 0, f = 0;
	for (let t = 0; t < 32 && !c.done; t++) {
		let t = c.rollout;
		if (d += Hx(c.rollout, u - d, n, r, i, o.boosterSource ? {
			eligible: (t, n) => Nx(e, t, n),
			paid: (t, a, o, s) => jx(e, t, a, o, s, n, r, i)
		} : void 0), c.rollout.done) {
			if (c.stage === "hint") f += oS(c, i, Xx - f);
			else if (c.stage === "validate") {
				if (a && d === l) break;
				let t = c.rollout.state, n = fS(t), r = (!o.boosterSource || o.boosterSource.valid && o.boosterSource.checked && c.sourceLineage === o.boosterSource.lineageId) && c.origin.damage?.revision === e.damage?.revision && c.selected.damageRevision === c.origin.damage?.revision, i = r ? Gb(c.selected, n, e.world.environmentTime) : void 0;
				if (r && (i || n && c.origin.autopilot.boosterPhase === "coast")) {
					let e = {
						...c.selected.forecast,
						fuel: t.vehicle.propellantMass
					};
					c.published = {
						originTime: c.origin.world.environmentTime,
						originX: c.origin.kinematics.downRangeDistance,
						originVX: c.origin.kinematics.speedX,
						forecast: e,
						...i ? { decision: i } : {}
					}, i && (o.boosterReturnPlan = i, o.boosterCoastPitch = i.coastPitch);
				}
				i || n || c.origin.autopilot.boosterPhase === "coast" ? c.done = !0 : pS(c);
			} else mS(c);
		}
		if (c.done || d >= u || f >= Xx || c.rollout === t) break;
	}
	o.boosterPrediction = c;
	let p = c.published;
	if (p) {
		let t = Math.max(0, e.world.environmentTime - p.originTime);
		o.boosterRangeError = p.forecast.rangeError + (p.burnRangeRate ?? 0) * t, o.boosterFallTime = Math.max(0, p.forecast.time - t), o.boosterForecastReached = p.forecast.reached;
	}
	return d;
}
//#endregion
//#region src/core/autopilot/booster.ts
var gS = iv(), _S = av(), vS = x_(), yS = Ty(), bS = By(), xS = Db(), SS = .5, CS = Fb(), wS = (e, t, n) => Math.max(t, Math.min(n, e));
function TS(e, t) {
	for (let n = 0; n < e.engines.running.length; n++) t.includes(n) ? !e.engines.running[n] && e.engines.ignitionCountdown[n] === null && !e.engines.failed[n] && !e.failures.fuelRunOut && qb(e, n) : Hv(e, n);
}
function ES(e, t, n, r, i) {
	let a = e.kinematics, o = e.autopilot, s = i.gridFins;
	xv(e, e.atmosphere.airDensity, t, n, a.pitch, gS, i, vS, W(-s.maxAngle));
	let c = vS.torque;
	xv(e, e.atmosphere.airDensity, t, n, a.pitch, gS, i, vS, W(s.maxAngle));
	let l = vS.torque, u = -s.maxAngle, d = s.maxAngle;
	if (Math.abs(l - c) > 1) {
		for (let o = 0; o < 14; o++) {
			let o = (u + d) / 2;
			xv(e, e.atmosphere.airDensity, t, n, a.pitch, gS, i, vS, W(o)), vS.torque < r == l > c ? u = o : d = o;
		}
		let f = (u + d) / 2;
		o.boosterFinControl = f / s.maxAngle * 100, xv(e, e.atmosphere.airDensity, t, n, a.pitch, gS, i, vS, W(f));
	} else o.boosterFinControl = 0;
}
function DS(e, t, n, r, i = !1) {
	let a = e.kinematics, o = e.autopilot, s = Math.atan2(Math.sin(t - a.pitch), Math.cos(t - a.pitch));
	Z(e, r, _S, gS);
	let c = (s / n ** 2 - 2 * a.angularVelocity / n - (_S.engineSupportAvailable ? e.forces.offAxisThrustDifferenceAcceleration : 0) - e.forces.angularDragAcceleration) * (e.damage ? _S.momentOfInertia : e.vehicle.vehicleMomentOfInertia), l = (_S.engineSupportAvailable ? e.forces.thrust : 0) * Mv(e.engines.running, e.atmosphere.airPressure, r), u = a.speedX - ty(e.world, a.altitude), d = a.speedY - e.world.gustVertical;
	xv(e, e.atmosphere.airDensity, u, d, a.pitch, gS, r, vS);
	let f = vS.torque, p = l * gS.engineArm * Math.sin(e.vehicle.gimbalPosition * .01 * Gc), m = f + p;
	l > 0 ? (o.pitchControl = Math.asin(wS((c - f) / (l * gS.engineArm), -Math.sin(Gc), Math.sin(Gc))) / Gc * 100, i ? (e.status.finActive = !0, ES(e, u, d, c - p, r)) : (o.boosterFinControl = 0, e.status.finActive = !1)) : (o.pitchControl = 0, e.status.finActive = !0, ES(e, u, d, c, r)), e.status.rcsActive = e.vehicle.rcsRunTimeRemaining > 0, o.rcsThrustCommand = e.status.rcsActive ? wS((c - m) / gS.rcsArm, -Zc, Zc) : 0;
}
function OS(e, t, n, r, i = !1) {
	Vb(e);
	let a = e.autopilot;
	if (r) return a.boosterReturnPlan || a.boosterPhase === "entry" || a.boosterPhase === "terminal" ? (a.boosterFallTime = Math.max(2, (a.boosterFallTime ?? 2) - t), 0) : (a.boosterRangeError === void 0 && (eb(e, Y.bodyCentreAltitude, yS, bS, n, W(0)), bS.reached && (a.boosterRangeError = e.kinematics.downRangeDistance - K + bS.downRange, a.boosterFallTime = bS.time)), hS(e, t, r, NS, n, i));
	if (a.boosterPredictorCountdown = (a.boosterPredictorCountdown ?? 0) - t, a.boosterPredictorCountdown > 0) return 0;
	if (eb(e, Y.bodyCentreAltitude, yS, bS, n, W(0)), bS.reached && (a.boosterRangeError = e.kinematics.downRangeDistance - K + bS.downRange, a.boosterFallTime = bS.time), a.boosterPhase === "coast" && bS.reached) {
		eb(e, Y.bodyCentreAltitude, yS, bS, n, W(.05));
		let t = bS.downRange;
		eb(e, Y.bodyCentreAltitude, yS, bS, n, W(-.05));
		let r = (t - bS.downRange) / .1;
		a.boosterCoastPitch = W(Math.abs(r) > 1 ? wS(-(a.boosterRangeError ?? 0) / r, -.2, .2) : 0);
	}
	let o = Math.abs(e.kinematics.accelerationX) * (a.boosterFallTime ?? 0) * .25;
	return a.boosterPredictorCountdown = a.boosterPhase === "boostback" && Math.abs(a.boosterRangeError ?? Infinity) <= 2 * o ? t : .25, 0;
}
function kS(e) {
	let t = e.kinematics;
	return Kf(Math.max(Y.bodyCentreAltitude, t.altitude + Math.min(0, t.speedY) * Rv - .5 * Cy(e) * Rv ** 2), yS.atmosphere), sb(yS.atmosphere.airDensity);
}
function AS(e, t) {
	if (Z(e, t, _S), !_S.engineSupportAvailable || !_S.hasMass || lu.some((t) => e.engines.failed[t])) return !1;
	let n = Math.max(0, -e.kinematics.speedY);
	if (n === 0) return !1;
	let r = Cy(e), i = lu.every((t) => e.engines.running[t]) ? 0 : Rv, a = Math.max(0, (100 - e.vehicle.throttleCurrent) / 60), o = Math.max(i, a), s = n * o + .5 * r * o ** 2, c = n + r * o, l = Ry(3, _S.totalMass, c, Y.bodyCentreAltitude, t), u = e.kinematics.altitude <= l + s ? zy(3, _S.totalMass, c, Y.bodyCentreAltitude, yS, t, _S.retainedDryMass) : null;
	return u !== null && e.kinematics.altitude <= u + s;
}
function jS(e, t, n, r) {
	let i = e.autopilot;
	if (r && Dx(e, t), i.manualControlOn || !i.autoLandOn && !i.autoBoostBackOn) {
		i.boosterFinControl = void 0, Bb(i);
		return;
	}
	e.status.landed || e.failures.crashed || e.failures.inFlightBreakUp || (i.boosterPhase ||= "align-boost", r || OS(e, t, n), NS(e, t, n));
}
function MS(e, t, n, r) {
	let i = e.autopilot;
	if (i.manualControlOn || !i.autoLandOn && !i.autoBoostBackOn || e.status.landed || e.failures.crashed || e.failures.inFlightBreakUp) return;
	Ox(e);
	let a = Ax(e, t, r, NS, n), o = OS(e, t, n, r, !!a);
	kx(e, t, r, NS, n, a && (Mx(e, a) || o >= Math.max(1, Math.floor(480 * t))) ? a : void 0);
}
function NS(e, t, n) {
	Vb(e);
	let r = e.autopilot, i = e.kinematics;
	if (r.manualControlOn || !r.autoLandOn && !r.autoBoostBackOn) {
		r.boosterFinControl = void 0;
		return;
	}
	if (e.status.landed || e.failures.crashed || e.failures.inFlightBreakUp) return;
	e.status.translationModeOn = !0, e.status.finLocked = !1, e.status.dumpingFuel = !1, r.boosterPhase ||= "align-boost";
	let a = (r.boosterRangeError ?? i.downRangeDistance - K) >= 0 ? -1 : 1;
	if (r.boosterPhase === "align-boost") {
		TS(e, []), e.vehicle.throttle = 100;
		let t = W(a * Math.PI / 2);
		DS(e, t, 1.5, n), Math.abs(Math.atan2(Math.sin(t - i.pitch), Math.cos(t - i.pitch))) < 5 * Math.PI / 180 && Math.abs(i.angularVelocity) < .1 && (r.boosterPhase = "boostback");
	} else if (r.boosterPhase === "boostback") TS(e, uu), e.vehicle.throttle = 100, r.boostBackInitCompleted ||= (r.boostBackDirection = a, !0), DS(e, W(r.boostBackDirection * Math.PI / 2), 1.5, n), !r.boosterForecastBurn && r.boosterReturnPlan && e.world.environmentTime + t >= r.boosterReturnPlan.shutdownAt && (TS(e, []), r.boosterPhase = "coast");
	else if (r.boosterPhase === "coast") TS(e, []), e.vehicle.throttle = 100, DS(e, r.boosterReturnPlan?.coastPitch ?? r.boosterCoastPitch ?? W(0), 1.5, n), AS(e, n) ? r.boosterPhase = "terminal" : Math.hypot(i.speedX - ty(e.world, i.altitude), i.speedY - e.world.gustVertical) > kS(e) && (r.boosterPhase = "entry");
	else if (r.boosterPhase === "entry") {
		TS(e, r.boosterEntryCentreOnly ? lu : uu);
		let t = kS(e), a = Math.sqrt(Math.max(0, t ** 2 - i.speedX ** 2)), o = Math.max(0, -i.speedY - a) / 2, s = Math.max(2, 2 * Math.max(0, i.altitude - Y.bodyCentreAltitude) / (Math.max(0, -i.speedY) + 2)), c = -6 * (i.downRangeDistance - K) / s ** 2 - 4 * i.speedX / s;
		Ob(e, c, o, n, xS), Z(e, n, _S);
		let l = _S.engineSupportAvailable && _S.hasMass ? kv([
			!0,
			!0,
			!0
		], e.atmosphere.airPressure, n) / _S.totalMass : 0;
		lu.every((t) => e.engines.running[t]) && Math.hypot(xS.requiredX, xS.requiredY) <= l && (r.boosterEntryCentreOnly = !0, TS(e, lu)), Nb(e, c, o, n, xS), DS(e, xS.pitch, .5, n), e.vehicle.throttle = Pb(e, o, n), AS(e, n) ? r.boosterPhase = "terminal" : i.speedY >= 0 && (TS(e, []), r.boosterPhase = "coast");
	} else {
		if (r.boosterTerminalMissed) {
			TS(e, []), DS(e, W(0), .5, n);
			return;
		}
		if (r.boosterTerminalIgnitionTime === void 0 && (r.boosterTerminalIgnitionTime = e.world.environmentTime), TS(e, lu), lu.some((t) => e.engines.failed[t]) && (r.boosterTerminalMissed = !0), !lu.every((t) => e.engines.running[t]) && (e.world.environmentTime - r.boosterTerminalIgnitionTime > Rv + 2 * t && (r.boosterTerminalMissed = !0), !r.boosterTerminalMissed)) {
			e.vehicle.throttle = 100, DS(e, W(0), .5, n);
			return;
		}
		if (zb(e, t, n, CS), r.boosterArrivalTime === 0 && (r.boosterTerminalMissed = !0), r.boosterTerminalMissed) {
			TS(e, []), DS(e, W(0), .5, n);
			return;
		}
		Ob(e, CS.centreAX, CS.centreAY, n, xS), DS(e, W(0), SS, n, !0), r.pitchControl = wS(-Math.atan2(Math.sin(xS.pitch - i.pitch), Math.cos(xS.pitch - i.pitch)) / Gc * 100, -100, 100), e.vehicle.throttle = Pb(e, CS.centreAY, n), kv(e.engines.running, e.atmosphere.airPressure, n) === 0 && (e.vehicle.throttle = 100);
	}
}
//#endregion
//#region src/core/autopilot/booster-utilities.ts
function PS(e, t) {
	let { autopilot: n, kinematics: r } = e;
	n.manualControlOn || e.failures.crashed || e.failures.inFlightBreakUp || e.status.landed || (n.pitchHoldOn && (Math.abs(r.pitchRateOfChange) < .4 && (n.holdingPitch = r.pitch), e.status.translationModeOn = !0, DS(e, n.holdingPitch, .5, t)), !n.autoTakeOffOn) || (n.autoTakeOffInitialised ||= (n.autoMaxThrustOn = !0, e.engines.running.some(Boolean) || Jb(e, t), !0), e.status.translationModeOn = !0, DS(e, r.altitude < 25e3 ? W(yl * r.altitude / 25e3) : r.altitude < 8e4 ? W(yl + (bl - yl) * (r.altitude - 25e3) / 55e3) : bl, 3, t), e.vehicle.propellantMass < 12e3 && e.engines.running.some(Boolean) && (Jb(e, t), n.autoTakeOffOn = !1));
}
var FS = xp(G), IS = Ty(), LS = av();
function RS(e) {
	if (Z(e, q, LS), !LS.engineSupportAvailable || !LS.hasMass) return 0;
	let t = LS.totalMass * FS, n = 1;
	return H_(q.propulsion, "sea-level", 101325 / 1e3) * .8 < t && (n = 2), H_(q.propulsion, "sea-level", 101325 / 1e3) * 2 * .8 < t && (n = 3), Math.min(n, Ov(e.engines.failed));
}
function zS(e) {
	return zy(RS(e), LS.totalMass, -e.kinematics.speedY, 0, IS, q, LS.retainedDryMass) ?? e.kinematics.altitude;
}
function BS(e) {
	let t = -e.kinematics.speedY;
	Z(e, q, LS);
	let n = zy(LS.engineSupportAvailable ? Dv(e.engines.running) : 0, LS.totalMass, t, q.height * .5, IS, q, LS.retainedDryMass);
	return n === null ? e.kinematics.altitude : n + t * 1 * .5;
}
//#endregion
//#region src/core/autopilot/index.ts
var VS = qb, HS = Yb, US = iv(), WS = av();
function GS(e) {
	let { autopilot: t, kinematics: n } = e;
	!t.pitchHoldOn || t.manualControlOn || (Math.abs(n.pitchRateOfChange) < .4 && (t.holdingPitch = n.pitch), cb(e, t.holdingPitch, .5));
}
function KS(e, t = q) {
	e.autopilot.autoMaxThrustOn && mb(e, sb(e.atmosphere.airDensity), 10, 4, t);
}
function qS(e) {
	let { autopilot: t, kinematics: n, vehicle: r, engines: i, status: a } = e;
	!t.autoTakeOffOn || t.manualControlOn || (t.autoTakeOffInitialised ||= (t.autoMaxThrustOn || ax(e), Tv(i.running) === 0 && Jb(e), a.finActive && Yb(e), a.finLocked = !0, !0), n.altitude < 25e3 ? cb(e, W(yl * n.altitude / 25e3), 3) : n.altitude < 8e4 ? cb(e, W(yl + (bl - yl) * (n.altitude - 25e3) / 55e3), 3) : cb(e, bl, 3), r.propellantMass < 12e3 && Tv(i.running) > 0 && (Jb(e), ox(e), a.finLocked = !1));
}
function JS(e, t) {
	let { autopilot: n, kinematics: r, vehicle: i, engines: a } = e;
	if (!n.autoBoostBackOn || n.manualControlOn) return;
	let o = () => {
		sx(e), YS(e), n.autoLandOn || cx(e);
	};
	if (n.boostBackInitCompleted ||= (n.boostBackDirection = r.downRangeDistance > K - 100 ? -Math.PI * .5 : Math.PI * .5, e.status.rcsActive || Xb(e), Tv(a.running) === 0 && Jb(e), n.autoMaxThrustOn || ax(e), n.autoTakeOffOn && ox(e), !0), !n.accelerationStageCompleted) n.decelerationStageEstDuration = Math.abs(r.speedX) / dl + 4, cb(e, W(n.boostBackDirection), 1.5), (K - r.downRangeDistance - 100) / (r.speedX * .5) < n.decelerationStageEstDuration + 2 && (K - r.downRangeDistance) / r.speedX > 0 && (Jb(e), n.autoMaxThrustOn && ax(e), n.accelerationStageCompleted = !0);
	else if (n.boostBackDecelerationStageInitCompleted ||= (n.boostBackDecelerationCheckCountdown = 5, !0), n.boostBackDecelerationCheckCountdown !== null && (n.boostBackDecelerationCheckCountdown -= t, n.boostBackDecelerationCheckCountdown <= 0 && (n.boostBackDecelerationCheckCountdown = null, r.accelerationX < 14.906640000000001 && (n.boostBackAeroDeceleration = !1, Jb(e)))), n.boostBackAeroDeceleration ? gb(e, n.boostBackDirection < 0 ? dl : -dl, t, HS) : (cb(e, W(-n.boostBackDirection), 1), _b(e, VS), ub(e, dl)), Math.abs(r.speedX) < 3) {
		o();
		return;
	}
	(i.propellantMass < 12e3 || r.altitude < 700 && r.speedY < 0) && o();
}
function YS(e) {
	let { autopilot: t } = e;
	t.autoBoostBackOn = !1, t.decelerationStageEstDuration = 0, t.boostBackDirection = 0, t.boostBackInitCompleted = !1, t.boostBackAeroDeceleration = !0, t.boostBackDecelerationStageInitCompleted = !1, t.boostBackDecelerationCheckCountdown = null, t.accelerationStageCompleted = !1;
}
function XS(e) {
	let { autopilot: t } = e;
	t.autoLandOn = !1, t.initVehicleConfigCompleted = !1, t.landingSiteXPos = K, t.aeroDescentCompleted = !1, t.fineTunePercentage = void 0, t.bellyFlopTriggerAltitude = 0, t.flipStageInitialised = !1, t.flipCompleted = !1, t.horizontalAdjustmentStageCompleted = !1, t.horizontalAdjustmentStageInitialised = !1, t.horizontalAdjustmentTimeLeft = void 0, t.horizontalAdjustmentDesiredSpeed = void 0, t.effectiveVerticalMaxThrust = void 0, t.finalStagePessimisticAltitude = void 0, t.finalDescentStageInitialised = !1, t.distanceToGround = void 0, t.finalDescentStageCompleted = !1;
}
function ZS(e, t) {
	let { autopilot: n, vehicle: r, engines: i, status: a } = e;
	!n.autoLandOn || n.manualControlOn || (n.initVehicleConfigCompleted ||= (a.finActive || Yb(e), a.rcsActive || Xb(e), r.throttle = 40, r.propellantMass > 18e3 && !a.dumpingFuel && Zb(e), Tv(i.running) > 0 && Jb(e), !0), a.dumpingFuel && r.propellantMass <= 18e3 && Zb(e), n.aeroDescentCompleted ? n.flipCompleted ? n.horizontalAdjustmentStageCompleted ? n.finalDescentStageCompleted || nC(e, t) : tC(e) : eC(e) : (QS(e), $S(e)));
}
function QS(e) {
	let { autopilot: t, kinematics: n } = e;
	if (n.altitude >= 2500) return;
	let r = RS(e) > 1 ? vl : gl;
	t.finalStagePessimisticAltitude = zS(e), Z(e, q, WS, US);
	let i = WS.engineSupportAvailable ? Math.min(1, Ov(e.engines.failed)) : 0, a = i > 0 && WS.momentOfInertia > 0 && US.engineArm > 0 ? ap(i * H_(q.propulsion, "sea-level", Jc / 1e3) * 40 * .01, US.engineArm, WS.momentOfInertia) : 0;
	if (!(a > 0)) {
		t.bellyFlopTriggerAltitude = Infinity;
		return;
	}
	let o = Math.sqrt((Math.PI / 2 + ml) / 2 / a * 2) * 2;
	t.bellyFlopTriggerAltitude = t.finalStagePessimisticAltitude + -n.speedY * (o + Rv) - -30 * r + q.height / 2;
}
function $S(e) {
	let { autopilot: t, kinematics: n } = e, r = n.downRangeDistance - t.landingSiteXPos + 100, i = -r / n.speedX, a;
	Math.abs(n.speedX) > 20 ? a = n.angleOfMotion - Math.PI : r > 0 ? (a = -pl, i < 5 && i > 0 && (t.fineTunePercentage = Math.abs(n.speedX) > 5 ? 1 : Math.abs(n.speedX) / 5, a = pl * 2 * t.fineTunePercentage)) : (a = pl, i < 5 && i > 0 && (t.fineTunePercentage = Math.abs(n.speedX) > 5 ? 1 : Math.abs(n.speedX) / 5, a = -pl * 2 * t.fineTunePercentage)), cb(e, W(a + Math.PI / 2), .7), (n.altitude < t.bellyFlopTriggerAltitude && n.speedY < 5 && n.altitude < 2500 || n.altitude < 300) && (t.aeroDescentCompleted = !0);
}
function eC(e) {
	let { autopilot: t, kinematics: n, vehicle: r, status: i } = e;
	t.flipStageInitialised ||= (i.dumpingFuel && Zb(e), i.rcsActive && Xb(e), Jb(e), !0), cb(e, ml, .4), n.pitch < 0 && (r.throttle = 100), n.pitch < ml && (t.flipCompleted = !0);
}
function tC(e) {
	let { autopilot: t, kinematics: n, engines: r, status: i } = e;
	t.horizontalAdjustmentStageInitialised ||= (i.finActive && Yb(e), i.finLocked = !0, Dv(r.running) < 3 && (t.horizontalAdjustmentVerticalSpeedLimit /= 1.5, t.horizontalAdjustmentHorizontalSpeedLimit *= 2), !0);
	let a = t.landingSiteXPos - n.downRangeDistance, [o, s, c] = r.running;
	o && !s && !c ? a -= 12 : (!o && s && c || !o && (s && !c || !s && c)) && (a += 4), t.finalStagePessimisticAltitude = BS(e), t.horizontalAdjustmentTimeLeft = (n.altitude - t.finalStagePessimisticAltitude - q.height / 2) / -n.speedY, t.horizontalAdjustmentDesiredSpeed = a / t.horizontalAdjustmentTimeLeft, t.horizontalAdjustmentDesiredSpeed > t.horizontalAdjustmentHorizontalSpeedLimit ? t.horizontalAdjustmentDesiredSpeed = t.horizontalAdjustmentHorizontalSpeedLimit : t.horizontalAdjustmentDesiredSpeed < -t.horizontalAdjustmentHorizontalSpeedLimit && (t.horizontalAdjustmentDesiredSpeed = -t.horizontalAdjustmentHorizontalSpeedLimit), n.speedY > t.horizontalAdjustmentVerticalSpeedLimit && _b(e, VS), t.horizontalAdjustmentTimeLeft < 3 && t.horizontalAdjustmentTimeLeft > -3 ? fb(e, 0, hl, 10, .8) : fb(e, t.horizontalAdjustmentDesiredSpeed ?? 0, hl, 6, 1), pb(e, t.horizontalAdjustmentVerticalSpeedLimit, 10, 2), t.finalStagePessimisticAltitude * 1.1 > n.altitude && (t.horizontalAdjustmentStageCompleted = !0);
}
function nC(e, t, n = -5, r) {
	let { autopilot: i, kinematics: a, vehicle: o, engines: s, status: c } = e;
	if (i.finalDescentStageInitialised ||= !0, i.distanceToGround = a.altitude - q.height * .5, a.altitude > q.height * .5 + 5) {
		let [t, n, r] = s.running;
		t && !n && !r ? fb(e, -.8, W(hl / 2), 5, .7) : !t && n && r ? fb(e, .8, W(hl / 2), 5, .7) : !t && (n && !r || !n && r) ? fb(e, .72, W(hl / 2), 5, .7) : fb(e, 0, W(hl / 2), 5, .7);
	} else cb(e, W(0), .4);
	a.speedY > n && _b(e, VS);
	let l = -i.distanceToGround / 3 - .1, u = Cy(e);
	Z(e, q, WS);
	let d = (WS.engineSupportAvailable && WS.hasMass ? ob(s.running, o.gimbalPointingDirection, e.atmosphere.airPressure, a.pitch) / WS.totalMass : 0) - u, f = Math.sqrt(2 * Math.max(0, d) * Math.max(0, i.distanceToGround));
	if (!r && d > 0 && -l > f) {
		let t = a.speedY + f, n = 1 + d / u - t / 10;
		db(e, Math.max(0, Math.min(3, n)));
	} else pb(e, l, 10, 3);
	if (a.altitude <= q.height * .5 + .05) {
		if (r) {
			r(e);
			return;
		}
		o.throttle = 40, Jb(e), c.forceDump = !0, c.dumpingFuel || Zb(e), cx(e), XS(e);
	}
}
function rC(e, t) {
	e.autopilot.demoAutoLandOn && nC(e, t, -20, (e) => {
		Jb(e), e.autopilot.demoAutoLandOn = !1, e.status.finLocked = !1, e.vehicle.propellantMass = Fc, e.autopilot.pitchControl = 0, e.vehicle.throttle = 100;
	});
}
var iC = W(-Math.PI / 2);
function aC(e) {
	let t = e.autopilot.landingSiteXPos - e.kinematics.downRangeDistance;
	return t < 0 ? t + kc : t;
}
function oC(e) {
	let { kinematics: t } = e;
	return Tp(t.distanceToPlanetCenter, t.speedX, t.speedY, G + ul) + ll;
}
function sC(e) {
	let { kinematics: t, engines: n } = e;
	if (Z(e, q, WS), !WS.engineSupportAvailable || !WS.hasMass) return Infinity;
	let r = Ov(n.failed);
	if (r <= 0) return Infinity;
	let i = 150 * WS.totalMass / (r * H_(q.propulsion, "sea-level", e.atmosphere.airPressure));
	return (t.speedX - 75) * i + Tp(t.distanceToPlanetCenter, t.speedX - 150, t.speedY, G + ul) + ll;
}
function cC(e) {
	let { autopilot: t, kinematics: n, vehicle: r, engines: i, status: a } = e;
	if (!(!t.autoDeorbitOn || t.manualControlOn)) {
		if (t.deorbitInitCompleted ||= (t.landingSiteXPos = K, a.rcsActive || Xb(e), Tv(i.running) > 0 && Jb(e), r.throttle = 100, !0), cb(e, iC, 4), !t.deorbitBurnStarted) {
			let i = sC(e);
			Number.isFinite(i) && aC(e) <= i && (t.deorbitTargetSpeed = n.speedX, Jb(e), r.throttle = 100, t.deorbitBurnStarted = !0);
			return;
		}
		if (!t.deorbitBurnCompleted) {
			let a = t.deorbitTargetSpeed - n.speedX;
			(a >= 75 && oC(e) <= aC(e) || a >= 240) && (Tv(i.running) > 0 && Jb(e), r.throttle = 40, t.deorbitBurnCompleted = !0);
			return;
		}
		n.speedY < 0 && (t.autoDeorbitOn = !1, t.autoLandOn || cx(e));
	}
}
function lC(e, t, n = q, r) {
	if (n.id === "super-heavy") {
		let i = e.autopilot.autoLandOn || e.autopilot.autoBoostBackOn;
		jS(e, t, n, r), i || (KS(e, n), PS(e, n));
		return;
	}
	rC(e, t), KS(e), GS(e), qS(e), ZS(e, t), JS(e, t), cC(e);
}
//#endregion
//#region src/core/control/actuation.ts
function uC(e, t, n, r = !1) {
	return e < t + n && e > t - n ? t : (r ? e <= t : e < t) ? e + n : e - n;
}
function dC(e, t, n) {
	e.vehicle.frontFinExtension = uC(e.vehicle.frontFinExtension, t, 120 * n);
}
function fC(e, t, n) {
	e.vehicle.aftFinExtension = uC(e.vehicle.aftFinExtension, t, 120 * n, !0);
}
function pC(e, t, n) {
	let { status: r, kinematics: i } = e;
	r.finActive ? i.angleOfAttack < 0 ? (dC(e, 50 - t, n), fC(e, 50 + t, n)) : (dC(e, 50 + t, n), fC(e, 50 - t, n)) : r.finLocked ? (dC(e, 0, n), fC(e, 0, n)) : (dC(e, 100, n), fC(e, 100, n));
}
function mC(e, t, n, r = !1) {
	let { status: i, vehicle: a, forces: o, autopilot: s } = e, c = s.rcsThrustCommand;
	if (s.rcsThrustCommand = 0, !i.rcsActive || a.rcsRunTimeRemaining <= 0) {
		o.rcsThrust = 0;
		return;
	}
	if (o.rcsThrust = r ? Math.max(-Zc, Math.min(Zc, c)) : t > 99 ? Zc : t < -99 ? -Zc : c, o.rcsThrust !== 0) {
		let e = 1 / n, t = Math.abs(o.rcsThrust) / Zc, r = a.rcsRunTimeRemaining * e;
		t >= r ? (o.rcsThrust = Math.sign(o.rcsThrust) * Zc * r, a.rcsRunTimeRemaining = 0) : a.rcsRunTimeRemaining = (r - t) / e;
	}
}
function hC(e, t, n) {
	e.vehicle.gimbalPosition = uC(e.vehicle.gimbalPosition, t, 600 * n);
}
function gC(e, t) {
	e.vehicle.throttleCurrent = uC(e.vehicle.throttleCurrent, e.vehicle.throttle, 60 * t);
}
function _C(e, t, n, r = q, i = !1) {
	e.status.translationModeOn && (r.gridFins ? (dC(e, 50 + (e.status.finActive && !e.status.finLocked ? Math.max(-100, Math.min(100, e.autopilot.boosterFinControl ?? t)) : 0) / 2, n), fC(e, 50, n)) : pC(e, t / 2, n), mC(e, t, n, !!r.gridFins && !i && !e.autopilot.manualControlOn && (e.autopilot.autoLandOn || e.autopilot.autoBoostBackOn || e.autopilot.pitchHoldOn || e.autopilot.autoTakeOffOn) && e.autopilot.boosterFinControl !== void 0), hC(e, t, n));
}
//#endregion
//#region src/core/control/mechanical.ts
function vC(e, t, n, r, i, a, o, s = !0) {
	if (t.damage && !t.damage.terminal.active) {
		let e = t.damage.revision;
		wv(t, n, i, "hull"), t.damage.revision !== e && i.id === "super-heavy" && Bb(t.autopilot);
	}
	return t.damage?.terminal.active ? (fy(t, i, o), t.world.environmentTime += n, t) : (a(t, n, i), r.throttle !== void 0 && (t.vehicle.throttle = r.throttle), r.pitchControl !== void 0 && (t.autopilot.pitchControl = r.pitchControl, i.gridFins && (t.autopilot.boosterFinControl = r.pitchControl)), _C(t, t.autopilot.pitchControl, n, i, r.pitchControl !== void 0), gC(t, n), fy(t, i, o), s && i.id === "super-heavy" && wb(e, t, i), t.world.environmentTime += n, !t.failures.crashed && !t.failures.inFlightBreakUp && !t.status.onTheGround && !t.status.landed && (t.world.timeSpent += n), t);
}
//#endregion
//#region src/core/physics/body-reference.ts
function yC(e, t, n, r) {
	let i = Math.sin(e.pitch), a = Math.cos(e.pitch), o = a * t + i * n, s = -i * t + a * n, c = e.angularVelocity, l = e.angularAcceleration;
	r.downRangeDistance = e.downRangeDistance + o, r.downRangeDistanceNextFrame = r.downRangeDistance, r.altitude = e.altitude + s, r.speedX = e.speedX + c * s, r.speedY = e.speedY - c * o, r.accelerationX = e.accelerationX + l * s - c ** 2 * o, r.accelerationY = e.accelerationY - l * o - c ** 2 * s, r.pitch = e.pitch, r.angularVelocity = c, r.angularAcceleration = l, r.distanceToPlanetCenter = G + r.altitude, r.orbitalVelocityAtCurrentAltitude = yp(r.distanceToPlanetCenter), r.trueSpeed = Math.hypot(r.speedX, r.speedY), r.totalAcceleration = Math.hypot(r.accelerationX, r.accelerationY);
}
//#endregion
//#region src/core/mission-free-flight.ts
var bC = sy(), xC = { ...q }, SC = { ...J };
function CC(e, t, n, r) {
	let i = e.kinematics, a = Math.sin(i.pitch), o = Math.cos(i.pitch);
	e.damage ? (t.pitch = i.pitch, t.angularVelocity = i.angularVelocity, t.angularAcceleration = i.angularAcceleration, yC(t, -r, -n, i)) : (i.downRangeDistance = t.downRangeDistance - n * a, i.downRangeDistanceNextFrame = i.downRangeDistance, i.altitude = t.altitude - n * o, i.distanceToPlanetCenter = G + i.altitude, i.orbitalVelocityAtCurrentAltitude = yp(i.distanceToPlanetCenter), i.speedX = t.speedX - n * i.angularVelocity * o, i.speedY = t.speedY + n * i.angularVelocity * a, i.accelerationX = t.accelerationX - n * (i.angularAcceleration * o - i.angularVelocity ** 2 * a), i.accelerationY = t.accelerationY + n * (i.angularAcceleration * a + i.angularVelocity ** 2 * o), i.totalAcceleration = Math.hypot(i.accelerationX, i.accelerationY)), i.trueSpeed = Math.hypot(i.speedX, i.speedY), i.machSpeed = sp(i.speedX, i.speedY, ty(e.world, i.altitude), e.world.gustVertical) / Xf(e.atmosphere.airTemperature);
}
function wC(e, t, n, r, i) {
	let a = fx(e);
	if (r.id === "super-heavy" && e.status.landed) return a.damage && Np(a.damage, X(r).debris, t), a.engines.running.fill(!1), a.engines.ignitionCountdown.fill(null), a.world.environmentTime += t, a.world.updatedFrameCount += 1, a;
	if (r.id === "super-heavy" && (n.pitchControl !== void 0 || n.throttle !== void 0) && Bb(a.autopilot), a.damage?.terminal.active) return Np(a.damage, X(r).debris, t), fv(a), a.world.environmentTime += t, a.world.updatedFrameCount++, a;
	if (hy(a, t, r, bC), a.damage && Np(a.damage, X(r).debris, t), a.damage?.terminal.active) return a.engines.running.fill(!1), a.engines.ignitionCountdown.fill(null), a.world.environmentTime += t, a;
	_v(a, r, bC.massProperties);
	let o = a.kinematics, s = (a.damage ? bC.massProperties.centreOfMass : $_(a.vehicle.propellantMass, r)) - r.height / 2, c = a.damage ? bC.massProperties.centreOfMassX : 0, l = Math.sin(o.pitch), u = Math.cos(o.pitch), d = {
		...o,
		downRangeDistance: o.downRangeDistance + s * l,
		altitude: o.altitude + s * u,
		speedX: o.speedX + s * o.angularVelocity * u,
		speedY: o.speedY - s * o.angularVelocity * l
	};
	a.damage && yC(o, c, s, d), d.distanceToPlanetCenter = G + d.altitude;
	let f = r.id === "ship" ? xC : SC;
	f.height = r.height + 2 * s * Math.sign(u);
	let p = gy({
		kinematics: d,
		forces: a.forces,
		status: a.status,
		failures: a.failures
	}, t, bC.bodyAccelerationX, bC.bodyAccelerationY, f, a.damage ? r.height * Math.abs(u) / 2 + (d.altitude - o.altitude) : void 0);
	p && (o.angularVelocity = 0), a.damage ? _v(a, r, bC.massProperties) : rv(a.vehicle.propellantMass, bC.massProperties, r), a.vehicle.vehicleMomentOfInertia = bC.massProperties.momentOfInertia, vy(a, t, p, bC), CC(a, d, s, c), _y(a, t, bC);
	let m = yy(a, r, bC);
	return by(a, t, p, bC.omega0, bC.alpha0, m), CC(a, d, s, c), vC(e, a, t, n, r, i, bC);
}
function TC(e, t, n) {
	lC(e, t, n, EC);
}
function EC(e, t, n, r) {
	return wC(e, t, OC, r, n);
}
function DC(e, t, n, r) {
	let i = wC(e, t, n, r, TC);
	return r.id === "super-heavy" && !i.damage?.terminal.active && MS(i, t, r, EC), i;
}
//#endregion
//#region src/core/step.ts
var OC = {}, kC = sy();
function AC(e, t, n = OC, r = q) {
	let i = NC(e, t, n, r, jC);
	return r.id === "super-heavy" && !i.damage?.terminal.active && MS(i, t, r, MC), i;
}
function jC(e, t, n) {
	lC(e, t, n, MC);
}
function MC(e, t, n, r) {
	return NC(e, t, OC, r, n);
}
function NC(e, t, n, r, i) {
	if (e.damage) return wC(e, t, n, r, i);
	let a = fx(e);
	if (r.id === "super-heavy" && e.status.landed) return a.engines.running.fill(!1), a.engines.ignitionCountdown.fill(null), a.world.environmentTime += t, a.world.updatedFrameCount += 1, a;
	r.id === "super-heavy" && (n.pitchControl !== void 0 || n.throttle !== void 0) && Bb(a.autopilot), hy(a, t, r, kC);
	let o = gy(a, t, kC.bodyAccelerationX, kC.bodyAccelerationY, r);
	return _y(a, t, kC), xy(a, t, r, kC, o), vC(e, a, t, n, r, i, kC);
}
//#endregion
//#region src/app/loop.ts
var PC = 1 / 120, FC = .25;
function IC(e) {
	return {
		state: e,
		previous: e,
		accumulator: 0,
		totalSteps: 0,
		simulatedTime: 0
	};
}
function LC(e) {
	return IC(e);
}
function RC(e, t, n, r, i) {
	let a = n.timeWarp ?? 1, o = n.slowMotion ?? 1, s = n.onStep, c = !1, l = t;
	if (l > 0 || (l = 0), l > .25 && (l = FC, c = !0), n.paused === !0) return {
		steps: 0,
		alpha: e.accumulator / PC,
		clamped: c,
		simulatedDt: 0
	};
	e.accumulator += o === 1 ? l : l / o;
	let u = 0;
	for (; e.accumulator >= PC;) {
		e.accumulator -= PC;
		for (let t = 0; t < a; t++) if (e.previous = e.state, e.state = i(e.state, PC, r), s && s(e.state), u += 1, e.totalSteps += 1, e.simulatedTime += PC, u >= 2e3) return e.accumulator = 0, {
			steps: u,
			alpha: 0,
			clamped: !0,
			simulatedDt: u * PC
		};
	}
	return {
		steps: u,
		alpha: e.accumulator / PC,
		clamped: c,
		simulatedDt: u * PC
	};
}
//#endregion
//#region src/core/scenarios.ts
var zC = [
	{
		id: "booster-sep",
		name: "Booster Sep",
		description: "Just after stage separation: high, fast, and pointed downrange.",
		altitude: 7e4,
		xPosition: 45e3,
		speedX: 1130,
		speedY: 1130,
		pitch: Dc(45),
		propellant: 500
	},
	{
		id: "rtls",
		name: "RTLS",
		description: "Return to launch site — downrange and climbing, needs a boostback burn.",
		altitude: 15e3,
		xPosition: 5e3,
		speedX: 330,
		speedY: 430,
		pitch: Dc(30),
		propellant: 200
	},
	{
		id: "reentry",
		name: "Re-entry",
		description: "Orbital velocity, 1980 km short of the pad. The hardest one.",
		altitude: 8e4,
		xPosition: -198e4,
		speedX: 7300,
		speedY: -30,
		pitch: Dc(30),
		propellant: 50
	},
	{
		id: "before-flip",
		name: "Before Flip",
		description: "Belly-down at terminal velocity, moments from the flip.",
		altitude: 1e3,
		xPosition: -100,
		speedX: 0,
		speedY: -70,
		pitch: Dc(90),
		propellant: 30
	},
	{
		id: "landing-burn",
		name: "Landing Burn",
		description: "Vertical, low and slow. The last few seconds.",
		altitude: 200,
		xPosition: 0,
		speedX: 0,
		speedY: -35,
		pitch: Dc(0),
		propellant: 20
	}
], BC = {
	id: "launch-pad",
	name: "Launch Pad",
	description: "On the pad at StarBase, full tanks.",
	altitude: q.height / 2,
	xPosition: 0,
	speedX: 0,
	speedY: 0,
	pitch: Dc(0),
	propellant: Fc / 1e3
}, VC = 200, HC = {
	id: "intro",
	name: "Intro Demo",
	description: "The auto-landing sequence that plays when the game opens.",
	altitude: VC - 1,
	xPosition: 0,
	speedX: 0,
	speedY: -VC / 4,
	pitch: Dc(0),
	propellant: 12
}, UC = 15e4, WC = Cp(G + UC, yp(G + UC)), GC = [{
	id: "circularize",
	name: "Circularize",
	description: "Just short of orbital speed at 150 km — a short prograde burn closes the orbit.",
	altitude: UC,
	xPosition: 0,
	speedX: WC - 20,
	speedY: 0,
	pitch: Dc(90),
	propellant: 200
}, {
	id: "deorbit",
	name: "Deorbit Burn",
	description: "Circular at 150 km, half a lap short of StarBase. Burn retrograde and come home.",
	altitude: UC,
	xPosition: -Math.PI * G,
	speedX: WC,
	speedY: 0,
	pitch: Dc(90),
	propellant: 300
}], KC = [
	BC,
	...zC,
	...GC,
	HC
];
function qC(e) {
	return KC.find((t) => t.id === e);
}
function JC(e, t) {
	return XC(e, t, q);
}
function YC(e, t) {
	let n = e.id === "custom" ? e.basedOn : e.id, r = n === "booster-sep" || n === "rtls" ? J : q;
	return {
		state: XC(e, t, r),
		vehicle: r
	};
}
function XC(e, t, n) {
	let r = dx(t, n), i = e.altitude;
	i < n.height / 2 && (i = n.height / 2), r.kinematics.altitude = i, r.kinematics.distanceToPlanetCenter = G + i, r.kinematics.downRangeDistance = e.xPosition + K, r.kinematics.downRangeDistanceNextFrame = r.kinematics.downRangeDistance, r.kinematics.speedX = e.speedX, r.kinematics.speedY = e.speedY, r.kinematics.trueSpeed = Math.sqrt(e.speedX ** 2 + e.speedY ** 2), r.kinematics.pitch = Oc(e.pitch), n.gridFins && (r.kinematics.pitchRecord = [r.kinematics.pitch, r.kinematics.pitch]);
	let a = e.propellant * 1e3;
	return a > n.propellantCapacity && (a = n.propellantCapacity), a > 0 || (a = 0), r.vehicle.propellantMass = a, r.vehicle.vehicleMass = n.dryMass + a, n.gridFins && (r.vehicle.vehicleMomentOfInertia = tv(a, n)), r.world.wind = e.wind ?? 0, r.kinematics.machSpeed = sp(r.kinematics.speedX, r.kinematics.speedY, ty(r.world, r.kinematics.altitude), r.world.gustVertical) / Xf(If(i).airTemperature), r.damage = Jd(X(n).partition, D_(i, If(i).airTemperature)), r;
}
function ZC(e) {
	let t = JC(HC, e);
	return t.status.finLocked = !0, t.autopilot.demoAutoLandOn = !0, Jb(t), t;
}
//#endregion
//#region src/core/mission.ts
var QC = {}, $C = av(), ew = av();
function tw(e, t) {
	Z(e, J, $C), Z(t, q, ew);
	let n = $C.totalMass, r = ew.totalMass, i = $C.centreOfMass, a = J.height + ew.centreOfMass, o = $C.centreOfMassX, s = ew.centreOfMassX, c = n + r, l = (n * i + r * a) / c, u = (n * o + r * s) / c;
	return {
		mass: c,
		centreStation: l,
		centreX: u,
		inertia: $C.momentOfInertia + ew.momentOfInertia + n * ((i - l) ** 2 + (o - u) ** 2) + r * ((a - l) ** 2 + (s - u) ** 2),
		boosterStation: i,
		shipStation: a,
		boosterX: o,
		shipX: s
	};
}
function nw(e = ux) {
	let t = zC.find((e) => e.id === "booster-sep"), n = YC(t, e).state, r = JC({
		...t,
		id: "hot-stage",
		propellant: 1200
	}, e ^ 1397246288), i = Math.sin(n.kinematics.pitch), a = Math.cos(n.kinematics.pitch), o = (J.height + q.height) / 2;
	r.kinematics.downRangeDistance += o * i, r.kinematics.altitude += o * a, r.kinematics.pitchRecord.fill(r.kinematics.pitch);
	let s = tw(n, r), c = s.centreStation - J.height / 2, l = {
		kinematics: {
			...n.kinematics,
			pitchRecord: [...n.kinematics.pitchRecord],
			downRangeDistance: n.kinematics.downRangeDistance + c * i,
			altitude: n.kinematics.altitude + c * a
		},
		forces: { ...n.forces },
		status: { ...n.status },
		failures: { ...n.failures }
	};
	l.kinematics.distanceToPlanetCenter = G + l.kinematics.altitude, l.kinematics.orbitalVelocityAtCurrentAltitude = yp(l.kinematics.distanceToPlanetCenter), l.kinematics.downRangeDistanceNextFrame = l.kinematics.downRangeDistance;
	let u = {
		phase: "attached",
		booster: n,
		ship: r,
		aggregate: l,
		elapsedTime: 0,
		stageRequested: !1,
		stagingFailed: !1
	};
	return lw(u, s), u;
}
var rw = sy(), iw = sy(), aw = {
	omega0: 0,
	alpha0: 0
}, ow = () => {}, sw = {
	...q,
	height: J.height + q.height
};
function cw(e, t, n, r, i, a) {
	let o = e.kinematics, s = n.kinematics, c = Math.sin(s.pitch), l = Math.cos(s.pitch), u = r - a.centreStation, d = i - a.centreStation;
	yC(s, -a.centreX, u, o), o.machSpeed = sp(o.speedX, o.speedY, ty(e.world, o.altitude), e.world.gustVertical) / Xf(e.atmosphere.airTemperature), _v(e, t), e.damage || (e.vehicle.vehicleMomentOfInertia = tv(e.vehicle.propellantMass, t));
	let f = (t.id === "ship" ? a.shipX : a.boosterX) - a.centreX, p = f * l + d * c, m = -f * c + d * l, h = G + s.altitude + m, g = s.speedX + s.angularVelocity * m, _ = s.speedY - s.angularVelocity * p, v = s.accelerationX + s.angularAcceleration * m - s.angularVelocity ** 2 * p, y = s.accelerationY - s.angularAcceleration * p - s.angularVelocity ** 2 * m, b = (v - wp(h, g, _)) / Kc, x = (y - bp(h, g)) / Kc;
	e.forces.perceivedG_X = b, e.forces.perceivedG_Y = x, e.forces.perceivedG = Math.sqrt(b ** 2 + x ** 2);
}
function lw(e, t) {
	cw(e.booster, J, e.aggregate, J.height / 2, t.boosterStation, t), cw(e.ship, q, e.aggregate, J.height + q.height / 2, t.shipStation, t);
}
function uw(e) {
	e.stageRequested = !0, e.booster.vehicle.throttle = e.ship.vehicle.throttle = 100;
	for (let t = 0; t < J.engines.length; t++) lu.includes(t) || Hv(e.booster, t);
	for (let t of lu) !e.booster.engines.running[t] && e.booster.engines.ignitionCountdown[t] === null && qb(e.booster, t);
	for (let t = 0; t < q.engines.length; t++) !e.ship.engines.running[t] && e.ship.engines.ignitionCountdown[t] === null && qb(e.ship, t);
}
function dw(e, t, n = QC) {
	if (e.phase === "separated") return {
		...e,
		ship: DC(e.ship, t, n.ship ?? OC, q),
		booster: DC(e.booster, t, n.booster ?? OC, J),
		elapsedTime: e.elapsedTime + t
	};
	let r = {
		...e,
		ship: fx(e.ship),
		booster: fx(e.booster),
		aggregate: {
			kinematics: {
				...e.aggregate.kinematics,
				pitchRecord: [...e.aggregate.kinematics.pitchRecord]
			},
			forces: { ...e.aggregate.forces },
			status: { ...e.aggregate.status },
			failures: { ...e.aggregate.failures }
		},
		elapsedTime: e.elapsedTime + t
	};
	if (uy(r.booster, J), uy(r.ship, q), r.booster.damage?.terminal.active || r.ship.damage?.terminal.active) return r.phase = "separated", r.stagingFailed = !0, r.booster = DC(r.booster.damage?.terminal.active ? r.booster : e.booster, t, n.booster ?? OC, J), r.ship = DC(r.ship.damage?.terminal.active ? r.ship : e.ship, t, n.ship ?? OC, q), r;
	r.booster.damage && Np(r.booster.damage, X(J).debris, t), r.ship.damage && Np(r.ship.damage, X(q).debris, t);
	let i = tw(e.booster, e.ship);
	hy(r.booster, t, J, rw), hy(r.ship, t, q, iw);
	let a = tw(r.booster, r.ship), o = r.aggregate.kinematics, s = a.centreStation - i.centreStation;
	yC(o, a.centreX - i.centreX, s, o);
	let c = r.booster.vehicle.vehicleMass, l = r.ship.vehicle.vehicleMass, u = rw.bodyAccelerationX * c, d = rw.bodyAccelerationY * c, f = iw.bodyAccelerationX * l, p = iw.bodyAccelerationY * l, m = (u + f) / a.mass, h = (d + p) / a.mass, g = gy(r.aggregate, t, m, h, sw);
	vy(r.aggregate, t, g, aw), lw(r, a), _y(r.booster, t, rw), _y(r.ship, t, iw), _v(r.booster, J, rw.massProperties), _v(r.ship, q, iw.massProperties);
	let _ = yy(r.booster, J, rw) * rw.massProperties.momentOfInertia, v = yy(r.ship, q, iw) * iw.massProperties.momentOfInertia, y = Math.sin(o.pitch), b = Math.cos(o.pitch), x = (a.boosterStation - a.centreStation) * (b * u - y * d) - (a.boosterX - a.centreX) * (y * u + b * d), S = (a.shipStation - a.centreStation) * (b * f - y * p) - (a.shipX - a.centreX) * (y * f + b * p);
	if (by(r.aggregate, t, g, aw.omega0, aw.alpha0, (_ + v + x + S) / a.inertia), lw(r, a), vC(e.booster, r.booster, t, n.booster ?? OC, J, ow, rw, !1), vC(e.ship, r.ship, t, n.ship ?? OC, q, ow, iw, !1), r.ship.damage?.terminal.active || r.booster.damage?.terminal.active) return r.phase = "separated", r.stagingFailed = !0, r;
	let C = tw(r.booster, r.ship);
	if ((C.centreX !== a.centreX || C.centreStation !== a.centreStation) && yC(o, C.centreX - a.centreX, C.centreStation - a.centreStation, o), n.stage && !r.stageRequested && uw(r), r.stageRequested) {
		(r.ship.engines.failed.every(Boolean) || lu.some((e) => r.booster.engines.failed[e]) || r.ship.failures.inFlightBreakUp || r.booster.failures.inFlightBreakUp) && (r.stagingFailed = !0);
		let e = (y * f + b * p) / l, t = (y * u + b * d) / c;
		!r.stagingFailed && r.ship.forces.thrust > 0 && lu.every((e) => r.booster.engines.running[e]) && e > t && (r.phase = "separated");
	}
	return r;
}
//#endregion
//#region src/app/mission-loop.ts
function fw(e) {
	return IC(e);
}
function pw(e, t, n = {}) {
	return RC(e, t, n, n.input ?? QC, dw);
}
//#endregion
//#region src/app/controls.ts
function mw(e, t, n = q) {
	switch (n.id === "super-heavy" && Bb(e.autopilot), t.type) {
		case "engineGroup": {
			if (n.id !== "super-heavy") return;
			let r = du[t.group], i = r.some((t) => e.engines.running[t] || e.engines.ignitionCountdown[t] !== null);
			for (let t of r) {
				let n = e.engines.running[t] || e.engines.ignitionCountdown[t] !== null;
				(i ? n : !e.engines.failed[t]) && qb(e, t);
			}
			return;
		}
		case "raptor":
			qb(e, t.engine);
			return;
		case "allRaptors":
			Jb(e, n);
			return;
		case "throttle":
			$b(e, t.percent);
			return;
		case "pitch":
			ex(e, t.percent);
			return;
		case "yokeGrab":
			tx(e);
			return;
		case "yokeRelease":
			nx(e);
			return;
		case "autoMaxThrust":
			ax(e);
			return;
		case "autoTakeOff":
			ox(e);
			return;
		case "boostBack":
			sx(e);
			return;
		case "pitchHold":
			ix(e);
			return;
		case "autoLand":
			cx(e);
			return;
		case "autoDeorbit":
			lx(e);
			return;
		case "fins":
			Yb(e);
			return;
		case "rcs":
			Xb(e);
			return;
		case "dumpFuel":
			Zb(e);
			return;
		default: throw Error(`unhandled control event: ${JSON.stringify(t)}`);
	}
}
//#endregion
//#region src/ui/session/mission-controller.ts
function hw() {
	let e = LC(ZC()), t = q, n, r = !1, i, a, o = {};
	function s(e) {
		return t.id === "ship" ? e.ship : e.booster;
	}
	function c(t = !1) {
		n && (e.state = s(n.state), e.previous = s(n.previous), e.accumulator = n.accumulator, e.totalSteps = n.totalSteps + +!!t, e.simulatedTime = n.state.elapsedTime);
	}
	let l = {
		input: o,
		onStep: () => {
			c(!0), i?.(e.state);
		}
	}, u = (e, n, r) => AC(e, n, r, t), d = {};
	function f(t) {
		e.state = t, e.previous = t, e.accumulator = 0, e.totalSteps = 0, e.simulatedTime = 0, r = !1, a = void 0;
	}
	return {
		loop: e,
		get model() {
			return t;
		},
		get mission() {
			return n?.state;
		},
		get previousMission() {
			return n?.previous;
		},
		get stagePending() {
			return r;
		},
		startFlight(e) {
			let r = YC(e);
			n = void 0, t = r.vehicle, f(r.state);
		},
		startHotStage(e = ux) {
			n = fw(nw(e)), t = q, f(n.state.ship);
		},
		selectVehicle(e) {
			n && (t = e === "ship" ? q : J, c());
		},
		emit(r) {
			(t.id !== "super-heavy" || r.type !== "autoDeorbit") && (n?.state.phase !== "attached" || r.type !== "autoLand" && r.type !== "boostBack" && r.type !== "autoDeorbit" && r.type !== "autoTakeOff" && r.type !== "autoMaxThrust" && r.type !== "pitchHold") && mw(e.state, r, t);
		},
		stage() {
			n?.state.phase === "attached" && (r = !0);
		},
		advance(s, f = d) {
			if (!n) return RC(e, s, f, f.input ?? OC, u);
			a !== f && (a = f, i = f.onStep, l.timeWarp = f.timeWarp ?? 1, l.slowMotion = f.slowMotion ?? 1, l.paused = f.paused ?? !1), o.stage = r, o.ship = t.id === "ship" ? f.input ?? OC : OC, o.booster = t.id === "super-heavy" ? f.input ?? OC : OC;
			let p = pw(n, s, l);
			return p.steps > 0 && (r = !1), c(), p;
		}
	};
}
//#endregion
//#region src/ui/session/camera-follow.ts
function gw() {
	let e = !0, t = !1, n = {
		width: 0,
		height: 0,
		physicalWidth: 0,
		physicalHeight: 0,
		scale: 0
	}, r = {
		left: 0,
		right: 0,
		bottom: 0,
		top: 0
	}, i = { ...r }, a = { ...r }, o = {
		downRangeDistance: 0,
		altitude: 0,
		speedX: 0,
		speedY: 0,
		landed: !1,
		onTheGround: !1,
		crashed: !1,
		dynamicPressure: 0,
		thrustAcceleration: 0
	}, s = {
		reducedMotion: typeof matchMedia == "function" && matchMedia("(prefers-reduced-motion: reduce)").matches,
		mode: "follow",
		padX: K
	};
	function c(e, n) {
		o.downRangeDistance = e.kinematics.downRangeDistance, o.altitude = e.kinematics.altitude, o.speedX = e.kinematics.speedX, o.speedY = e.kinematics.speedY, o.landed = e.status.landed && e.status.onTheGround, o.onTheGround = e.status.onTheGround, o.crashed = e.failures.crashed, o.dynamicPressure = e.forces.dynamicPressure, o.thrustAcceleration = e.forces.thrustAcceleration, t = !1;
		let r = e.damage;
		if (!r?.terminal.active) return;
		let i = X(n), s = 0, c = 0, l = 0, u = 0, d = 0, f = !0;
		a.left = a.bottom = Infinity, a.right = a.top = -Infinity;
		for (let e = 0; e < r.debris.length; e++) {
			let t = r.debris[e];
			if (!t.active) continue;
			let n = i.partition.components[e].mass, o = i.debris.pieces[e].supportRadius;
			s += n, c += n * t.x, l += n * t.altitude, u += n * t.speedX, d += n * t.speedY, a.left = Math.min(a.left, t.x - o), a.right = Math.max(a.right, t.x + o), a.bottom = Math.min(a.bottom, t.altitude - o), a.top = Math.max(a.top, t.altitude + o), f = f && t.altitude <= o && t.speedX === 0 && t.speedY === 0;
		}
		s > 0 && (t = !0, o.downRangeDistance = c / s, o.altitude = l / s, o.speedX = u / s, o.speedY = d / s, o.landed = o.onTheGround = f, o.crashed = !1, o.dynamicPressure = o.thrustAcceleration = 0);
	}
	function l(e) {
		if (s.mode !== "follow") return;
		let t = Math.max(o.downRangeDistance - a.left, a.right - o.downRangeDistance), n = Math.max(o.altitude - a.bottom, a.top - o.altitude);
		a.left = o.downRangeDistance - t, a.right = o.downRangeDistance + t, a.bottom = o.altitude - n, a.top = o.altitude + n, f(e, 0, 1);
	}
	function u(e) {
		let t = e.viewport, n = e.camera, r = t.physicalWidth * .45, i = t.physicalHeight * .45, o = a.right - r, s = a.left + r, c = a.top - i, l = a.bottom + i;
		o <= s && (n.posX = Math.max(o, Math.min(s, n.posX))), c <= l && (n.posY = Math.max(t.physicalHeight / 2, c, Math.min(l, n.posY)));
	}
	function d(e, t, n, r) {
		let i = (Math.abs(Math.sin(t.pitch)) * n + Math.abs(Math.cos(t.pitch)) * r) / 2, a = (Math.abs(Math.cos(t.pitch)) * n + Math.abs(Math.sin(t.pitch)) * r) / 2;
		e.left = t.downRangeDistance - i, e.right = t.downRangeDistance + i, e.bottom = t.altitude - a, e.top = t.altitude + a;
	}
	function f(e, t = 0, r = 1) {
		let i = e.viewport, o = Math.max(t, (a.top - a.bottom) / .7, (a.right - a.left) / .7 * i.height / i.width), s = o + (Math.max(i.physicalHeight, o) - o) * r;
		n.width = i.width, n.height = i.height, n.physicalHeight = s, n.physicalWidth = s * i.width / i.height, n.scale = i.height / s, e.viewport = n;
	}
	function p(e, t, n) {
		if (n.id !== "super-heavy") return;
		d(a, t.kinematics, n.height, 17);
		let r = t.status.landed && !t.status.onTheGround;
		r && (a.left = Math.min(a.left, K), a.right = Math.max(a.right, K), a.bottom = Math.min(a.bottom, 0)), f(e, r ? 2 * Math.max(0, t.kinematics.altitude) : 0);
	}
	function m(t, n) {
		let s = n.ship.kinematics, c = n.booster.kinematics, l = Math.hypot(s.downRangeDistance - c.downRangeDistance, s.altitude - c.altitude), u = q.height + J.height;
		if (l > u) {
			e = !1;
			return;
		}
		d(r, s, q.height, q.diameter), d(i, c, J.height, 17), a.left = Math.min(r.left, i.left), a.right = Math.max(r.right, i.right), a.bottom = Math.min(r.bottom, i.bottom), a.top = Math.max(r.top, i.top);
		let p = Math.max(0, Math.min(1, (l - u / 2) / (u / 2))), m = p * p * (3 - 2 * p), h = (a.left + a.right) / 2, g = (a.bottom + a.top) / 2;
		o.downRangeDistance = h + (o.downRangeDistance - h) * m, o.altitude = g + (o.altitude - g) * m, o.speedX = (s.speedX + c.speedX) / 2 + (o.speedX - (s.speedX + c.speedX) / 2) * m, o.speedY = (s.speedY + c.speedY) / 2 + (o.speedY - (s.speedY + c.speedY) / 2) * m, f(t, 0, m);
	}
	function h(e) {
		let t = e.camera;
		t.posX = o.downRangeDistance, t.posY = Math.max(e.viewport.physicalHeight / 2, o.altitude), t.speedX = o.speedX, t.speedY = o.speedY, t.accX = 0, t.accY = 0, t.shakeX = 0, t.shakeY = 0, t.padHeld = !1;
	}
	function g(e, t) {
		let n = e.viewport, r = e.camera;
		d(a, t.kinematics, q.height, Bg);
		let i = .5 / n.scale, o = a.right - n.physicalWidth / 2 + i - r.shakeX, s = a.left + n.physicalWidth / 2 - i - r.shakeX, c = a.top - n.physicalHeight / 2 + i - r.shakeY, l = a.bottom + n.physicalHeight / 2 - i - r.shakeY;
		o <= s && (r.posX = Math.max(o, Math.min(s, r.posX))), c <= l && (r.posY = Math.max(n.physicalHeight / 2, c, Math.min(l, r.posY)));
	}
	return {
		reset(n, r, i, a = q) {
			e = !0, c(r, a), n.followAltitude(o.altitude), t ? l(n) : (p(n, r, a), i && m(n, i)), h(n);
		},
		select(n, r, i = q) {
			e = !1, c(r, i), n.followAltitude(o.altitude), t ? l(n) : p(n, r, i), h(n);
		},
		step(n, r, i, a = q) {
			c(r, a), n.followAltitude(o.altitude), t ? (e = !1, l(n)) : (p(n, r, a), i && e && m(n, i)), Kl(n.camera, o, n.viewport, PC, s), t && s.mode === "follow" && u(n), !t && !i && a.id === q.id && s.mode === "follow" && !r.autopilot.demoAutoLandOn && !r.failures.crashed && g(n, r);
		},
		setMode(e) {
			s.mode = e;
		}
	};
}
//#endregion
//#region src/app/debug.ts
function _w(e, t = "", n = {}) {
	if (typeof e == "number" || typeof e == "boolean") n[t] = e;
	else if (Array.isArray(e)) e.forEach((e, r) => _w(e, `${t}[${r}]`, n));
	else if (typeof e == "object" && e) for (let [r, i] of Object.entries(e)) _w(i, t ? `${t}.${r}` : r, n);
	return n;
}
//#endregion
//#region docs/research/2026-10-04-cloud-resume/render-kernel-texture-repair-entry.ts
async function vw(e) {
	if (e !== 32 && e !== 1) throw Error("Exactly declared baseline32 or candidate1");
	let t = document.querySelector("[data-testid=\"world-canvas\"]");
	if (!(t instanceof HTMLCanvasElement)) throw Error("Owned actual world canvas required");
	let n = hw(), r = qC("launch-pad");
	n.startFlight(r);
	let i = n.loop.state, a = await Yl({
		canvas: t,
		vehicleHeight: 50,
		downRangeDistance: i.kinematics.downRangeDistance,
		speedY: i.kinematics.speedY,
		width: 1280,
		height: 720,
		preference: "webgl"
	});
	a.app.stop();
	try {
		let o = window.__programAttribution.result();
		if (o.totalDrawCalls !== 0 || o.programs.some((e) => e.links.some((e) => e.linkedShaders.some((e) => e.source?.includes("uniform sampler2D uTextures["))))) throw Error("Draw/batch shader existed before policy selection");
		if (a.app.renderer.type !== O.WEBGL) throw Error("Actual WebGL required; no backend fallback");
		let s = a.app.renderer, c = s.gl, l = c.getExtension("WEBGL_debug_renderer_info");
		if (!l) throw Error("Actual unmasked renderer unavailable; no diagnostic guess");
		let u = c.getParameter(l.UNMASKED_RENDERER_WEBGL), d = c.getParameter(c.MAX_TEXTURE_IMAGE_UNITS);
		if (typeof u != "string" || !/\bSwiftShader\b/i.test(u) || d !== 32 || s.limits.maxBatchableTextures !== 32) throw Error("Exact actual SwiftShader/hardware32/baseline batch32 required");
		if (c.getContextAttributes()?.antialias !== !0 || s.resolution !== 1 || devicePixelRatio !== 1 || t.width !== 1280 || t.height !== 720 || c.drawingBufferWidth !== 1280 || c.drawingBufferHeight !== 720 || a.viewport.width !== 1280 || a.viewport.height !== 720) throw Error("Declared AA/DPR/resolution/backing/viewport changed");
		s.limits.maxBatchableTextures = e;
		let f = gw();
		f.reset(a, i, n.mission, n.model);
		let p = await b_(a, () => !1);
		if (!p) throw Error("Owned scene unexpectedly disposed");
		let m = !1, h = !1, g = 0, _ = { onStep: (e) => f.step(a, e, n.mission, n.model) };
		function v() {
			let e = 0;
			function t(n) {
				if (++e > 12e3) throw Error("Public display witness cap exceeded");
				let r = Tc(n), i = n.label === "particles" ? n.children.filter((e) => e.visible) : n.children;
				return {
					label: n.label,
					visible: n.visible,
					renderable: n.renderable,
					position: {
						x: n.position.x,
						y: n.position.y
					},
					scale: {
						x: n.scale.x,
						y: n.scale.y
					},
					pivot: {
						x: n.pivot.x,
						y: n.pivot.y
					},
					skew: {
						x: n.skew.x,
						y: n.skew.y
					},
					...r,
					rotation: n.rotation,
					alpha: n.alpha,
					tint: n.tint,
					blendMode: n.blendMode,
					omittedInvisibleChildren: n.children.length - i.length,
					children: i.map(t)
				};
			}
			return {
				graph: t(a.app.stage),
				inspectedNodes: e,
				omittedPrivateParticleState: [
					"vx/vy",
					"raw ages/lifetimes",
					"birth counters",
					"PRNG cursors",
					"free/live slot arrays"
				],
				coverage: "All public display nodes, all visible particle sprite transforms/colors/textures plus pool hidden-count and original public aggregate inspection; private emitter arrays are not exposed or reconstructed"
			};
		}
		let y = () => ({
			state: structuredClone(n.loop.state),
			previous: structuredClone(n.loop.previous),
			telemetry: _w(n.loop.state),
			accumulator: n.loop.accumulator,
			totalSteps: n.loop.totalSteps,
			simulatedTime: n.loop.simulatedTime,
			modelId: n.model.id,
			mission: n.mission ?? null,
			camera: structuredClone(a.camera),
			viewport: { ...a.viewport },
			presentation: p.presentation(),
			display: v(),
			rendererPolicy: {
				hardwareMaximum: d,
				originalBatchBound: 32,
				selectedBatchBound: s.limits.maxBatchableTextures,
				observedRenderer: u,
				antialias: c.getContextAttributes()?.antialias,
				resolution: s.resolution,
				dpr: devicePixelRatio,
				backingWidth: t.width,
				backingHeight: t.height,
				drawingBufferWidth: c.drawingBufferWidth,
				drawingBufferHeight: c.drawingBufferHeight
			},
			startupWitness: {
				noDrawsBeforePolicy: o.totalDrawCalls === 0,
				noLinkedBatchShaderBeforePolicy: !0
			},
			renderCount: g,
			physicsFrozen: h
		});
		return {
			async condition() {
				if (h || m) throw Error("Exactly one deterministic conditioning recipe");
				n.emit({ type: "autoTakeOff" });
				for (let e = 0; e < 360; e++) n.advance(PC, _);
				let e = [];
				for (let t = 0; t < 3; t++) {
					let t = n.advance(.25, _);
					if (t.simulatedDt !== .25 || t.steps !== 30) throw Error("Declared deterministic0.25/30-step input changed");
					p.draw(n.loop.state, n.loop.previous, .25, r, n), a.app.render(), c.finish(), g++, e.push({
						advance: t,
						snapshot: y()
					});
				}
				return h = !0, {
					recipe: {
						rawFixedSteps: 360,
						fixedDt: PC,
						positiveConditioningDraws: 3,
						conditioningSimulatedDt: .25,
						actualController: !0,
						actualCameraPerStep: !0,
						actualSceneEmitUpdate: !0,
						wallClockReplacement: !1
					},
					steps: e,
					frozen: y()
				};
			},
			draw() {
				if (!h || m) throw Error("Kernel must be positively conditioned and live");
				p.draw(n.loop.state, n.loop.previous, 0, r, n), a.app.render(), g++;
			},
			snapshot: y,
			destroy() {
				m || (m = !0, p.destroy(), a.destroy());
			}
		};
	} catch (e) {
		throw a.destroy(), e;
	}
}
//#endregion
export { PC as DT, gw as createCameraFollow, vw as createKernel, hw as createMissionController, b_ as createScene, Yl as createView };

//# sourceMappingURL=kernel.js.map